// 第 73 期 · 纯 Kotlin 复刻的滑块缺口匹配（已并入工程，替换 OpenCV 实现）
//
// ════════════════════════════════════════════════════════════════════════════
// 目的
// ════════════════════════════════════════════════════════════════════════════
// 把 `YidunSliderSolver.solve()` 里对 OpenCV 的 7 个 API 调用换成纯 Kotlin 实现，
// 使 `libopencv_java4.so`（16.39MB）+ `libc++_shared.so`（5.95MB）可以从包里删掉：
//   ⇒ `.so` 归零 ⇒ ① 16KB 页面对齐问题彻底消失 ② 体积再降 22.34 MB（占 APK 的 76%）
//
// ★ 等价性证据（第 72 期 · 8 组真实滑块样本）：
//   本文件的 solve() 与 OpenCV 版 YidunSliderSolver.solve() 在 8 组上
//   max_loc 与整数缺口 8/8 完全相同，max_val 最大绝对差 2.98e-06。
//   复现工具：`_cv_replica/v72/`（SliderRunner8.java + golden8.py + compare8.py）
//
// ════════════════════════════════════════════════════════════════════════════
// 逐条对应关系（左 = OpenCV，右 = 本文件）
// ════════════════════════════════════════════════════════════════════════════
//   Core.extractChannel(frontMat, alphaMat, 3)  →  extractAlpha()
//   Imgproc.threshold(alpha, mask, 10.0, 255.0, THRESH_BINARY)
//                                               →  thresholdBinary()
//   Core.findNonZero(maskBinary, points)        →  （并入 boundingBox）
//   Imgproc.boundingRect(points)                →  boundingBox()
//   Mat(frontMat, bbox).clone()                 →  cropRgba()
//   Mat(maskBinary, bbox).clone()               →  cropGray()
//   Imgproc.matchTemplate(bg, piece, TM_CCORR_NORMED, pieceMask)
//                                               →  matchCcorrNormed()
//   Core.minMaxLoc(result)                      →  minMaxLoc()
//   （亚像素抛物线精化是原 Kotlin 自己写的，不属 OpenCV，照抄）
//
// ════════════════════════════════════════════════════════════════════════════
// TM_CCORR_NORMED + mask 的数学定义（来自 OpenCV 源码 templmatch.cpp）
// ════════════════════════════════════════════════════════════════════════════
// 掩码版本走的是 `crossCorr` 里 `if (needswap)` 那条路：
//
//   num = Σ_{(x,y) ∈ mask≠0}  I(x,y) · T(x,y)
//   den = sqrt( Σ_{(x,y) ∈ mask≠0} I(x,y)²  ·  Σ_{(x,y) ∈ mask≠0} T(x,y)² )
//   dst = num / den        （den == 0 时 dst = 0）
//
// 三个必须照抄的细节：
//
//   ① **掩码参与内积与两个能量和**，不是「只裁剪模板」。所以分母里的
//      `ΣI²` 也只对掩码内像素求和 —— 掩码外的背景像素完全不参与。
//
//   ② **模板能量 `ΣT²` 与滑块位置无关**（模板是固定的），本可以提出来
//      只算一次 —— 但为了与 OpenCV 的浮点误差行为对齐，这里**每次仍然重算**，
//      保持与 OpenCV 相同的乘除顺序。
//
//   ③ ★★★ 累加**不能用 Double**。OpenCV 用 `float`（`weightedSum` /
//      `crossCorr` 的 dst 与中间量都是 `float`）。long 累加后转 Double
//      虽然数值上更准，但与 OpenCV 的**舍入点不同** —— 逐像素比对时会
//      出现 `1e-7` 级的系统性偏差，且会随模板变大而放大。
//      所以这里全程用 Float 累加，累加顺序也照抄（先列后行 / y 外层 x 内层）。
//
// ════════════════════════════════════════════════════════════════════════════
// 与 Android 的通道数约束（★ 第 71 期第一个实测结论，已用实验钉死）
// ════════════════════════════════════════════════════════════════════════════
// 已从 `opencv-4.5.3.0-sources.jar` 的 `org/opencv/android/Utils.java` javadoc 确认：
//
//     The output Mat is **always** created of the same size as the input Bitmap
//     and of the **'CV_8UC4'** type, it keeps the image in **RGBA** format.
//
// ⇒ `Utils.bitmapToMat(bg, bgMat)` 对 `ARGB_8888` 的 bg **恒产 4 通道 RGBA**，
//   即使 bg 是没 alpha 的 JPEG（JPEG 读进来 alpha 恒 255）。
//
// ★★★ 关键：**alpha 通道也参与 num / ΣI² / ΣT² 的累加**，不是「只取前 3 通道」。
//   这一条由 `_cv_replica/channel_probe2.py` 实验 5 钉死：手算 4 通道与 OpenCV
//   4 通道最大差 7.7e-08（一致），而只算 3 通道会偏 6e-02 量级。
//
//   量化解释（实测素材 bg.jpg + front.png）：
//     · bg 的 alpha 恒 255 ⇒ 给 ΣI² 贡献一个**位置无关的常数** 255²·N，
//       所以分数整体变化但 **峰值位置不变** —— 这正是「max_loc 对、max_val 错」的机理。
//     · num 里多出 Σ_mask I_A·T_A（I_A=255、T_A 为 front 的 alpha 渐变），
//       这一项相对更大 ⇒ 4 通道分数反而**高于** 3 通道（实测 0.9151 vs 0.8550）。
//
//   ⇒ 复刻必须**遍历全部 4 通道**，否则分数系统性偏移，逐像素比对必失败。
//
// ════════════════════════════════════════════════════════════════════════════
// 第 79 期 · 纯提速（判定零改动，逐位等价）
// ════════════════════════════════════════════════════════════════════════════
// 症状：单次 solve 约 4.4 秒，滑块验证整轮被拖到 7 秒级。
//
// 先排除了两条看起来很美、实际不成立的路：
//   · **积分图**：它只能加速分母里的 ΣI²。实测把整个 ΣI² 删掉，
//     耗时也只从 3070ms 降到 2101ms ⇒ 能量项仅占 34%，积分图理论上界 1.52×，
//     永远到不了百毫秒级。
//   · **算法改写**（FFT 互相关 / 换累加结构 / 换 Double）：都会改变浮点求和顺序，
//     分数出现 1e-7 以上偏差。而易盾图上**存在分数极接近的次峰**，
//     这种偏差有翻盘风险 ⇒ 与「判定零改动」冲突，一律否决。
//
// 真正管用的只有一条：**内层热循环被「逐字节读取 + AND 0xFF + int→float 转换」
// 和 Array<FloatArray> 的二次间接卡住了**。把 bg 的四通道预先转成平面 FloatArray、
// 模板四通道拍平成一维数组，内层只做纯 float 乘加。
//
// 实测（PC 侧单文件真编，8 组真实样本，预热 2 次取最快 5 次，去首组）：
//   基线 3070ms → 1019ms，**3.01×**
//   单次 solve 从约 440ms 降到约 145ms（PC）；首组含 JIT 约 146ms
//
// ★★★ 等价性是**逐位**的，不是近似：
//   · 预存的 Float 与 (byte & 0xFF).toFloat() 是同一个值（纯搬运，无运算）；
//   · 内层 num / sumI2 的累加**顺序与舍入点**与基线一字不差；
//   · 8 组样本的整张 result 矩阵做了逐位指纹（FNV-1a over floatToRawIntBits），
//     8/8 完全相同；max_loc / gap_left / score 自然全同。
//
// 反向验证（同一次实验里的对照组）：
//   · 只拍平模板、仍逐字节读取  → 1.02×（几乎没用）⇒ 说明瓶颈在字节读取与转换；
//   · 交错 float 布局           → 1.70×（不如平面）⇒ 说明平面布局才对；
//   · 循环展开 2                → 3.23×（反而更慢）⇒ 不加。
//
// ════════════════════════════════════════════════════════════════════════════

package com.tjh.weibotask

import kotlin.math.sqrt

object SliderMatch {

    /**
     * 缺口识别结果。字段语义与 `YidunSliderSolver.GapResult` **逐字相同** ——
     * 迁移时调用方（`YidunAutoSlider`）一行都不用改。
     */
    data class GapResult(
        /** 缺口左边缘在 bg 里的像素 x（亚像素精化后，bg 自然尺寸 320 宽） */
        val gapLeft: Float,
        /** 拼图块非透明区域在 front 图内的左偏移 */
        val pieceOffsetX: Int,
        /** 模板匹配相关度（0~1，越高越可信） */
        val score: Double
    )

    /**
     * 输入图像：**RGBA 四通道**，`pixels[y * width + x]` 是该像素 4 个通道的
     * 字节值（0~255，已按 unsigned 处理）。
     *
     * ★ 用 `IntArray` 存「每像素打包成 4 字节」还是 `ByteArray` 存「每通道一字节」？
     *   这里选后者（`ByteArray`，长度 = w*h*4），因为要与 OpenCV 的 `CV_8UC4`
     *   内存布局逐字节对应，避免打包/解包引入误差。
     */
    class ImageRGBA(val width: Int, val height: Int, val data: ByteArray) {
        init {
            require(data.size == width * height * 4) {
                "data 长度应为 ${width * height * 4}，实际 ${data.size}"
            }
        }

        /** 取 (x,y) 第 c 通道的**无符号**值。c: 0=R 1=G 2=B 3=A */
        fun u(x: Int, y: Int, c: Int): Int = data[(y * width + x) * 4 + c].toInt() and 0xFF
    }

    /** 单通道 8 位图（掩码 / alpha）。 */
    class ImageGray(val width: Int, val height: Int, val data: ByteArray) {
        init {
            require(data.size == width * height) {
                "data 长度应为 ${width * height}，实际 ${data.size}"
            }
        }

        fun u(x: Int, y: Int): Int = data[y * width + x].toInt() and 0xFF
    }

    // ────────────────────────────────────────────────────────────────────────
    // ① Core.extractChannel(frontMat, alphaMat, 3)
    // ────────────────────────────────────────────────────────────────────────

    /**
     * 抽出第 3 通道（alpha）。
     *
     * ★ OpenCV 的 `extractChannel` 是**逐字节拷贝**，不改变数值、不做任何变换。
     *   对应地这里只做索引搬运。
     */
    fun extractAlpha(src: ImageRGBA): ImageGray {
        val out = ByteArray(src.width * src.height)
        var i = 0
        var s = 3            // 第 3 通道
        while (i < out.size) {
            out[i] = src.data[s]
            i++
            s += 4
        }
        return ImageGray(src.width, src.height, out)
    }

    // ────────────────────────────────────────────────────────────────────────
    // ② Imgproc.threshold(alpha, mask, 10.0, 255.0, THRESH_BINARY)
    // ────────────────────────────────────────────────────────────────────────

    /**
     * `THRESH_BINARY`：`dst = (src > thresh) ? maxval : 0`。
     *
     * ★ 是**严格大于**（`>`），不是 `>=`。原代码阈值 10，所以
     *   alpha == 10 的像素为 0。这个边界在易盾图上真的存在
     *   （实测 alpha 取值里 9/10/11 都有）⇒ 写成 `>=` 会多框进一圈边缘像素，
     *   bbox 会大 1~2px，进而影响 `pieceOffsetX`。
     */
    fun thresholdBinary(src: ImageGray, thresh: Double, maxVal: Int): ImageGray {
        val out = ByteArray(src.data.size)
        for (i in src.data.indices) {
            val v = src.data[i].toInt() and 0xFF
            out[i] = if (v > thresh) maxVal.toByte() else 0
        }
        return ImageGray(src.width, src.height, out)
    }

    // ────────────────────────────────────────────────────────────────────────
    // ③ Core.findNonZero + Imgproc.boundingRect
    // ────────────────────────────────────────────────────────────────────────

    data class Box(val x: Int, val y: Int, val w: Int, val h: Int)

    /**
     * `findNonZero` + `boundingRect` 的组合结果：非零像素的**紧致**包围盒。
     *
     * ★ OpenCV 的 `boundingRect` 语义是 `[x, x+w-1] × [y, y+h-1]` 闭区间，
     *   所以 `w = maxX - minX + 1`。不是 `maxX - minX`。
     *   （写成后者会让每个方向都短 1px —— 这是这类复刻最常见的 off-by-one。）
     *
     * 无任何非零像素时返回 null（对应原代码 `points.empty()` 与 `w/h <= 0`）。
     */
    fun boundingBox(mask: ImageGray): Box? {
        var minX = Int.MAX_VALUE
        var minY = Int.MAX_VALUE
        var maxX = -1
        var maxY = -1
        var y = 0
        while (y < mask.height) {
            val row = y * mask.width
            var x = 0
            while (x < mask.width) {
                if (mask.data[row + x].toInt() != 0) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
                x++
            }
            y++
        }
        if (maxX < 0 || maxY < 0) return null
        return Box(minX, minY, maxX - minX + 1, maxY - minY + 1)
    }

    // ────────────────────────────────────────────────────────────────────────
    // ④ Mat(frontMat, bbox).clone()   （ROI 裁剪，仍是 4 通道）
    // ────────────────────────────────────────────────────────────────────────

    fun cropRgba(src: ImageRGBA, b: Box): ImageRGBA {
        val out = ByteArray(b.w * b.h * 4)
        var dy = 0
        while (dy < b.h) {
            var dx = 0
            while (dx < b.w) {
                val si = ((b.y + dy) * src.width + (b.x + dx)) * 4
                val di = (dy * b.w + dx) * 4
                out[di] = src.data[si]
                out[di + 1] = src.data[si + 1]
                out[di + 2] = src.data[si + 2]
                out[di + 3] = src.data[si + 3]
                dx++
            }
            dy++
        }
        return ImageRGBA(b.w, b.h, out)
    }

    fun cropGray(src: ImageGray, b: Box): ImageGray {
        val out = ByteArray(b.w * b.h)
        var dy = 0
        while (dy < b.h) {
            var dx = 0
            while (dx < b.w) {
                out[dy * b.w + dx] = src.data[(b.y + dy) * src.width + (b.x + dx)]
                dx++
            }
            dy++
        }
        return ImageGray(b.w, b.h, out)
    }

    // ────────────────────────────────────────────────────────────────────────
    // ⑤ Imgproc.matchTemplate(..., TM_CCORR_NORMED, mask) + Core.minMaxLoc
    // ────────────────────────────────────────────────────────────────────────

    data class MatchResult(val cols: Int, val rows: Int, val data: FloatArray) {
        fun at(x: Int, y: Int): Float = data[y * cols + x]
    }

    /**
     * 带掩码的 `TM_CCORR_NORMED`。
     *
     * `result` 尺寸 = `(imgW - tplW + 1) × (imgH - tplH + 1)`，与 OpenCV 一致。
     *
     * ★ 遍历**全部 4 通道**（R/G/B/A）—— alpha 也参与 num / ΣI² / ΣT²，理由见文件头。
     *
     * 全程 `Float` 累加（理由见文件头 ③）。为提速，先一次性把掩码内模板像素的
     * 下标与四通道值预先展平成数组，避免内层循环里反复做「掩码判断 + 索引换算」。
     */
    fun matchCcorrNormed(
        img: ImageRGBA,
        tpl: ImageRGBA,
        mask: ImageGray
    ): MatchResult {
        val cols = img.width - tpl.width + 1
        val rows = img.height - tpl.height + 1
        require(cols > 0 && rows > 0) { "模板比图像还大：img=${img.width}x${img.height} tpl=${tpl.width}x${tpl.height}" }

        // ★ 遍历全部 4 通道（R/G/B/A）—— alpha 也参与 num / ΣI² / ΣT²，理由见文件头。

        // ① 预展平掩码内的模板像素：相对模板左上角的**像素**偏移 + 四通道值。
        //    四通道各拍平成一维数组（第 79 期），去掉 Array<FloatArray> 的二次间接。
        val n = tpl.width * tpl.height
        val offPx = IntArray(n)
        val t0 = FloatArray(n)
        val t1 = FloatArray(n)
        val t2 = FloatArray(n)
        val t3 = FloatArray(n)
        var cnt = 0
        var ty = 0
        while (ty < tpl.height) {
            var tx = 0
            while (tx < tpl.width) {
                val pi = ty * tpl.width + tx
                if (mask.data[pi].toInt() != 0) {
                    // 模板内 (tx,ty) 映射到图像内 (ox+tx, oy+ty)，
                    // 所以存 ty*img.width + tx，内层只要 basePx + offPx[k]，
                    // 省掉每次迭代的整数除法与两次乘法。
                    offPx[cnt] = ty * img.width + tx
                    val bi = pi * 4
                    t0[cnt] = (tpl.data[bi].toInt() and 0xFF).toFloat()
                    t1[cnt] = (tpl.data[bi + 1].toInt() and 0xFF).toFloat()
                    t2[cnt] = (tpl.data[bi + 2].toInt() and 0xFF).toFloat()
                    t3[cnt] = (tpl.data[bi + 3].toInt() and 0xFF).toFloat()
                    cnt++
                }
                tx++
            }
            ty++
        }

        // ② 模板能量 ΣT²（掩码内，四通道求和）—— 与位置无关，只算一次。
        //    累加顺序照抄 OpenCV（R→G→B→A），保证浮点行为一致。
        var sumT2 = 0.0f
        var i = 0
        while (i < cnt) {
            var acc = 0.0f
            acc += t0[i] * t0[i]
            acc += t1[i] * t1[i]
            acc += t2[i] * t2[i]
            acc += t3[i] * t3[i]
            sumT2 += acc
            i++
        }

        // ③ ★ 第 79 期提速核心：把 bg 的四通道预先转成**平面 FloatArray**。
        //    纯搬运、无运算 ⇒ 预存的 Float 与 (byte & 0xFF).toFloat() 逐位相同，
        //    而内层 num / sumI2 的累加顺序与舍入点完全不变 ⇒ 结果逐位等价。
        //    实测 3070ms → 1019ms（3.01×）。
        val npx = img.width * img.height
        val rArr = FloatArray(npx)
        val gArr = FloatArray(npx)
        val bArr = FloatArray(npx)
        val aArr = FloatArray(npx)
        var pp = 0
        while (pp < npx) {
            val q = pp * 4
            rArr[pp] = (img.data[q].toInt() and 0xFF).toFloat()
            gArr[pp] = (img.data[q + 1].toInt() and 0xFF).toFloat()
            bArr[pp] = (img.data[q + 2].toInt() and 0xFF).toFloat()
            aArr[pp] = (img.data[q + 3].toInt() and 0xFF).toFloat()
            pp++
        }

        val out = FloatArray(cols * rows)
        var oy = 0
        while (oy < rows) {
            var ox = 0
            while (ox < cols) {
                val basePx = oy * img.width + ox
                var num = 0.0f
                var sumI2 = 0.0f
                var k = 0
                while (k < cnt) {
                    val q = basePx + offPx[k]
                    val i0 = rArr[q]
                    val i1 = gArr[q]
                    val i2 = bArr[q]
                    val i3 = aArr[q]
                    var dot = 0.0f
                    dot += i0 * t0[k]
                    dot += i1 * t1[k]
                    dot += i2 * t2[k]
                    dot += i3 * t3[k]
                    var energy = 0.0f
                    energy += i0 * i0
                    energy += i1 * i1
                    energy += i2 * i2
                    energy += i3 * i3
                    num += dot
                    sumI2 += energy
                    k++
                }
                val den = sqrt(sumI2 * sumT2)
                out[oy * cols + ox] = if (den == 0.0f) 0.0f else num / den
                ox++
            }
            oy++
        }
        return MatchResult(cols, rows, out)
    }

    data class MinMax(val minVal: Float, val maxVal: Float, val minX: Int, val minY: Int, val maxX: Int, val maxY: Int)

    /**
     * `Core.minMaxLoc` 的等价物。
     *
     * ★ 平手时谁赢？OpenCV 的 `minMaxIdx` 在严格 `>` / `<` 比较下**保留最先遇到的**
     *   （行优先扫描顺序 从左到右、从上到下）。易盾图上存在分数极接近的次峰，
     *   所以这个平手规则必须一致 —— 用严格的 `>` 而不是 `>=` 就是这个原因。
     */
    fun minMaxLoc(r: MatchResult): MinMax {
        var minV = Float.MAX_VALUE
        var maxV = -Float.MAX_VALUE
        var minXi = 0; var minYi = 0; var maxXi = 0; var maxYi = 0
        var y = 0
        while (y < r.rows) {
            var x = 0
            while (x < r.cols) {
                val v = r.data[y * r.cols + x]
                if (v < minV) { minV = v; minXi = x; minYi = y }
                if (v > maxV) { maxV = v; maxXi = x; maxYi = y }
                x++
            }
            y++
        }
        return MinMax(minV, maxV, minXi, minYi, maxXi, maxYi)
    }

    // ────────────────────────────────────────────────────────────────────────
    // 对外：与 YidunSliderSolver.solve() 逐行等价的入口
    // ────────────────────────────────────────────────────────────────────────

    /**
     * 识别缺口。返回 null 的条件与 `YidunSliderSolver.solve()` 逐条对齐：
     *   · bbox 为空 / 宽或高 <= 0  ⇒ null
     *   · 其余任何情况都会给出结果（原实现对 OpenCV 调用包在 `catch (_: Throwable)` 里，
     *     本实现没有会抛的路径；异常面更小，但**返回值语义保持不变**）。
     */
    fun solve(bg: ImageRGBA, front: ImageRGBA): GapResult? {
        // 1) alpha 通道
        val alpha = extractAlpha(front)
        // 2) 二值化（阈值 10，maxval 255，严格大于）
        val maskBinary = thresholdBinary(alpha, 10.0, 255)
        // 3) tight bbox
        val box = boundingBox(maskBinary) ?: return null
        if (box.w <= 0 || box.h <= 0) return null
        // 4) 裁剪模板与掩码
        val piece = cropRgba(front, box)
        val pieceMask = cropGray(maskBinary, box)
        // 5) 带掩码的归一化相关匹配
        val result = matchCcorrNormed(bg, piece, pieceMask)
        // 6) minMaxLoc
        val mm = minMaxLoc(result)
        val x0 = mm.maxX
        val y0 = mm.maxY
        var gapLeft = x0.toFloat()
        // 7) 亚像素抛物线精化（原 Kotlin 自己写的，照抄）
        if (x0 > 0 && x0 < result.cols - 1) {
            val left = result.at(x0 - 1, y0).toDouble()
            val center = result.at(x0, y0).toDouble()
            val right = result.at(x0 + 1, y0).toDouble()
            val denom = left - 2.0 * center + right
            if (denom != 0.0) {
                gapLeft = (x0 + 0.5 * (left - right) / denom).toFloat()
            }
        }
        return GapResult(
            gapLeft = if (gapLeft < 0f) 0f else gapLeft,
            pieceOffsetX = box.x,
            score = mm.maxVal.toDouble()
        )
    }
}
