package com.tjh.weibotask

/**
 * ★★★★ 第 113 期：发帖失败的**结构化原因**。
 *
 * 用户原话（2026-10-14）：
 *   「『状态 失败』太笼统了 —— 要能看出失败原因、发生时间、重试次数。」
 *
 * ★★★ 先说清楚根因（这一点很重要，别搞反了）：
 *   **数据层其实一直是好的**。`Prefs.postLastMessage` 里存的从来都是
 *   **微博返回的原文**（第 86 期的代码注释原话：「绝不能把它简化成『发帖失败』四个字」），
 *   `Prefs.postLastRunAt` 存着发生时间。
 *   真正的问题是 **`MainActivity.renderPostTaskCard()` 只印了 `postLastStatus` 一个状态码**，
 *   把那两样早就存好的东西晾在一边没显示出来。
 *   ⇒ 所以本期**纯 UI 可解，`Prefs` 一个键都不动、一个写入时机都不改**。
 *
 * ★ 分类器的纪律（与全项目一致）：
 *   1. **判据认结构、不认文案** —— 优先看状态码，其次才看关键词；
 *   2. 关键词**匹配不上就回落 [UNKNOWN]**，**绝不假装知道原因**；
 *   3. 微博回包的中文常是 `\uXXXX` 转义 ⇒ 必须**先反转义再匹配**（见 [PostFailure.unescape]），
 *      否则中文关键词会**静默失效**（这是本项目反复踩过的坑）。
 */
enum class FailureReason(val labelRes: Int) {
    /** 账号未登录 / 登录态失效 */
    NOT_LOGGED_IN(R.string.post_fail_not_logged_in),

    /** 操作频繁、被限流（微博最常见的软拒绝） */
    RATE_LIMITED(R.string.post_fail_rate_limited),

    /** 内容命中敏感词 */
    SENSITIVE_WORD(R.string.post_fail_sensitive),

    /** 超话侧限制：未关注 / 等级不够 / 不允许发 */
    TOPIC_LIMIT(R.string.post_fail_topic_limit),

    /** 网络超时 */
    NETWORK_TIMEOUT(R.string.post_fail_timeout),

    /** 配置不完整（没超话 / 没正文）—— 这一条是**状态码直判**，不靠关键词 */
    CONFIG_MISSING(R.string.post_fail_config),

    /** 认不出来 —— 照实说，不编 */
    UNKNOWN(R.string.post_fail_unknown)
}

object PostFailure {

    /**
     * 关键词表：`原因 → 关键词列表`。
     *
     * ★★ **顺序有意义**，先判最具体的。比如一条回包同时含「超话」和「频繁」时，
     *   应该判成「操作频繁」（那是真正要等一等的原因），所以 [RATE_LIMITED] 排在
     *   [TOPIC_LIMIT] 前面。
     * ★ 关键词一律**小写**比较（原文先 `lowercase()`），中文不受影响，
     *   英文（`timeout` 等）才能稳定命中。
     * ★ 带上了几个**微博错误码**：`100006`（未登录/缺 st 的最外层拒绝）、
     *   `20016`（操作频繁）、`20017`（内容违规）。
     */
    private val RULES: List<Pair<FailureReason, List<String>>> = listOf(
        FailureReason.NOT_LOGGED_IN to listOf(
            "100006", "21332", "未登录", "登录已过期", "登录失效", "重新登录"
        ),
        FailureReason.RATE_LIMITED to listOf(
            "20016", "100013", "操作频繁", "频繁", "太快", "稍后再试", "稍后重试", "操作过于"
        ),
        FailureReason.SENSITIVE_WORD to listOf(
            "20017", "敏感", "违规", "含非法", "内容不合法", "被屏蔽"
        ),
        FailureReason.NETWORK_TIMEOUT to listOf(
            "超时", "timeout", "timed out", "socket", "网络"
        ),
        FailureReason.TOPIC_LIMIT to listOf(
            "超话", "未关注", "等级", "权限", "不允许发", "没有权限"
        )
    )

    /**
     * 从「状态码 + 微博原文」里判一个原因出来。
     *
     * @param status      `Prefs.postLastStatus`（结构状态码，权威判据）
     * @param rawMessage  `Prefs.postLastMessage`（微博返回原文，可能多行）
     */
    fun classify(status: String, rawMessage: String): FailureReason {
        // ① 状态码直判：这几条不需要猜
        if (status == "CONFIG_MISSING") return FailureReason.CONFIG_MISSING

        // ② 原文关键词判：先反转义，再小写比较
        val text = unescape(rawMessage).lowercase()
        if (text.isBlank()) return FailureReason.UNKNOWN
        for ((reason, keys) in RULES) {
            if (keys.any { text.contains(it) }) return reason
        }

        // ③ 认不出来就照实说
        return FailureReason.UNKNOWN
    }

    /**
     * 把微博回包里的 `\uXXXX` 反转义回中文。
     *
     * ★★ 为什么必须有这一步：微博的 JSON 里中文经常是 `\u64cd\u4f5c\u9891\u7e41`
     *   这种形式。直接拿 `contains("操作频繁")` 去比对会**永远不命中**，
     *   而且**不会报错** —— 是最难发现的一类静默失效。
     *
     * ★ 只处理标准的 4 位 `\uXXXX`；反斜杠本身用 `\\` 转义的（`\\u`）这里不特殊处理，
     *   因为微博回包里不会出现。解析不出十六进制时**原样保留**，绝不吞字符。
     */
    fun unescape(s: String): String {
        if (!s.contains("\\u")) return s
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            if (s[i] == '\\' && i + 6 <= s.length && s[i + 1] == 'u') {
                val code = s.substring(i + 2, i + 6).toIntOrNull(16)
                if (code != null) {
                    sb.append(code.toChar())
                    i += 6
                    continue
                }
            }
            sb.append(s[i])
            i++
        }
        return sb.toString()
    }
}
