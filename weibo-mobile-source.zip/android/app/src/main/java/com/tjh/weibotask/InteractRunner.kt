package com.tjh.weibotask

import android.content.Context

/**
 * 互动任务的执行器。
 *
 * ★★ 本文件分三层，越往下越「真」：
 *
 *   ① [localCheck] —— 纯本地检查：目标填没填、类型对不对、账号能不能动、语料有没有。
 *                     不联网、不改任何计数。
 *   ② [rehearse]   —— 真预演：本地检查**之外**，再联网把目标核对成一条具体的微博。
 *                     ★ 只用 GET ⇒ **不消耗 POST 额度**。
 *   ③ [send]       —— 真发送。★ **默认关闭**（[sendEnabled] = false）。
 *
 * ★★ 为什么 ③ 还关着（第 46 期暂停的原因，留着省得以后重复问）：
 *   真实的发送动作要落到微博的接口上，而接口的**入参名、鉴权票据、错误码**
 *   必须用真机抓包才能定死 —— 星签的 Cookie 存在 App 私有的加密存储里，
 *   PC 端读不出来；直接拿公开文档里的参数名猜着写，只会写出一份
 *   「看着像、跑起来全是 403 / 100006」的代码，然后拿用户的账号去试错。
 *   ⇒ 第 46 期阶段 1 做的就是去抓一条真实请求；抓到之后这里是一道**填空题**。
 *
 * ★★ 为什么 ② 要真的联网（第 44 期的教训）：
 *   第 43/44 期的「干跑」只检查「填没填」，于是用户填了一个用户主页链接
 *   （`weibo.com/u/6986999782`）它也打印「以上检查全部通过」—— **那是骗人**：
 *   它根本没问过微博那条帖子在不在。现在会真的去问。
 *
 * ★★ 边界：不碰 [Prefs]、不写 [AccountStore]、不走 [WeiboClient]。
 *   整个文件删掉，签到 / 发帖 / 验证的行为不会有任何变化。
 *
 * ★ 第 56 期起它会调 [InteractTaskStore.markRun] —— 那是**互动功能自己的**存储
 *   （`interact_tasks.xml`），写的是 [InteractTask] 的字段，与账号数据无关。
 *   上面那条边界（Prefs / AccountStore / WeiboClient）一个字都没松。
 *
 * ★ [rehearse] / [send] 会**阻塞**（同步网络请求），调用方**必须**放后台线程。
 */
object InteractRunner {

    /**
     * ★★★★ 真发送的总开关。**默认 false。**
     *
     * 在抓包拿到「确定能通的请求头」之前，一次都不许真发 ——
     * 每一次真发都是在拿用户的账号去赌参数对不对。
     * 抓包确认之后 **把这里改成 true 即可**（改这一行，别处都不用动）。
     */
    @Volatile
    var sendEnabled = false

    /** 本地检查的结果。 */
    private class LocalCheck(
        val lines: MutableList<String>,
        val ok: Boolean,
        /** 选好的语料；本地检查没过就是空串。 */
        val content: String
    )

    // ---------------------------------------------------------------- ① 本地检查

    /**
     * 不联网的那部分检查。
     *
     * ★★ 先把目标**分类**再说别的（第 44 期）：
     *   「评论」要的是**某一条微博**，而「用户主页」要先去拉他最新那条 ——
     *   两者要做的事完全不同，必须先说清楚，不能一句「检查通过」糊过去。
     *
     * ★★★★ 第 59 期：参数从「账号的 label 字符串」换成**整个 [WeiboAccount]**。
     *   原因是同一个账号有**两个名字**，而且必须分开用：
     *     · [WeiboAccount.label]     —— 内部序号（`syncOrderLabels` 统一写成「账号 N」）。
     *                                   它是**键**：[RateGuard.verdict] / [RateGuard.markRun]
     *                                   按它记账，`interact_tasks.xml` 里存的也是它。
     *     · [WeiboAccount.displayName] —— **给人看的名字**（有昵称就是昵称）。
     *   原来这一行把 label 直接印给用户看，于是「发送结果」里写着「账号：账号 1」，
     *   用户根本认不出是哪个号 —— 而上面刚在新建任务的下拉框里改成了显示昵称，
     *   两处对不上，反而更像坏了。
     *   ⇒ **键继续用 label，只有印出来的那几处换成 displayName。**
     *   ★ 只改显示：`RateGuard` 的键、空值判据一个字都没动。
     */
    private fun localCheck(context: Context, task: InteractTask, account: WeiboAccount?): LocalCheck {
        val lines = mutableListOf<String>()

        // 键（记账 / 判空用）—— 必须是 label
        val label = account?.label.orEmpty()
        // 给人看的名字 —— displayName 内部已经带了「昵称为空就退回 label」的兜底
        val shown = account?.displayName.orEmpty()

        val kind = InteractTarget.kind(task.target)
        lines.add(context.getString(R.string.interact_dry_action, context.getString(task.action.labelRes)))
        lines.add(context.getString(R.string.interact_dry_target, task.target.ifBlank { "—" }))
        lines.add(context.getString(R.string.interact_dry_target_kind, context.getString(kind.labelRes)))
        lines.add(context.getString(R.string.interact_dry_account, shown.ifBlank { "—" }))

        // ① 任务本身
        if (!task.enabled) {
            lines.add(context.getString(R.string.interact_dry_disabled))
            return LocalCheck(lines, false, "")
        }
        // ★★★★ 第 66 期：**第 55 期那道闸撤了** —— 「互评 / 楼赞」现在真能发了。
        //
        //    第 55 期拦它的理由（「选互评实际会发出一条全新的顶层评论」）**已经在物理上消失**：
        //      · 互评走 `POST /api/comments/reply`，请求体里带父评论 `cid`；
        //      · 楼赞走 `POST /api/likes/update`，体是 `{id: <楼层 id>, type: "comment"}`；
        //      · 两条路径都由**回包结构**判成败（回复看 `rootid == cid`，
        //        楼赞看重拉列表的 `liked`），不再可能悄悄变成顶层评论。
        //    ★ 但「回哪一层」需要一条**真实存在的评论** —— 那要联网才知道，
        //      所以这项检查搬到了 [rehearse] / [send] 里（仍然只读）。
        //    ★ 纯本地判断，不联网、不写任何状态。
        // ② 目标
        when (kind) {
            TargetKind.NONE -> {
                lines.add(context.getString(R.string.interact_dry_no_target))
                return LocalCheck(lines, false, "")
            }
            TargetKind.UNKNOWN -> {
                lines.add(context.getString(R.string.interact_dry_target_unknown))
                return LocalCheck(lines, false, "")
            }
            TargetKind.PROFILE -> lines.add(context.getString(R.string.interact_dry_profile_note))
            TargetKind.POST -> lines.add(context.getString(R.string.interact_dry_post_note))
            // ★★★★ 第 68 期：超话 —— 也是「先去拿一条微博」，只是来源不同。
            //   干跑这里只加一句说明（**纯本地、不联网**）；真正去拉帖子列表的是
            //   [InteractProbe.resolveTarget]（预演/发送时才会走到）。
            TargetKind.SUPERTOPIC -> lines.add(context.getString(R.string.interact_dry_supertopic_note))
        }
        // ③ 账号 —— ★ 判空看的是**键**（label），不是给人看的那个名字
        if (label.isBlank()) {
            lines.add(context.getString(R.string.interact_dry_no_account))
            return LocalCheck(lines, false, "")
        }
        // ④ 频率保护 —— ★ 查额度必须用**键**（label），换了键等于把额度记到别人头上
        val verdict = RateGuard.verdict(label)
        if (verdict.state == GuardState.RESTING) {
            lines.add(
                context.getString(
                    R.string.interact_dry_resting,
                    shown,
                    InteractFormat.until(verdict.until)
                )
            )
            return LocalCheck(lines, false, "")
        }
        // ⑤ 语料 —— ★ 第 66 期：楼赞**不发任何文字**，不该因为语料库空就被拦住。
        //    （只发一个赞，请求体里根本没有 content 这一栏 —— 见 InteractProbe.likeForm）
        if (task.action == InteractAction.LIKE) {
            return LocalCheck(lines, true, "")
        }
        val content = if (task.groupId.isBlank()) CommentLib.pickFirst() else CommentLib.pick(task.groupId)
        if (content.isNullOrBlank()) {
            lines.add(context.getString(R.string.interact_dry_no_content))
            return LocalCheck(lines, false, "")
        }
        lines.add(context.getString(R.string.interact_dry_content, content))
        return LocalCheck(lines, true, content)
    }

    // ---------------------------------------------------------------- ② 真预演

    /**
     * 真预演：本地检查 + **联网把目标核对成一条具体的微博**。
     *
     * ★ 与旧「干跑」的区别：旧版只会说「目标填了、类型对」，
     *   然后打印「以上检查全部通过」—— 用户根本不知道那条微博**在不在**。
     *   现在会真的去问微博：这条存在吗？是主页的话，他最新一条是哪条？
     *
     * ★ **只用 GET**，不消耗 POST 额度；
     *   也**不调** [RateGuard.markRun] ⇒ 用户可以反复点，不会把额度试没。
     *
     * ★ 会阻塞，必须在后台线程调用。
     */
    fun rehearse(context: Context, task: InteractTask, account: WeiboAccount?): String {
        val check = localCheck(context, task, account)
        val lines = check.lines

        if (!check.ok) return finish("[预演]", lines)

        if (account == null || account.cookie.isBlank()) {
            lines.add(context.getString(R.string.interact_rehearse_no_cookie))
            return finish("[预演]", lines)
        }

        // ⑥ 联网核对目标 —— 只发 GET
        val target = InteractProbe.resolveTarget(context, account, task.target)
        lines.add(context.getString(R.string.interact_rehearse_target, target.detail))
        when (target.state) {
            InteractProbe.TargetState.EXISTS -> {
                lines.add(context.getString(R.string.interact_rehearse_mid, target.mid))
                // ⑦ ★★★★ 第 66 期：互评 / 楼赞还要先定下「动哪一层」——
                //   只读 GET 一次评论列表，把会动的那层楼**明确写出来**给用户看。
                //   ★ 为什么必须在预演里就说清楚：这两个动作是**公开可见**的，
                //     用户点「预演」就是为了先看清「它到底会碰谁」。
                //   ★ 挑不出评论就**不下结论**（连「可以发」都不说）。
                if (task.action != InteractAction.COMMENT) {
                    val comments = InteractProbe.listComments(context, account, target.mid)
                    if (comments.isEmpty()) {
                        lines.add(context.getString(R.string.interact_dry_no_comment))
                        return finish("[预演]", lines)
                    }
                    val ownUid = InteractProbe.ownUid(account)
                    // ★★★★ 挑法与 [doCommentAction] 里的**必须同源**（含楼赞的「剔掉已赞」），
                    //   否则会出现「预演说会赞 A 楼、真发却赞了 B 楼」——
                    //   用户点预演就是为了先看清它到底会碰谁。
                    val picked = pickComment(comments, ownUid, task.action == InteractAction.LIKE)
                    lines.add(
                        context.getString(
                            R.string.interact_rehearse_pick,
                            picked?.user.orEmpty(),
                            picked?.id.orEmpty(),
                            picked?.text.orEmpty()
                        )
                    )
                    if (ownUid.isNotBlank() && picked?.uid == ownUid) {
                        lines.add(context.getString(R.string.interact_rehearse_pick_own))
                    }
                }
                // ⑧ 到这一步，除了「真的发出去」以外的每一步都已经确认过了
                lines.add(context.getString(R.string.interact_dry_send_stub))
                lines.add(context.getString(R.string.interact_dry_ok))
            }
            // ★ UNKNOWN 与 NOT_EXISTS 一样不许往下走 ——
            //   第 46 期被 `ok:0` 骗开过一次闸门（报错的回包同样也是 `ok:0`）
            InteractProbe.TargetState.NOT_EXISTS ->
                lines.add(context.getString(R.string.interact_rehearse_stop))
            InteractProbe.TargetState.UNKNOWN ->
                lines.add(context.getString(R.string.interact_rehearse_unsure))
        }
        return finish("[预演]", lines)
    }

    // ---------------------------------------------------------------- ③ 真发送

    /**
     * 真正的发送。
     *
     * ★★ 目前**默认不真发**（[sendEnabled] = false）—— 抓包确认接口之前不发。
     *   把它做成「静默失败」是最坏的选择：用户会以为发出去了。
     *
     * ★ 会阻塞，必须在后台线程调用。
     */
    fun send(context: Context, task: InteractTask, account: WeiboAccount?): String {
        // ★ 第 59 期：这个 `label` 是**记账用的键**（[RateGuard]），日志里也用它 ——
        //   它跟 `interact_tasks.xml` 里存的 `accountLabel` 是同一个东西，
        //   出问题时靠它对得上号。**给人看的名字**在 [localCheck] 里用 displayName，两者刻意分开。
        val label = account?.label.orEmpty()
        InteractTrace.log("[发送] 动作=" + task.action.name + " 账号=" + label + " 目标=" + task.target)

        if (!sendEnabled) {
            InteractTrace.log("[发送] 未启用（sendEnabled=false）：本次没有发出任何请求")
            return context.getString(R.string.interact_send_not_ready)
        }

        val check = localCheck(context, task, account)
        if (!check.ok) return finish("[发送]", check.lines)
        val lines = check.lines

        if (account == null || account.cookie.isBlank()) {
            lines.add(context.getString(R.string.interact_rehearse_no_cookie))
            return finish("[发送]", lines)
        }

        // ★★ 发送前**再核一次**目标（联网 GET）。
        //    第 46 期的教训：闸门只看本地填了什么，会把「不存在」和「接口报错」混成一件事。
        val target = InteractProbe.resolveTarget(context, account, task.target)
        lines.add(context.getString(R.string.interact_rehearse_target, target.detail))
        if (target.state != InteractProbe.TargetState.EXISTS) {
            // ★ UNKNOWN 与 NOT_EXISTS 一样中止 —— 宁可不发，也不发到不确定的地方
            InteractTrace.log("[发送] 中止：目标状态=" + target.state + " mid=" + target.mid)
            lines.add(context.getString(R.string.interact_send_aborted))
            return finish("[发送]", lines)
        }

        // ★★ 第 52 期：doPost 接上了，返回值从「靠字符串前缀约定」换成**结构化的结果** ——
        //    成功与否由**回包**决定，界面文案也就不必再带一个 OK 前缀。
        // ★★★★ 第 66 期：改成**按动作分派** —— 三种动作走三条不同的接口：
        //    · 评论 → `POST /api/comments/create`（第 52 期就接好了）
        //    · 互评 → `POST /api/comments/reply`（体里带父评论 cid）
        //    · 楼赞 → `POST /api/likes/update`（体 `{id: 楼层id, type: "comment"}`）
        val outcome = when (task.action) {
            InteractAction.COMMENT -> doPost(context, account, target.mid, check.content)
            else -> doCommentAction(context, account, task, target.mid, check.content)
        }
        // ★ 只有真的发出去了才记账 —— 失败不消耗额度，否则用户会越试越少
        if (outcome.ok) {
            RateGuard.markRun(label)
            InteractTrace.log("[发送] 已记账：账号=" + label)
        }
        // ★★★★ 第 56 期：把「上次执行」写回任务。
        //    走到这一行 = **真的打过一次发送接口**（不管成功失败），所以两种情况都记：
        //    失败也要能在任务行上看见，否则用户只知道「刚才弹了个框」，
        //    回头再问「到底发没发出去」就无从查起。
        //    ★ 记的是**互动任务自己**的字段（`interact_tasks.xml`），
        //      与账号上的 `lastRunAt`（签到链路）是两个东西 —— 见 InteractTaskStore.markRun。
        InteractTaskStore.markRun(task.id, outcome.detail)
        lines.add(outcome.detail)
        return finish("[发送]", lines)
    }

    /**
     * ★★★★ 第 52 期：**这道填空题填上了**。
     *
     * 第 46 期阶段 1 抓到的真实请求（回包 ok:1）已经把入参定死；
     * 第 51 期又查清了「能看不能发」的根因（陈旧的 XSRF-TOKEN 遮住了服务器新下发的值）。
     * 两件事合起来，这里就从「明确地空着」变成「按规格实现」。
     *
     * 请求规格（第 51 期真机抓包，详见当轮报告 §9）：
     *   · POST https://m.weibo.cn/api/comments/create
     *   · 体：content / mid / st / _spr
     *     ★ 构造点**只有一处** —— InteractProbe 里的 commentForm，
     *       自检与真发共用 ⇒ 「自检跑通了」= 「真发的请求体没问题」。
     *   · 头：X-XSRF-TOKEN 必须等于**现取的** st（绝不能用账号 Cookie 里那份陈旧的）
     *   · 成功判据：回包 ok:1 且带新评论 id。★ 不看界面提示。
     *
     * ★★ 但它**依然发不出去** —— [sendEnabled] 还是 false，
     *   [send] 在调用本函数之前就返回了。这一段是「随时可以开」的准备工作。
     */
    private fun doPost(
        context: Context,
        account: WeiboAccount,
        mid: String,
        content: String
    ): InteractProbe.SendOutcome {
        InteractTrace.log(
            "[发送] 真发送：URL=" + InteractProbe.SEND_URL +
                " 目标微博 mid=" + mid + " 正文长度=" + content.length
        )
        val outcome = InteractProbe.postComment(context, account, mid, content)
        InteractTrace.log("[发送] 结果：" + outcome.detail)
        return outcome
    }

    /**
     * ★★★★ 第 66 期：从评论列表里**挑一层楼**。
     *
     * ★ 挑法（第 66 期的默认，界面上会写出来）：
     *   ① 楼赞时**先剔掉已经赞过的** —— `api/likes/update` 是「点赞」而不是开关，
     *      对已赞的楼再打一次只会白耗一次额度，还会让自检误报「成功」
     *      （重拉列表看到 liked=true 就报成功，其实那一下什么都没做）；
     *   ② 剩下的里优先挑**别人的**评论 —— 自己回复自己看起来最假；
     *   ③ 整页都是自己的，就退回挑第一条（并在界面上注明），
     *      而不是直接中止 —— 否则「自己给自己盖楼」这种正常用法会被一刀切掉。
     * ★ 纯函数、只读：不联网、不写任何状态。
     * ★ 返回 null = **没有可动的楼层**，调用方必须**一个请求都不发**。
     */
    private fun pickComment(
        comments: List<InteractProbe.CommentBrief>,
        ownUid: String,
        skipLiked: Boolean
    ): InteractProbe.CommentBrief? {
        val pool = if (skipLiked) comments.filter { !it.liked } else comments
        if (pool.isEmpty()) return null
        val others = pool.firstOrNull { ownUid.isBlank() || it.uid != ownUid }
        return others ?: pool.first()
    }

    /**
     * ★★★★ 第 66 期：**互评 / 楼赞**的执行。
     *
     * 先只读挑一层楼，再发**那一次**写请求：
     *   ① 评论列表里必须有评论 —— 挑不出来就**不发**（绝不瞎发）；
     *   ② 楼赞先剔掉已经赞过的；剩下的里优先挑别人的楼（见 [pickComment]）；
     *   ③ 每种动作**只发一次**，绝不重试（[InteractProbe] 的写请求本身也不重试）。
     *
     * ★★ 楼赞的成败**只认重拉列表的 `liked`**（见 [InteractProbe.postLikeComment]）——
     *   回包 `ok:1` 不算数：第 65 期就是被它坑的（那一下赞其实记到了微博上）。
     *
     * ★ 会阻塞（挑楼层 1~2 次 GET + 1 次写 + 楼赞再多 1 次 GET），必须在后台线程调用。
     */
    private fun doCommentAction(
        context: Context,
        account: WeiboAccount,
        task: InteractTask,
        mid: String,
        content: String
    ): InteractProbe.SendOutcome {
        val comments = InteractProbe.listComments(context, account, mid)
        if (comments.isEmpty()) {
            InteractTrace.log("[发送] 中止：评论列表是空的，没有可以动的楼层")
            return InteractProbe.SendOutcome(
                false,
                context.getString(R.string.interact_dry_no_comment)
            )
        }
        val ownUid = InteractProbe.ownUid(account)
        // ★ 楼赞要剔掉已经赞过的（见 [pickComment] ①）—— 否则会白打一次写请求，
        //   而且自检看到 liked=true 还会报「成功」，其实那一下什么都没做。
        val skipLiked = task.action == InteractAction.LIKE
        val picked = pickComment(comments, ownUid, skipLiked)
        if (picked == null) {
            InteractTrace.log(
                "[发送] 中止：列表 " + comments.size + " 条里没有可动的楼层" +
                    "（只挑未赞=" + skipLiked + "，其中已赞 " +
                    comments.count { it.liked } + " 条）—— 一个请求都没发"
            )
            return InteractProbe.SendOutcome(
                false,
                context.getString(
                    if (skipLiked) R.string.interact_send_like_all_done
                    else R.string.interact_dry_no_comment
                )
            )
        }
        InteractTrace.log(
            "[发送] 挑中楼层 id=" + picked.id + " 作者=" + picked.user +
                " 自己的=" + (ownUid.isNotBlank() && picked.uid == ownUid) +
                " 已赞=" + picked.liked + " 赞数=" + picked.likeCount
        )
        return when (task.action) {
            InteractAction.REPLY -> InteractProbe.postReply(context, account, mid, picked.id, content)
            InteractAction.LIKE -> InteractProbe.postLikeComment(context, account, mid, picked.id)
            else -> InteractProbe.SendOutcome(
                false,
                context.getString(R.string.interact_dry_no_comment)
            )
        }
    }

    private fun finish(tag: String, lines: List<String>): String {
        for (line in lines) InteractTrace.log(tag + " " + line)
        return lines.joinToString("\n")
    }
}

/**
 * 时间格式化的小工具。
 *
 * ★ 为什么不放在 [InteractActivity] 里：预演和界面都要说「到几点几分恢复」，
 *   两处各写一份迟早会一个显示「3 分钟后」、另一个显示「15:42」，用户对不上。
 */
object InteractFormat {

    private val format = java.text.SimpleDateFormat("HH:mm", java.util.Locale.CHINA)

    /**
     * ★ 第 56 期：任务行「上次执行」用的时刻 —— 带日期。
     *
     * ★ 为什么这里**必须**带日期：互动任务是**隔天**才会再跑一次的东西，
     *   只写 `21:01` 的话，今天看到的和三天前看到的长得一模一样，
     *   用户会以为「刚发的」。（本项目已经吃过一次「日志没日期」的亏，
     *   见第 55 期把前一天的记录当成当天新发现那件事。）
     */
    private val stampFormat = java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.CHINA)

    /** 「到 15:42 恢复」里的那个时刻。 */
    fun until(at: Long): String = format.format(java.util.Date(at))

    /** 任务行上的「上次执行」时刻，形如 `10-03 21:01`。 */
    fun stamp(at: Long): String = stampFormat.format(java.util.Date(at))
}
