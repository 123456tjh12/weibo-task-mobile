package com.tjh.weibotask

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** 一条评语。 */
data class CommentLine(val id: String, val text: String)

/**
 * 一次导入的结果。
 *
 * ★ 为什么要把 `cleaned` 单独报出来：第 44 期实测发现，用户从微博 App
 *   「复制」一条评论再粘贴进来，末尾会带上 `[/cp]` 这个**复制标记**
 *   （微博自己加的，用来标记「这段文字是从本站复制的」）。
 *   原样发出去，等于主动告诉对方「这条是复制粘贴的」。
 *   清理是静默做掉的，但必须让用户知道**发生过**，否则他会以为程序乱改了内容。
 */
data class CommentImport(val added: Int, val cleaned: Int)

/**
 * 一个语料分组：一组可以互相替换的评语（例如「夸人」「提问」「催更」）。
 *
 * ★ `name` 必须是 `var`：分组是可以改名的（[CommentLib.renameGroup]）。
 *   `id` 和 `lines` 是 `val` —— 容器本身不换，只改里面的内容。
 */
data class CommentGroup(val id: String, var name: String, val lines: MutableList<CommentLine>)

/**
 * 互动功能的「评语库」。
 *
 * ★ 抄的是豆星人的 `pages-build-library` / `select_default_comment` / `add_content`
 *   那一套：**评语按分组存放，一次批量导入一整组，发的时候从组里随机取一条**。
 *   另外豆星人还有一个「评论后缀」—— 随机接在评语后面，让同一条评语每次看起来都不一样。
 *   这里两样都有。
 *
 * ★ 边界（与 [SliderTrace] 同一条纪律）：
 *   - **不碰 [Prefs]**：另开私有文件 `interact_lib`。
 *   - **不碰 [AccountStore]**、不碰 [WeiboClient]。
 *   - 纯数据，没有任何网络请求、没有任何判定被别处依赖。
 *     把它整个删掉，签到 / 发帖 / 验证的行为不会有任何变化。
 */
object CommentLib {

    private const val STORE_NAME = "interact_lib"
    private const val KEY_GROUPS = "groups"
    private const val KEY_SUFFIXES = "suffixes"

    /** 新建分组时如果用户没填名字，用这个。 */
    const val FALLBACK_GROUP_NAME = "未命名分组"

    // ------------------------------------------------------------ 内置默认语录
    //
    // ★★★★ 第 109 期（用户批准）：**内置「默认语录」并置顶**。
    //
    //   起因 = 第 109 期查明的「首评一条都发不出去」根因：
    //   「一键超Like」面板**没有语料分组选择器**（`SuperLikePlan.groupId` 恒为空串），
    //   取语料走 [pickFirst] —— **永远只看第一个分组**；第一个分组是空的，
    //   `SuperLikeRunner` 拿不到内容就当场 `break`，一个写请求都不发。
    //
    //   ⇒ 首启时把下面这 43 条播成一个**排在最前面**的分组，超Like 开箱即可跑首评。
    //
    //   ★ 只在**第一次**读盘时播种一次（[KEY_SEEDED]）：用户把它删了 / 清了 / 改了名，
    //     都**不会**自己长回来 —— 用户的意志优先，不做「删了又活」的僵尸数据。
    //   ★ 播种判据认**结构**（固定 id），不认名字 —— 用户随时可以把「默认语录」改名。

    /** 内置默认语录分组的**固定** id（用户改名也不影响播种判据）。 */
    const val DEFAULT_GROUP_ID = "default_quotes"

    /** 内置默认语录分组的名字（用户可改）。 */
    const val DEFAULT_GROUP_NAME = "默认语录"

    /** 「默认语录是否已播种过」的标记键。 */
    private const val KEY_SEEDED = "default_seeded"

    /**
     * 内置默认语录（43 条，用户 2026-10-13 提供）。
     *
     * ★ 顺序 = 用户给的顺序，**一个字都没改**（emoji / 特殊符号全部原样保留）。
     * ★ 已经是去重后的 43 条（用户贴了 60 行，其中 17 行是重复）。
     * ★ 取用仍然走 [pick] 的随机 + 后缀拼接，不因为「默认」就换一套规则。
     */
    private val DEFAULT_LINES = listOf(
        "张奕然 全肯定 全溺爱𓆩♡𓆪",
        "张奕然 全肯定🧡",
        "看一遍爱一遍 忍不住看好多遍！",
        "然猪 然猪 妈咪的小猪🐷",
        "欢迎收看张奕然随便一张都是头像系列",
        "然然 比今天的你更好看的只有明天的你🥰",
        "张奕然 看见你 除了窒息我没有什么要表演的！",
        "我有点花心 喜欢每一个你🧡",
        "张奕然 你怎么长成这样 完全符合我的想象",
        "今天是九宫格都装不下的好看呀",
        "张奕然不放弃我们就不放弃",
        "然然 期待下次见面🧡",
        "然然 彩带落下的瞬间 我许愿 下次见🧡",
        "我已被张奕然的神颜迷晕🧡",
        "张奕然 那一天你走进了我的生命🧡",
        "张奕然太帅了 惩罚自己看一百遍",
        "张奕然 这是不心动挑战吗 有点意思",
        "爱我的一只猪🧡",
        "然然 慢慢长大吧🧡",
        "然然 健康平安 幸福快乐 🧡",
        "张奕然 看见你这张脸就算幸福۶•͈⚇•͈♡",
        "大家帮我看看这个张奕然是好男孩吗",
        "张奕然 这么可爱 啥意思🥳",
        "张奕然冷脸萌的权威我后知后觉",
        "张奕然 在吗 出来挨夸！",
        "张奕然 请问这是什么宇宙级别的帅气🧡",
        "糟糕.ᐟ.ᐟ被张奕然可爱到了🧡",
        "依然幸福 幸福奕然🧡",
        "没有然后了 因为我有然然了",
        "幸福的秘密是domi🧡",
        "幸福奕然会准时降临🧡",
        "domi domi domi 🧡",
        "爱domi会多米！🧡",
        "四男一四女一四萌一四韩一🧡",
        "很难不爱张奕然🧡",
        "满分男孩 张然然！🧡",
        "然猪然猪 可爱的小猪",
        "张奕然是全世界最可爱的小朋友",
        "张奕然是全世界最棒的小朋友",
        "小猪小猪 可爱的小猪🐖",
        "我想用漂亮的话去夸你 但思来想去漂亮的只有你🧡",
        "看到张奕然的脸 我将会给全世界一个好脸色🧡",
        "此男已成神🧡🧡🧡🧡🧡"
    )

    /** 微博「复制」标记：`[/cp]`，也容忍 `[cp]` / 大小写 / 中间空格。 */
    private val COPY_MARK = Regex("""\[\s*/?\s*cp\s*]""", RegexOption.IGNORE_CASE)

    /** 零宽字符：从网页复制时经常夹带，肉眼不可见。 */
    private val ZERO_WIDTH = Regex("""[\u200B-\u200D\uFEFF\u2060]""")

    private val groups = mutableListOf<CommentGroup>()
    private val suffixes = mutableListOf<String>()
    private var store: SharedPreferences? = null
    private var loaded = false

    /** 读盘。**必须在用之前调用一次**；同一进程内重复调用无副作用。 */
    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        val sp = try {
            context.applicationContext.getSharedPreferences(STORE_NAME, Context.MODE_PRIVATE)
        } catch (_: Throwable) {
            null
        }
        store = sp
        groups.clear()
        suffixes.clear()
        try {
            val raw = sp?.getString(KEY_GROUPS, "").orEmpty()
            if (raw.isNotBlank()) {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val group = CommentGroup(
                        item.optString("id").ifBlank { UUID.randomUUID().toString() },
                        item.optString("name").ifBlank { FALLBACK_GROUP_NAME },
                        mutableListOf()
                    )
                    val lineArray = item.optJSONArray("lines")
                    if (lineArray != null) {
                        for (j in 0 until lineArray.length()) {
                            val line = lineArray.optJSONObject(j) ?: continue
                            val text = line.optString("text")
                            if (text.isNotBlank()) {
                                group.lines.add(
                                    CommentLine(
                                        line.optString("id").ifBlank { UUID.randomUUID().toString() },
                                        text
                                    )
                                )
                            }
                        }
                    }
                    groups.add(group)
                }
            }
            val suffixRaw = sp?.getString(KEY_SUFFIXES, "").orEmpty()
            if (suffixRaw.isNotBlank()) {
                val suffixArray = JSONArray(suffixRaw)
                for (i in 0 until suffixArray.length()) {
                    val s = suffixArray.optString(i)
                    if (s.isNotBlank()) suffixes.add(s)
                }
            }
        } catch (_: Throwable) {
            // 解析失败就当成空库，不能因为一份坏数据把整个互动页打不开。
            groups.clear()
            suffixes.clear()
        }
        loaded = true
        seedDefaultGroup(sp)
    }

    /**
     * ★★★★ 第 109 期：把内置默认语录播成**第一个**分组。**只播一次**。
     *
     * ★ 为什么必须排在最前面：超Like 面板没有分组选择器，取语料走 [pickFirst]
     *   （只看第一个分组）。排在后面等于没播。
     * ★ 为什么用 `groups.add(0, …)` 而不是先清空：用户已有的分组一条都不能动，
     *   只是往后挪一位（数据层不许因为一次升级就丢用户的东西）。
     * ★ 为什么播完还要写一个 [KEY_SEEDED] 标记：见常量处的注释 —— 不做僵尸数据。
     * ★ 任何异常都吞掉：播种失败最多是「超Like 没语料可用」，
     *   绝不能因为一份坏数据让整个互动页打不开（与 [init] 同一条纪律）。
     */
    private fun seedDefaultGroup(sp: SharedPreferences?) {
        if (sp == null) return
        if (sp.getBoolean(KEY_SEEDED, false)) return
        try {
            if (groups.none { it.id == DEFAULT_GROUP_ID }) {
                val group = CommentGroup(
                    DEFAULT_GROUP_ID,
                    DEFAULT_GROUP_NAME,
                    DEFAULT_LINES.map { CommentLine(UUID.randomUUID().toString(), it) }
                        .toMutableList()
                )
                groups.add(0, group)
                save()
            }
            sp.edit().putBoolean(KEY_SEEDED, true).apply()
        } catch (_: Throwable) {
            // 静默：播种不是关键路径。
        }
    }

    // ---------------------------------------------------------------- 分组

    /** 全部分组（按添加顺序）。 */
    @Synchronized
    fun groups(): List<CommentGroup> = groups.toList()

    @Synchronized
    fun findGroup(id: String): CommentGroup? = groups.firstOrNull { it.id == id }

    @Synchronized
    fun addGroup(name: String): CommentGroup {
        val group = CommentGroup(
            UUID.randomUUID().toString(),
            name.trim().ifBlank { FALLBACK_GROUP_NAME },
            mutableListOf()
        )
        groups.add(group)
        save()
        return group
    }

    @Synchronized
    fun removeGroup(id: String) {
        groups.removeAll { it.id == id }
        save()
    }

    @Synchronized
    fun renameGroup(id: String, name: String) {
        val group = groups.firstOrNull { it.id == id } ?: return
        group.name = name.trim().ifBlank { FALLBACK_GROUP_NAME }
        save()
    }

    // ---------------------------------------------------------------- 评语

    /**
     * 批量导入。一行一条；空行忽略；**组内重复的自动丢掉**（重复发同一条最容易撞风控）。
     *
     * ★ 导入前每条都过一遍 [sanitize]：去掉微博的复制标记与零宽字符。
     *
     * @return [CommentImport]：新增条数 + 被清理过内容的条数
     */
    @Synchronized
    fun addLines(groupId: String, raw: String): CommentImport {
        val group = groups.firstOrNull { it.id == groupId } ?: return CommentImport(0, 0)
        val existing = group.lines.map { it.text }.toMutableSet()
        var added = 0
        var cleaned = 0
        for (piece in raw.split("\n")) {
            val original = piece.replace("\r", "").trim()
            if (original.isBlank()) continue
            val text = sanitize(original)
            if (text.isBlank()) continue
            if (text != original) cleaned++
            if (!existing.add(text)) continue
            group.lines.add(CommentLine(UUID.randomUUID().toString(), text))
            added++
        }
        if (added > 0) save()
        return CommentImport(added, cleaned)
    }

    /**
     * 清掉「从微博复制」带进来的痕迹。
     *
     * 目前处理三类：
     *  1. `[/cp]` / `[cp]` —— 微博「复制」按钮加在末尾的标记。★ 这是实测踩到的，
     *     用户粘进来的第一条语料末尾就带着它。
     *  2. 零宽字符（U+200B~U+200D / U+FEFF / U+2060）—— 从网页复制常带，
     *     肉眼看不见，但会让两条「看起来一样」的评语判成不同，也会被风控当异常特征。
     *  3. 首尾空白。
     *
     * ★ 刻意**不动正文里的任何字**：用户写什么就发什么。
     *   这里只清「不是用户写的」那一部分。
     */
    fun sanitize(text: String): String {
        var value = text
        value = ZERO_WIDTH.replace(value, "")
        value = COPY_MARK.replace(value, "")
        return value.trim()
    }

    @Synchronized
    fun clearGroup(groupId: String) {
        val group = groups.firstOrNull { it.id == groupId } ?: return
        group.lines.clear()
        save()
    }

    @Synchronized
    fun totalLines(): Int = groups.sumOf { it.lines.size }

    @Synchronized
    fun groupCount(): Int = groups.size

    // ---------------------------------------------------------------- 后缀

    /** 全部后缀。 */
    @Synchronized
    fun suffixes(): List<String> = suffixes.toList()

    /** 加一个后缀；已存在或为空则返回 false。 */
    @Synchronized
    fun addSuffix(text: String): Boolean {
        val value = text.trim()
        if (value.isBlank()) return false
        if (suffixes.contains(value)) return false
        suffixes.add(value)
        save()
        return true
    }

    @Synchronized
    fun removeSuffix(text: String) {
        suffixes.remove(text)
        save()
    }

    @Synchronized
    fun suffixCount(): Int = suffixes.size

    // ---------------------------------------------------------------- 取用

    /**
     * 从分组里随机取一条**组装好的**评语（评语 + 随机后缀）。
     *
     * @return null 表示分组不存在或这个分组还没有评语
     */
    @Synchronized
    fun pick(groupId: String): String? {
        val group = groups.firstOrNull { it.id == groupId } ?: return null
        if (group.lines.isEmpty()) return null
        // ★ 取的时候**再过一遍** sanitize：第 43 期之前存进去的语料带着 `[/cp]`，
        //   不可能要求用户重新导入一遍才能用上这个修复。
        val base = sanitize(group.lines.random().text)
        if (base.isBlank()) return null
        if (suffixes.isEmpty()) return base
        return base + suffixes.random()
    }

    /**
     * 不指定分组时的兜底：用第一个分组。
     *
     * ★ 为什么不「所有分组混着取」：分组本身就是用户用来区分场景的
     *   （夸人 / 提问 / 催更），混着取等于把用户的分类意图抹掉。
     */
    @Synchronized
    fun pickFirst(): String? {
        val first = groups.firstOrNull() ?: return null
        return pick(first.id)
    }

    // ---------------------------------------------------------------- 落盘

    private fun save() {
        val sp = store ?: return
        try {
            val array = JSONArray()
            for (group in groups) {
                val item = JSONObject()
                item.put("id", group.id)
                item.put("name", group.name)
                val lineArray = JSONArray()
                for (line in group.lines) {
                    lineArray.put(JSONObject().put("id", line.id).put("text", line.text))
                }
                item.put("lines", lineArray)
                array.put(item)
            }
            val suffixArray = JSONArray()
            for (s in suffixes) suffixArray.put(s)
            sp.edit()
                .putString(KEY_GROUPS, array.toString())
                .putString(KEY_SUFFIXES, suffixArray.toString())
                .apply()
        } catch (_: Throwable) {
            // 写盘失败静默：数据层不能反过来把界面搞崩。
        }
    }
}
