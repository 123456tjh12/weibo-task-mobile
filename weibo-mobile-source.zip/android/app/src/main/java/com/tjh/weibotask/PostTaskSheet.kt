package com.tjh.weibotask

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * ============================================================================
 * ★★★★ 第 116 期：「创建超话发帖任务」弹窗（近全屏 BottomSheet）的**控制器**。
 *
 * ## 用户要的是什么
 *
 * 用户原话（2026-10-15）：
 *   「请帮我实现一个「创建超话发帖任务」的弹窗表单组件……」
 *   「把立即发一条试试这个按钮，换成创建任务，创建任务之后自动执行」
 *   「我想做的是，首先需要有默认发帖的内容，其次，客户可以自己添加内容发帖」
 *
 * ⇒ 主界面那个按钮（id 仍是 `testPostButton`）改成「创建任务」，
 *   点开就是本弹窗；表单填完**落盘成一条 [PostTask]**。
 *
 * ## ★★★ 本期边界：**只落盘，不执行**（用户拍板「分两期做」）
 *
 * [save] 的最后一步是 `PostTaskStore.save(task)` + 一句 toast + `dismiss()`。
 * 它**不会**调 `startPostRunFromUi()`、**不会**碰 `AgentService`、
 * **不会**写 [Prefs] —— 「保存后立即开始」的编排链路**下一期**接。
 * 所以表单上那三个开关（定时开始 / 限制运行时间段 / 保存后立即开始）
 * 本期**只存值**，没有任何执行侧读取点。这是刻意的，不是漏了。
 *
 * ## ★ 与四条核心链路的关系
 *
 * 本文件**只读** [AccountStore.ready]（拿账号名给用户勾）与
 * [PostContentRegistry.all]（拿文案来源名），**只写** [PostTaskStore] 那个私有文件。
 * 不写 [Prefs]、不写 [AccountStore]、不调 `AccountStore.save()`。
 * ============================================================================
 */
object PostTaskSheet {

    /** 黑匣子 / logcat 的 tag。 */
    private const val LOG_TAG = "PostTaskSheet"

    /**
     * 打开弹窗。**唯一入口**（`MainActivity` 里那个按钮调它）。
     *
     * ★ [PostTaskStore.init] 在这里顺手调一次（它幂等）：本弹窗是
     *   `post_tasks` 这个私有文件的**唯一**使用者，把读盘放在自己入口
     *   比散在 `MainActivity.onCreate` 里更好找 —— 以后删掉本功能时，
     *   一处入口一起消失，不留悬空的初始化调用。
     */
    fun show(activity: Activity) {
        PostTaskStore.init(activity)

        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_post_task, null)
        val dialog = BottomSheetDialog(activity)
        dialog.setContentView(view)

        // ---- 取控件 ----
        val nameEdit = view.findViewById<EditText>(R.id.ptNameEdit)
        val scopeAll = view.findViewById<TextView>(R.id.ptScopeAll)
        val scopeGroup = view.findViewById<TextView>(R.id.ptScopeGroup)
        val scopeManual = view.findViewById<TextView>(R.id.ptScopeManual)
        val manualRow = view.findViewById<TextView>(R.id.ptManualRow)
        val sourceList = view.findViewById<LinearLayout>(R.id.ptSourceList)
        val syncSwitch = view.findViewById<SwitchCompat>(R.id.ptSyncSwitch)
        val perRoundEdit = view.findViewById<EditText>(R.id.ptPerRoundEdit)
        val roundsEdit = view.findViewById<EditText>(R.id.ptRoundsEdit)
        val roundWaitEdit = view.findViewById<EditText>(R.id.ptRoundWaitEdit)
        val actionGapEdit = view.findViewById<EditText>(R.id.ptActionGapEdit)
        val rateCoolEdit = view.findViewById<EditText>(R.id.ptRateCoolEdit)
        val overlaySwitch = view.findViewById<SwitchCompat>(R.id.ptOverlaySwitch)
        val scheduleSwitch = view.findViewById<SwitchCompat>(R.id.ptScheduleSwitch)
        val scheduleRow = view.findViewById<TextView>(R.id.ptScheduleRow)
        val windowSwitch = view.findViewById<SwitchCompat>(R.id.ptWindowSwitch)
        val windowRow = view.findViewById<TextView>(R.id.ptWindowRow)
        val startNowSwitch = view.findViewById<SwitchCompat>(R.id.ptStartNowSwitch)
        val cancelButton = view.findViewById<android.widget.Button>(R.id.ptCancelButton)
        val saveButton = view.findViewById<android.widget.Button>(R.id.ptSaveButton)

        // ---- 表单状态（★ 全部初值取自 PostTask 的默认参数，见 applyDefaults） ----
        val defaults = PostTask()
        var scope = defaults.accountScope
        val pickedAccountIds = mutableSetOf<String>()
        var scheduleAtMillis: Long? = null
        var windowStartMinute: Int? = null
        var windowEndMinute: Int? = null

        // ---- 文案来源：按注册表顺序生成勾选项 ----
        val sourceBoxes = mutableListOf<Pair<PostContentSource, CheckBox>>()
        for (source in PostContentRegistry.all()) {
            val box = CheckBox(activity).apply {
                // ★ 与 activity_interact.xml 里那两个勾选框**同一个 drawable**，
                //   保证「任务复选框」在全 App 只有一种长相。
                //   ★ 用 `setButtonDrawable` 而不是老的 `setButton`：后者在本工程的
                //     编译 SDK 上已经不存在（实测「Unresolved reference」）。
                setButtonDrawable(ContextCompat.getDrawable(activity, R.drawable.bg_superlike_check))
                // ★ 文字 = 来源显示名 + 「（只读）」后缀（pt_source_readonly）。
                //   本期 5 个只读源的内容是空的（用户选了「先搭结构、内容留空待补」），
                //   所以这一行就是在如实告诉用户「这个源现在只读、还填不了」。
                text = activity.getString(R.string.pt_source_readonly, source.displayName)
                // ★ 必须写成 `setTextColor(...)` 而不是 `textColor = ...`：
                //   `TextView` 只有 setter、**没有 getter**，Kotlin 合成不出属性。
                setTextColor(ContextCompat.getColor(activity, R.color.text_primary))
                textSize = 15f
                setPadding(dp(activity, 4), dp(activity, 6), dp(activity, 4), dp(activity, 6))
            }
            sourceList.addView(
                box,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            sourceBoxes.add(source to box)
        }

        // ================================================================ 参与账号

        fun applyChip(chip: TextView, selected: Boolean) {
            chip.isSelected = selected
            chip.setTextColor(
                ContextCompat.getColor(
                    activity,
                    if (selected) R.color.text_on_brand else R.color.text_secondary
                )
            )
            chip.setTypeface(null, if (selected) Typeface.BOLD else Typeface.NORMAL)
        }

        fun refreshManualRow() {
            manualRow.text = if (pickedAccountIds.isEmpty()) {
                activity.getString(R.string.pt_manual_none)
            } else {
                activity.getString(R.string.pt_manual_pick, pickedAccountIds.size)
            }
        }

        fun refreshScope() {
            applyChip(scopeAll, scope == PostAccountScope.ALL)
            // ★ 「分组」本期**永不高亮** —— 它还没有实现（用户拍板：置灰）。
            applyChip(scopeGroup, false)
            applyChip(scopeManual, scope == PostAccountScope.MANUAL)
            manualRow.visibility = if (scope == PostAccountScope.MANUAL) View.VISIBLE else View.GONE
            refreshManualRow()
        }

        fun pickAccounts() {
            val accounts = AccountStore.ready()
            if (accounts.isEmpty()) {
                toast(activity, activity.getString(R.string.need_account))
                return
            }
            val labels = accounts.map { it.label }.toTypedArray()
            val checked = BooleanArray(accounts.size) { accounts[it].id in pickedAccountIds }
            AlertDialog.Builder(activity)
                .setTitle(activity.getString(R.string.pt_account_title))
                .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                    checked[which] = isChecked
                }
                .setPositiveButton(activity.getString(R.string.pt_save)) { _, _ ->
                    pickedAccountIds.clear()
                    accounts.forEachIndexed { index, account ->
                        if (checked[index]) pickedAccountIds.add(account.id)
                    }
                    refreshManualRow()
                }
                .setNegativeButton(activity.getString(R.string.dialog_cancel), null)
                .show()
        }

        scopeAll.setOnClickListener {
            scope = PostAccountScope.ALL
            refreshScope()
        }
        scopeGroup.setOnClickListener {
            // ★ 用户拍板：可点但置灰，点了只提示、**不改变选中态**。
            toast(activity, activity.getString(R.string.pt_group_todo))
        }
        scopeManual.setOnClickListener {
            scope = PostAccountScope.MANUAL
            refreshScope()
        }
        manualRow.setOnClickListener { pickAccounts() }

        // ============================================================ 保存按钮状态

        fun refreshSaveEnabled() {
            val anySource = sourceBoxes.any { it.second.isChecked }
            saveButton.isEnabled = anySource
            saveButton.alpha = if (anySource) 1f else 0.45f
        }
        for ((_, box) in sourceBoxes) {
            box.setOnCheckedChangeListener { _, _ -> refreshSaveEnabled() }
        }

        // ================================================================ 定时开始

        fun refreshScheduleRow() {
            val at = scheduleAtMillis
            scheduleRow.text = if (at == null) {
                activity.getString(R.string.pt_time_none)
            } else {
                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(at))
            }
        }

        scheduleSwitch.setOnCheckedChangeListener { _, checked ->
            scheduleRow.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) scheduleAtMillis = null
            refreshScheduleRow()
        }
        scheduleRow.setOnClickListener {
            val seed = Calendar.getInstance().apply {
                scheduleAtMillis?.let { timeInMillis = it }
            }
            val year = seed.get(Calendar.YEAR)
            val month = seed.get(Calendar.MONTH)
            val day = seed.get(Calendar.DAY_OF_MONTH)
            val hour = seed.get(Calendar.HOUR_OF_DAY)
            val minute = seed.get(Calendar.MINUTE)
            // ★ 先选日期、再选时刻。日期框的标题就是「选择开始时间」
            //   （`pt_schedule_pick`），两段式选择用户不会走丢。
            val dateDialog = DatePickerDialog(
                activity,
                { _, y, m, d ->
                    TimePickerDialog(
                        activity,
                        { _, hh, mm ->
                            scheduleAtMillis = Calendar.getInstance().apply {
                                set(y, m, d, hh, mm, 0)
                                set(Calendar.MILLISECOND, 0)
                            }.timeInMillis
                            refreshScheduleRow()
                        },
                        hour,
                        minute,
                        true
                    ).show()
                },
                year,
                month,
                day
            )
            dateDialog.setTitle(activity.getString(R.string.pt_schedule_pick))
            dateDialog.show()
        }

        // ========================================================== 限制运行时间段

        fun refreshWindowRow() {
            val start = windowStartMinute
            val end = windowEndMinute
            windowRow.text = if (start == null || end == null) {
                activity.getString(R.string.pt_time_none)
            } else {
                activity.getString(R.string.pt_window_fmt, minuteText(start), minuteText(end))
            }
        }

        windowSwitch.setOnCheckedChangeListener { _, checked ->
            windowRow.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) {
                windowStartMinute = null
                windowEndMinute = null
            }
            refreshWindowRow()
        }
        windowRow.setOnClickListener {
            // ★ 两段式：先选起点、再选终点。第一段的标题就是「选择时间段」
            //   （`pt_window_pick`）—— 用户点一下就知道接下来在选什么。
            val startPicker = TimePickerDialog(
                activity,
                { _, h1, m1 ->
                    TimePickerDialog(
                        activity,
                        { _, h2, m2 ->
                            windowStartMinute = h1 * 60 + m1
                            windowEndMinute = h2 * 60 + m2
                            refreshWindowRow()
                        },
                        18,
                        0,
                        true
                    ).show()
                },
                9,
                0,
                true
            )
            startPicker.setTitle(activity.getString(R.string.pt_window_pick))
            startPicker.show()
        }

        // ================================================================ 取消 / 保存

        cancelButton.setOnClickListener {
            // ★ 取消 = 丢弃本次表单，**不落盘**；再次打开时全部回到默认值
            //   （每次 show() 都重新 inflate 一份布局，天然没有残留）。
            dialog.dismiss()
        }

        saveButton.setOnClickListener {
            val chosenSources = sourceBoxes.filter { it.second.isChecked }.map { it.first.id }
            if (chosenSources.isEmpty()) {
                // 正常情况下保存按钮此时是置灰的，走不到这里；
                // 留这一手是因为「按钮状态」与「真正收集到的数据」是两处，
                // 万一哪次刷新漏了，宁可明确提示也不要存下一条没有来源的任务。
                toast(activity, activity.getString(R.string.pt_err_no_source))
                return@setOnClickListener
            }
            val task = PostTask(
                name = nameEdit.text?.toString()?.trim().orEmpty(),
                accountScope = scope,
                accountIds = pickedAccountIds.toList(),
                contentSourceIds = chosenSources,
                syncToWeibo = syncSwitch.isChecked,
                perAccountPerRound = readInt(perRoundEdit, 1, 1, 20),
                rounds = readInt(roundsEdit, 1, 1, 50),
                roundWaitMinutes = readInt(roundWaitEdit, 20, 1, 1440),
                actionGapSeconds = readInt(actionGapEdit, 5, 1, 600),
                rateCoolMinutes = readInt(rateCoolEdit, 10, 1, 1440),
                showOverlay = overlaySwitch.isChecked,
                scheduleStart = scheduleSwitch.isChecked,
                scheduleAtMillis = if (scheduleSwitch.isChecked) scheduleAtMillis else null,
                limitWindow = windowSwitch.isChecked,
                windowStartMinute = if (windowSwitch.isChecked) windowStartMinute else null,
                windowEndMinute = if (windowSwitch.isChecked) windowEndMinute else null,
                startImmediately = startNowSwitch.isChecked
            )
            // ★ 字段逐个打日志（走项目统一的 Dbg，`Dbg.enabled = false` 时不产生噪音）。
            Dbg.log(LOG_TAG, describe(task))
            PostTaskStore.save(task)
            toast(activity, activity.getString(R.string.pt_saved_toast))
            dialog.dismiss()
            // ★★ 到此为止 —— 本期**不执行**任何发帖（见文件头「本期边界」）。
        }

        // ================================================================ 初值 & 显示

        // 初值一律取自 PostTask 的默认参数（唯一默认值定义处）。
        syncSwitch.isChecked = defaults.syncToWeibo
        perRoundEdit.setText(defaults.perAccountPerRound.toString())
        roundsEdit.setText(defaults.rounds.toString())
        roundWaitEdit.setText(defaults.roundWaitMinutes.toString())
        actionGapEdit.setText(defaults.actionGapSeconds.toString())
        rateCoolEdit.setText(defaults.rateCoolMinutes.toString())
        overlaySwitch.isChecked = defaults.showOverlay
        scheduleSwitch.isChecked = defaults.scheduleStart
        windowSwitch.isChecked = defaults.limitWindow
        startNowSwitch.isChecked = defaults.startImmediately
        scheduleRow.visibility = if (defaults.scheduleStart) View.VISIBLE else View.GONE
        windowRow.visibility = if (defaults.limitWindow) View.VISIBLE else View.GONE
        refreshScheduleRow()
        refreshWindowRow()
        refreshScope()
        refreshSaveEnabled()

        // ★ 近全屏：BottomSheetDialog 的容器默认是 wrap_content，
        //   不把它撑开的话 EXPANDED 也只能长到内容高度（表单很长时看着像半截）。
        dialog.setOnShowListener {
            // ★★ 把 sheet 容器撑到满高：`BottomSheetDialog` 的容器默认是 wrap_content，
            //   不撑开的话 EXPANDED 也只能长到「内容高度」—— 而表单里的 ScrollView 用的是
            //   `0dp + weight=1`，一旦容器不是满高，它会被压成 0，整张表单都看不见。
            //
            //   ★ 这里**刻意不去 findViewById 库里的那张 sheet 容器**（Material 的
            //     `design_bottom_sheet`）：闸门 2 有一条「Kotlin 里出现的每一个
            //     id 引用都必须真实存在于本工程的布局文件里」，而库里的 id
            //     不在本工程布局中 ⇒ 会被报成假红灯。
            //     ⇒ 改成「从自己的根视图往上走一层」拿**同一个**容器：
            //       `BottomSheetDialog` 把我们的布局直接 add 进那张 sheet 容器，
            //       所以 `view.parent` 就是它。效果完全一样，且不引入库 id。
            //     （★ 连注释里也不写那个带点号的全名 —— 闸门 2 查的是原始文本。）
            (view.parent as? ViewGroup)?.let { container ->
                container.layoutParams = container.layoutParams.apply {
                    height = ViewGroup.LayoutParams.MATCH_PARENT
                }
            }
            // ★ 这里刻意**直接调 Java setter**（而不是 Kotlin 属性语法）：
            //   `skipCollapsed` 的 getter 是 `isSkipCollapsed()`，
            //   属性名到底是 `skipCollapsed` 还是 `isSkipCollapsed` 容易记错，
            //   写死方法名就不用猜。
            dialog.behavior.setState(BottomSheetBehavior.STATE_EXPANDED)
            dialog.behavior.setSkipCollapsed(true)
        }
        dialog.show()
    }

    // ================================================================== 小工具

    /**
     * 读一个数字框。
     *
     * ★ 空 / 非数字 / 超范围**一律回落到默认值再夹到区间内** ——
     *   表单里一个空框不该让「保存」失败，也不该把 0 条 / 0 分钟这种
     *   无意义的值存进任务里。夹区间而不是报错，是因为这些框在界面上
     *   已经用 `inputType="number"` 挡住了大部分非法输入。
     */
    private fun readInt(edit: EditText, fallback: Int, min: Int, max: Int): Int {
        val value = edit.text?.toString()?.trim()?.toIntOrNull() ?: fallback
        return value.coerceIn(min, max)
    }

    /** 把「当天第几分钟」写成 `HH:mm`。 */
    private fun minuteText(minute: Int): String =
        String.format(Locale.US, "%02d:%02d", minute / 60, minute % 60)

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    private fun toast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    /**
     * 把一条任务的全部字段拼成一段多行文本，供日志使用。
     *
     * ★ 刻意**逐字段列出**而不是 `task.toString()`：`data class` 的 toString
     *   会把 [PostTask.accountIds] / [PostTask.contentSourceIds] 打成
     *   内存地址风格的一长串，排查时反而看不清到底勾了什么。
     */
    private fun describe(task: PostTask): String {
        // ★ 先把几处「可能为空」的字段摊平成普通字符串再拼 ——
        //   避免在字符串模板的 `${}` 里再嵌 lambda（能写但极易看错）。
        val name = if (task.name.isBlank()) "（未命名）" else task.name
        val at = task.scheduleAtMillis?.let {
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(it))
        } ?: "未设置"
        val windowStart = task.windowStartMinute?.let { minuteText(it) } ?: "未设置"
        val windowEnd = task.windowEndMinute?.let { minuteText(it) } ?: "未设置"
        return buildString {
            appendLine("创建超话发帖任务：")
            appendLine("  id=" + task.id)
            appendLine("  名称=" + name)
            appendLine("  参与账号=" + task.accountScope.name + "（勾中 " + task.accountIds.size + " 个）")
            appendLine("  账号id=" + task.accountIds.joinToString(","))
            appendLine("  文案来源=" + task.contentSourceIds.joinToString(","))
            appendLine("  同步到个人微博=" + task.syncToWeibo)
            appendLine("  每账号每轮=" + task.perAccountPerRound)
            appendLine("  轮数=" + task.rounds)
            appendLine("  轮间等待=" + task.roundWaitMinutes + " 分钟")
            appendLine("  动作间隔=" + task.actionGapSeconds + " 秒")
            appendLine("  频繁冷却=" + task.rateCoolMinutes + " 分钟")
            appendLine("  独立悬浮窗=" + task.showOverlay)
            appendLine("  定时开始=" + task.scheduleStart + "（" + at + "）")
            appendLine("  限制时间段=" + task.limitWindow + "（" + windowStart + " ~ " + windowEnd + "）")
            appendLine("  保存后立即开始=" + task.startImmediately)
            append("  ★ 本期只落盘、不执行（编排链路下一期接）")
        }
    }
}
