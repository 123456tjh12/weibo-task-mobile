package com.tjh.weibotask

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * ============================================================================
 * ★★★★ 第 116 期：「创建超话发帖任务」弹窗（近全屏 BottomSheet）的**控制器**。
 *
 * ## 用户要的是什么
 *
 * 用户原话（2026-10-15）：
 *   「请帮我实现一个「创建超话发帖任务」的弹窗表单组件……」
 *   「把立即发一条试试这个按钮，换成创建任务，创建任务之后自动执行」
 *   「我想做的是，首先需要有默认发帖的内容，其次，客户可以自己添加内容发帖」
 *
 * ⇒ 主界面那个按钮（id 仍是 `testPostButton`）改成「创建任务」，
 *   点开就是本弹窗；表单填完**落盘成一条 [PostTask]**。
 *
 * ## ★★★ 第 116 期边界：表单**只落盘、不执行**
 *
 * [save] 的最后一步是 `PostTaskStore.save(task)` + 一句 toast + `dismiss()`。
 * 第 116 期它**不会**调 `startPostRunFromUi()`、**不会**碰 `AgentService`、**不会**写 [Prefs]。
 * **第 117 期已接执行链路**：勾选「保存后立即开始」时，[save] 末尾改调
 * [PostTaskStarter.start]（界面层入口），由它校验 + 拉起 `AgentService` 的前台服务跑一次。
 *
 * ## ★★★★ 第 118 期（用户拍板，2026-10-16）改了两块界面
 *
 * 1. **参与账号**：从「三个胶囊（全部/分组/手动）+ 弹窗多选」改成
 *    **账号清单（用户名 + 方格，多选）+ 一个「所有账号轮流」方格**。
 *    · 「分组」入口按用户要求**删除**（`PostAccountScope.GROUP` 枚举值保留做老数据兜底）；
 *    · 默认**全勾**（等价于上一版的「全部」默认态）。
 * 2. **发帖文案来源**：注册表里的 5 个源换了（见 [PostContentRegistry]），
 *    但**本文件的生成逻辑一行未改** —— 它本来就是「按注册表顺序动态生成」，
 *    所以换了源，界面自动跟着变。这是第 116 期留插槽的兑现。
 *
 * ## ★ 与四条核心链路的关系
 *
 * 本文件**只读** [AccountStore.ready]（拿账号名给用户勾）与
 * [PostContentRegistry.all]（拿文案来源名），**只写** [PostTaskStore] 那个私有文件。
 * 不写 [Prefs]、不写 [AccountStore]、不调 `AccountStore.save()`。
 * ============================================================================
 */
object PostTaskSheet {

    /** 黑匣子 / logcat 的 tag。 */
    private const val LOG_TAG = "PostTaskSheet"

    /**
     * 打开弹窗。**唯一入口**（`MainActivity` 里那个按钮调它）。
     *
     * ★★★★ 第 122 期（用户拍板「编辑」按钮全做）：新增 [taskId] 参数 =
     *   **编辑模式** —— 表单回填那条任务的全部字段，保存时**原地更新**
     *   （`id` / `createdAt` / `ranAt` / `retryCount` 原样保留）。
     *   · 新建行为（taskId 传 null）**一行未变**：初值仍是 [PostTask] 的默认参数；
     *   · 编辑**不自动开跑**：用户改个名字就立刻发一遍是反直觉的，
     *     要跑用任务卡上的「开始」按钮（那是明确的用户动作）；
     *   · 但「定时开始 / 限制时间段」**真的变了**必须重挂闹钟（见保存末尾）。
     *
     * ★ [PostTaskStore.init] 在这里顺手调一次（它幂等）：本弹窗是
     *   `post_tasks` 这个私有文件的**唯一**使用者，把读盘放在自己入口
     *   比散在 `MainActivity.onCreate` 里更好找 —— 以后删掉本功能时，
     *   一处入口一起消失，不留悬空的初始化调用。
     */
    fun show(activity: Activity, taskId: String? = null) {
        PostTaskStore.init(activity)

        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_post_task, null)
        val dialog = BottomSheetDialog(activity)
        dialog.setContentView(view)

        // ★★★★ 第 122 期：编辑模式 = 既有任务；新建 = null。
        //   `editingTask` 为 null 时下面每一处初值都退回 PostTask 的默认参数，
        //   与第 116~121 期的行为**逐字节一致**。
        val editingTask = taskId?.let { PostTaskStore.get(it) }
        if (taskId != null && editingTask == null) {
            // 任务已被删（比如用户刚在卡上点过删除）⇒ 按新建打开，不崩。
            toast(activity, activity.getString(R.string.pt_task_missing))
        }
        // 标题：新建「创建超话发帖任务」/ 编辑「编辑发帖任务」
        view.findViewById<TextView>(R.id.ptTitle).setText(
            if (editingTask != null) R.string.pt_title_edit else R.string.pt_title
        )

        // ---- 取控件 ----
        val nameEdit = view.findViewById<EditText>(R.id.ptNameEdit)
        val accountList = view.findViewById<LinearLayout>(R.id.ptAccountList)
        val rotateCheck = view.findViewById<CheckBox>(R.id.ptRotateCheck)
        val sourceList = view.findViewById<LinearLayout>(R.id.ptSourceList)
        val syncSwitch = view.findViewById<SwitchCompat>(R.id.ptSyncSwitch)
        val perRoundEdit = view.findViewById<EditText>(R.id.ptPerRoundEdit)
        val roundsEdit = view.findViewById<EditText>(R.id.ptRoundsEdit)
        val roundWaitEdit = view.findViewById<EditText>(R.id.ptRoundWaitEdit)
        val actionGapEdit = view.findViewById<EditText>(R.id.ptActionGapEdit)
        val rateCoolEdit = view.findViewById<EditText>(R.id.ptRateCoolEdit)
        val overlaySwitch = view.findViewById<SwitchCompat>(R.id.ptOverlaySwitch)
        val scheduleSwitch = view.findViewById<SwitchCompat>(R.id.ptScheduleSwitch)
        val scheduleRow = view.findViewById<TextView>(R.id.ptScheduleRow)
        val windowSwitch = view.findViewById<SwitchCompat>(R.id.ptWindowSwitch)
        val windowRow = view.findViewById<TextView>(R.id.ptWindowRow)
        val startNowSwitch = view.findViewById<SwitchCompat>(R.id.ptStartNowSwitch)
        val cancelButton = view.findViewById<android.widget.Button>(R.id.ptCancelButton)
        val saveButton = view.findViewById<android.widget.Button>(R.id.ptSaveButton)

        // ---- 表单状态：新建 = PostTask 的默认参数；编辑 = 既有任务的全部字段 ----
        //    ★ 初值**唯一**来源就是这一份 seed：账号勾选 / 来源勾选 / 各数字框 /
        //      开关全部从它取，不再像第 116~121 期那样各自写默认值 ——
        //      「XML 写一套、代码写一套」的漂移从源头消除。
        val seed: PostTask = editingTask ?: PostTask()
        var scheduleAtMillis: Long? = seed.scheduleAtMillis
        var windowStartMinute: Int? = seed.windowStartMinute
        var windowEndMinute: Int? = seed.windowEndMinute

        // ================================================================ 参与账号

        // ★★★★ 第 118 期：**账号清单（用户名 + 方格）**。
        //   用户原话：「参与账号换成用户名，加一个所有账号轮流选项」+「分组功能可以先删除」。
        //   · 取 [AccountStore.ready]（与第 116 期「手动」弹窗同一个口径），
        //     再按 `order` 排序 —— 让清单顺序与账号页一致（`ready()` 本身不排序）。
        //   · 每个方格 = 一个账号，文字用 [WeiboAccount.displayName]（**用户名**优先）。
        //   · 默认**全勾** = 等价于上一版「参与账号 = 全部」的默认态。
        val accounts = AccountStore.ready().sortedBy { it.order }
        val accountBoxes = mutableListOf<Pair<WeiboAccount, CheckBox>>()
        for (account in accounts) {
            val box = CheckBox(activity).apply {
                // ★ 与文案来源那两个勾选框**同一个 drawable**，全 App 只有一种勾选长相。
                setButtonDrawable(ContextCompat.getDrawable(activity, R.drawable.bg_superlike_check))
                text = account.displayName
                // ★ 必须写成 `setTextColor(...)` 而不是 `textColor = ...`：
                //   `TextView` 只有 setter、**没有 getter**，Kotlin 合成不出属性。
                setTextColor(ContextCompat.getColor(activity, R.color.text_primary))
                textSize = 15f
                setPadding(dp(activity, 4), dp(activity, 6), dp(activity, 4), dp(activity, 6))
                // ★★★★ 第 122 期：初值按 seed 的口径来 ——
                //   · 新建（seed = 默认参数）：全部勾上 = 上一版「参与账号 = 全部」的默认态；
                //   · 编辑：ROTATE / ALL / GROUP ⇒ 全勾；MANUAL ⇒ 只勾 seed 里记下的那几个。
                isChecked = when (seed.accountScope) {
                    PostAccountScope.MANUAL -> account.id in seed.accountIds.toSet()
                    else -> true
                }
            }
            accountList.addView(
                box,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            accountBoxes.add(account to box)
        }

        /**
         * 勾了「所有账号轮流」时，把账号清单**置灰**（而不是隐藏）。
         *
         * ★ 为什么置灰不隐藏：让用户仍然看得到有哪些账号参与了轮流 ——
         *   隐藏会让「轮流」变成一个黑盒，用户不知道到底轮的是哪几个账号。
         */
        fun refreshRotateState() {
            val editable = !rotateCheck.isChecked
            for ((_, box) in accountBoxes) {
                box.isEnabled = editable
                box.alpha = if (editable) 1f else 0.4f
            }
        }

        // ---- 文案来源：按注册表顺序生成勾选项 ----
        // ★★★★ 第 118 期：这一段**一行未改** —— 注册表里换了源，界面自动跟着变。
        val sourceBoxes = mutableListOf<Pair<PostContentSource, CheckBox>>()
        for (source in PostContentRegistry.all()) {
            val box = CheckBox(activity).apply {
                // ★ 与 activity_interact.xml 里那两个勾选框**同一个 drawable**，
                //   保证「任务复选框」在全 App 只有一种长相。
                //   ★ 用 `setButtonDrawable` 而不是老的 `setButton`：后者在本工程的
                //     编译 SDK 上已经不存在（实测「Unresolved reference」）。
                setButtonDrawable(ContextCompat.getDrawable(activity, R.drawable.bg_superlike_check))
                // ★ 文字 = 来源显示名 + 「（只读）」后缀（pt_source_readonly）。
                //   第 118 期起这 5 个源**有真内容了**，但仍然是只读的
                //   （内容编译进 APK，界面上改不了）⇒ 这个后缀依然如实。
                text = activity.getString(R.string.pt_source_readonly, source.displayName)
                // ★ 必须写成 `setTextColor(...)` 而不是 `textColor = ...`：
                //   `TextView` 只有 setter、**没有 getter**，Kotlin 合成不出属性。
                setTextColor(ContextCompat.getColor(activity, R.color.text_primary))
                textSize = 15f
                setPadding(dp(activity, 4), dp(activity, 6), dp(activity, 4), dp(activity, 6))
                // ★★★★ 第 122 期：初值 = seed 里勾中的来源（新建时 seed.contentSourceIds
                //   是空列表 ⇒ 一个都不勾，与第 116~121 期「新建时来源全不勾」一致）。
                isChecked = source.id in seed.contentSourceIds.toSet()
            }
            sourceList.addView(
                box,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            sourceBoxes.add(source to box)
        }

        // ============================================================ 保存按钮状态

        /**
         * 「保存」的启用条件 = **至少勾一个文案来源** 且 **至少有一个参与账号**。
         *
         * ★ 第 118 期新增后半条：账号改成清单勾选后，「一个都没勾」是一个
         *   用户能轻易走到的状态（上一版靠「全部」胶囊兜底，走不到）。
         *   与其存下一条跑不了的任务，不如当场置灰 + 保存时再明确提示一次。
         * ★ 勾了「所有账号轮流」时视为「有参与账号」—— 它用的是全部账号。
         */
        fun refreshSaveEnabled() {
            val anySource = sourceBoxes.any { it.second.isChecked }
            val anyAccount = rotateCheck.isChecked || accountBoxes.any { it.second.isChecked }
            val ok = anySource && anyAccount
            saveButton.isEnabled = ok
            saveButton.alpha = if (ok) 1f else 0.45f
        }
        for ((_, box) in sourceBoxes) {
            box.setOnCheckedChangeListener { _, _ -> refreshSaveEnabled() }
        }
        for ((_, box) in accountBoxes) {
            box.setOnCheckedChangeListener { _, _ -> refreshSaveEnabled() }
        }
        // ★ 这个监听器放在这里（而不是「参与账号」那一段）是因为它要调 [refreshSaveEnabled]，
        //   而 Kotlin 的局部函数必须先定义后使用。
        rotateCheck.setOnCheckedChangeListener { _, _ ->
            refreshRotateState()
            refreshSaveEnabled()
        }

        // ================================================================ 定时开始

        fun refreshScheduleRow() {
            val at = scheduleAtMillis
            scheduleRow.text = if (at == null) {
                activity.getString(R.string.pt_time_none)
            } else {
                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(at))
            }
        }

        scheduleSwitch.setOnCheckedChangeListener { _, checked ->
            scheduleRow.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) scheduleAtMillis = null
            refreshScheduleRow()
        }
        scheduleRow.setOnClickListener {
            // ★ 第 122 期：局部变量改名 pickSeed —— 与外层表单初值 seed（PostTask）
            //   同名会触发「Name shadowed」告警（基线告警数一条不许多）。
            val pickSeed = Calendar.getInstance().apply {
                scheduleAtMillis?.let { timeInMillis = it }
            }
            val year = pickSeed.get(Calendar.YEAR)
            val month = pickSeed.get(Calendar.MONTH)
            val day = pickSeed.get(Calendar.DAY_OF_MONTH)
            val hour = pickSeed.get(Calendar.HOUR_OF_DAY)
            val minute = pickSeed.get(Calendar.MINUTE)
            // ★ 先选日期、再选时刻。日期框的标题就是「选择开始时间」
            //   （`pt_schedule_pick`），两段式选择用户不会走丢。
            val dateDialog = DatePickerDialog(
                activity,
                { _, y, m, d ->
                    TimePickerDialog(
                        activity,
                        { _, hh, mm ->
                            scheduleAtMillis = Calendar.getInstance().apply {
                                set(y, m, d, hh, mm, 0)
                                set(Calendar.MILLISECOND, 0)
                            }.timeInMillis
                            refreshScheduleRow()
                        },
                        hour,
                        minute,
                        true
                    ).show()
                },
                year,
                month,
                day
            )
            dateDialog.setTitle(activity.getString(R.string.pt_schedule_pick))
            dateDialog.show()
        }

        // ========================================================== 限制运行时间段

        fun refreshWindowRow() {
            val start = windowStartMinute
            val end = windowEndMinute
            windowRow.text = if (start == null || end == null) {
                activity.getString(R.string.pt_time_none)
            } else {
                activity.getString(R.string.pt_window_fmt, minuteText(start), minuteText(end))
            }
        }

        windowSwitch.setOnCheckedChangeListener { _, checked ->
            windowRow.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) {
                windowStartMinute = null
                windowEndMinute = null
            }
            refreshWindowRow()
        }
        windowRow.setOnClickListener {
            // ★ 两段式：先选起点、再选终点。第一段的标题就是「选择时间段」
            //   （`pt_window_pick`）—— 用户点一下就知道接下来在选什么。
            val startPicker = TimePickerDialog(
                activity,
                { _, h1, m1 ->
                    TimePickerDialog(
                        activity,
                        { _, h2, m2 ->
                            windowStartMinute = h1 * 60 + m1
                            windowEndMinute = h2 * 60 + m2
                            refreshWindowRow()
                        },
                        18,
                        0,
                        true
                    ).show()
                },
                9,
                0,
                true
            )
            startPicker.setTitle(activity.getString(R.string.pt_window_pick))
            startPicker.show()
        }

        // ================================================================ 取消 / 保存

        cancelButton.setOnClickListener {
            // ★ 取消 = 丢弃本次表单，**不落盘**；再次打开时全部回到默认值
            //   （每次 show() 都重新 inflate 一份布局，天然没有残留）。
            dialog.dismiss()
        }

        saveButton.setOnClickListener {
            val chosenSources = sourceBoxes.filter { it.second.isChecked }.map { it.first.id }
            if (chosenSources.isEmpty()) {
                // 正常情况下保存按钮此时是置灰的，走不到这里；
                // 留这一手是因为「按钮状态」与「真正收集到的数据」是两处，
                // 万一哪次刷新漏了，宁可明确提示也不要存下一条没有来源的任务。
                toast(activity, activity.getString(R.string.pt_err_no_source))
                return@setOnClickListener
            }
            val rotate = rotateCheck.isChecked
            val checkedIds = accountBoxes.filter { it.second.isChecked }.map { it.first.id }
            if (!rotate && checkedIds.isEmpty()) {
                // 同上：置灰状态下的双保险。
                toast(activity, activity.getString(R.string.pt_err_no_account))
                return@setOnClickListener
            }
            // ★★★ 口径换算（第 118 期）：
            //   · 勾了「所有账号轮流」 ⇒ [PostAccountScope.ROTATE]（账号集合 = 全部）；
            //   · 全勾 ⇒ [PostAccountScope.ALL] —— 与「全部」语义等价，
            //     存成 ALL 比存一串全量 id 更不容易在账号增删后失真；
            //   · 部分勾 ⇒ [PostAccountScope.MANUAL] + 勾中的 id。
            //   ★ 只有 MANUAL 才写 [PostTask.accountIds]，其余一律留空。
            val scope = when {
                rotate -> PostAccountScope.ROTATE
                checkedIds.size == accountBoxes.size -> PostAccountScope.ALL
                else -> PostAccountScope.MANUAL
            }
            val task = PostTask(
                // ★★★★ 第 122 期：编辑模式**原地更新** —— id / createdAt / ranAt /
                //   retryCount 一律取自既有那条（新 UUID 会变成「新建一条」，
                //   旧那条还留在库里，排队与闹钟全对不上）。
                id = editingTask?.id ?: UUID.randomUUID().toString(),
                name = nameEdit.text?.toString()?.trim().orEmpty(),
                accountScope = scope,
                accountIds = if (scope == PostAccountScope.MANUAL) checkedIds else emptyList(),
                contentSourceIds = chosenSources,
                syncToWeibo = syncSwitch.isChecked,
                perAccountPerRound = readInt(perRoundEdit, 1, 1, 20),
                rounds = readInt(roundsEdit, 1, 1, 50),
                roundWaitMinutes = readInt(roundWaitEdit, 20, 1, 1440),
                actionGapSeconds = readInt(actionGapEdit, 5, 1, 600),
                rateCoolMinutes = readInt(rateCoolEdit, 10, 1, 1440),
                showOverlay = overlaySwitch.isChecked,
                scheduleStart = scheduleSwitch.isChecked,
                scheduleAtMillis = if (scheduleSwitch.isChecked) scheduleAtMillis else null,
                limitWindow = windowSwitch.isChecked,
                windowStartMinute = if (windowSwitch.isChecked) windowStartMinute else null,
                windowEndMinute = if (windowSwitch.isChecked) windowEndMinute else null,
                startImmediately = startNowSwitch.isChecked,
                // ★ 编辑保留这三个「执行痕迹」字段：ranAt（已跑不重触）与
                //   retryCount（补跑计数，跨重启落盘）绝不能被一次改配置刷掉 ——
                //   否则「改了名字 ⇒ 重新跑一遍」和「无限补跑」两个坑同时出现。
                createdAt = editingTask?.createdAt ?: System.currentTimeMillis(),
                ranAt = editingTask?.ranAt,
                retryCount = editingTask?.retryCount ?: 0
            )
            // ★ 字段逐个打日志（走项目统一的 Dbg，`Dbg.enabled = false` 时不产生噪音）。
            Dbg.log(LOG_TAG, describe(task))
            PostTaskStore.save(task)
            toast(
                activity,
                activity.getString(
                    if (editingTask != null) R.string.pt_updated_toast else R.string.pt_saved_toast
                )
            )
            dialog.dismiss()
            if (editingTask != null) {
                // ★★★★ 第 122 期：**编辑模式不自动开跑**。
                //   · 用户改个名字就立刻跑一遍发帖 = 反直觉的惊喜动作；
                //   · 要跑用任务卡上的「开始」按钮（那是明确的用户动作）。
                //   · 但「定时开始 / 限制时间段」**真的变了**必须重挂闹钟，
                //     否则「改了时间、闹钟还挂在旧时刻」—— 到点跑的是新参数、
                //     但时刻是旧的。只碰这两项，别的改动（名字/条数/来源）
                //     一律不动任何闹钟 —— 尤其**不能碰补跑闹钟**
                //     （它与任务闹钟同一 request code，cancel 会把它一起清掉）。
                val scheduleChanged = editingTask.scheduleStart != task.scheduleStart ||
                    editingTask.scheduleAtMillis != task.scheduleAtMillis
                val windowChanged = editingTask.limitWindow != task.limitWindow ||
                    editingTask.windowStartMinute != task.windowStartMinute ||
                    editingTask.windowEndMinute != task.windowEndMinute
                if (scheduleChanged || windowChanged) {
                    PostTaskScheduler.cancel(activity, task.id)
                    when {
                        task.scheduleStart -> {
                            task.scheduleAtMillis?.let {
                                PostTaskScheduler.scheduleOneShot(activity, task.id, it)
                            }
                        }
                        task.limitWindow -> {
                            val s = task.windowStartMinute
                            val e = task.windowEndMinute
                            if (s != null && e != null && s != e) {
                                val now = Calendar.getInstance()
                                val trigger =
                                    if (ScheduleWindow.inWindow(ScheduleWindow.minuteOfDay(now), s, e)) {
                                        System.currentTimeMillis()
                                    } else {
                                        ScheduleWindow.nextWindowStartMillis(now, s, e)
                                    }
                                PostTaskScheduler.scheduleOneShot(activity, task.id, trigger)
                            }
                        }
                    }
                }
                return@setOnClickListener
            }
            // ★★★★ 第 117 期：勾了「保存后立即开始」就当场跑一次（用户原话「创建任务之后自动执行」）。
            //   ★ 仍然**不写 Prefs** —— 任务的参数通过 Intent 传 taskId，AgentService 从 PostTaskStore 读。
            //   ★ 校验（无账号 / 无内容 / 任务不存在）在 PostTaskStarter 里做，失败只弹提示、不启动服务。
            //
            // ★★★★ 第 120 期：触发优先级（P1 拍板：**定时开始优先于立即开始**）。
            //   · `scheduleStart` 开 → 挂一次性闹钟到 `scheduleAtMillis`，**忽略**「立即开始」
            //     （开了定时又立刻跑是反直觉的，见方案 P1）；
            //   · 否则勾了「立即开始」→ 当场跑一次（时间窗判定在 `executePostTaskOnce` 内部，
            //     窗外会重挂等窗口，见方案 P2）；
            //   · 都没开、但限了时间窗 → 等到窗口开启再跑一次（窗内 = 现在，窗外 = 下一窗口起点）。
            when {
                task.scheduleStart -> {
                    val at = task.scheduleAtMillis
                    if (at != null) {
                        PostTaskScheduler.scheduleOneShot(activity, task.id, at)
                    }
                }
                task.startImmediately -> {
                    PostTaskStarter.start(activity, task.id)
                }
                task.limitWindow -> {
                    val s = task.windowStartMinute
                    val e = task.windowEndMinute
                    if (s != null && e != null && s != e) {
                        val now = Calendar.getInstance()
                        val trigger =
                            if (ScheduleWindow.inWindow(ScheduleWindow.minuteOfDay(now), s, e)) {
                                System.currentTimeMillis()
                            } else {
                                ScheduleWindow.nextWindowStartMillis(now, s, e)
                            }
                        PostTaskScheduler.scheduleOneShot(activity, task.id, trigger)
                    }
                }
            }
        }

        // ================================================================ 初值 & 显示

        // 初值一律取自 seed（新建 = PostTask 默认参数，编辑 = 既有任务）。
        nameEdit.setText(seed.name)
        syncSwitch.isChecked = seed.syncToWeibo
        perRoundEdit.setText(seed.perAccountPerRound.toString())
        roundsEdit.setText(seed.rounds.toString())
        roundWaitEdit.setText(seed.roundWaitMinutes.toString())
        actionGapEdit.setText(seed.actionGapSeconds.toString())
        rateCoolEdit.setText(seed.rateCoolMinutes.toString())
        overlaySwitch.isChecked = seed.showOverlay
        scheduleSwitch.isChecked = seed.scheduleStart
        windowSwitch.isChecked = seed.limitWindow
        startNowSwitch.isChecked = seed.startImmediately
        // ★ 「所有账号轮流」的初值同样取自 seed（`PostAccountScope.ROTATE` ⇒ 勾）。
        rotateCheck.isChecked = seed.accountScope == PostAccountScope.ROTATE
        scheduleRow.visibility = if (seed.scheduleStart) View.VISIBLE else View.GONE
        windowRow.visibility = if (seed.limitWindow) View.VISIBLE else View.GONE
        refreshScheduleRow()
        refreshWindowRow()
        refreshRotateState()
        refreshSaveEnabled()

        // ★ 近全屏：BottomSheetDialog 的容器默认是 wrap_content，
        //   不把它撑开的话 EXPANDED 也只能长到内容高度（表单很长时看着像半截）。
        dialog.setOnShowListener {
            // ★★ 把 sheet 容器撑到满高：`BottomSheetDialog` 的容器默认是 wrap_content，
            //   不撑开的话 EXPANDED 也只能长到「内容高度」—— 而表单里的 ScrollView 用的是
            //   `0dp + weight=1`，一旦容器不是满高，它会被压成 0，整张表单都看不见。
            //
            //   ★ 这里**刻意不去 findViewById 库里的那张 sheet 容器**（Material 的
            //     `design_bottom_sheet`）：闸门 2 有一条「Kotlin 里出现的每一个
            //     id 引用都必须真实存在于本工程的布局文件里」，而库里的 id
            //     不在本工程布局中 ⇒ 会被报成假红灯。
            //     ⇒ 改成「从自己的根视图往上走一层」拿**同一个**容器：
            //       `BottomSheetDialog` 把我们的布局直接 add 进那张 sheet 容器，
            //       所以 `view.parent` 就是它。效果完全一样，且不引入库 id。
            //     （★ 连注释里也不写那个带点号的全名 —— 闸门 2 查的是原始文本。）
            (view.parent as? ViewGroup)?.let { container ->
                container.layoutParams = container.layoutParams.apply {
                    height = ViewGroup.LayoutParams.MATCH_PARENT
                }
            }
            // ★ 这里刻意**直接调 Java setter**（而不是 Kotlin 属性语法）：
            //   `skipCollapsed` 的 getter 是 `isSkipCollapsed()`，
            //   属性名到底是 `skipCollapsed` 还是 `isSkipCollapsed` 容易记错，
            //   写死方法名就不用猜。
            dialog.behavior.setState(BottomSheetBehavior.STATE_EXPANDED)
            dialog.behavior.setSkipCollapsed(true)
        }
        dialog.show()
    }

    // ================================================================== 小工具

    /**
     * 读一个数字框。
     *
     * ★ 空 / 非数字 / 超范围**一律回落到默认值再夹到区间内** ——
     *   表单里一个空框不该让「保存」失败，也不该把 0 条 / 0 分钟这种
     *   无意义的值存进任务里。夹区间而不是报错，是因为这些框在界面上
     *   已经用 `inputType="number"` 挡住了大部分非法输入。
     */
    private fun readInt(edit: EditText, fallback: Int, min: Int, max: Int): Int {
        val value = edit.text?.toString()?.trim()?.toIntOrNull() ?: fallback
        return value.coerceIn(min, max)
    }

    /** 把「当天第几分钟」写成 `HH:mm`。 */
    private fun minuteText(minute: Int): String =
        String.format(Locale.US, "%02d:%02d", minute / 60, minute % 60)

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    private fun toast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    /**
     * 把一条任务的全部字段拼成一段多行文本，供日志使用。
     *
     * ★ 刻意**逐字段列出**而不是 `task.toString()`：`data class` 的 toString
     *   会把 [PostTask.accountIds] / [PostTask.contentSourceIds] 打成
     *   内存地址风格的一长串，排查时反而看不清到底勾了什么。
     */
    private fun describe(task: PostTask): String {
        // ★ 先把几处「可能为空」的字段摊平成普通字符串再拼 ——
        //   避免在字符串模板的 `${}` 里再嵌 lambda（能写但极易看错）。
        val name = if (task.name.isBlank()) "（未命名）" else task.name
        val at = task.scheduleAtMillis?.let {
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(it))
        } ?: "未设置"
        val windowStart = task.windowStartMinute?.let { minuteText(it) } ?: "未设置"
        val windowEnd = task.windowEndMinute?.let { minuteText(it) } ?: "未设置"
        return buildString {
            appendLine("创建超话发帖任务：")
            appendLine("  id=" + task.id)
            appendLine("  名称=" + name)
            appendLine("  参与账号=" + task.accountScope.name + "（勾中 " + task.accountIds.size + " 个）")
            appendLine("  账号id=" + task.accountIds.joinToString(","))
            appendLine("  文案来源=" + task.contentSourceIds.joinToString(","))
            appendLine("  同步到个人微博=" + task.syncToWeibo)
            appendLine("  每账号每轮=" + task.perAccountPerRound)
            appendLine("  轮数=" + task.rounds)
            appendLine("  轮间等待=" + task.roundWaitMinutes + " 分钟")
            appendLine("  动作间隔=" + task.actionGapSeconds + " 秒")
            appendLine("  频繁冷却=" + task.rateCoolMinutes + " 分钟")
            appendLine("  独立悬浮窗=" + task.showOverlay)
            appendLine("  定时开始=" + task.scheduleStart + "（" + at + "）")
            appendLine("  限制时间段=" + task.limitWindow + "（" + windowStart + " ~ " + windowEnd + "）")
            appendLine("  保存后立即开始=" + task.startImmediately)
            append("  ★ 第 117 期：勾选「保存后立即开始」后由 PostTaskStarter 启动一次发帖")
        }
    }
}
