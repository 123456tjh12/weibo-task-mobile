package com.tjh.weibotask

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

/** 账号在互动这件事上的状态。 */
enum class GuardState {
    /** 可以继续。 */
    OK,

    /** 已达上限，正在自动休息。 */
    RESTING
}

/**
 * 一次频率检查的结果。
 *
 * @param until 处于 [GuardState.RESTING] 时，恢复到什么时候（毫秒时间戳）；OK 时为 0
 * @param usedInWindow 本小时内已经互动了几条
 * @param limit 本小时的上限
 */
data class GuardVerdict(
    val state: GuardState,
    val until: Long,
    val usedInWindow: Int,
    val limit: Int
)

/**
 * 账号级「频率保护」。
 *
 * ★★ 这是从三个竞品里**唯一一个必须抄**的设计，也是它们最成熟的一块。
 *   豆星人的原话（`pages-build-rate_setting`）：
 *     「请根据自己的微博账号情况合理设置频率，以免造成账号频繁」
 *     「当一个账号 X 小时内盖楼数达到上限，系统会启动保护模式，让该账号休息 Y 小时」
 *   首页还写着「同一个微博账号在盖楼时请勿同时捞贴」。
 *
 *   ★ 为什么这条对我们尤其重要：星签的账号是**拿来签到的**。
 *     签到是「账号活着就有收益」的日常动作，而互动是「做多了会被限流」的高风险动作。
 *     如果没有这层保护，用户为了抢首评把某个账号刷到风控，
 *     赔掉的是这个账号**当天的签到**（甚至更久）—— 用主业的资产去赌副业的收益。
 *
 * ★ 边界（和 [SliderTrace] 同一条纪律，这一条尤其关键）：
 *   - 状态**按账号标签（字符串）记**，存在自己的私有文件 `interact_guard` 里。
 *   - **绝不写 [WeiboAccount] 上的任何一个字段** —— 尤其不写 `restUntil`。
 *     那个 `restUntil` 是签到链路 `ready()` 的过滤条件（`WeiboAccount.kt:389`），
 *     一旦被互动功能写脏，签到就会**静默跳过这个账号**，
 *     而这正是用户说的「不要影响我其他功能」里最危险的一种破法。
 *     这里用的名字是「互动休息」，和签到的「静置期」是两码事，两套状态各管各的。
 */
object RateGuard {

    private const val STORE_NAME = "interact_guard"
    private const val KEY_LIMIT = "hourly_limit"
    private const val KEY_REST = "rest_minutes"
    private const val KEY_STATE = "state"

    /** 默认每小时最多互动几条。 */
    const val DEFAULT_LIMIT = 5

    /** 默认触发保护后休息多少分钟。 */
    const val DEFAULT_REST_MINUTES = 60

    /** 上限的取值范围（用户可调）。 */
    const val MIN_LIMIT = 1
    const val MAX_LIMIT = 50

    /** 休息时长的取值范围（用户可调）。 */
    const val MIN_REST_MINUTES = 5
    const val MAX_REST_MINUTES = 720

    /** 计数窗口：1 小时。 */
    private const val WINDOW_MS = 3600_000L

    /**
     * ★★★★ 第 63 期：达到上限后，是否**真的按 1 小时窗口封顶**。
     *
     * 起因（2026-10-04 真机取证 + 夹具模拟 `_p62_rate_guard_test.py`）：
     *   用户把「每小时最多互动几条」设成 **1**、「触发后休息几分钟」设成 **5**。
     *   界面上承诺的是「每小时最多 1 条」，实际却是 **每 5 分钟 1 条 = 12 条/小时**。
     *
     * 病因：旧 `markRun` 达到上限时把 `windowStart` 与 `count` **一起清零**，
     *   `expireIfNeeded` 里休息到期时又清一次 ⇒ 1 小时的计数窗口**永远攒不满**，
     *   节流退化成「每 `rest_minutes` 一次」。
     *   `rest_minutes` 只要小于 60，实际频率就**超过**用户设的上限 ——
     *   用户想设成最保守，结果拿到最激进的一档，这比没有闸更危险。
     *
     * 本开关为 true 时：达到上限**不清窗口**，休息到 `max(now + 休息分钟, 窗口满 1 小时)`。
     *   · 上限 1 + 休息 5 分钟 ⇒ 1 条/小时（界面承诺成立）
     *   · 上限 5 + 休息 60 分钟 ⇒ 5 条/64 分钟（略保守，符合预期）
     *
     * ★ 一键回滚：改成 false ⇒ 逐字回到第 52 期那套「一休息就重开窗口」的行为。
     * ★ 注意：本文件不在七道闸门的覆盖范围里（既不是 CORE_KT / CHAIN_FILES，
     *   也不以 `Interact`/`Comment` 开头）—— 这是工具盲区，已记录在案。
     */
    @Volatile var capByHourWindow = true

    private class AccountGuard {
        var windowStart: Long = 0L
        var count: Int = 0
        var restUntil: Long = 0L
    }

    private val guards = HashMap<String, AccountGuard>()
    private var store: SharedPreferences? = null
    private var loaded = false
    private var limit = DEFAULT_LIMIT
    private var restMinutes = DEFAULT_REST_MINUTES

    /** 读盘。**必须在用之前调用一次**；同一进程内重复调用无副作用。 */
    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        val sp = try {
            context.applicationContext.getSharedPreferences(STORE_NAME, Context.MODE_PRIVATE)
        } catch (_: Throwable) {
            null
        }
        store = sp
        guards.clear()
        limit = clamp(sp?.getInt(KEY_LIMIT, DEFAULT_LIMIT) ?: DEFAULT_LIMIT, MIN_LIMIT, MAX_LIMIT)
        restMinutes = clamp(
            sp?.getInt(KEY_REST, DEFAULT_REST_MINUTES) ?: DEFAULT_REST_MINUTES,
            MIN_REST_MINUTES,
            MAX_REST_MINUTES
        )
        try {
            val raw = sp?.getString(KEY_STATE, "").orEmpty()
            if (raw.isNotBlank()) {
                val root = JSONObject(raw)
                val names = root.keys()
                while (names.hasNext()) {
                    val name = names.next()
                    val item = root.optJSONObject(name) ?: continue
                    val guard = AccountGuard()
                    guard.windowStart = item.optLong("windowStart")
                    guard.count = item.optInt("count")
                    guard.restUntil = item.optLong("restUntil")
                    guards[name] = guard
                }
            }
        } catch (_: Throwable) {
            guards.clear()
        }
        loaded = true
    }

    @Synchronized
    fun hourlyLimit(): Int = limit

    @Synchronized
    fun restMinutes(): Int = restMinutes

    @Synchronized
    fun setHourlyLimit(value: Int) {
        limit = clamp(value, MIN_LIMIT, MAX_LIMIT)
        store?.edit()?.putInt(KEY_LIMIT, limit)?.apply()
    }

    @Synchronized
    fun setRestMinutes(value: Int) {
        restMinutes = clamp(value, MIN_REST_MINUTES, MAX_REST_MINUTES)
        store?.edit()?.putInt(KEY_REST, restMinutes)?.apply()
    }

    /**
     * 查这个账号现在能不能动。
     *
     * ★ 这个方法**只读**（顺带清理过期的休息状态），不会因为「查了一下」就把账号推进休息。
     */
    @Synchronized
    fun verdict(accountLabel: String): GuardVerdict {
        val guard = guards[accountLabel] ?: return GuardVerdict(GuardState.OK, 0L, 0, limit)
        expireIfNeeded(guard)
        if (guard.restUntil > System.currentTimeMillis()) {
            return GuardVerdict(GuardState.RESTING, guard.restUntil, guard.count, limit)
        }
        return GuardVerdict(GuardState.OK, 0L, guard.count, limit)
    }

    /**
     * 记一次「真的做了」。
     *
     * ★ 第 52 期原实现：计数到上限时**立刻进入休息并把本轮计数与窗口一起清零**。
     *   清窗口的理由是「不清零的话，休息结束后计数仍然 ≥ 上限，会马上再次触发休息，
     *   账号就永远出不来了」—— 这个担心本身是对的，但**清错了东西**：
     *   它把「1 小时的计数窗口」也一起清掉了 ⇒ 窗口永远攒不满 ⇒
     *   `rest_minutes < 60` 时实际频率**超过**用户设的每小时上限（第 63 期实测 12 倍）。
     *
     * ★ 第 63 期改法：**不清窗口**，只把休息结束时间钉在
     *   `max(now + 休息分钟, 窗口起点 + 1 小时)` —— 休息结束时窗口必然也到期，
     *   计数自然归零，既不会「出不来」，又真的按小时封顶。
     *   `capByHourWindow = false` 时逐字回到第 52 期的行为。
     *
     * @return 记录之后的状态（调用方据此决定要不要提示用户）
     */
    @Synchronized
    fun markRun(accountLabel: String): GuardVerdict {
        val guard = guards.getOrPut(accountLabel) { AccountGuard() }
        val now = System.currentTimeMillis()
        expireIfNeeded(guard)
        // 本窗口的第一次：把窗口起点钉在现在，1 小时后计数自动归零。
        if (guard.windowStart == 0L) guard.windowStart = now
        guard.count += 1
        if (guard.count >= limit) {
            guard.restUntil = if (capByHourWindow) {
                // ★ 第 63 期：休息至少要撑到「本窗口满 1 小时」，否则封顶就落空。
                val byRest = now + restMinutes * 60_000L
                val byWindow = guard.windowStart + WINDOW_MS
                if (byWindow > byRest) byWindow else byRest
            } else {
                // ★ 回滚档：逐字回到第 52 期 —— 休息的同时把计数与窗口一起清掉。
                guard.count = 0
                guard.windowStart = 0L
                now + restMinutes * 60_000L
            }
            save()
            return GuardVerdict(GuardState.RESTING, guard.restUntil, guard.count, limit)
        }
        save()
        return GuardVerdict(GuardState.OK, 0L, guard.count, limit)
    }

    /** 手动把某个账号从休息里放出来（用户觉得自己心里有数时用）。 */
    @Synchronized
    fun reset(accountLabel: String) {
        guards.remove(accountLabel)
        save()
    }

    /** 清掉所有账号的互动计数与休息状态。 */
    @Synchronized
    fun resetAll() {
        guards.clear()
        save()
    }

    /** 休息到期就清干净；顺带处理「跨了窗口」的计数。 */
    private fun expireIfNeeded(guard: AccountGuard) {
        val now = System.currentTimeMillis()
        if (guard.restUntil > 0L && now >= guard.restUntil) {
            guard.restUntil = 0L
            // ★★★★ 第 63 期：**不再**在这里顺手清 count / windowStart。
            //   旧实现在这里把计数一起清掉（配合 markRun 里那两行），等于「一休息就重开窗口」，
            //   1 小时的窗口永远攒不满 ⇒ 「每小时最多互动几条」形同虚设。
            //   计数的归零只交给下面那个**真正的窗口过期判断**。
            if (!capByHourWindow) {
                // ★ 回滚档：逐字回到第 52 期 —— 休息到期时把计数与窗口一起清掉。
                guard.count = 0
                guard.windowStart = 0L
            }
        }
        if (guard.windowStart > 0L && now - guard.windowStart >= WINDOW_MS) {
            guard.count = 0
            guard.windowStart = 0L
        }
    }

    private fun clamp(value: Int, min: Int, max: Int): Int = when {
        value < min -> min
        value > max -> max
        else -> value
    }

    private fun save() {
        val sp = store ?: return
        try {
            val root = JSONObject()
            for ((name, guard) in guards) {
                root.put(
                    name,
                    JSONObject()
                        .put("windowStart", guard.windowStart)
                        .put("count", guard.count)
                        .put("restUntil", guard.restUntil)
                )
            }
            sp.edit().putString(KEY_STATE, root.toString()).apply()
        } catch (_: Throwable) {
        }
    }
}
