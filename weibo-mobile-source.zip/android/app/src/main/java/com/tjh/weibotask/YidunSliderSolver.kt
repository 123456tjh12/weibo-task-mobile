package com.tjh.weibotask

import android.graphics.Bitmap

/**
 * 易盾滑块缺口识别。
 *
 * 输入：bg 背景图、front 拼图块（带透明通道）。
 * 输出：缺口左边缘在背景图里的像素 x，以及拼图块在 front 图内的水平偏移。
 *
 * ★★★ 第 94 期：**输入图的尺寸不固定** —— 早先这里写「320x160 / 60x158」，那只是
 *   **1 倍图**那一种情况；易盾会按机型 / 随机次下发 **2 倍图（640x…）** 等其它尺寸。
 *   本文件与 `SliderMatch` **全程逐像素、零缩放** ⇒ 返回的 `gapLeft` 与
 *   `bg.width` 处于**同一坐标系**（即「本题实际下发的原图」）。
 *
 * 说明：拖动距离最终由调用方换算 —— 分母必须是**本题实际的原图宽**，不能写死：
 *   拖动CSSpx = gapLeft * (bg渲染宽度 / bg原图宽) - pieceOffsetX * (拼图块渲染宽度 / 拼图块原图宽)
 * `bg原图宽` / `拼图块原图宽` 由调用方从解码出的 `Bitmap.width` 取（见 `YidunAutoSlider.scheduleDrag`）。
 * 拼图块在 front 图内的偏移以每次实际 bbox 为准（1 倍图实测约 2px）。
 *
 * ════════════════════════════════════════════════════════════════════════════
 * ★★★ 第 73 期 B：**已删掉 OpenCV** —— 本文件只剩纯 Kotlin 一条路径
 * ════════════════════════════════════════════════════════════════════════════
 * 第 73 期 A 先把实现换成 `SliderMatch`（纯 Kotlin），但**保留**了 OpenCV 路径与
 * 两个开关（`usePureKotlin` / `abProbe`）；本期 B 把旧路径与依赖一起删掉。
 *
 * ★ A 期已把 `usePureKotlin = true` 设为生效路径，所以 B 期**只删死代码、不改行为**：
 *   删掉的 `solveOpenCv()` 在此之前**已经永远不会被调用**。
 *
 * 删 OpenCV 的理由：
 *   它带进来 `libopencv_java4.so`(16.39MB) + `libc++_shared.so`(5.95MB) = 原 APK 的 76%，
 *   且两个 .so 的 ELF PT_LOAD 对齐**均为 4096** ⇒ 16KB 页手机 `dlopen` 必失败。
 *   删后 APK 由 29.52 MB 降到 ≈7.2 MB。
 *
 * ════════════════════════════════════════════════════════════════════════════
 * 等价性证据（分两层，都是**真编译代码跑真实素材**，不是推理）
 * ════════════════════════════════════════════════════════════════════════════
 * ① 算法层（第 72 期 · 8 组真实滑块样本，纯 Kotlin vs OpenCV）：
 *      max_loc 与整数缺口 **8/8 完全相同**；max_val 最大绝对差 2.98e-06。
 *      复现工具：`_cv_replica/v72/`。
 *
 * ② 转换层（第 73 期 A 补充取证 · 8 组**真机真实样本** × 6 变体）：
 *      唯一没被 ① 覆盖的一环是「`Bitmap` → RGBA 字节」。两条路（`getPixels()` 反预乘
 *      vs 已删的 `bitmapToMat(unpremultiplyAlpha = true)`）读的是**同一个 Bitmap**，
 *      所以差异只可能出在反预乘取整上，**每个通道最多差 1**。
 *      把 front 图里所有 mask 内半透明像素统一 ±1（即上界）后：
 *        · `max_loc` **0/8 翻转**
 *        · 最大 |ΔgapLeft| **0.0071 px**（判据阈 0.1，低 14 倍）
 *        · `bbox` / `pieceOffsetX` 在所有变体下完全相同（只由 alpha 决定，反预乘不动 alpha）
 *        · bg 是 JPEG（无 alpha）⇒ 反预乘是空操作 ⇒ 两条路逐字节相同
 *      余量约 5 倍：扰动放大到 ±5 才出现 1 组翻转。
 *      复现工具：`_p73_ab_bound/SliderRunner74.java`（依赖 `_cv_replica/v73/out`）。
 *
 * ★ 对外契约零变化：`GapResult` 三个字段名与类型逐字不变，
 *   调用方 `YidunAutoSlider.kt:873/:909` 一行都不用改。
 */
object YidunSliderSolver {

    data class GapResult(
        /** 缺口左边缘在 bg 背景图里的像素 x（亚像素精化后）。★ 坐标系 = **本题实际下发的原图**（`bg.width`），尺寸随机型/次变，不是固定 320。 */
        val gapLeft: Float,
        /** 拼图块非透明区域在 front 图内的左偏移（1 倍图实测约 2px，随下发尺寸变） */
        val pieceOffsetX: Int,
        /** 模板匹配相关度（0~1，越高越可信）。★ 调用方**只把它写进日志**，不参与判定。 */
        val score: Double
    )

    /**
     * 识别缺口位置。
     * @param bg    背景图 Bitmap（**尺寸不固定**：1 倍图 320x160、2 倍图 640x320… 以实际下发为准）
     * @param front 拼图块 Bitmap（含 alpha 通道）
     * @return 识别结果；失败返回 null
     */
    fun solve(bg: Bitmap, front: Bitmap): GapResult? {
        try {
            val r = SliderMatch.solve(bitmapToRgba(bg), bitmapToRgba(front)) ?: return null
            return GapResult(
                gapLeft = r.gapLeft,
                pieceOffsetX = r.pieceOffsetX,
                score = r.score
            )
        } catch (_: Throwable) {
            return null
        }
    }

    /**
     * `Bitmap`(ARGB_8888) → RGBA 四通道字节数组。
     *
     * ★ 布局与 OpenCV `CV_8UC4` 逐字节对应：`data[(y*width+x)*4 + c]`，c: 0=R 1=G 2=B 3=A。
     * ★ `Bitmap.getPixels()` 返回的是**非预乘** ARGB（int 高字节是 A）。
     * ★ 调用方 `YidunAutoSlider` 解码时用的是 `inPreferredConfig = ARGB_8888`（`:1217`），
     *   所以这里不必再做一次 `copy()` 转配置。
     */
    private fun bitmapToRgba(bmp: Bitmap): SliderMatch.ImageRGBA {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val data = ByteArray(w * h * 4)
        var i = 0
        while (i < px.size) {
            val p = px[i]
            data[i * 4] = ((p ushr 16) and 0xFF).toByte()      // R
            data[i * 4 + 1] = ((p ushr 8) and 0xFF).toByte()   // G
            data[i * 4 + 2] = (p and 0xFF).toByte()            // B
            data[i * 4 + 3] = ((p ushr 24) and 0xFF).toByte()  // A
            i++
        }
        return SliderMatch.ImageRGBA(w, h, data)
    }
}
