package com.tjh.weibotask

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import android.webkit.WebView
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/**
 * 易盾滑块自动处理：检测验证码 -> 下载图片 -> 本机识别缺口 -> 拖动。
 *
 * 设计要点：
 * 1. 缺口识别跑在手机本地（OpenCV），不依赖电脑。
 * 2. 拖动方式由 `useTrustedTouchForDrag` 决定（**第 38 期起默认 `false`**）：
 *    - `false`（当前）＝ 页面内 JS 注入合成 `pointermove` 串（`jsDrag`）。
 *      ★ 这是**实测唯一能驱动滑块**的方式 —— 第 36 期 4 次拖动缺口 x 每次都变（= 滑块动了）。
 *    - `true` ＝ `dispatchTrack` 注入真实 `MotionEvent`（DOWN + 24×MOVE + UP）。
 *      ★ 第 37 期试过，**实测无效**：24 步全部投递成功，但 Chromium 侧
 *        没有生成 `pointermove` / `pointerup`（`pointerup` 恒为 0），滑块一动不动。
 *        详见 `useTrustedTouchForDrag` 的注释。
 * 3. 轨迹：加速-匀速-减速 + 轻微纵向抖动，时长随距离缩放。
 * 4. 最多自动尝试 `maxAttempts`（= 8）次，超过后停手，由用户手动完成（避免风险分越刷越高）。
 *
 * ★ 类头这四行长期与代码不符（旧版写着「拖动使用 Android 原生 MotionEvent 注入…
 *   不是 JS dispatchEvent 伪造」「最多自动尝试 3 次」）。第 38 期顺手改成与事实一致。
 */
class YidunAutoSlider(
    private val webView: WebView,
    private val onLog: (String) -> Unit = {}
) {

    @Volatile private var running = false
    @Volatile private var stopped = false
    @Volatile private var solving = false
    @Volatile private var pageReady = false
    private var lastSolvedBg = ""
    private var attempts = 0

    /** 同一张验证图连续出现的次数 */
    private var sameBgPolls = 0

    /**
     * ★★ 第 38 期：同一张验证图连续出现的**上限**。
     *
     * 原来这个计数**没有上限**（第 35 期「只留痕、不改判定 —— 等拿到证据再决定要不要收口」），
     * 于是「拖完不换图」时循环会**死转**：真机实测 `重复 1 → 180 次`，**白耗约 108 秒**，
     * 而且 `attempts` 不增 ⇒ 8 次机会只用了 1 次，还把整轮时间吃光。
     *
     * 现在证据到了，收口：连续这么多次同一张图就判「这次拖动没起作用」，
     * **打一条明确的日志后退出本轮**（不再空转）。
     * ★ 取值依据：第 36 期真机里「拖成功后页面跳走」只用了 **1 次**同图轮询，
     *   所以 12 次（约 8 秒）足够宽松，不会误伤「成功但页面还没跳」的情况。
     */
    private val sameBgLimit = 12

    /**
     * ★ 第 38 期：验证码**曾经出现过**。
     *
     * 只用于一条**纯读**日志 —— 把「验证码消失」和「压根没出验证码」这两件事分开
     * （原来它们混在同一个 `state == null` 分支里，事后无从分辨）。
     * **不参与任何判定**：成功判定仍然只走 `OverlayVerifyHost.onPageStarted` 的域名规则。
     */
    private var captchaEverSeen = false

    /**
     * ★★★ 第 61 期：本轮**已经**留过「页面上只有点不动的按钮」这条痕了。
     *
     * 为什么需要：`tapCheckinButton()` 找不到真正的「签到」按钮时返回 `false`，
     * 而 `loop()` 每 600ms 就会再调它一次 —— 不加这个闸门，30 秒里会刷 50 条同样的日志。
     * 每个页面只留一次（`onPageStarted` / `start` / `restart` 都会复位）。
     * **不参与任何判定**，只影响日志条数。
     */
    @Volatile private var deadBtnLogged = false

    /** 最多自动拖动次数，超过后停手让用户手动划 */
    var maxAttempts = 8

    /**
     * 落点校准（CSS 像素）：正数 = 多拖一点，负数 = 少拖一点。
     * 当前：落点稳定偏左一个缺口突块，需要多拖。
     */
    var dragOffsetCss = 8f

    /**
     * ★★★ 第 39 期：本轮自动处理「用尽机会仍失败」时的回调。
     *
     * ## 默认值
     *
     * **`null` = 不回调** ⇒ 行为与第 38 期**逐字节相同**。
     *
     * ## 谁挂它
     *
     * **只有 `OverlayVerifyHost`**（全自动那条路）。
     * `WeiboLoginActivity`（用户手动点通知打开验证页的兜底路径）**不挂** ⇒
     * 那条路上这个回调恒为 `null`，一个字都不变。
     *
     * ## 什么时候触发
     *
     * `loop()` 退出、且**不是因为 `stop()`** 时触发一次，覆盖三种「失败收尾」：
     *   ① 8 次机会用满（`attempts >= maxAttempts`）
     *   ② 拖完验证图连续 12 次未刷新（`sameBgPolls >= sameBgLimit`）
     *   ③ 30 秒没等到验证码（`idlePolls > 50`）
     *
     * ★★★ **③ 同时「也是验证成功的形状」**（验证码消失 → 页面跳走 → `onVerifySuccess`
     *   → `finishCurrent()` ⇒ `stopped = true`）。所以接收方**必须自己先看 `finished`
     *   与 `running`**，否则会在成功之后又去重挂一次。
     *
     * ## 为什么要有它
     *
     * 第 38 期真机结论：`jsDrag` 单次拖动命中率大约 1/3，而一轮只有 8 次机会。
     * 用户 2026-10-01 的要求是「失败后重新挂一次再试」，上限 2 轮（约 3 个会话）。
     *
     * ★ 只是「多打一个回调」：滑块识别 / 缺口计算 / 拖动轨迹 / 成功判定 / 数据层一字未动。
     */
    var onGaveUp: (() -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    /** 是否已经自动点过签到按钮（避免重复点） */
    @Volatile
    private var checkinClicked = false

    companion object {
        /**
         * ★★ 第 33 期实验开关（P1）：「点签到」用哪种方式点。
         *
         * - `true` （本轮默认）＝ 用**页面内 JS 合成点击**（`element.dispatchEvent`
         *   一串 pointerdown/mousedown/pointerup/mouseup/click）。
         *   它**完全不经过系统触摸分发**，所以不要求窗口「可见 / 可聚焦 / 可触摸」，
         *   也不要求页面处于前台可见状态（同步执行，不依赖页面定时器）。
         * - `false` ＝ 恢复第 32 期行为（无障碍 `dispatchGesture` 真实 tap，走系统触摸管线）。
         *
         * 为什么做这个实验：第 31 期的系统层取证显示，锁屏时我们的悬浮窗
         * `inputConfig=NOT_VISIBLE`、触摸被 NotificationShade 独占，真实 tap
         * **根本到不了页面**。若换成不依赖触摸分发的 JS 点击后滑块能被唤起来，
         * 就说明「点签到」这一环的瓶颈确实是系统触摸，而非页面本身。
         *
         * ★ 只换「点」这个动作；滑块识别 / 缺口计算 / 拖动轨迹 / 成功判定 / 数据层
         *   一字未动。翻回 `false` 即可逐字节回到第 32 期。
         */
        @Volatile
        var useJsClickForCheckin = true

        /**
         * ★★★ 第 36 期实验开关（P2）：「点签到」优先用 **WebView 真实触摸**。
         *
         * - `true`（本轮默认）＝ 用 `webView.dispatchTouchEvent()` 注入一对真实
         *   `MotionEvent`（ACTION_DOWN + ACTION_UP）。这条路径走 **WebView 自己的输入管线**，
         *   所以同时得到两样合成事件给不了的东西：
         *     ① 事件 `isTrusted=true`；
         *     ② 真正产生 **user activation**（`navigator.userActivation.hasBeenActive` 变 true）。
         * - `false` ＝ 逐字节恢复第 35 期行为（页面内 JS `dispatchEvent` 合成点击）。
         *
         * ## 为什么做这个实验
         *
         * 第 35 期真机报告已经证实两件事：
         *   ① **点击确实触发了签到请求** —— 探针里 `page/checkin#t2624` 与点击行的
         *      `@2620` 只差 4 ms，服务端回 200。⇒ 瓶颈**不在「点不动」**。
         *   ② 同一份报告里探针读到 **`ua=00`** —— 页面从头到尾**没见过一次真实用户手势**
         *      （`dispatchEvent` 合成事件不产生 user activation）。
         *
         * 所以问题落在**签到 POST 之后**：页面的回包处理器什么都不做。而处理器可能的三道门
         * 恰好都与 user activation 相关：
         *   ① `window.open(scheme)` 打开验证窗 —— **无 user activation 时 Chromium 直接拦掉**；
         *   ② `alert()/confirm()` 提示 —— 本工程 `WebChromeClient` 是默认实现，什么都不显示，
         *      且 `onJsConfirm` 直接返回 false（等于用户点了「取消」）；
         *   ③ 处理器自己读 `navigator.userActivation` 决定要不要弹验证。
         * 真实触摸能同时满足 ①②③ 的前提条件 —— 一条改动覆盖三种解释。
         *
         * ## 坐标
         *
         * 必须是 **WebView 本地像素**：`(left + width/2) * (webView.width / clientW)`，
         * **不加** `getLocationOnScreen()`（那条换算链是给「系统级触摸」用的，本机实测 ≈ (917.0, 782.5)）。
         * 也正因为走 View 自己、**不经过系统窗口分发**，窗口不可见 / 不可触摸 / 锁屏都不影响
         * （第 31 期证明的「触摸送不到」在这条路径上不成立）。
         *
         * ★ 只换「怎么点」；滑块识别 / 缺口计算 / 拖动轨迹 / 成功判定 / 数据层一字未动。
         */
        @Volatile
        var useTrustedTouchForCheckin = true

        /**
         * ★★★ 第 37 期实验开关（P3）：「拖滑块」用哪种方式。
         *
         * - `true`（本轮默认）＝ 用 `webView.dispatchTouchEvent()` 注入**真实触摸序列**
         *   （`ACTION_DOWN` + 24 个 `ACTION_MOVE` + `ACTION_UP`，`source = SOURCE_TOUCHSCREEN`），
         *   走 WebView 自己的输入管线 ⇒ **`isTrusted=true` 且真正产生 user activation**。
         * - `false` ＝ 逐字节恢复第 36 期行为（页面内 JS `dispatchEvent` 合成 `pointermove` 串）。
         *
         * ## 为什么做这个实验
         *
         * 第 36 期真机已经用**同一个手法**把「点签到」修好了：换成真实触摸后，
         * 点击后 **0.687 秒**页面就跳到了 `security.weibo.com/captcha/geetest`，
         * 探针读出 **`bg=1 jig=1`（滑块第一次出现）**。
         * ⇒ 「这个页面按『有没有真实手势』分支」已被证实。
         *
         * 而**拖动这一环还是合成事件**：`jsDrag` 用页面内 `setTimeout` 分 24 步
         * `dispatchEvent` 发 `pointermove` —— `isTrusted=false`、不产生 user activation。
         * 真机实测：滑块出现后**拖了 4 次都没过**
         * （缺口 139.1 / 166.8 / 17.6 / 243.1，可信度 0.93~0.94，每次都换来一张新图）。
         * 易盾的滑块正是最可能校验 `isTrusted` / user activation 的地方。
         *
         * ## 为什么改动量极小
         *
         * `buildTrack()` 与 `dispatchTrack()` 是**项目里早就写好、却从来没有被调用过的死代码**
         * （全项目 grep 零调用点），而且 `scheduleDrag()` 里算出来的
         * `startX` / `startY` / `dist` **本来就是按 WebView 本地像素算的**
         * （`(kLeft + kWidth/2) * scale`，**不加** `getLocationOnScreen()`）——
         * 那三个 `Variable 'startX'/'startY' is never used` 编译告警就是它们留下的。
         * 所以本轮只是**把现成的东西接上**，没有另写一套轨迹算法。
         *
         * ★ 轨迹本身一个字没改：仍是 24 步、ease-in-out、±1.2px 纵向抖动、时长随距离缩放。
         * ★ 只换「怎么把轨迹发出去」；滑块识别 / 缺口计算 / 成功判定 / 数据层一字未动。
         *
         * ## ★★★ 第 38 期结论：这条路**走不通**，默认已翻回 `false`
         *
         * 真机实测（`87/0.20.46`，2026-09-30 23:30）——**序列发得完美，滑块却一动不动**：
         *   · 投递成功：`[触摸] action=0` + **24 个 `action=2`** + `action=1`，
         *     收尾 `[拖动] P3 真实触摸序列已发完 步数=24 用时ms=1354 终点=(1125,1591)`；
         *   · **但探针前后都是 `bg=1 jig=1 cap=93`** —— 验证码原封不动；
         *   · 探针 `ev=1,1,1,0,0,0,0` = touchstart 1 / touchend 1 / pointerdown 1 / **`pointerup` 0**，
         *     而 `it=22/0` 说明页面确实收到了 22 个 **trusted** 事件（含 `touchmove`）。
         *   ⇒ **触摸事件到了，但 Chromium 那侧的 `pointermove` / `pointerup` 没有生成**
         *     （`pointerup` 恒为 0 是铁证）⇒ 易盾滑块走 pointer 事件 ⇒ **没被驱动**。
         *
         * 对照组：第 36 期 22:00 那次用的是 **`jsDrag`**（页面内合成 `pointermove`），
         * 4 次拖动**缺口 x 每次都变**（`139.1 → 166.8 → 17.6 → 243.1`）
         * ⇒ **拖动确实驱动了滑块**（被拒，但动了）。**它才是「能动的那一个」。**
         *
         * ★★ 教训：「真实触摸」**不是万能钥匙**。第 36 期它救活了**点击**
         *   （页面按 user activation 分支 ⇒ 滑块第一次出现），但**拖动**这条路上它反而更差。
         *   同一个手法、两条链路、结论相反 —— 别再默认「真实 ≥ 合成」。
         *
         * ★ 开关保留，方便以后换思路再试；`false` = 恢复第 36 期的 `jsDrag`。
         */
        @Volatile
        var useTrustedTouchForDrag = false

        /**
         * ★★★ 第 61 期（用户批准，属链路③「点签到」识别层）：「签到按钮」是否用**严格判据**。
         *
         * - `true`（本轮默认）＝ 只认真正的「签到」按钮 —— **排除**文案里含「已签」的
         *   （即「已签到」/「今日已签到」）。
         * - `false` ＝ 逐字节恢复第 60 期行为（`indexOf('签到') >= 0`，「已签到」也算命中）。
         *
         * ## 为什么必须改
         *
         * `'已签到'.indexOf('签到') === 0` ⇒ 旧判据把「已签到」也当成签到按钮。
         * 而「已签到」点下去微博**什么都不做**（不签、不发请求、不弹验证码），
         * 于是验证流程连点 `1 + maxSliderRearms` 轮、每轮干等 30 秒，最后
         * 「已重挂 2/2 轮仍未过，停手」⇒ `needsVerify` 留着不清 ⇒ 该账号被
         * `!needsVerify` 过滤出待签池 ⇒ **当天再也不会自动去签它**。
         *
         * 真机实证（第 60 期报告 + 手机 `slider_trace.xml`）——「文本=已签到」共 5 次，
         * 每一次后面都紧跟着「30 秒内没等到验证码」→「已重挂 2/2 轮仍未过，停手」：
         *   · 10-02 16:31:00 / 16:31:46 / 16:32:33（然妈爱吃汉堡包）
         *   · 10-04 09:47:39 / 09:48:27（用户8242606810）
         *
         * ## 这条判据**不是新发明**
         *
         * 无障碍那条路（`WeiboClient.kt:867`）从一开始就是对的：
         * `buttonName.contains("签到") && !buttonName.contains("已签")`。
         * 本开关只是把 JS 这条路**对齐到同一条判据**，并把它收敛成**全工程唯一一份**
         * （见 `jsCheckinBtnHelper()`）—— 三处调用点共用，不会再各写一份走样。
         *
         * ## 一个字没动什么
         *
         * 滑块的识别 / 缺口计算 / 拖动轨迹 / **成功判定**全部未动；
         * 只决定「点哪个元素」，不决定「这一轮算不算过」。数据层未动。
         *
         * ## 一键回滚
         *
         * 置 `false` ⇒ 逐字节回到第 60 期的按钮匹配。
         */
        @Volatile
        var strictCheckinButtonText = true
    }

    fun start() {
        if (running) return
        running = true
        stopped = false
        deadBtnLogged = false
        Thread { loop() }.start()
    }

    fun stop() {
        stopped = true
        pageReady = false
        // 取消所有待执行的回调（识别轮询 + 手势事件），防止 WebView 销毁后还被调用
        mainHandler.removeCallbacksAndMessages(null)
    }

    /**
     * ★★★ 第 39 期：把这一轮复位成「刚 `start()`」的状态，再跑一轮。
     *
     * 为什么不直接再调 `start()`：`attempts` 已经等于 `maxAttempts`，
     * `while (!stopped && attempts < maxAttempts)` 会**立刻退出**，等于什么都没做。
     * 所以必须把 `attempts` / `sameBgPolls` / `lastSolvedBg` / `checkinClicked` /
     * `captchaEverSeen` / `pageReady` 全部复位。
     *
     * ★ 闸门用 `running` 与 `stopped` 两个 `@Volatile`：
     *   · `running == true` ⇒ 上一轮还在跑，拒绝；
     *   · `stopped == true` ⇒ 宿主已经 `stop()` 过（例如 `finishCurrent()` 收摊），拒绝。
     *   两个都读到 false 才动手，`@Volatile` 自带 happens-before ⇒ 复位不会与旧线程打架。
     * ★ `stopped` 复位成 `false`：重挂是「再来一轮」，不是「停止」。
     */
    fun restart() {
        if (running || stopped) return
        attempts = 0
        sameBgPolls = 0
        lastSolvedBg = ""
        checkinClicked = false
        captchaEverSeen = false
        deadBtnLogged = false
        pageReady = false
        running = true
        stopped = false
        Thread { loop() }.start()
    }

    /** 页面开始跳转时调用（暂停轮询，避免导航中调用 JS 导致渲染进程崩溃） */
    fun onPageStarted() {
        pageReady = false
        checkinClicked = false
        // ★ 第 61 期：换页了 ⇒ 允许再留一次「页面上只有点不动的按钮」的痕（每页一条）。
        deadBtnLogged = false
    }

    /** 页面加载完成时调用 */
    fun onPageFinished() {
        if (stopped) return
        pageReady = true
    }

    private fun loop() {
        var idlePolls = 0
        while (!stopped && attempts < maxAttempts) {
            // ① 先尝试自动点「签到」（触发滑块）——优先无障碍真实点击，JS 注入为兜底
            if (pageReady && !checkinClicked) {
                if (tapCheckinButton()) {
                    checkinClicked = true
                    onLog("已自动点击签到按钮")
                }
            }
            // ② 检查滑块
            val state = readCaptchaState()
            if (state == null) {
                idlePolls++
                // ★★ 第 38 期：纯读把「验证码消失」和「压根没出验证码」分开 ——
                //   原来这两件事混在同一个分支里，事后完全无从分辨。
                //   见过滑块 + 拖过 + 现在它没了 = 「验证成功」的形状。
                //   ★ **只打一行日志，不参与判定**：成功判定仍只走 onPageStarted 的域名规则。
                if (idlePolls == 1 && captchaEverSeen && attempts >= 1) {
                    onLog("验证码已消失（曾出现过且已拖动 " + attempts + " 次）—— 疑似验证成功，等页面跳转判定")
                }
                // 连续 30 秒没看到验证码就退出（可能已经验证成功或不需要验证）
                if (idlePolls > 50) {
                    // ★ 这条原来完全静默：滑块到底有没有出现过，事后无从判断。
                    onLog(
                        "30 秒内没等到验证码（点签到=" + checkinClicked +
                            "，曾出现过=" + captchaEverSeen + "，已拖动 " + attempts + " 次），停止自动处理"
                    )
                    onLog("[现场] " + dumpPageState())
                    break
                }
                sleep(600)
                continue
            }
            idlePolls = 0
            captchaEverSeen = true
            val (bgUrl, jigsawUrl) = state
            if (bgUrl == lastSolvedBg) {
                // ★★ 第 38 期：**收口**。原来这里没有上限 —— 拖完不换图就死转，
                //   真机实测 `重复 1 → 180 次`（约 108 秒），attempts 不增 ⇒ 8 次机会只用 1 次。
                sameBgPolls++
                if (sameBgPolls == 1 || sameBgPolls >= sameBgLimit) {
                    onLog("验证图未刷新，重复 " + sameBgPolls + " 次（已尝试 " + attempts + " 次）")
                }
                if (sameBgPolls >= sameBgLimit) {
                    onLog(
                        "拖动后验证图连续 " + sameBgLimit + " 次未刷新（上限 " + sameBgLimit +
                            " 次），判定这次拖动没起作用，结束本轮自动处理"
                    )
                    break
                }
                sleep(600)
                continue
            }
            sameBgPolls = 0
            lastSolvedBg = bgUrl
            if (solving) {
                sleep(600)
                continue
            }
            solving = true
            try {
                solveOnce(bgUrl, jigsawUrl)
            } finally {
                solving = false
            }
        }
        running = false
        // ★ 收尾必须留痕：「用满次数」「被停止」「等到验证码」，三种结局完全不同。
        onLog("自动滑块结束：已尝试 " + attempts + "/" + maxAttempts + " 次")
        // ★★★ 第 39 期：不是被 stop() 停掉的 ⇒ 这是一次「失败收尾」，交给宿主决定要不要重挂。
        //   ★ 接收方（OverlayVerifyHost.scheduleRearm）会先查 finished / running，
        //     所以「30 秒没等到验证码」这条**同时也是成功形状**的路径不会被误重挂。
        //   ★ onGaveUp 为 null（默认，例如 WeiboLoginActivity 那条路）时这里什么都不做。
        if (!stopped) onGaveUp?.invoke()
    }

    /**
     * 放弃前抓一次现场：当前地址 + 三个关键选择器是否存在。
     *
     * ★ 只在「30 秒没等到验证码」这一条收尾路径上跑一次，之后再无任何动作，
     *   因此不可能影响滑块本身的判定。
     */
    private fun dumpPageState(): String {
        val js = """
            (function(){
              var b = document.querySelector('.yidun_bg-img');
              var j = document.querySelector('.yidun_jigsaw');
              var k = document.querySelector('.yidun_slider');
              return 'bg=' + (b?1:0) + ' jigsaw=' + (j?1:0) + ' slider=' + (k?1:0) +
                     ' title=' + document.title + ' url=' + location.href;
            })()
        """.trimIndent()
        return evalJs(js) ?: "(读取失败)"
    }

    /**
     * ★★ 第 34 期诊断：纯读「点击后页面反应快照」。★ 第 35 期补时间戳。
     *
     * 回答第 33 期报告答不了的那个问题：JS 合成点击「事件到了 document、页面却零反应」，
     * 到底是 ① 页面的点击处理器**压根没跑**，还是 ② 处理器跑了但**微博不出滑块**？
     * —— 这两条的下一步完全不同，所以必须先分开。
     *
     * 三条线索：
     *   ① **页面有没有真的发出网络请求** —— 读 `performance.getEntriesByType('resource')`，
     *      **不 hook fetch / XMLHttpRequest、不改页面**。
     *      ★★ 第 35 期：每条挂上 `#t<startTime> d<duration> s<responseStatus>`，
     *      并附 `now=<performance.now()>`；与点击返回值里的 `@<performance.now()>` 一比，
     *      才能定死「这条请求是点击触发的、还是页面加载时就发的」——
     *      第 34 期就是因为没有时间戳，`req=` 里的 checkin 成了两可证据，白跑一轮。
     *   ② 页面上有没有新冒出来的**可见提示文案**（含 验证/异常/身份/滑块 等关键词，最多 3 条）。
     *   ③ 签到按钮文案 —— 看有没有从「签到」变成「已签到」。
     *      ★ 第 35 期删掉 `title=`/`url=`：同一轮的「P1 JS 点击后现场」已经打过，且全程没变过。
     *   ④ ★★ 第 36 期新增 `net=`：页面**自己那次请求的回包原文**（数据来自
     *      `OverlayVerifyHost.NET_HOOK_JS` 装的纯读钩子）——风控话术与验证地址都在回包体里。
     *
     * ★ **纯读**：只读 DOM 与 performance、只拼字符串、只返回给日志。
     *   不改页面、不发请求、不参与任何判定。整段删掉不影响任何功能。
     */
    private fun dumpPageReaction(): String {
        val js = """
            (function(){
              var out = [];
              try {
                var rs = performance.getEntriesByType('resource') || [];
                var hits = [];
                for (var i = rs.length - 1; i >= 0 && hits.length < 4; i--) {
                  var e = rs[i] || {};
                  var n = e.name || '';
                  if (n.indexOf('necapcha') >= 0 || n.indexOf('captcha') >= 0 || n.indexOf('yidun') >= 0 ||
                      n.indexOf('sign') >= 0 || n.indexOf('checkin') >= 0 || n.indexOf('verify') >= 0 ||
                      n.indexOf('slide') >= 0 || n.indexOf('aj/') >= 0 || n.indexOf('proxy') >= 0 ||
                      n.indexOf('/api/') >= 0) {
                    // ★ 第 35 期：名字后面挂上 t=startTime(相对导航开始,ms) / d=duration / s=responseStatus。
                    //   没有时间戳时，「req= 里有 checkin」是两可证据（页面加载时也会发），
                    //   跟点击时刻一比才能定死。★ 过滤词补了 yidun/verify/slide ——
                    //   易盾 SDK 的脚本名里既没有 captcha 也没有 sign，原来会被整条漏掉。
                    hits.push(n.split('?')[0].slice(-48) +
                              '#t' + Math.round(e.startTime || 0) +
                              ' d' + Math.round(e.duration || 0) +
                              ' s' + (e.responseStatus || '-'));
                  }
                }
                out.push('req=' + (hits.length ? hits.reverse().join(' ; ') : '(无)') +
                         ' 总数=' + rs.length + ' now=' + Math.round(performance.now()));
              } catch(e) { out.push('req=err'); }
              try {
                var kw = /验证|异常|安全|身份|滑块|拖动|稍后|失败|频繁|太快/;
                var hint = [];
                var all = document.querySelectorAll('div,span,p,section,article,li');
                var lim = Math.min(all.length, 3000);
                for (var j = 0; j < lim && hint.length < 3; j++) {
                  var e = all[j];
                  if (e.children.length !== 0 || e.offsetParent === null) continue;
                  var t = (e.textContent || '').trim();
                  if (t && t.length <= 60 && kw.test(t)) hint.push(t);
                }
                out.push('hint=' + (hint.length ? hint.join(' | ') : '(无)'));
              } catch(e) { out.push('hint=err'); }
              var btn = '';
              try {
                // ★★★ 第 61 期：这里**故意保持「包含『签到』」的宽判据，不要改成 tjhIsCheckinBtn()**。
                //   这一项是**纯诊断读数**，用途就是回答「页面上那个按钮到底是『签到』还是『已签到』」——
                //   改成严格判据后，「已签到」的页面会读到空串，恰好把本轮要查的那个现象藏掉。
                //   动作侧（点哪个）用严格判据，诊断侧（页面长什么样）用宽判据，两边**故意不一致**。
                var cand = document.querySelectorAll('a,button,div,span,i,[class*="check"],[class*="sign"]');
                for (var k = 0; k < cand.length; k++) {
                  var tt = (cand[k].textContent || '').trim();
                  var rr = cand[k].getBoundingClientRect();
                  if (tt.indexOf('签到') >= 0 && cand[k].offsetParent !== null && rr.width > 0 && rr.width < 300) {
                    btn = tt; break;
                  }
                }
              } catch(e) {}
              // ★★ 第 36 期新增 net= ：读 `OverlayVerifyHost` 装的纯读钩子（XHR + fetch），
              //   拿到**页面自己那次签到请求的回包原文**。
              //   第 35 期只能看到「请求发出去了、200」，看不到回包内容 ——
              //   而微博的风控话术（`msg`）与验证地址（`scheme`）就在回包体里。
              //   这是回答「处理器跑了、微博回了什么、它想让我们去哪」的唯一手段。
              //   只读 `window.__tjhNet`（钩子自己收集的数组），不碰网络、不改页面。
              try {
                var net = window.__tjhNet || [];
                if (net.length) {
                  var s = [];
                  for (var q = Math.max(0, net.length - 2); q < net.length; q++) {
                    var it = net[q] || {};
                    s.push(it.u + ' s' + it.s + ' ' + String(it.b || '').slice(0, 170));
                  }
                  out.push('net=' + s.join(' ;; '));
                } else {
                  out.push('net=(无)');
                }
              } catch(e) { out.push('net=err'); }
              // ★ 第 35 期：删掉 title=/url=（同轮的「P1 JS 点击后现场」已打过，且全程没变过）。
              return out.join(' || ') + ' || btn=' + btn;
            })()
        """.trimIndent()
        return evalJs(js) ?: "(读取失败)"
    }

    /**
     * ★★★ 第 61 期：「签到按钮」的 JS 判据 —— **全工程只有这一份**，三处调用点共用。
     *
     * 为什么必须抽成一份：这个条件在 `tapCheckinButton()` 里要出现两次（先滚动、再测量），
     * 在 `clickCheckinButton()` 里还要出现第三次。各写一份的结果就是迟早走样 ——
     * 本轮的 bug 正是「无障碍那份写对了、JS 这三份漏了」，而漏了整整 60 期没人发现。
     *
     * 判据本身与 `WeiboClient.kt:867` 的无障碍版本**逐字对应**：
     *   · `t.indexOf('签到') >= 0`  ⇒ `buttonName.contains("签到")`
     *   · `t.indexOf('已签') < 0`   ⇒ `!buttonName.contains("已签")`
     *   · 加上原有的「可见 / 有宽度 / 宽度 < 300」三个几何条件（无障碍那份不需要，它拿的是接口字段）。
     *
     * `strictCheckinButtonText = false` 时**整条「排除已签」都不生成** ⇒ 与第 60 期逐字节相同。
     */
    private fun jsCheckinBtnHelper(): String =
        "function tjhIsCheckinBtn(el){" +
            "if(!el||el.offsetParent===null)return false;" +
            "var t=(el.textContent||'').trim();" +
            "var r=el.getBoundingClientRect();" +
            "if(t.indexOf('签到')<0)return false;" +
            (if (strictCheckinButtonText) "if(t.indexOf('已签')>=0)return false;" else "") +
            "return r.width>0&&r.width<300;}"

    /** 在页面里找「签到」按钮并点击，触发验证码 */
    /**
     * 找「签到」按钮，滚动到可见区域后，用无障碍真实点一下。
     */
    private fun tapCheckinButton(): Boolean {
        // 1) 找按钮并滚动到可视区（水平也要滚，否则按钮可能在屏幕右侧外面）
        val scrollJs = """
            (function(){
              ${jsCheckinBtnHelper()}
              var all = document.querySelectorAll('a, button, div, span, i, [class*="check"], [class*="sign"], [class*="btn"], [class*="Button"]');
              var raw = '';
              for (var i=0; i<all.length; i++) {
                var el = all[i];
                var t = (el.textContent || '').trim();
                if (!raw && t.indexOf('签到') >= 0 && el.offsetParent !== null) raw = t;
                if (tjhIsCheckinBtn(el)) {
                  el.scrollIntoView({block:'center', inline:'center'});
                  return 'scrolled';
                }
              }
              return 'none|' + raw;
            })()
        """.trimIndent()
        val scrolled = evalJs(scrollJs) ?: ""
        if (scrolled.startsWith("none")) {
            // ★★★ 第 61 期：页面上只有「已签到」这类**点不动**的按钮 ⇒ 本轮**不点**，只留一次痕。
            //
            //   旧实现在这里照样点下去：微博什么都不做，30 秒等不到验证码，重挂、再点、再等，
            //   最后「已重挂 2/2 轮仍未过，停手」—— 账号被留在 `needsVerify=true` 里出不来，
            //   当天再也不会自动去签它。真机 5 次实证见 `strictCheckinButtonText` 的注释。
            //
            //   ★ 这里只「不点 + 留痕」，**不做任何判定**：要不要重挂仍由宿主的 `onGaveUp` 决定。
            val raw = scrolled.substringAfter('|', "")
            if (raw.isNotBlank() && !deadBtnLogged) {
                deadBtnLogged = true
                SliderTrace.log(
                    "[手势] 页面上只有「" + raw + "」按钮（点它不会发出签到请求、也不会弹验证码），" +
                        "本轮不点 —— 避免空等 30 秒后误判成「验证没过」"
                )
            }
            return false
        }
        sleep(400) // 等滚动稳定

        // 2) 重新测量按钮在可视区的位置
        //    ★ 第 61 期：判据换成 `tjhIsCheckinBtn()` —— 「已签到」不再算候选。
        //      选「文案最短」的规则不变（真按钮之间它仍是好启发式）。
        val js = """
            (function(){
              ${jsCheckinBtnHelper()}
              var best = null;
              var all = document.querySelectorAll('a, button, div, span, i, [class*="check"], [class*="sign"], [class*="btn"], [class*="Button"]');
              for (var i=0; i<all.length; i++) {
                var el = all[i];
                var t = (el.textContent || '').trim();
                var r = el.getBoundingClientRect();
                if (tjhIsCheckinBtn(el)) {
                  var area = r.width * r.height;
                  if (!best || t.length < best.t.length || (t.length === best.t.length && area < best.area)) {
                    best = { el: el, t: t, area: area };
                  }
                }
              }
              if (best) {
                var r = best.el.getBoundingClientRect();
                return r.left + '|' + r.top + '|' + r.width + '|' + r.height + '|' + document.documentElement.clientWidth + '|' + best.t;
              }
              return 'none';
            })()
        """.trimIndent()
        val out = evalJs(js) ?: return false
        if (out == "none" || out.isBlank()) return false
        val p = out.split('|')
        if (p.size < 6) return false
        val left = p[0].toFloatOrNull() ?: return false
        val top = p[1].toFloatOrNull() ?: return false
        val width = p[2].toFloatOrNull() ?: return false
        val height = p[3].toFloatOrNull() ?: return false
        val clientW = p[4].toFloatOrNull() ?: return false
        val text = p[5]

        val svc = SliderGestureAccessibilityService.instance
        Dbg.log("CheckinBtn", "按钮 rect=($left,$top,$width,$height) clientW=$clientW webW=${webView.width} 文本=$text")
        // ★ 第 23 期取证：把按钮矩形与视口宽度落黑匣子，好在报告里核对坐标换算。
        SliderTrace.log(
            "[手势] 按钮 rect=($left,$top,$width,$height) clientW=$clientW webW=${webView.width} 文本=$text"
        )
        // ★★★ 第 36 期 P2 实验：优先用 WebView **真实触摸**点签到（理由见 companion object）。
        //   坐标换算与下面那条无障碍路径**不同**：这里要 WebView 本地像素，所以**不加** loc。
        if (useTrustedTouchForCheckin) {
            val scaleLocal =
                if (clientW > 0f && webView.width > 0) webView.width.toFloat() / clientW else 1f
            val localX = (left + width / 2f) * scaleLocal
            val localY = (top + height / 2f) * scaleLocal
            SliderTrace.log(
                "[手势] P2 实验：改用 WebView 真实触摸点签到（trusted）本地坐标=(" +
                    "%.0f".format(localX) + "," + "%.0f".format(localY) + ") 缩放=" +
                    "%.3f".format(scaleLocal)
            )
            if (dispatchTrustedClick(localX, localY)) {
                // 只留痕：与 JS 那条路径抓**同样的两个现场**，好逐字对比。
                sleep(900)
                SliderTrace.log("[手势] P2 真实触摸后现场 " + dumpPageState())
                sleep(600)
                SliderTrace.log("[手势] P2 真实触摸后反应 " + dumpPageReaction())
                return true
            }
            SliderTrace.log("[手势] P2 实验：真实触摸派发失败，回退页面内 JS 点击")
        }
        // ★★ 第 33 期 P1 实验：先试「页面内 JS 点击」。
        //   它不走系统触摸分发 ⇒ 锁屏 / 窗口不可见时同样能生效（同步执行，不吃页面定时器）。
        //   若 JS 连按钮都没找到（理论上不会：上面刚测量到），再回退第 32 期的无障碍 tap。
        if (useJsClickForCheckin) {
            SliderTrace.log("[手势] P1 实验：改用页面内 JS 点击签到（不经系统触摸）")
            if (clickCheckinButton()) {
                // 只留痕：JS 点击后抓一次现场，看滑块有没有被唤起来（bg/jigsaw/slider）。
                sleep(900)
                SliderTrace.log("[手势] P1 JS 点击后现场 " + dumpPageState())
                // ★★ 第 34 期新增：纯读「点击后页面反应快照」。
                //   上一轮报告答不了「事件到了 document、页面却零反应」到底是
                //   ① 处理器压根没跑，还是 ② 跑了但微博不出滑块 —— 这两条的下一步完全不同。
                //   快照里最硬的一条是「页面有没有真的发出网络请求」（读 performance 资源条目）。
                //   ★ 第 36 期：只留 1.5 秒这一次 —— 第 35 期实测 5 秒那次与它**逐字相同**
                //     （回包在点击后 ~100ms 就回来了），纯占篇幅。
                sleep(600)
                SliderTrace.log("[手势] P1 点击后反应(1.5s) " + dumpPageReaction())
                return true
            }
            SliderTrace.log("[手势] P1 实验：JS 点击没找到按钮，回退无障碍 tap")
        }
        if (svc == null) {
            Dbg.log("CheckinBtn", "无障碍未开，回退 JS 点击")
            SliderTrace.log("[手势] 无障碍未开，回退 JS 点击")
            return clickCheckinButton()
        }

        mainHandler.post {
            if (stopped) return@post
            val loc = IntArray(2)
            webView.getLocationOnScreen(loc)
            val scale = if (clientW > 0 && webView.width > 0) webView.width.toFloat() / clientW else 1f
            val sx = loc[0] + (left + width / 2f) * scale
            val sy = loc[1] + (top + height / 2f) * scale
            // ★ 第 23 期取证：算出实际要点的屏幕坐标（换算链路 loc/scale 一并留痕）。
            SliderTrace.log(
                "[手势] 换算 loc=(" + loc[0] + "," + loc[1] + ") scale=" + scale +
                    " → 屏幕坐标 (" + sx + "," + sy + ")"
            )
            svc.tap(sx, sy) { ok ->
                Dbg.log("CheckinBtn", "无障碍点击=" + ok + " 文本=" + text)
            }
        }
        Dbg.log("CheckinBtn", "已调度无障碍点击 文本=" + text)
        return true
    }

    /**
     * ★★★ 第 36 期：用 WebView 的**真实触摸**点一下（trusted，且真正产生 user activation）。
     *
     * 与 `clickCheckinButton()`（页面内 `dispatchEvent`）的本质区别：
     *   · 合成事件：`isTrusted=false`、**不产生 user activation**（第 35 期实测 `ua=00`）；
     *   · `webView.dispatchTouchEvent()`：走 WebView 自己的输入管线，在 Blink 侧是 trusted 事件，
     *     并真正设置 user activation ⇒ `window.open` / `confirm` 这些「要手势」的 API 才可用。
     *
     * ★ 必须在主线程派发；DOWN 与 UP 之间要有真实间隔（这里 70ms），否则 Chromium 会当噪声丢掉。
     * ★ 只发一对 DOWN/UP，**不发 MOVE** —— 这是「点击」，不是「拖动」（拖动仍走 `jsDrag`）。
     * ★ 任何一步失败（抛异常 / 主线程 1.5 秒没跑完）都返回 false，由调用方回退到 JS 点击。
     * ★ 纯动作层：不改任何判定、不读页面状态、不影响 `attempts` / 滑块检测。
     */
    private fun dispatchTrustedClick(localX: Float, localY: Float): Boolean {
        if (stopped) return false
        val downTime = SystemClock.uptimeMillis()
        if (!sendTouch(MotionEvent.ACTION_DOWN, downTime, downTime, localX, localY)) return false
        sleep(70)
        val upTime = SystemClock.uptimeMillis()
        val upOk = sendTouch(MotionEvent.ACTION_UP, downTime, upTime, localX, localY)
        SliderTrace.log(
            "[手势] P2 真实触摸已派发 up=" + upOk +
                " 坐标=(" + "%.0f".format(localX) + "," + "%.0f".format(localY) + ")"
        )
        return upOk
    }

    /** 在主线程把单个 MotionEvent 交给 WebView；返回「是否真的派发出去」。 */
    private fun sendTouch(action: Int, downTime: Long, eventTime: Long, x: Float, y: Float): Boolean {
        val done = CountDownLatch(1)
        var sent = false
        mainHandler.post {
            if (!stopped) {
                try {
                    val ev = MotionEvent.obtain(downTime, eventTime, action, x, y, 0)
                    ev.source = InputDevice.SOURCE_TOUCHSCREEN
                    webView.dispatchTouchEvent(ev)
                    ev.recycle()
                    sent = true
                } catch (_: Throwable) {
                }
            }
            done.countDown()
        }
        // CountDownLatch 自带 happens-before ⇒ await 之后读到的是主线程写进去的值。
        done.await(1500, TimeUnit.MILLISECONDS)
        return sent
    }

    private fun clickCheckinButton(): Boolean {
        val js = """
            (function(){
              ${jsCheckinBtnHelper()}
              var best = null;
              var all = document.querySelectorAll('a, button, div, span, i, [class*="check"], [class*="sign"], [class*="btn"], [class*="Button"]');
              for (var i=0; i<all.length; i++) {
                var el = all[i];
                var t = (el.textContent || '').trim();
                var r = el.getBoundingClientRect();
                if (tjhIsCheckinBtn(el)) {
                  var area = r.width * r.height;
                  if (!best || t.length < best.t.length || (t.length === best.t.length && area < best.area)) {
                    best = { el: el, t: t, area: area };
                  }
                }
              }
              if (best) {
                var el = best.el;
                var r = el.getBoundingClientRect();
                var x = r.left + r.width/2, y = r.top + r.height/2;
                function fire(type, Ctor, buttons, isPointer) {
                  try {
                    var init = {bubbles:true, cancelable:true, composed:true,
                                clientX:x, clientY:y, screenX:x, screenY:y,
                                button:0, buttons:buttons, detail:1, view:window};
                    if (isPointer) {
                      init.pointerId = 1; init.pointerType = 'touch'; init.isPrimary = true;
                      init.width = 1; init.height = 1; init.pressure = buttons ? 0.5 : 0;
                    }
                    el.dispatchEvent(new Ctor(type, init));
                  } catch(e) {}
                }
                // ★★★ 第 35 期：把「按下的那一下」补成真机形状。
                //   第 34 期真机报告已经排除环境（锁屏/安全锁/亮屏全不是原因），
                //   于是只剩「页面认不认这一串事件」。而第 34 期发出去的
                //   pointerdown 实际上长这样（按 W3C 默认值）：
                //     buttons=0      ← 真机按下时是 1（抬起才是 0）
                //     pointerType=''  ← 真机触摸是 'touch'
                //     isPrimary=false ← 真机触摸是 true
                //     pointerId=0     ← 真机触摸 ≥ 2
                //     pressure=0      ← 真机触摸 > 0
                //     composed 缺省    ← 真机事件是 true
                //   页面或风控只要看其中任一项（`e.buttons`、`e.pointerType`、
                //   `e.isPrimary`）就能把这一串当成噪声丢掉 —— 比 isTrusted 好查得多。
                //   现在按真机顺序与真机属性补齐；仍然 isTrusted=false（合成事件绕不过）。
                fire('pointerdown', PointerEvent, 1, true);
                // ★ 第 34 期：补上 touch 事件。上一轮真机报告里探针实测 ts=0 te=0 ——
                //   我们只发了 pointer/mouse 系列，若页面把点击处理绑在 touch 上，
                //   这个序列**天然不会触发它**（移动端网页用 touch 处理点击非常常见）。
                //   顺序照 Chromium 真机点一下的顺序：
                //   pointerdown → touchstart → touchend → pointerup → mousedown → mouseup → click
                //   （注意：合成事件同样 isTrusted=false，补 touch 并不能解决 isTrusted 问题。）
                function fireTouch(type, empty) {
                  try {
                    var t = new Touch({
                      identifier: 1, target: el,
                      clientX: x, clientY: y, pageX: x, pageY: y, screenX: x, screenY: y,
                      radiusX: 2, radiusY: 2, force: 1
                    });
                    el.dispatchEvent(new TouchEvent(type, {
                      bubbles: true, cancelable: true, composed: true,
                      touches: empty ? [] : [t],
                      targetTouches: empty ? [] : [t],
                      changedTouches: [t]
                    }));
                  } catch(e) {}
                }
                fireTouch('touchstart', false);
                fireTouch('touchend', true);
                fire('pointerup', PointerEvent, 0, true);
                fire('mousedown', MouseEvent, 1, false);
                fire('mouseup', MouseEvent, 0, false);
                fire('click', MouseEvent, 0, false);
                // ★ 第 35 期：返回值带上点击那一刻的 performance.now()（毫秒）。
                //   这是「点击后反应快照」里资源时间戳的比对基准 ——
                //   资源条目的 startTime 若 ≈ 这个值 ⇒ 请求是我们点击触发的；
                //   若远小于它 ⇒ 那是页面加载时就发的，跟点击无关。
                return 'clicked:' + best.t + '[+touch]@' + Math.round(performance.now());
              }
              return 'none';
            })()
        """.trimIndent()
        val result = evalJs(js) ?: ""
        Dbg.log("CheckinBtn", "检测结果=" + result)
        if (result.startsWith("clicked")) {
            onLog("签到按钮: " + result)
        }
        return result.startsWith("clicked")
    }

    private fun solveOnce(bgUrl: String, jigsawUrl: String) {
        onLog("检测到易盾滑块，开始识别缺口…")
        val bg = downloadImage(bgUrl, "bg")
        val jigsaw = downloadImage(jigsawUrl, "front")
        if (bg == null || jigsaw == null) {
            onLog("图片下载失败，等下一题")
            sleep(1000)
            return
        }
        val gap = YidunSliderSolver.solve(bg, jigsaw)
        if (gap == null) {
            onLog("缺口识别失败，等下一题")
            sleep(1000)
            return
        }
        // ★ 第 93 期：一并打出**原图像素尺寸** —— 它是判断「拖动换算基准」对不对的唯一依据。
        //   `bg.width` 就是 `downloadImage()` 解出来的 Bitmap 宽（未做任何缩放）⇒ 即原图宽。
        onLog("缺口x=${"%.1f".format(gap.gapLeft)} 可信度=${"%.2f".format(gap.score)} 原图=${bg.width}x${bg.height}")
        val ok = scheduleDrag(gap)
        onLog(if (ok) "已执行拖动，等待结果…" else "拖动失败")
        attempts++
        sleep(1800)
    }

    /** 读取验证码状态：验证码就绪时返回 bg/jigsaw 图片 URL，否则 null */
    private fun readCaptchaState(): Pair<String, String>? {
        val js = """
            (function(){
              var bg = document.querySelector('.yidun_bg-img');
              var jg = document.querySelector('.yidun_jigsaw');
              if (bg && jg && bg.src && jg.src &&
                  bg.src.indexOf('necaptcha') >= 0 && jg.src.indexOf('necaptcha') >= 0) {
                return bg.src + '|' + jg.src;
              }
              return '';
            })()
        """.trimIndent()
        val out = evalJs(js) ?: return null
        if (out.isBlank()) return null
        val parts = out.split('|')
        if (parts.size < 2 || parts[0].isBlank() || parts[1].isBlank()) return null
        return Pair(parts[0], parts[1])
    }

    /**
     * 测量滑块按钮在页面里的位置，换算成 Android 物理像素，调度拖动手势。
     */
    private fun scheduleDrag(gap: YidunSliderSolver.GapResult): Boolean {
        // 1) 先滚动到滑块，等一下让滚动稳定（否则测到的位置是滚动前的旧值）
        evalJs("(function(){var k=document.querySelector('.yidun_slider'); if(k) k.scrollIntoView({block:'center'}); return '';})()")
        sleep(300)

        // 2) 测量位置
        val js = """
            (function(){
              var knob = document.querySelector('.yidun_slider');
              var bg = document.querySelector('.yidun_bg-img');
              var jg = document.querySelector('.yidun_jigsaw');
              if (!knob || !bg || !jg) return '';
              var k = knob.getBoundingClientRect();
              var b = bg.getBoundingClientRect();
              var j = jg.getBoundingClientRect();
              var dpr = window.devicePixelRatio || 1;
              var cw = document.documentElement.clientWidth || 980;
              // ★★ 第 93 期：额外读出两张图的**自然尺寸**（原图像素宽）。
              //   `.yidun_bg-img` 是 <img>，naturalWidth 即原图宽；若选择器命中的不是 <img>，
              //   该属性为 undefined ⇒ 拼出来是字符串 "undefined" ⇒ Kotlin 侧解析失败、回退旧基准。
              return [k.left, k.top, k.width, k.height, dpr, b.width, j.width, cw,
                      b.naturalWidth, j.naturalWidth].join('|');
            })()
        """.trimIndent()
        val out = evalJs(js) ?: return false
        if (out.isBlank()) {
            SliderTrace.log("[放弃] 页面里找不到 .yidun_slider / .yidun_bg-img / .yidun_jigsaw")
            return false
        }
        val p = out.split('|')
        if (p.size < 8) {
            SliderTrace.log("[放弃] 滑块测量结果字段不足：" + out)
            return false
        }
        val kLeft = p[0].toFloatOrNull() ?: return false
        val kTop = p[1].toFloatOrNull() ?: return false
        val kWidth = p[2].toFloatOrNull() ?: return false
        val kHeight = p[3].toFloatOrNull() ?: return false
        val dpr = p[4].toFloatOrNull() ?: 1f
        val bgWidth = p[5].toFloatOrNull() ?: 320f
        val jigWidth = p[6].toFloatOrNull() ?: 60f
        val clientWidth = p[7].toFloatOrNull() ?: 980f
        // ★★ 第 93 期新增：两张图的**自然尺寸**（原图像素）。缺失 / 非数字 ⇒ 0f ⇒ 回退旧基准。
        val bgNatural = p.getOrNull(8)?.toFloatOrNull() ?: 0f
        val jigNatural = p.getOrNull(9)?.toFloatOrNull() ?: 0f
        if (kWidth <= 0f || kHeight <= 0f || bgWidth <= 0f || jigWidth <= 0f) {
            SliderTrace.log(
                "[放弃] 滑块/图片尺寸为 0：k=${kWidth}x${kHeight} bg=$bgWidth jig=$jigWidth"
            )
            return false
        }
        if (webView.width <= 0) {
            SliderTrace.log("[放弃] WebView 宽度为 0")
            return false
        }

        // CSS 像素 -> Android 物理像素：用 WebView 实际宽度 / 页面视口宽度。
        // 电脑版页面无 mobile viewport，会被整体缩放，直接用 dpr 会偏大很多，导致点不到滑块。
        val scale = webView.width.toFloat() / clientWidth

        // 图片像素 -> 页面 CSS 像素
        // ★★★ 第 93 期根因修复：分母必须是**图片自然宽度**，不能写死 320 / 60。
        //   实测（2026-10-10 真机日志）`缺口x=370.0` 配 `图=320x61` —— 缺口坐标 370 比
        //   渲染宽 320 还大，只可能是「原图比渲染尺寸大」（易盾下发 2 倍图、CSS 按 1 倍显示）。
        //   旧式 `bgWidth / 320f` 把这种情况当成 1:1 ⇒ 拖动距离**翻倍** ⇒ 滑块被拖过头 ⇒ 必被拒。
        //   反解自洽：`370 * 1.0 - 4 * (61/60) + 8 = 374`，正是日志里的「拖动css=374.0」。
        //   ★ 自然宽恰好 = 320 / 60 时，本式与旧式**逐字节相同**；取不到自然尺寸也回退旧基准。
        val bgScale = if (bgNatural > 0f) bgWidth / bgNatural else bgWidth / 320f
        val jigScale = if (jigNatural > 0f) jigWidth / jigNatural else jigWidth / 60f
        val dragCss = gap.gapLeft * bgScale - gap.pieceOffsetX * jigScale + dragOffsetCss
        Dbg.log("DragDebug", "gapLeft=${gap.gapLeft} pieceOffset=${gap.pieceOffsetX} bgW=$bgWidth jigW=$jigWidth bgNat=$bgNatural jigNat=$jigNatural dragCss=$dragCss offset=$dragOffsetCss")
        SliderTrace.log(
            "[几何] 缺口x=" + "%.1f".format(gap.gapLeft) +
                " 可信度=" + "%.2f".format(gap.score) +
                " 拖动css=" + "%.1f".format(dragCss) +
                " 缩放=" + "%.3f".format(scale) +
                " 滑块=(" + "%.0f".format(kLeft) + "," + "%.0f".format(kTop) + "," +
                "%.0f".format(kWidth) + "x" + "%.0f".format(kHeight) + ")" +
                " 图=" + "%.0f".format(bgWidth) + "x" + "%.0f".format(jigWidth) +
                " 自然=" + "%.0f".format(bgNatural) + "x" + "%.0f".format(jigNatural) +
                " 视口=" + "%.0f".format(clientWidth) + " webW=" + webView.width
        )

        val startX = (kLeft + kWidth / 2f) * scale
        val startY = (kTop + kHeight / 2f) * scale
        val dist = dragCss * scale
        if (dist <= 5f) {
            SliderTrace.log("[放弃] 拖动距离过短：dist=" + dist)
            return false
        }

        // 时长随距离缩放，整体更慢：快速拖动会产生“惯性”，导致滑块冲过缺口
        val base = (dragCss * 6f + 500f).toInt().coerceIn(800, 2000)
        val duration = base + Random.nextInt(200)

        // ★★★ 第 37 期 P3 实验：优先用「真实触摸序列」拖动（理由见 companion object）。
        //   轨迹用现成的 buildTrack()；坐标用上面**已经按 WebView 本地像素算好**的 startX/startY/dist
        //   （`(kLeft+kWidth/2)*scale`，不含 loc）—— 所以这里不需要任何新换算。
        if (useTrustedTouchForDrag) {
            val track = buildTrack(dist, duration)
            SliderTrace.log(
                "[拖动] P3 实验：改用真实触摸拖动（trusted）起点=(" +
                    "%.0f".format(startX) + "," + "%.0f".format(startY) + ") 距离px=" +
                    "%.0f".format(dist) + " 步数=" + track.size + " 时长ms=" + duration
            )
            // dispatchTrack 会直接在**主线程**调 webView.dispatchTouchEvent，必须 post 过去。
            mainHandler.post { dispatchTrack(startX, startY, track) }
            return true
        }
        // 拖动用 JS 注入（无障碍拖动手势在这台手机上不动，只有无障碍点击能用）
        mainHandler.post {
            jsDrag(dragCss, duration)
        }
        return true
    }

    /**
     * 用 JS 在页面里直接派发 PointerEvent/MouseEvent 拖动滑块。
     * 事件带 bubbles，能从滑块气泡到控制条，触发易盾的拖拽处理器。
     */
    private fun jsDrag(distanceCss: Float, durationMs: Int) {
        val js = """
            (function(distance, duration){
              var knob = document.querySelector('.yidun_slider');
              if (!knob) return 'no-knob';
              var r = knob.getBoundingClientRect();
              var sx = r.left + r.width/2, sy = r.top + r.height/2;
              var steps = 24;
              function fire(type, x, y) {
                try {
                  knob.dispatchEvent(new PointerEvent(type, {bubbles:true, cancelable:true, clientX:x, clientY:y, pointerId:1, pointerType:'touch', isPrimary:true}));
                } catch(e) {}
                try {
                  var mt = type==='pointerdown' ? 'mousedown' : (type==='pointerup' ? 'mouseup' : 'mousemove');
                  knob.dispatchEvent(new MouseEvent(mt, {bubbles:true, cancelable:true, clientX:x, clientY:y}));
                } catch(e) {}
              }
              fire('pointerdown', sx, sy);
              for (var i=1; i<steps; i++) {
                (function(i){
                  var f = i/steps;
                  var ease = f < 0.5 ? 4*f*f*f : 1 - Math.pow(-2*f+2,3)/2;
                  var x = sx + distance*ease + (Math.random()*1.4-0.7);
                  var y = sy + (Math.random()*2.4-1.2);
                  var t = Math.round(duration*f);
                  setTimeout(function(){ fire('pointermove', x, y); }, t);
                })(i);
              }
              setTimeout(function(){ fire('pointermove', sx+distance, sy); }, duration);
              setTimeout(function(){ fire('pointerup', sx+distance, sy); }, duration+60);
              return 'ok';
            })(${"%.1f".format(distanceCss)}, $durationMs)
        """.trimIndent()
        mainHandler.post {
            if (stopped) return@post
            // ★ 拖动发出的**那一刻**页面是不是真的可见 —— 这是判断
            //   「滑块没动」到底是「定时器被限流」还是「被易盾拒绝」的唯一依据。
            //   只读两个 View 属性，零 JS 开销，且在主线程上读。
            SliderTrace.log(
                "[拖动] 页面可见=" + webView.isShown +
                    " 窗口焦点=" + webView.hasWindowFocus() +
                    " 距离css=" + "%.1f".format(distanceCss) +
                    " 时长ms=" + durationMs
            )
            try {
                // 已经在主线程，直接派发（不要走 evalJs，它会在主线程死锁 2 秒）
                webView.evaluateJavascript(js, null)
            } catch (_: Throwable) {
            }
        }
        // 诊断：拖动结束后读滑块实际 left，对比目标距离
        // 仅 Dbg 打开时才做这次额外读取，否则纯属多余的 JS 往返
        if (Dbg.enabled) mainHandler.postDelayed({
            if (stopped) return@postDelayed
            try {
                webView.evaluateJavascript(
                    "(function(){var k=document.querySelector('.yidun_slider'); if(!k) return 'gone'; return k.style.left + '/' + getComputedStyle(k).left;})()"
                ) { v ->
                    Dbg.log("DragDebug", "实际left=${"${v?.trim('"')}"} 目标=${"%.1f".format(distanceCss)}")
                }
            } catch (_: Throwable) {
            }
        }, durationMs + 150L)
    }

    private data class TrackPoint(val x: Float, val y: Float, val t: Long)

    /** 生成人手式轨迹：ease-in-out + 轻微抖动，终点精确落在目标距离 */
    private fun buildTrack(distance: Float, durationMs: Int): List<TrackPoint> {
        val steps = 24
        val rnd = Random(System.nanoTime())
        val points = ArrayList<TrackPoint>(steps)
        for (i in 1..steps) {
            val f = i.toFloat() / steps
            val ease = if (f < 0.5f) {
                4f * f * f * f
            } else {
                1f - (-2f * f + 2f).let { it * it * it } / 2f
            }
            val x = (distance * ease + rnd.nextFloat() * 1.4f - 0.7f).coerceIn(0f, distance)
            val y = rnd.nextFloat() * 2.4f - 1.2f
            val t = (durationMs * f).toLong() + rnd.nextLong(-12L, 12L)
            points.add(TrackPoint(x, y, t.coerceAtLeast(0L)))
        }
        points[points.size - 1] = TrackPoint(distance, 0f, durationMs.toLong())
        return points
    }

    /**
     * 在主线程用 MotionEvent 注入真实手势（**必须在主线程调用**：`dispatchTouchEvent` 是 View 方法）。
     *
     * ★ 第 37 期起**不再是死代码**：`scheduleDrag()` 在 `useTrustedTouchForDrag = true` 时会调用它
     *   （第 36 期之前全项目零调用点）。坐标是 **WebView 本地像素**，由 `scheduleDrag()` 算好传入。
     */
    private fun dispatchTrack(startX: Float, startY: Float, track: List<TrackPoint>) {
        if (stopped) return
        val downTime = SystemClock.uptimeMillis()
        var ev = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, startX, startY, 0)
        ev.source = InputDevice.SOURCE_TOUCHSCREEN
        try {
            webView.dispatchTouchEvent(ev)
        } catch (_: Throwable) {
        }
        ev.recycle()

        for (pt in track) {
            val t = pt.t
            mainHandler.postDelayed({
                val e = MotionEvent.obtain(
                    downTime, downTime + t, MotionEvent.ACTION_MOVE,
                    startX + pt.x, startY + pt.y, 0
                )
                e.source = InputDevice.SOURCE_TOUCHSCREEN
                try {
                    webView.dispatchTouchEvent(e)
                } catch (_: Throwable) {
                }
                e.recycle()
            }, t)
        }

        val end = track.last()
        mainHandler.postDelayed({
            val e = MotionEvent.obtain(
                downTime, downTime + end.t + 50L, MotionEvent.ACTION_UP,
                startX + end.x, startY + end.y, 0
            )
            e.source = InputDevice.SOURCE_TOUCHSCREEN
            try {
                webView.dispatchTouchEvent(e)
            } catch (_: Throwable) {
            }
            e.recycle()
            // ★ 第 37 期：本条死代码被接上后补一行收尾留痕 ——
            //   确认「整条 DOWN→MOVE×24→UP 序列真的发完了」，而不是中途被丢掉。
            SliderTrace.log(
                "[拖动] P3 真实触摸序列已发完 步数=" + track.size +
                    " 用时ms=" + (end.t + 50L) + " 终点=(" +
                    "%.0f".format(startX + end.x) + "," + "%.0f".format(startY + end.y) + ")"
            )
        }, end.t + 50L)
    }

    /** 主线程执行 JS 并等待结果（2 秒超时） */
    private fun evalJs(js: String): String? {
        if (stopped || !pageReady) return null
        val latch = CountDownLatch(1)
        var out: String? = null
        mainHandler.post {
            if (stopped || !pageReady) {
                latch.countDown()
                return@post
            }
            try {
                webView.evaluateJavascript(js) { v ->
                    out = v
                    latch.countDown()
                }
            } catch (_: Throwable) {
                latch.countDown()
            }
        }
        latch.await(2, TimeUnit.SECONDS)
        val raw = out?.trim('"') ?: return null
        return if (raw == "null") null else raw
    }

    /**
     * 下载一张验证图。
     *
     * @param kindHint 这张图是 `bg`（背景）还是 `front`（拼图块）。
     *   ★ 第 71 期补：`solveOnce()` 的调用位置**天然知道**第一张是 bg、第二张是 front，
     *   直接告知采样器，比让采样器读 URL 猜可靠（第 70 期猜 URL 的结果是样本恒 0）。
     *   **只用于采样留痕，不参与任何判定** —— 传 null 也不影响下载本身。
     */
    private fun downloadImage(urlStr: String, kindHint: String? = null): Bitmap? {
        try {
            val conn = URL(urlStr).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
            )
            val input: InputStream = conn.inputStream
            val bytes = input.readBytes()
            input.close()
            conn.disconnect()
            // ★★★ 第 70 期新增：顺手把**原始字节**交给采样器落盘（默认关闭，行为零变化）。
            //
            //   为什么选这里：这是全工程唯一「易盾原图字节已经在手上、且没有多花一次网络请求」
            //   的位置。`downloadImage()` 走 `HttpURLConnection`，不经过 WebView 的资源加载，
            //   所以 `shouldInterceptRequest` / JS 钩子都拿不到它。
            //   ★ 传的是 `bytes`（解码前的原文），不是 Bitmap —— 样本必须与 OpenCV 看到的
            //     逐字节一致，`bitmapToMat` 前的 `inPreferredConfig = ARGB_8888` 会做颜色转换。
            //   ★ 采样器 `enabled=false` 时本行是一次 `if` 判断就返回，**零副作用**；
            //     写盘失败也静默。**不参与任何判定** —— 没有任何返回值被这里使用。
            //   ★ Context 从 WebView 取（`webView.context`），不新增构造参数 ——
            //     加参数要改所有调用点的签名，属无谓的破坏面。
            SliderSampler.capture(webView.context, urlStr, bytes, kindHint)
            val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        } catch (_: Throwable) {
            return null
        }
    }

    private fun sleep(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }
}
