package com.tjh.weibotask

/**
 * ★★★★ 第 113 期：**发帖目标超话 —— 硬编码，界面不可修改**。
 *
 * 用户原话（2026-10-14）：
 *   「目标超话硬编码（极其重要）——把目标超话直接写死，界面上不再让用户输入。」
 *
 * 演进脉络（别把这段删掉，它解释了为什么是现在这个样子）：
 *   · 第 81 期：正文从「一大段」改成「逐条语料库」，超话仍是多行输入框；
 *   · 第 96 期：用户要求「只能发到一个超话」⇒ 多行输入框改单行，
 *     并且 `MainActivity` 会把用户填的多行**只保留第一行**再写回 `Prefs`；
 *   · 第 113 期（本期）：连输入都不需要了 —— 超话钉成常量，输入框降级为**只读展示卡**。
 *
 * ★★★ 为什么把常量放这里，而不是直接写进 `AgentService`：
 *   `AgentService` 属**核心链路②（发帖）**，改它等于改「发到哪」这个决定。
 *   本期的做法是 —— `MainActivity` 在**它原本就有的那个写回位置**
 *   （`setupPostPanel()` 里「取第一行写回 Prefs」那一行）把值换成
 *   [TARGET_SUPER_TOPIC_URL]。位置没变、时机没变、`Prefs` 键没变、
 *   语义（「发帖超话链接列表」）也没变，只是**值被钉死**。
 *   ⇒ `AgentService` 仍照原样读 `Prefs.postTopicsText`，读到的就是本常量，
 *     一行核心代码都不用动。
 *
 * ★ 一键回滚：把 [MainActivity] 里写回 `Prefs.postTopicsText` 的那一行改回
 *   「取用户输入的第一行」，界面把 `postTopicsEdit` 的只读属性去掉即可。
 *   `Prefs.post_topics_text` 键**保留不删**（与 `post_first` / `hourly_limit`
 *   同一套「保键不保值」办法）。
 */
object PostTarget {

    /**
     * 目标超话页地址（**唯一真源**）。
     *
     * 尾部那串就是 `containerid` —— 发帖接口要的就是它，
     * 由 [WeiboClient.parseSuperTopicRef] 从本行解析出来（与用户手填时的解析路径完全一致）。
     */
    const val TARGET_SUPER_TOPIC_URL =
        "https://m.weibo.cn/p/100808db807a7a7c131532c93920af92091f0e"

    /**
     * 目标超话真名 —— 2026-10-14 核验（微博超话页标题）。
     *
     * ★ 这是**写死的展示名**，不发起任何网络请求。
     *   起因：`m.weibo.cn/api/container/getIndex` 对 PC 直连返回 432（风控），
     *   真机解析又要占用发帖链路 ⇒ 为了「界面好看一点」多打一次接口不划算，
     *   更不该让一次解析失败挡住发帖。
     * ★ 展示名**永远不参与发帖判定**，只影响界面上那一行字。
     */
    const val TARGET_SUPER_TOPIC_NAME = "张奕然超话"

    /** 真名缺失时的回落展示名。 */
    const val DISPLAY_NAME_FALLBACK = "目标超话"

    /** 界面上显示的短 ID（让用户能核对「钉的是不是这一个超话」）。 */
    val shortId: String
        get() = containerId.let { if (it.length > 10) it.takeLast(10) else it }

    /** 从 [TARGET_SUPER_TOPIC_URL] 里解析出的 containerid；解析不出返回空串。 */
    val containerId: String
        get() = Regex("100808[0-9a-zA-Z]{20,40}").find(TARGET_SUPER_TOPIC_URL)?.value ?: ""

    /** 展示名：真名优先，取不到就用回落名。 */
    val displayName: String
        get() = TARGET_SUPER_TOPIC_NAME.ifBlank { DISPLAY_NAME_FALLBACK }
}
