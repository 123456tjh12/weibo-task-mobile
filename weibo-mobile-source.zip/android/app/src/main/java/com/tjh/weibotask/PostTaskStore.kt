package com.tjh.weibotask

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/**
 * ★★★★ 第 116 期：**「超话发帖任务」的唯一数据源**。
 *
 * ## 为什么**另开一个私有 SharedPreferences 文件**
 *
 * 与 [InteractTaskStore] 同一条理由，逐字适用：
 *
 * `AccountStore.save()` 是**整表覆盖**（把内存里那份账号列表整个序列化写回去）。
 * 发帖任务如果和账号存在同一个对象里，那么「保存一个发帖任务」这个动作
 * 就会顺带把账号表重写一遍 —— 而账号表里躺着 `restUntil` / `needsVerify` /
 * `lastRunDate` / `lastRunAt` 这四个**签到链路正在用的判定字段**。
 * 一旦那次重写的时机和签到链路撞上（签到执行中把账号标成「今日已完成」，
 * 这边同时把内存里的旧快照写回去），账号的当日状态就会被回滚 ——
 * 表现就是「明明签过了，第二天又签一遍」或者「明明没签，今天被跳过」。
 *
 * ⇒ 所以这里**另开一个私有文件**（`post_tasks`），和 `slider_trace` /
 *   `interact_tasks` 同一个思路：发帖任务的数据全部自包含，
 *   **删掉它不影响四条核心链路**。
 *
 * ## ★ 边界（硬纪律）
 *
 * - **不读不写 [Prefs]** —— 一个键都不碰
 * - **不读不写 [AccountStore]**，**不调 `AccountStore.save()`**
 *   （[PostTask.accountIds] 只是用户勾选结果的**副本**，见 [PostTask] 的注释）
 * - 解析失败一律**当成空表 / 跳过该条**，不抛异常 ——
 *   一份坏数据不该让主界面打不开
 *
 * ★ 本期 [PostTask] 只被「创建任务」弹窗写入，**没有任何执行侧读取点**
 *   （编排链路下一期接）。所以这个 Store 现在是一个**纯落盘**的容器。
 */
object PostTaskStore {

    private const val STORE_NAME = "post_tasks"
    private const val KEY_TASKS = "tasks"

    private val tasks = mutableListOf<PostTask>()

    private var store: SharedPreferences? = null
    private var loaded = false

    /** 读盘。**必须在用之前调用一次**；同一进程内重复调用无副作用。 */
    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        val sp = try {
            context.applicationContext.getSharedPreferences(STORE_NAME, Context.MODE_PRIVATE)
        } catch (_: Throwable) {
            null
        }
        store = sp
        tasks.clear()
        try {
            val raw = sp?.getString(KEY_TASKS, "").orEmpty()
            if (raw.isNotBlank()) {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    // ★ 单条坏数据只跳过它自己，不把整张表清掉 ——
                    //   与 [InteractTaskStore] 的 `?: continue` 同一处理。
                    val item = array.optJSONObject(i) ?: continue
                    tasks.add(PostTask.fromJson(item))
                }
            }
        } catch (_: Throwable) {
            // 整份 JSON 都坏了才当成空表。
            tasks.clear()
        }
        loaded = true
    }

    /** 全部任务（副本，外部改不动内存里那份）。 */
    @Synchronized
    fun all(): List<PostTask> = tasks.toList()

    @Synchronized
    fun get(id: String): PostTask? = tasks.firstOrNull { it.id == id }

    @Synchronized
    fun count(): Int = tasks.size

    /**
     * 新增或覆盖（按 [PostTask.id] 判定）；返回落盘后的那一条。
     *
     * ★ 做成 upsert 而不是「只增」：下一期接上编排之后，
     *   同一条任务会被反复改（比如把「保存后立即开始」关掉），
     *   到那时调用方不该还要自己区分「这是新建还是修改」。
     */
    @Synchronized
    fun save(task: PostTask): PostTask {
        val index = tasks.indexOfFirst { it.id == task.id }
        if (index >= 0) tasks[index] = task else tasks.add(task)
        persist()
        return task
    }

    /** 删掉某条；id 不存在时静默返回（任务可能已经被删过）。 */
    @Synchronized
    fun delete(id: String) {
        val removed = tasks.removeAll { it.id == id }
        if (removed) persist()
    }

    private fun persist() {
        val sp = store ?: return
        try {
            val array = JSONArray()
            for (task in tasks) array.put(task.toJson())
            sp.edit().putString(KEY_TASKS, array.toString()).apply()
        } catch (_: Throwable) {
            // 写盘失败静默：界面上这一趟照常走完，只是下次打开会少一条。
        }
    }
}
