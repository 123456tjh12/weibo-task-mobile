package com.tjh.weibotask

/**
 * ★★★★ 第 117 期：一次发帖运行的**配置**。
 *
 * 全部字段带默认值，默认 = 「现状 / 读 Prefs」——
 * [runPostPhase] 的既有调用点（`executePostOnce` → `runPostPhase(batch, today, lines)`）
 * 一行不改、行为逐字节不变；只有「创建超话发帖任务」的新调用点会传非默认 config。
 */
data class PostRunConfig(
    /** 门：今天最多发几条（`postIndex >= perAccount` 就跳过）。 */
    val perAccount: Int,
    /**
     * 每趟每个账号最多发几条。1 = 现状（第 80 期以来的「每轮一条」）。
     * >1 = 弹窗里的「每账号每轮发帖数」。（详见本文件头 / spec §3.2）
     */
    val postsPerAccountPerPass: Int = 1,
    /** 发完一条后额外等待的毫秒；0 = 现状（同账号连发之间没有间隔）。 */
    val actionGapMs: Long = 0L,
    /** 帖子正文；null = 沿用 `Prefs.postContentText`（现有行为）。 */
    val bodies: List<String>? = null,
    /** 任务专用 RateGuard 休息分钟数；null = 用全局默认（rateCoolMinutes ≤60 无效果，见 spec §3.1）。 */
    val restMinutesOverride: Int? = null,
    /** 是否要求 `Prefs.postEnabled` 为真；true = 现状。任务路传 false（见 spec §1.2）。 */
    val requirePostEnabled: Boolean = true
) {
    companion object {
        /** 现有行为：全部取现状值。 */
        fun fromPrefs(): PostRunConfig = PostRunConfig(perAccount = Prefs.postPerAccount)
    }
}
