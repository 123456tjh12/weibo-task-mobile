package com.tjh.weibotask

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

/**
 * ★★★★ 第 120 期：**发帖任务（PostTask）的一次性闹钟**机制。
 *
 * ## 它管什么
 *
 * 给 [PostTask.scheduleStart]（定时开始）挂一个**一次性**闹钟：到 [PostTask.scheduleAtMillis]
 * 触发一次 `ACTION_RUN_POST_TASK`，之后不再重挂。与签到主闹钟（[LocalScheduler]）**完全独立**：
 *
 * - **独立 request code**：见 [requestCodeFor]（按 taskId 哈希取 10000..24575 段），
 *   与签到主闹钟（2001）/ 看门狗（2003）/ 展示 intent（2002）不撞。
 * - **绝不写 `Prefs.nextRunAt`**：那是签到主闹钟的业务时间，写了会让维护循环
 *   以为「下次执行还早」而一直等（v19.4 的致命 bug）。发帖任务的触发时刻存在
 *   [PostTask.scheduleAtMillis]（PostTaskStore 自己的数据），不占 Prefs。
 * - **接收端复用 [CheckinAlarmReceiver]**：带 [EXTRA_POST_TASK_ID] 标记，Receiver 在
 *   守卫与心跳**之前**分流到发帖任务路径，绝不影响签到链路（也就无需改清单、新增 Receiver）。
 *
 * ## 去重（已跑不重触）
 *
 * 一次性任务开跑前由 [AgentService.executePostTaskOnce] 写 [PostTask.ranAt]；
 * 之后闹钟即便再响（异常残留），Receiver 见 `ranAt != null` 直接跳过。
 * 开机重挂只挑 `scheduleStart && ranAt == null && scheduleAtMillis 在未来` 的任务（见 [remountPending]）。
 */
object PostTaskScheduler {

    /** 发帖任务闹钟的标记：Receiver 靠它区分「签到闹钟」和「发帖任务闹钟」。 */
    const val EXTRA_POST_TASK_ID = "com.tjh.weibotask.EXTRA_POST_TASK_ID"

    /** 发帖任务 request code 基址；与签到主闹钟（2001/2002/2003）留足间隔。 */
    private const val REQUEST_CODE_BASE = 10000

    /** setAlarmClock 展示用 intent 的 request code（与任务码段 10000..24575 不撞）。 */
    private const val SHOW_REQUEST_CODE = 9000

    /**
     * 由 taskId 稳定算出 request code（0..0x3FFF 偏移到 10000..24575）。
     *
     * ★ 必须**跨重启稳定**（同一 taskId 永远同一 code），否则开机重挂会挂出一个
     *   新 PendingIntent、旧的cancel不掉。UUID 的 hashCode 稳定满足这一点。
     */
    fun requestCodeFor(taskId: String): Int =
        REQUEST_CODE_BASE + (taskId.hashCode() and 0x3FFF)

    /**
     * 挂一次性闹钟：[triggerAtMillis] 触发 `ACTION_RUN_POST_TASK(taskId)`。
     *
     * 三级降级与 [LocalScheduler.scheduleAt] 同款（setAlarmClock → setExactAndAllowWhileIdle
     * → setAndAllowWhileIdle），但**不写任何 Prefs**。触发时刻过近时兜底推到 1 分钟后
     * （避免登记到过去时间点导致立刻触发 + 反复重排的死循环）。
     */
    fun scheduleOneShot(context: Context, taskId: String, triggerAtMillis: Long) {
        val now = System.currentTimeMillis()
        val safeTrigger = if (triggerAtMillis <= now + 5_000L) now + 60_000L else triggerAtMillis
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(context, taskId)
        try {
            alarmManager.setAlarmClock(
                AlarmManager.AlarmClockInfo(safeTrigger, showIntent(context)),
                pi
            )
            return
        } catch (_: Exception) {
        }
        try {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
            return
        } catch (_: Exception) {
        }
        try {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
        } catch (_: Exception) {
            // 三档全失败：不写 Prefs，静默（发帖任务丢一次触发可接受，绝不能污染签到 nextRunAt）。
        }
    }

    /** 取消某任务的一次性闹钟（任务被删 / 已跑 / 用户改配置时调用）。 */
    fun cancel(context: Context, taskId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            alarmManager.cancel(pendingIntent(context, taskId))
        } catch (_: Exception) {
        }
    }

    /**
     * ★★★★ 第 123 期（用户拍板）：算出 [anchorMillis]（一个具体时刻）的
     * **下一次未来出现**——「每天重复」把同一时刻每天循环：跑完一幕后
     * 把闹钟挂到本函数返回的时刻。
     *
     * ★ 中国无夏令时，直接 +24h 不会漂移；加 5 秒余量与 [scheduleOneShot]
     *   的「过近推 1 分钟」兜底对齐（刚跑完的当天时刻不会被误判成「未来」）。
     */
    fun nextDailyOccurrence(anchorMillis: Long, nowMillis: Long): Long {
        val day = 24 * 60 * 60 * 1000L
        var next = anchorMillis
        while (next <= nowMillis + 5_000L) next += day
        return next
    }

    /**
     * 开机 / 解锁后重挂所有「该挂还没挂」的发帖任务闹钟。
     *
     * 重启会清掉 AlarmManager 里的登记。挑 `ranAt == null`（还没跑过 / 有排定触发票）的任务：
     *   · ★★★★ 第 126 期（用户拍板）：**还在落盘的排队队列里** ——
     *     说明它已经被准入过一次（用户点过开始 / 闹钟已响过），只是没轮到就断了进程。
     *     按补跑时刻（若有，作为下限）或「现在」重挂，等它自己把队列跑空。
     *     不加这一条的话，「立即开始 + 不限时间窗」的任务排队后遇进程被杀 = **永久丢失**。
     *   · ★★★★ 第 123 期：正在**等补跑**（`retryAtMillis != null`）→ 优先按**补跑时刻**重挂
     *     （不按 scheduleAtMillis——那多半已过点，走下面「已过点挂现在」会抢在
     *     RateGuard 休息结束之前白跑一趟）；补跑点已过（重启吞掉）→ 挂现在立即补。
     *   · `scheduleStart` 开 → 重挂到 [PostTask.scheduleAtMillis]（仅当还在未来）；
     *   · ★★★★ 第 121 期：`scheduleStart` 且**已过点**（`at <= now`）——
     *     闹钟被重启吞掉、任务还没跑 ⇒ 重挂到**现在**立即补跑。
     *     不重挂的话「到点那天恰好重启过」的任务会**永久丢失**（一次性闹钟不会再来）。
     *     `scheduleOneShot` 内部会把过近的触发推到 1 分钟后，不会死循环。
     *   · `limitWindow` 开但没设定时开始 → 等到窗口开启再跑（窗内 = 现在，窗外 = 下一窗口起点）。
     *     ★ 这一类（「立即开始 + 限窗、保存时窗外被重挂等窗口」）同样要跨重启存活，
     *       否则重启就丢了、永远等不到窗口。
     *   · 两者都没开 → 不重挂（纯「立即跑一次」任务；若因重启没跑成，用户重新保存即可，
     *     不自动重挂以免每次开机都意外跑一遍）。
     * 到点后的时间窗判定（P2）由 [AgentService.executePostTaskOnce] 负责，这里只负责「把闹钟挂回去」。
     */
    fun remountPending(context: Context) {
        PostTaskStore.init(context)
        // ★★★★ 第 126 期（用户拍板）：把**落盘的排队队列**读回来。
        //   不读的话，「排队期间进程被杀」的任务在下面这个循环里根本认不出来 ——
        //   它既没有 scheduleStart、也没有时间窗、也没有 retryAtMillis，
        //   会直接掉进 `when` 的 else 什么都不挂 ⇒ 永久丢失。
        TaskQueue.init(context)
        val now = System.currentTimeMillis()
        val nowCal = Calendar.getInstance()
        for (task in PostTaskStore.all()) {
            if (task.ranAt != null) continue
            // ★ 显式拷贝到局部变量：var 属性不能做智能转换（与下面 s/e 同一套路）。
            val retryAt = task.retryAtMillis
            val s = task.windowStartMinute
            val e = task.windowEndMinute
            when {
                // ★★★★ 第 126 期（用户拍板）：**还在队列里** ⇒ 它已经被「准入」过一次
                //   （用户点过开始 / 闹钟已经响过），只是没轮到就断了进程。
                //   按补跑时刻（若有）或「现在」重挂，等它自己把队列跑空。
                //   ★ 放在 `retryAt != null` 之前是刻意的：在队列里说明用户要它**现在**跑，
                //     补跑时刻只是它的下限，不能因为排了补跑就把它推到后面去。
                TaskQueue.contains(task.id) -> {
                    val trigger = if (retryAt != null && retryAt > now) retryAt else now
                    scheduleOneShot(context, task.id, trigger)
                }
                retryAt != null -> {
                    scheduleOneShot(context, task.id, if (retryAt > now) retryAt else now)
                }
                task.scheduleStart -> {
                    val at = task.scheduleAtMillis ?: continue
                    if (at > now) {
                        scheduleOneShot(context, task.id, at)
                    } else {
                        // ★ 第 121 期：已过点未跑（重启吞掉闹钟）→ 挂「现在」立即补跑。
                        scheduleOneShot(context, task.id, now)
                    }
                }
                // 显式非空判断，触发智能转换（s/e 在此分支内是 Int）
                task.limitWindow && s != null && e != null && s != e -> {
                    val trigger =
                        if (ScheduleWindow.inWindow(ScheduleWindow.minuteOfDay(nowCal), s, e)) {
                            now
                        } else {
                            ScheduleWindow.nextWindowStartMillis(nowCal, s, e)
                        }
                    scheduleOneShot(context, task.id, trigger)
                }
            }
        }
    }

    private fun pendingIntent(context: Context, taskId: String): PendingIntent {
        val intent = Intent(context, CheckinAlarmReceiver::class.java)
            .putExtra(EXTRA_POST_TASK_ID, taskId)
        return PendingIntent.getBroadcast(
            context,
            requestCodeFor(taskId),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** setAlarmClock() 要求的展示用 PendingIntent（点状态栏闹钟图标打开本应用）。 */
    private fun showIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
        return PendingIntent.getActivity(
            context,
            SHOW_REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
