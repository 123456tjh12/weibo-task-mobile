package com.tjh.weibotask

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * ★★★★ 第 116 期：**「创建超话发帖任务」弹窗**的「参与账号」口径。
 *
 * 用户 2026-10-15 拍板：本期**只做「全部」与「手动」**，
 * 「分组」显示但**置灰**（点了弹一句提示，不改变选中态）——
 * 因为账号分组这个功能在本工程里**还不存在**，做成可点就是骗人。
 *
 * ★ 枚举名进 JSON（`toJson` 写 `name`），老数据认不出时退回 [ALL] ——
 *   与 [InteractAction.fromName] 同一套兜底纪律：**认不出就当默认值**，
 *   绝不让一份新写的名字把整条任务读崩。
 */
enum class PostAccountScope {
    ALL,
    GROUP,
    MANUAL;

    companion object {
        fun fromName(value: String): PostAccountScope =
            entries.firstOrNull { it.name == value } ?: ALL
    }
}

/**
 * ★★★★ 第 116 期：**一个「超话发帖任务」**。
 *
 * ## 它是什么
 *
 * 用户原话：「我想做的是，首先需要有默认发帖的内容，其次，客户可以自己添加内容发帖」
 * +「把立即发一条试试这个按钮，换成创建任务，创建任务之后自动执行」。
 *
 * ⇒ 主界面那个「立即发一条试试」按钮改成「创建任务」，点开就是这张表单；
 *   表单填完**落盘成一条 [PostTask]**。
 *
 * ## ★★ 本期边界（用户明确选择「分两期做」）
 *
 * **本期只到「落盘」为止**：表单保存后**不执行任何发帖**，
 * 不调 `startPostRunFromUi()`、不碰 `AgentService`、不写 [Prefs]。
 * 「保存后立即开始」的**编排链路下一期**接 ——
 * 所以 [startImmediately] / [scheduleStart] / [limitWindow] 这三个开关
 * 本期**只存值**，没有任何执行侧读取点。这是刻意的，不是漏了。
 *
 * ## ★ 字段全部是本功能自己的
 *
 * 与 [InteractTask] 同一条纪律：这里**没有一个字段是 [WeiboAccount] 上的**。
 * 账号的状态机（`restUntil` / `needsVerify` / `lastRunAt` / `lastRunDate`）
 * 在本文件里**根本没有对应的写入口** —— 这是「加它不影响四条核心链路」的物理保证。
 * [accountIds] 存的是 `WeiboAccount.id` 的**副本**，只是「用户勾了哪几个」的记录，
 * 不是对账号对象的引用；账号被删掉时这条记录只会变成一个对不上的 id，
 * 不会去动账号表。
 *
 * ## ★ 默认值 = 设计稿上的默认态
 *
 * 见 `dialog_post_task.xml` 与 `PostTaskSheet` 的注释；这里是**唯一**的定义处，
 * 界面上的初值一律取自本类的默认参数（避免「XML 写一套、代码写一套」）。
 */
data class PostTask(
    var id: String = UUID.randomUUID().toString(),
    /** 任务名称；空串 = 未命名（弹窗里那个「任务名称（可选）」）。 */
    var name: String = "",
    /** 参与账号口径；默认 [PostAccountScope.ALL]。 */
    var accountScope: PostAccountScope = PostAccountScope.ALL,
    /** [PostAccountScope.MANUAL] 时用户勾中的账号 id（[WeiboAccount.id]）。 */
    var accountIds: List<String> = emptyList(),
    /**
     * 勾选的发帖文案来源 id（[PostContentSource.id]）。
     *
     * ★★ **必填**：弹窗的「保存」在一条都没勾时是**置灰**的。
     *   依据是设计稿里 5 项全未勾选时保存按钮为禁用态。
     */
    var contentSourceIds: List<String> = emptyList(),
    /** 「同步到个人微博」；默认开。 */
    var syncToWeibo: Boolean = true,
    /** 每账号每轮发帖数；默认 1。 */
    var perAccountPerRound: Int = 1,
    /** 轮数；默认 1。 */
    var rounds: Int = 1,
    /** 轮间等待（分钟）；默认 20。 */
    var roundWaitMinutes: Int = 20,
    /** 动作间隔（秒）；默认 5。 */
    var actionGapSeconds: Int = 5,
    /** 频繁基础冷却（分钟）；默认 10。 */
    var rateCoolMinutes: Int = 10,
    /** 「为该任务显示独立悬浮窗（可拖动）」；默认开。 */
    var showOverlay: Boolean = true,
    /** 「定时开始」；默认关。 */
    var scheduleStart: Boolean = false,
    /** 定时开始的具体时刻；[scheduleStart] 为真时有值，否则 `null`。 */
    var scheduleAtMillis: Long? = null,
    /** 「限制运行时间段」；默认关。 */
    var limitWindow: Boolean = false,
    /** 时间段起点：当天第几分钟（0..1439）；未设置 = `null`。 */
    var windowStartMinute: Int? = null,
    /** 时间段终点：当天第几分钟（0..1439）；未设置 = `null`。 */
    var windowEndMinute: Int? = null,
    /** 「保存后立即开始」；默认开。★ 本期**只存值**，执行链路下一期接。 */
    var startImmediately: Boolean = true,
    var createdAt: Long = System.currentTimeMillis()
) {

    /**
     * ★ 写 JSON。字段名与 [fromJson] **必须逐字对应** ——
     *   两边一起改，改一个忘一个会静默丢字段（`optXxx` 的默认值会把它吃掉）。
     *
     * ★ 可空数字写成 `JSONObject.NULL` 而不是省略：省略与「值就是 null」
     *   在语义上一样，但写出来能让 JSON 自查时一眼看出「这个字段存在且为空」。
     */
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("accountScope", accountScope.name)
        .put("accountIds", stringArray(accountIds))
        .put("contentSourceIds", stringArray(contentSourceIds))
        .put("syncToWeibo", syncToWeibo)
        .put("perAccountPerRound", perAccountPerRound)
        .put("rounds", rounds)
        .put("roundWaitMinutes", roundWaitMinutes)
        .put("actionGapSeconds", actionGapSeconds)
        .put("rateCoolMinutes", rateCoolMinutes)
        .put("showOverlay", showOverlay)
        .put("scheduleStart", scheduleStart)
        .put("scheduleAtMillis", scheduleAtMillis ?: JSONObject.NULL)
        .put("limitWindow", limitWindow)
        .put("windowStartMinute", windowStartMinute ?: JSONObject.NULL)
        .put("windowEndMinute", windowEndMinute ?: JSONObject.NULL)
        .put("startImmediately", startImmediately)
        .put("createdAt", createdAt)

    companion object {

        private fun stringArray(values: List<String>): JSONArray {
            val array = JSONArray()
            for (value in values) array.put(value)
            return array
        }

        /** 读一个字符串数组；缺字段 / 类型不对一律读成空列表。 */
        private fun readStrings(source: JSONObject, key: String): List<String> {
            val array = source.optJSONArray(key) ?: return emptyList()
            val out = mutableListOf<String>()
            for (i in 0 until array.length()) {
                val value = array.optString(i, "")
                if (value.isNotBlank()) out.add(value)
            }
            return out
        }

        /**
         * 读一个**可空** Int。
         *
         * ★ 用 `Int.MIN_VALUE` 当哨兵再 `takeIf` 掉，是为了把
         *   「缺字段 / 显式 null / 写了个非数字」三种情况**统一**读成 `null` ——
         *   否则 `optInt(key, 0)` 会把「没设置」误读成「设置成了 0 分钟」。
         */
        private fun readNullableInt(source: JSONObject, key: String): Int? {
            if (source.isNull(key)) return null
            val value = source.optInt(key, Int.MIN_VALUE)
            return if (value == Int.MIN_VALUE) null else value
        }

        /** 读一个**可空** Long，哨兵同理（见 [readNullableInt]）。 */
        private fun readNullableLong(source: JSONObject, key: String): Long? {
            if (source.isNull(key)) return null
            val value = source.optLong(key, Long.MIN_VALUE)
            return if (value == Long.MIN_VALUE) null else value
        }

        fun fromJson(source: JSONObject): PostTask = PostTask(
            id = source.optString("id").ifBlank { UUID.randomUUID().toString() },
            name = source.optString("name"),
            accountScope = PostAccountScope.fromName(source.optString("accountScope")),
            accountIds = readStrings(source, "accountIds"),
            contentSourceIds = readStrings(source, "contentSourceIds"),
            // 默认值一律与上面那个 data class 的默认参数**保持一致** ——
            // 老数据 / 缺字段时读出来的任务，必须与「刚打开弹窗时的默认态」完全一样。
            syncToWeibo = source.optBoolean("syncToWeibo", true),
            perAccountPerRound = source.optInt("perAccountPerRound", 1),
            rounds = source.optInt("rounds", 1),
            roundWaitMinutes = source.optInt("roundWaitMinutes", 20),
            actionGapSeconds = source.optInt("actionGapSeconds", 5),
            rateCoolMinutes = source.optInt("rateCoolMinutes", 10),
            showOverlay = source.optBoolean("showOverlay", true),
            scheduleStart = source.optBoolean("scheduleStart", false),
            scheduleAtMillis = readNullableLong(source, "scheduleAtMillis"),
            limitWindow = source.optBoolean("limitWindow", false),
            windowStartMinute = readNullableInt(source, "windowStartMinute"),
            windowEndMinute = readNullableInt(source, "windowEndMinute"),
            startImmediately = source.optBoolean("startImmediately", true),
            createdAt = source.optLong("createdAt")
        )
    }
}
