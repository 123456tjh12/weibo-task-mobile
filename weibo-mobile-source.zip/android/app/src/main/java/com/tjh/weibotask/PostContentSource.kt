package com.tjh.weibotask

/**
 * ★★★★ 第 113 期：**发帖文案来源（`contentSources` 插槽）**。
 *
 * 用户原话（2026-10-14）：
 *   「代码需要预留 contentSources（发帖文案来源）的插槽，因为我后续会自己加具体的文案数据源。」
 *
 * 现状：文案来源写死在 `Prefs.postContentText` 里 —— 一个「多段用单独一行 --- 分隔」的字符串。
 * 本文件把它抽象成一个接口，**默认实现就是现状、逐字不变**；
 * 后续要加的「数据源」只要实现 [PostContentSource] 并注册进 [PostContentRegistry]，
 * 调用方拿到的就自动是新来源，**不用再改调用点**。
 *
 * ★★ 本期**只提供 [PrefsContentSource]**（= 现有行为）。
 *   `RemoteContentSource`（拉接口）/ `LocalFileContentSource`（读本地文件）/
 *   `AIContentSource`（生成）这些**本期不写，只留位**。
 *
 * ★★★ 所有未来实现必须遵守的同一条铁律：
 *   **[bodies] 返回空列表 = 「没有可用内容」，调用方必须据此跳过发帖** ——
 *   绝不能返回占位文案（那会让账号发出一条毫无意义的帖子，是比不发更糟的结果）。
 */
interface PostContentSource {

    /** 稳定标识（用于持久化用户的选择）。 */
    val id: String

    /** 界面上显示的名字。 */
    val displayName: String

    /** 取本次可用的全部文案。空列表 = 无可用内容。 */
    fun bodies(): List<String>
}

/**
 * 默认实现：读写 `Prefs.postContentText`（多段以单独一行 --- 分隔）。
 *
 * ★★★ 这里的切段正则必须与 `AgentService.parsePostBodies` **逐字一致**
 *   （(?m)^\s*-{3,}\s*$），否则「界面显示的分段」会和「真正发出去的分段」对不上 ——
 *   这是本项目公认最难查的一类问题。
 * ★★ 本期把 **`MainActivity` 那一份删掉**、改为调用本文件的 split；
 *   `AgentService` 那一份**原样保留** —— 它属于**核心链路②（发帖）**，
 *   本期按硬规则一行未动（`AgentService.kt` md5 与改前逐字节相同）。
 *   ⇒ 全工程仍是两份正则（本文件 + AgentService），但**界面侧**从此只有这一个入口：
 *     后续接上新的 PostContentSource 实现时，界面显示会**自动跟着来源走**，
 *     不会再出现「换了数据源、界面还按老规则切」的割裂。
 */
object PrefsContentSource : PostContentSource {

    override val id = "prefs"

    override val displayName = "本地文案（默认）"

    /** 分段规则：单独一行（允许前后空白）的三个及以上连字符。 */
    private val SEGMENT_REGEX = Regex("(?m)^\\s*-{3,}\\s*$")

    /**
     * 把「--- 分隔的单字符串」拆成一条条。
     *
     * ★ 空段直接丢掉：用户点了「＋ 添加一条」还没填，不该变成一条空帖子。
     */
    fun split(raw: String): List<String> =
        raw.split(SEGMENT_REGEX).map { it.trim() }.filter { it.isNotBlank() }

    override fun bodies(): List<String> = split(Prefs.postContentText)
}

/**
 * 来源注册表 —— 用户后续 new 一个 [PostContentSource] 实现丢进来即可。
 *
 * ★★ 本期 [active] **没有任何调用点**，这是**刻意的**：
 *   它就是这个插槽本身。真正的接入点（`AgentService.runPostPhase` 取文案那一行）
 *   属**核心链路②**，留到后续期次与本插槽的实际使用者一起接 ——
 *   现在硬接上去只会为了「看起来没白写」而多动一次核心代码。
 */
object PostContentRegistry {

    private val sources = linkedMapOf<String, PostContentSource>(
        PrefsContentSource.id to PrefsContentSource
    )

    /** 当前生效的来源。默认 = 现有行为。 */
    @Volatile
    var active: PostContentSource = PrefsContentSource
        private set

    /** 注册（同 id 覆盖）。 */
    fun register(src: PostContentSource) {
        sources[src.id] = src
    }

    /** 已注册的全部来源。 */
    fun all(): List<PostContentSource> = sources.values.toList()

    /** 切换当前来源；id 不存在则保持原样（不抛异常）。 */
    fun pick(id: String) {
        sources[id]?.let { active = it }
    }
}
