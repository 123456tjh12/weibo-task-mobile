package com.tjh.weibotask

/**
 * ★★★★ 第 113 期：**发帖文案来源（`contentSources` 插槽）**。
 *
 * 用户原话（2026-10-14）：
 *   「代码需要预留 contentSources（发帖文案来源）的插槽，因为我后续会自己加具体的文案数据源。」
 *
 * 现状：文案来源写死在 `Prefs.postContentText` 里 —— 一个「多段用单独一行 --- 分隔」的字符串。
 * 本文件把它抽象成一个接口，**默认实现就是现状、逐字不变**；
 * 后续要加的「数据源」只要实现 [PostContentSource] 并注册进 [PostContentRegistry]，
 * 调用方拿到的就自动是新来源，**不用再改调用点**。
 *
 * ★★ 本期**只提供 [PrefsContentSource]**（= 现有行为）。
 *   `RemoteContentSource`（拉接口）/ `LocalFileContentSource`（读本地文件）/
 *   `AIContentSource`（生成）这些**本期不写，只留位**。
 *
 * ★★★ 所有未来实现必须遵守的同一条铁律：
 *   **[bodies] 返回空列表 = 「没有可用内容」，调用方必须据此跳过发帖** ——
 *   绝不能返回占位文案（那会让账号发出一条毫无意义的帖子，是比不发更糟的结果）。
 *
 * ★★★★ 第 116 期补充：本期注册的 5 个只读源（`video_25` / `video_04` /
 *   `video_05` / `builtin` / `video_new`）**就是故意返回空列表的** ——
 *   用户 2026-10-15 选了「先搭结构、内容留空待补」。
 *   ⇒ **谁先接上执行链路，谁负责处理空列表**（跳过 + 明确提示，
 *     不许静默、更不许拿占位文案顶上）。
 *
 * ★★★★ 第 118 期（用户拍板，2026-10-16）：**那 5 个空占位源已被替换成 5 个内置真内容源**。
 *
 *   用户原话：
 *     「把绿色框里的文案来源删除，换成我接下来这几个 word 文档，名字就是 word 文档的名字」
 *   决定：「**内置进 APK（只读）**」+「**保留「本地文案（默认）」**」
 *
 *   · 删：`ReadonlyPlaceholderSource` 类本身，以及 `builtin` / `video_new` 两个 id；
 *   · 增：[BuiltinContentSource] + [BuiltinPostContent] 里的 5 组正文（共 75 条）；
 *   · 留：`video_25` / `video_04` / `video_05` **三个 id 沿用**（老任务勾过它们仍然有效），
 *         只是显示名从「帖」改成「贴」、内容从空变成真文案。
 *
 *   ⇒ 从本期起，界面上的 5 个只读项**不再是空占位**，勾了就能真的发出内容。
 *     [bodies] 返回空列表的那条铁律**依然有效**（它是接口契约），
 *     只是本期没有任何一个已注册来源会命中它了。
 */
interface PostContentSource {

    /** 稳定标识（用于持久化用户的选择）。 */
    val id: String

    /** 界面上显示的名字。 */
    val displayName: String

    /** 取本次可用的全部文案。空列表 = 无可用内容。 */
    fun bodies(): List<String>
}

/**
 * 默认实现：读写 `Prefs.postContentText`（多段以单独一行 --- 分隔）。
 *
 * ★★★ 这里的切段正则必须与 `AgentService.parsePostBodies` **逐字一致**
 *   （(?m)^\s*-{3,}\s*$），否则「界面显示的分段」会和「真正发出去的分段」对不上 ——
 *   这是本项目公认最难查的一类问题。
 * ★★ 本期把 **`MainActivity` 那一份删掉**、改为调用本文件的 split；
 *   `AgentService` 那一份**原样保留** —— 它属于**核心链路②（发帖）**，
 *   本期按硬规则一行未动（`AgentService.kt` md5 与改前逐字节相同）。
 *   ⇒ 全工程仍是两份正则（本文件 + AgentService），但**界面侧**从此只有这一个入口：
 *     后续接上新的 PostContentSource 实现时，界面显示会**自动跟着来源走**，
 *     不会再出现「换了数据源、界面还按老规则切」的割裂。
 */
object PrefsContentSource : PostContentSource {

    override val id = "prefs"

    override val displayName = "本地文案（默认）"

    /** 分段规则：单独一行（允许前后空白）的三个及以上连字符。 */
    private val SEGMENT_REGEX = Regex("(?m)^\\s*-{3,}\\s*$")

    /**
     * 把「--- 分隔的单字符串」拆成一条条。
     *
     * ★ 空段直接丢掉：用户点了「＋ 添加一条」还没填，不该变成一条空帖子。
     */
    fun split(raw: String): List<String> =
        raw.split(SEGMENT_REGEX).map { it.trim() }.filter { it.isNotBlank() }

    override fun bodies(): List<String> = split(Prefs.postContentText)
}

/**
 * ★★★★ 第 118 期：**内置只读源**（「创建超话发帖任务」弹窗里那 5 个勾选项）。
 *
 * ## 它是什么
 *
 * 正文来自 [BuiltinPostContent]（用户 2026-10-16 给的 5 个 Word 文档），
 * **编译进 APK、只读**——用户拍板「内置进 APK（只读）」。
 *
 * ## 与第 116 期那个 `ReadonlyPlaceholderSource` 的区别（关键）
 *
 * 第 116 期那 5 个源 [bodies] **恒返回 `emptyList()`**（用户当时选「先搭结构、内容留空待补」）；
 * 本类的 [bodies] **返回真实内容**。这不是「把占位文案顶上」——
 * [BuiltinPostContent] 里的每一条都是用户文档里的原文，不是编的。
 *
 * ## 为什么用一个类而不是 5 个 object
 *
 * 五个源的差别只有 id / 显示名 / 正文三样，行为完全一样。写 5 个 object 等于把
 * 同一段「返回 content」抄 5 遍 —— 以后改一处忘四处。
 */
private class BuiltinContentSource(
    override val id: String,
    override val displayName: String,
    /** 内置正文。★ 由 [BuiltinPostContent] 提供，本类不加工、不裁剪。 */
    private val content: List<String>
) : PostContentSource {

    override fun bodies(): List<String> = content
}

/**
 * 来源注册表 —— 用户后续 new 一个 [PostContentSource] 实现丢进来即可。
 *
 * ★★ 本期 [active] **没有任何调用点**，这是**刻意的**：
 *   它就是这个插槽本身。真正的接入点（`AgentService.runPostPhase` 取文案那一行）
 *   属**核心链路②**，留到后续期次与本插槽的实际使用者一起接 ——
 *   现在硬接上去只会为了「看起来没白写」而多动一次核心代码。
 */
object PostContentRegistry {

    /**
     * ★★★★ 第 118 期：注册表仍是 **6 个**，但后 5 个**全换了**。
     *
     * - [PrefsContentSource] **仍排第一** —— 它既是现有行为，也是 [active] 的默认值；
     *   用户拍板「**保留它**」（它是目前唯一由用户自己维护的文案来源）。
     * - 后面 5 个是**内置真内容源**（见 [BuiltinContentSource]），
     *   **这个顺序就是弹窗里的显示顺序**，与用户 2026-10-16 给文档的顺序一致，
     *   不许随意调整。
     *
     * ★ 第 116 期的 `builtin`（内置发帖文案库）/ `video_new`（新音视频帖）**已删除**；
     *   `video_25` / `video_04` / `video_05` **沿用旧 id**（老任务勾过它们仍然有效），
     *   显示名从「帖」改成「贴」以与用户文档名一致。
     */
    private val sources = linkedMapOf<String, PostContentSource>(
        PrefsContentSource.id to PrefsContentSource,
        "zyr_promo" to BuiltinContentSource(
            "zyr_promo", "张奕然安利文案", BuiltinPostContent.ZYR_PROMO
        ),
        "video_05" to BuiltinContentSource(
            "video_05", "五公视频贴", BuiltinPostContent.VIDEO_05
        ),
        "ct_photo" to BuiltinContentSource(
            "ct_photo", "主唱ct带图", BuiltinPostContent.CT_PHOTO
        ),
        "video_25" to BuiltinContentSource(
            "video_25", "25公演视频贴", BuiltinPostContent.VIDEO_25
        ),
        "video_04" to BuiltinContentSource(
            "video_04", "4月公演视频贴", BuiltinPostContent.VIDEO_04
        )
    )

    /**
     * 当前生效的来源。默认 = 现有行为（[PrefsContentSource]）。
     *
     * ★★★★ 第 118 期：**仍然是 [PrefsContentSource]，没有改**。
     *
     *   注意别把本字段与「任务选哪份文案」搞混 —— 两者是不同的东西：
     *   · 本字段 = 全局默认（旧「自动发帖」链路用），**至今没有调用点在读**；
     *   · 「任务选哪份文案」= 第 117 期起由 `PostTaskPlan.bodies(task)` 按
     *     `task.contentSourceIds` 从 [all] 里挑，**那才是真正生效的那条路**。
     *   ⇒ 本期给 5 个源填上真内容后，**任务路**立刻就能发出这些内容；
     *     而旧「自动发帖」链路（读 `Prefs.postContentText`）**一行未动**。
     */
    @Volatile
    var active: PostContentSource = PrefsContentSource
        private set

    /** 注册（同 id 覆盖）。 */
    fun register(src: PostContentSource) {
        sources[src.id] = src
    }

    /** 已注册的全部来源。 */
    fun all(): List<PostContentSource> = sources.values.toList()

    /** 切换当前来源；id 不存在则保持原样（不抛异常）。 */
    fun pick(id: String) {
        sources[id]?.let { active = it }
    }
}
