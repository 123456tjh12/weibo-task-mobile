package com.tjh.weibotask

import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.random.Random

data class WeiboTopic(
    val id: String,
    val name: String,
    val done: Boolean,
    val scheme: String
)

data class CheckinOutcome(
    val status: String,
    val riskScore: Int,
    val errorCode: String,
    val pauseReason: String,
    val consecutiveFailures: Int,
    val summary: JSONObject
)

class RiskException(message: String, val event: String) : Exception(message)

object WeiboClient {
    private const val BASE = "https://m.weibo.cn"
    private const val FOLLOW_SUPER = "100803_-_followsuper"
    private const val LIST_REFERER = BASE + "/p/index?containerid=" + FOLLOW_SUPER
    private const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"

    /**
     * 首屏游标。微博「我的超话」列表的 since_id 不是数字，而是一段 JSON 游标：
     *   {"manage":"","follow":"1022:10080xxxx","page":1}
     * 不带游标虽然通常也能拿到第一页，但条目数会被限制；
     * 拿不到任何超话时，用它再要一次首屏。
     */
    private const val FIRST_CURSOR = "{\"manage\":\"\",\"follow\":\"\",\"page\":1}"

    fun fetchConfig(): JSONObject {
        val json = httpJson(BASE + "/api/config", BASE + "/")
        val data = json.optJSONObject("data") ?: return JSONObject()
        // 结构异常（风控页 / 错误页 / 空响应）时不要据此判定登录失效，
        // 否则一次异常响应就会被上层当成「掉线」，进而关掉自动签到
        if (!data.has("login")) return data
        if (!data.optBoolean("login")) Prefs.weiboVerified = false
        return data
    }

    suspend fun runCheckin(): CheckinOutcome {
        val config = fetchConfig()
        if (!config.has("login")) {
            // 拿不到登录态：网络抖动或微博返回结构异常，不能误判成掉线
            return CheckinOutcome(
                "RETRY", Prefs.riskScore, "CONFIG_UNKNOWN",
                "无法获取微博登录态", Prefs.consecutiveFailures, JSONObject()
            )
        }
        if (!config.optBoolean("login")) {
            Prefs.weiboVerified = false
            val risk = addRisk(40)
            return CheckinOutcome("USER_REQUIRED", risk, "LOGIN_ANOMALY", "微博登录已失效", Prefs.consecutiveFailures, JSONObject())
        }

        var st = config.optString("st")

        // ★ 每一轮都从「干净」的状态开始。
        //   旧代码直接继承上一轮的 consecutiveFailures，只要上一轮停在 3，
        //   本轮第一个超话一失败就立刻 >=3 直接收工 —— 表现出来就是「只签到一个」。
        Prefs.consecutiveFailures = 0
        if (Prefs.riskScore > 0) Prefs.riskScore = Prefs.riskScore / 2

        val topics = fetchTopics()
        val pending = topics.filter { !it.done && it.scheme.isNotBlank() }
        val summary = JSONObject()
            .put("total", topics.size)
            .put("selected", pending.size)
            .put("success", 0)
            .put("already", 0)
            .put("failed", 0)
            .put("retried", 0)
            .put("skipped", topics.size - pending.size)
            .put("detail", "")

        if (pending.isEmpty()) {
            Prefs.consecutiveFailures = 0
            return CheckinOutcome("SUCCESS", Prefs.riskScore, "", "", 0, summary)
        }

        var consecutive = 0
        val failedTopics = mutableListOf<WeiboTopic>()
        for ((index, topic) in pending.withIndex()) {
            var finalMessage = ""
            var succeeded = false
            var alreadySigned = false

            for (attempt in 0..2) {
                try {
                    val result = checkinTopic(topic, st)
                    finalMessage = result.optString("message")
                    val state = result.optString("status")
                    if (state == "success" || state == "already") {
                        succeeded = true
                        alreadySigned = state == "already"
                        break
                    }
                    val event = classifyRisk(finalMessage)
                    if (event == "CAPTCHA") {
                        // 验证码只能人工处理，立刻停下，但把已完成的统计带回去
                        appendDetail(summary, topic.name, "需要验证码")
                        Prefs.consecutiveFailures = consecutive
                        return CheckinOutcome("USER_REQUIRED", addRisk(50), "CAPTCHA", finalMessage, consecutive, summary)
                    }
                    if (event == "REQUEST_ANOMALY") {
                        val risk = addRisk(20)
                        // ★ 不再一遇到「请求异常」就整批放弃。
                        //   旧代码 risk >= 70 直接 return，而 riskScore 是跨轮累计的，
                        //   很容易卡在高位，导致后面每个超话都签不到。现在只在极端情况下才停。
                        if (risk >= 90) {
                            appendDetail(summary, topic.name, "风控")
                            Prefs.consecutiveFailures = consecutive
                            return CheckinOutcome("PAUSED", risk, "RISK_SCORE", finalMessage, consecutive, summary)
                        }
                    }
                } catch (error: RiskException) {
                    if (error.event == "CAPTCHA") {
                        appendDetail(summary, topic.name, "需要验证码")
                        Prefs.consecutiveFailures = consecutive
                        return CheckinOutcome("USER_REQUIRED", addRisk(50), "CAPTCHA", error.message ?: "需要验证码", consecutive, summary)
                    }
                    finalMessage = error.message ?: "请求异常"
                } catch (error: Exception) {
                    finalMessage = error.message ?: "签到失败"
                }

                if (attempt < 2) delay(2000L + Random.nextLong(3000L))
            }

            if (succeeded) {
                if (alreadySigned) {
                    summary.put("already", summary.optInt("already") + 1)
                    appendDetail(summary, topic.name, "已签")
                } else {
                    summary.put("success", summary.optInt("success") + 1)
                    appendDetail(summary, topic.name, "成功")
                }
                consecutive = 0
                Prefs.consecutiveFailures = 0
            } else {
                summary.put("failed", summary.optInt("failed") + 1)
                appendDetail(summary, topic.name, "失败")
                failedTopics.add(topic)
                consecutive += 1
                Prefs.consecutiveFailures = consecutive
                if (consecutive >= 5) {
                    Prefs.consecutiveFailures = consecutive
                    return CheckinOutcome("PAUSED", addRisk(20), "CONSECUTIVE_FAILURE", "连续失败 " + consecutive + " 次，已提前停止", consecutive, summary)
                }
            }

            if (index < pending.size - 1) {
                // 刷新 st（失败也不影响主流程），并留一点间隔，避免请求过于密集
                val refreshed = try {
                    fetchConfig().optString("st")
                } catch (_: Exception) {
                    ""
                }
                if (refreshed.isNotBlank()) st = refreshed
                delay(3000L + Random.nextLong(5000L))
            }
        }

        // ★ 补签一轮：主循环里失败的超话，先歇一会儿再统一重试一次。
        //   微博经常对密集请求返回一次「请求异常 / 系统繁忙」，隔几十秒重来往往就成功了。
        //   只做一轮，不做无限重试，避免被判定成风控行为。
        if (failedTopics.isNotEmpty()) {
            // 先冷却 20~40 秒，让上一轮的限流状态散掉
            delay(20000L + Random.nextLong(20000L))

            for (topic in failedTopics.take(12)) {
                var retryMessage = ""
                var retryState = ""

                for (attempt in 0..1) {
                    try {
                        val result = checkinTopic(topic, st)
                        retryMessage = result.optString("message")
                        retryState = result.optString("status")
                        if (retryState == "success" || retryState == "already") break
                    } catch (error: RiskException) {
                        if (error.event == "CAPTCHA") {
                            // 验证码只能人工处理，立刻停下
                            appendDetail(summary, topic.name, "需要验证码")
                            Prefs.consecutiveFailures = 0
                            return CheckinOutcome(
                                "USER_REQUIRED", addRisk(50), "CAPTCHA",
                                error.message ?: "需要验证码", 0, summary
                            )
                        }
                        retryMessage = error.message ?: "请求异常"
                    } catch (error: Exception) {
                        retryMessage = error.message ?: "签到失败"
                    }
                    if (attempt < 1) delay(3000L + Random.nextLong(4000L))
                }

                if (retryState == "success" || retryState == "already") {
                    // 把之前记的「失败」改成「重试成功 / 重试已签」，并把计数挪过来
                    summary.put("failed", (summary.optInt("failed") - 1).coerceAtLeast(0))
                    summary.put("retried", summary.optInt("retried") + 1)
                    if (retryState == "already") {
                        summary.put("already", summary.optInt("already") + 1)
                        replaceDetail(summary, topic.name, "失败", "重试已签")
                    } else {
                        summary.put("success", summary.optInt("success") + 1)
                        replaceDetail(summary, topic.name, "失败", "重试成功")
                    }
                    Prefs.consecutiveFailures = 0
                } else {
                    replaceDetail(summary, topic.name, "失败", "重试仍失败")
                    Prefs.consecutiveFailures = summary.optInt("failed")
                    if (classifyRisk(retryMessage) == "CAPTCHA") {
                        Prefs.consecutiveFailures = 0
                        return CheckinOutcome(
                            "USER_REQUIRED", addRisk(50), "CAPTCHA",
                            retryMessage, 0, summary
                        )
                    }
                }

                val refreshed = try {
                    fetchConfig().optString("st")
                } catch (_: Exception) {
                    ""
                }
                if (refreshed.isNotBlank()) st = refreshed
                delay(3000L + Random.nextLong(4000L))
            }
        }

        return CheckinOutcome("SUCCESS", Prefs.riskScore, "", "", Prefs.consecutiveFailures, summary)
    }

    /**
     * 拉取「我的超话」全量列表。
     *
     * 旧实现的两个问题：
     *  1. 只在首屏没有条目时才不管游标；游标推进判断过严，容易只拿到第一页；
     *  2. 解析依赖固定的 card_group/buttons 层级，微博一旦改结构就静默少拿。
     * 现在按游标翻页，并且用「连续两页没有新增」作为终止条件。
     */
    private suspend fun fetchTopics(): List<WeiboTopic> {
        val output = mutableListOf<WeiboTopic>()
        val seen = mutableSetOf<String>()
        var cursor = ""
        var triedFirstCursor = false
        var emptyStreak = 0

        var page = 0
        while (page < 50) {
            page++
            val url = StringBuilder(BASE + "/api/container/getIndex?containerid=" + FOLLOW_SUPER)
            if (cursor.isNotBlank()) url.append("&since_id=").append(URLEncoder.encode(cursor, "UTF-8"))

            val payload = try {
                httpJson(url.toString(), LIST_REFERER)
            } catch (_: Exception) {
                null
            } ?: break
            val data = payload.optJSONObject("data") ?: break
            val cards = data.optJSONArray("cards") ?: JSONArray()

            val before = output.size
            collectTopics(cards, output, seen)
            val added = output.size - before

            // 首屏一条都没解析出来：换成官方首屏游标再试一次（只试一次）
            if (output.isEmpty() && cursor.isBlank() && !triedFirstCursor) {
                triedFirstCursor = true
                cursor = FIRST_CURSOR
                continue
            }

            val next = data.optJSONObject("cardlistInfo")?.optString("since_id").orEmpty()
            if (next.isBlank() || next == cursor) break

            if (added == 0) {
                emptyStreak++
                if (emptyStreak >= 2) break
            } else {
                emptyStreak = 0
            }

            cursor = next
            delay(800L + Random.nextLong(700L))
        }
        return output
    }

    /**
     * 递归遍历整棵卡片树，收集所有超话。
     *
     * 兼容两种已知结构：
     *  - m.weibo.cn 网页版：cards[].card_group[].{title_sub, buttons:[{name:"签到", scheme}]}
     *  - 原生 App 接口：cards[].card_group[].{card_type:8, title_sub, scheme}
     * 另外不再假设层级，任意嵌套里的同类对象都会被收进来。
     */
    private fun collectTopics(
        node: Any?,
        output: MutableList<WeiboTopic>,
        seen: MutableSet<String>,
        depth: Int = 0
    ) {
        if (depth > 12) return
        when (node) {
            is JSONArray -> {
                for (i in 0 until node.length()) collectTopics(node.opt(i), output, seen, depth + 1)
            }
            is JSONObject -> {
                val name = node.optString("title_sub").ifBlank { node.optString("title") }
                if (name.isNotBlank()) {
                    var scheme = ""
                    var done = false

                    val buttons = node.optJSONArray("buttons")
                    if (buttons != null) {
                        for (i in 0 until buttons.length()) {
                            val button = buttons.optJSONObject(i) ?: continue
                            val buttonName = button.optString("name").trim()
                            // 「已签到」也包含「签到」两个字，所以要先排除掉
                            if (buttonName.contains("签到") && !buttonName.contains("已签")) {
                                val candidate = button.optString("scheme")
                                if (candidate.isNotBlank()) scheme = candidate
                            }
                            if (buttonName.contains("已签") || buttonName.contains("明日再来")) done = true
                        }
                    }

                    // 少数卡片把签到链接直接挂在卡片上（没有 buttons 数组）
                    if (scheme.isBlank()) {
                        val direct = node.optString("scheme")
                        if (direct.contains("container/button") || direct.contains("checkin") || direct.contains("active_fcheckin")) {
                            scheme = direct
                        }
                    }

                    if (scheme.isNotBlank() || done) {
                        val key = topicKey(node, name, scheme)
                        if (seen.add(key)) output.add(WeiboTopic(key, name, done, scheme))
                    }
                }

                // 继续往下走，覆盖 card_group / cards 以及其它任意嵌套
                val keys = node.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    if (key == "buttons") continue
                    val child = node.opt(key)
                    if (child is JSONObject || child is JSONArray) {
                        collectTopics(child, output, seen, depth + 1)
                    }
                }
            }
        }
    }

    /**
     * 去重键。
     *
     * ★ 这里是「只签到一个超话」的根因所在：
     *   旧代码用 node.optString("oid").ifBlank { node.optString("id", name) } 当键，
     *   而 m.weibo.cn 卡片上的 id/oid 往往是**整张卡片共用**的，不是每个超话一个。
     *   于是 seen.add(id) 只有第一个超话成功，后面的全被判成「重复」丢掉，
     *   pending 只剩 1 条 —— 表现就是「只签到一个」。
     *
     * 现在优先用签到链接里的 containerid（每个超话唯一），
     * 其次 itemid，最后才退回超话名。
     */
    private fun topicKey(node: JSONObject, name: String, scheme: String): String {
        val containerId = extractParam(scheme, "containerid")
        if (containerId.isNotBlank()) return containerId
        val itemId = node.optString("itemid").ifBlank { node.optString("oid") }
        if (itemId.isNotBlank()) return itemId
        return "name:" + name
    }

    private fun extractParam(url: String, key: String): String {
        val marker = key + "="
        val index = url.indexOf(marker)
        if (index < 0) return ""
        val rest = url.substring(index + marker.length)
        val end = rest.indexOfFirst { it == '&' || it == '#' }
        return (if (end < 0) rest else rest.substring(0, end)).trim()
    }

    private fun appendDetail(summary: JSONObject, name: String, result: String) {
        val line = name + "：" + result
        val current = summary.optString("detail")
        val merged = if (current.isBlank()) line else current + "；" + line
        summary.put("detail", if (merged.length > 400) merged.take(400) + "…" else merged)
    }

    /**
     * 把某个超话的结果从 from 改写成 to。
     * 补签成功后用它把「失败」就地改成「重试成功」，而不是再追加一行，
     * 这样列表里一个超话只会出现一次结果。
     */
    private fun replaceDetail(summary: JSONObject, name: String, from: String, to: String) {
        val current = summary.optString("detail")
        val old = name + "：" + from
        if (current.contains(old)) {
            summary.put("detail", current.replace(old, name + "：" + to))
        } else {
            // 极端情况下（详情被 400 字截断）退化成追加，保证结果不丢
            appendDetail(summary, name, to)
        }
    }

    private fun checkinTopic(topic: WeiboTopic, st: String): JSONObject {
        val url = if (topic.scheme.startsWith("http")) topic.scheme else BASE + topic.scheme

        // ★ 参考实现（网页版接口）只用 Cookie 直接 GET，并不需要 st。
        //   旧代码无条件往签到链接后面拼 st=，一旦这个 st 过期就会返回验签失败，
        //   而下一轮又未必能刷到新 st，于是后面的超话全部签不动。
        //   现在先按不带 st 的方式请求，只有真的报验签错误时才补一次带 st 的重试。
        var payload = httpJson(url, LIST_REFERER)
        if (isStError(payload)) {
            val freshRaw = try {
                fetchConfig().optString("st")
            } catch (_: Exception) {
                ""
            }
            val fresh = freshRaw.ifBlank { st }
            if (fresh.isNotBlank()) {
                val withSt = url + (if (url.contains("?")) "&" else "?") + "st=" + URLEncoder.encode(fresh, "UTF-8")
                payload = httpJson(withSt, LIST_REFERER)
            }
        }

        val data = payload.optJSONObject("data") ?: JSONObject()
        val message = data.optString("msg")
            .ifBlank { data.optString("tipMessage").ifBlank { payload.optString("msg") } }
        val code = payload.optString("code").ifBlank { data.optString("code") }
        return when {
            // 「已签」要先判断：这类响应往往 ok 也是 1，否则会被算成新签到
            message.contains("已签") || message.contains("明日再来") || code == "382004" ->
                JSONObject().put("status", "already").put("message", message.ifBlank { "今日已签到" })
            payload.optInt("ok") == 1 || code == "100000" || code == "382010" ->
                JSONObject().put("status", "success").put("message", message.ifBlank { "签到成功" })
            else -> JSONObject().put("status", "failed").put("message", message.ifBlank { "签到失败" })
        }
    }

    private fun isStError(payload: JSONObject): Boolean {
        return payload.optString("errno") == "100015" ||
            payload.optString("msg").contains("验签") ||
            payload.optJSONObject("data")?.optString("msg")?.contains("验签") == true
    }

    private fun classifyRisk(message: String): String {
        val lower = message.lowercase()
        if (lower.contains("验证码") || lower.contains("安全验证") || lower.contains("captcha")) return "CAPTCHA"
        if (lower.contains("访问频繁") || lower.contains("请求异常") || lower.contains("系统繁忙") || lower.contains("风控")) return "REQUEST_ANOMALY"
        return ""
    }

    private fun addRisk(delta: Int): Int {
        val value = (Prefs.riskScore + delta).coerceIn(0, 100)
        Prefs.riskScore = value
        return value
    }

    private fun httpJson(urlText: String, referer: String): JSONObject {
        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 20000
        connection.readTimeout = 20000
        connection.setRequestProperty("Accept", "application/json, text/plain, */*")
        connection.setRequestProperty("User-Agent", UA)
        connection.setRequestProperty("Referer", referer)
        connection.setRequestProperty("X-Requested-With", "XMLHttpRequest")
        connection.setRequestProperty("MWeibo-Pwa", "1")
        if (Prefs.cookieHeader.isNotBlank()) connection.setRequestProperty("Cookie", Prefs.cookieHeader)

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        updateCookies(connection)
        connection.disconnect()

        if (code == 403 || code == 429) throw RiskException("微博请求异常 HTTP $code", "REQUEST_ANOMALY")
        if (code !in 200..299) throw IllegalStateException("微博 HTTP $code")
        if (text.contains("验证码") || text.contains("安全验证")) throw RiskException("检测到验证码", "CAPTCHA")
        return if (text.isBlank()) JSONObject() else JSONObject(text)
    }

    private fun updateCookies(connection: HttpURLConnection) {
        val values = linkedMapOf<String, String>()
        Prefs.cookieHeader.split(";").forEach { part ->
            val item = part.trim()
            val index = item.indexOf('=')
            if (index > 0) values[item.substring(0, index).trim()] = item.substring(index + 1).trim()
        }

        for ((header, headerValues) in connection.headerFields) {
            if (header == null || !header.equals("Set-Cookie", ignoreCase = true)) continue
            for (raw in headerValues) {
                val pair = raw.substringBefore(';').trim()
                val index = pair.indexOf('=')
                if (index <= 0) continue
                val name = pair.substring(0, index).trim()
                val value = pair.substring(index + 1).trim()
                if (value.isNotEmpty()) values[name] = value
            }
        }

        if (values.isNotEmpty()) {
            Prefs.cookieHeader = values.entries.joinToString("; ") { "${it.key}=${it.value}" }
        }
        val alf = values["ALF"]?.toLongOrNull()
        if (alf != null && alf > 0L) Prefs.cookieExpiryAt = alf * 1000L
    }
}
