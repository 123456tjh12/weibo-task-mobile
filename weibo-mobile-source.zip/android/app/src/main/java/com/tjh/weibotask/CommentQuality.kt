package com.tjh.weibotask

import android.content.Context

/**
 * ★★★★ 第 56 期：语料的「低质风险」自检 —— **纯本地、只读、只提示，不拦不拦改**。
 *
 * ## 为什么要有它
 *
 * 第 46 期阶段 3 真的把评论发出去了（评论 id `5350040316936616`），
 * 但微博把它**折叠**成「疑似低质或无意义」—— 计数照算，默认不显示。
 *
 * 这不是发送链路的错，链路 100% 通了。**这是内容问题**：
 * 那条评语是「话题标签 + 大量 emoji + @某人」的成套模板。
 * 微博的判据是黑盒，但「成套模板」这个形状是能从**本地**看出来的。
 *
 * ⇒ 与其让用户去猜，不如在**填语料的那一刻**就把风险说清楚。
 *
 * ## 边界（与 [CommentLib] 同一条纪律）
 *
 * - **只读**：只读用户填进来的那段文本，不读盘、不写盘、不联网。
 * - **不拦**：它**从不**阻止用户保存、也**从不**改写用户写的字。
 *   用户的语料是他的，我们只给意见。判定留在人手里。
 * - 不碰 [Prefs]、不碰 [AccountStore]、不碰 [WeiboClient]。
 *   把本文件整个删掉，签到 / 发帖 / 验证 / 互动发送的行为不会有任何变化。
 *
 * ## 判据为什么是「计数」而不是「认词」
 *
 * ★★★ 本工程反复吃过「认文案」的亏（第 54 期：微博把
 * 「还没有人评论哦~快来抢沙发！」换了个说法，写死的判据就静默失效）。
 * 所以这里**一个中文关键词都不认** —— 只数四件与语义无关的形状：
 * 话题标签个数、表情/符号个数、有没有 `@`、正文长度。
 * 微博换文案不影响这四个数；用户写什么内容也不影响这四个数。
 */
object CommentQuality {

    /** 一条评语的自检结果。`reasons` 为空 = 没看出模板味。 */
    class Verdict(val reasons: List<String>) {
        val ok: Boolean get() = reasons.isEmpty()
    }

    /** 整组自检的结果。 */
    class GroupReport(val total: Int, val risky: Int, val samples: List<String>) {
        val ok: Boolean get() = risky == 0
    }

    /**
     * 话题标签：`#...#`。
     *
     * ★ 用 `[^#\n]` 而不是 `.*?`：微博的话题标签里**不会有换行**，
     *   而 `.*?` 在跨行时会一口气吞掉好几条评语（批量导入时尤其明显）。
     * ★ 限 1~40 字：真话题名不会太长；不限长的话，一段文字里孤零零一个 `#`
     *   会跟很远的另一个 `#` 配成一对，把普通句子数成话题。
     */
    private val TOPIC_TAG = Regex("#[^#\\n]{1,40}#")

    /** 从第几个话题标签开始算「像广告」。 */
    private const val TOPIC_WARN = 2

    /** 从第几个表情/符号开始算「像模板」。 */
    private const val EMOJI_WARN = 6

    /** 超过多少字算「偏长」。 */
    private const val LENGTH_WARN = 80

    /**
     * 数「表情/符号」。
     *
     * 两个来源相加：
     *  1. **补充平面**的字符（UTF-16 里占 2 个 char）—— 绝大多数 emoji 都在这，
     *     用 `codePointAt` 的宽度判定，不需要一张 emoji 表。
     *  2. 基本平面里常见的**装饰符号**：`U+2600~U+27BF`（☀ ✨ ✅ ★ …）、
     *     `U+2B00~U+2BFF`（⭐ …）。
     *
     * ★ 刻意**不**把 `U+FE0F`（变体选择符）单独计数 —— 它是修饰符，不是表情本身，
     *   单独算会一个表情数成两个。
     * ★ 这里数的是「形状」，不是「语义」：`★` 用在正文里也算一个符号。
     *   宁可偶尔多算，也不去维护一张永远不全的 emoji 表。
     */
    private fun countSymbols(text: String): Int {
        var count = 0
        var index = 0
        while (index < text.length) {
            val codePoint = text.codePointAt(index)
            val width = Character.charCount(codePoint)
            if (width == 2) {
                count++
            } else if (codePoint in 0x2600..0x27BF || codePoint in 0x2B00..0x2BFF) {
                count++
            }
            index += width
        }
        return count
    }

    /**
     * 检查一条评语。
     *
     * @return [Verdict]；`reasons` 是**给人看的原因**（已本地化），空 = 没看出问题
     */
    fun check(context: Context, text: String): Verdict {
        val reasons = mutableListOf<String>()
        val value = text.trim()
        if (value.isBlank()) return Verdict(reasons)

        val topics = TOPIC_TAG.findAll(value).count()
        if (topics >= TOPIC_WARN) {
            reasons.add(context.getString(R.string.interact_quality_topics, topics))
        }

        val symbols = countSymbols(value)
        if (symbols >= EMOJI_WARN) {
            reasons.add(context.getString(R.string.interact_quality_symbols, symbols))
        }

        if (value.contains("@")) {
            reasons.add(context.getString(R.string.interact_quality_at))
        }

        if (value.length > LENGTH_WARN) {
            reasons.add(context.getString(R.string.interact_quality_length, value.length))
        }
        return Verdict(reasons)
    }

    /**
     * 把一条评语的结果拼成**一行**（对话框里实时显示用）。
     *
     * ★ 有风险时只报**处数**，不列全文 —— 输入框本来就窄，
     *   列全文会把用户正在写的那一行挤没。
     */
    fun summaryLine(context: Context, verdict: Verdict): String = if (verdict.ok) {
        context.getString(R.string.interact_quality_hint_ok)
    } else {
        context.getString(R.string.interact_quality_hint_risk, verdict.reasons.size)
    }

    /**
     * 对话框里那一行提示：**内容 + 它该用什么颜色**。
     *
     * ★ 第 57 期把「文字」和「是否正常」一起返回，是为了让界面只调一次
     *   [liveHint] —— 否则界面得先 `check` 一遍拿颜色、再 `liveHint` 一遍拿文字，
     *   同一段文本判两次，两处口径还有走偏的可能。
     */
    class LineHint(val text: String, val ok: Boolean)

    /**
     * ★★ 第 57 期：对话框里真正用的那一行提示 —— **自动区分「一条」和「一批」**。
     *
     * 为什么必须分开：用户可能一次粘 20 条评语。如果照旧把整段文字当成一条来数，
     * 20 条各带 1 个话题标签会被合起来数成 20 个 ⇒ **永远报警**，成了假信号，
     * 用户很快就会学会无视它 —— 那这个提示就废了。
     * ⇒ 多行时**按行分别判**，只报「N 行里有 M 行像模板」。
     *
     * ★ 空行忽略（`addLines` 也忽略空行，两边口径一致）。
     */
    fun liveHint(context: Context, text: String): LineHint {
        val lines = text.split("\n").map { it.trim() }.filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            return LineHint(context.getString(R.string.interact_quality_hint_ok), true)
        }
        if (lines.size == 1) {
            val verdict = check(context, lines[0])
            return LineHint(summaryLine(context, verdict), verdict.ok)
        }
        val risky = lines.count { !check(context, it).ok }
        return if (risky == 0) {
            LineHint(context.getString(R.string.interact_quality_hint_ok), true)
        } else {
            LineHint(
                context.getString(R.string.interact_quality_hint_batch, lines.size, risky),
                false
            )
        }
    }

    /**
     * 整组扫一遍。
     *
     * ★ 只扫**用户自己那组**，不跨组 —— 分组是用户区分场景用的（夸人 / 提问 / 催更），
     *   混着扫等于把用户的分类意图抹掉（同 [CommentLib.pickFirst] 的理由）。
     */
    fun checkGroup(context: Context, groupId: String): GroupReport {
        val group = CommentLib.findGroup(groupId)
            ?: return GroupReport(0, 0, emptyList())
        var risky = 0
        val samples = mutableListOf<String>()
        for (line in group.lines) {
            if (check(context, line.text).ok) continue
            risky++
            if (samples.size < MAX_SAMPLES) samples.add(line.text)
        }
        return GroupReport(group.lines.size, risky, samples)
    }

    /** 整组自检最多列几条示例。 */
    private const val MAX_SAMPLES = 3
}
