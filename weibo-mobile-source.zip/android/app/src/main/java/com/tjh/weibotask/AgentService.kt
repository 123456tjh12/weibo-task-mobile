package com.tjh.weibotask

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class AgentService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var running = false
    private var maintenanceJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        AccountStore.init(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RUN_CHECKIN -> {
                startForegroundNotification("正在准备签到")
                requestRun()
            }
            ACTION_START_SCHEDULED -> {
                startForegroundNotification("自动签到运行中")
                if (Prefs.scheduleEnabled) {
                    LocalScheduler.ensureScheduled(this)
                    startMaintenance()
                }
            }
            else -> {
                startForegroundNotification("自动签到运行中")
                if (Prefs.scheduleEnabled) startMaintenance()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        maintenanceJob?.cancel()
        scope.cancel()
        wakeLock?.release()
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun requestRun() {
        if (running) return
        running = true
        scope.launch {
            try {
                executeOnce()
            } finally {
                running = false
                if (!Prefs.scheduleEnabled) {
                    stopSelf()
                } else {
                    LocalScheduler.ensureScheduled(this@AgentService)
                    startMaintenance()
                }
            }
        }
    }

    private fun startMaintenance() {
        if (maintenanceJob?.isActive == true) return
        maintenanceJob = scope.launch {
            while (isActive) {
                if (!Prefs.scheduleEnabled) {
                    stopSelf()
                    break
                }
                val remaining = Prefs.nextRunAt - System.currentTimeMillis()
                if (remaining <= 0L) {
                    requestRun()
                    delay(60000)
                } else {
                    delay(min(max(remaining, 15000L), 15 * 60 * 1000L))
                }
            }
        }
    }

    private suspend fun executeOnce() {
        AccountStore.init(this)
        Prefs.running = true
        Prefs.lastRunAt = System.currentTimeMillis()
        Prefs.lastRunMessage = "正在准备签到"
        try {
            val accounts = AccountStore.enabled()
            if (accounts.isEmpty()) {
                Prefs.lastRunStatus = "USER_REQUIRED"
                Prefs.lastRunMessage = "还没有添加微博账号，请先在首页添加并登录"
                updateNotification("还没有添加微博账号")
                if (Prefs.scheduleEnabled) LocalScheduler.scheduleNext(this)
                return
            }

            val ready = accounts.filter { it.loggedIn }
            val skipped = accounts.filter { !it.loggedIn }

            if (ready.isEmpty()) {
                Prefs.lastRunStatus = "USER_REQUIRED"
                Prefs.lastRunMessage = "所有账号都未登录，请先完成微博登录"
                updateNotification("所有账号都未登录")
                if (Prefs.scheduleEnabled) LocalScheduler.scheduleNext(this)
                return
            }

            // 账号越多整轮越长，唤醒锁按时长放宽（每个账号最多 6 分钟，外加 10 分钟余量）
            acquireWakeLock((ready.size * 6 + 10).coerceAtLeast(30))

            val lines = mutableListOf<String>()
            var needsUser = false
            var anyPaused = false

            // ★ 逐个账号串行签到。
            //   不做并发：微博的风控是按账号算的，但同一台设备 IP 相同，
            //   并发请求会让几个号同时被判定成异常流量，反而更容易全盘失败。
            for ((index, account) in ready.withIndex()) {
                val prefix = "[" + account.label + "] "
                updateNotification(prefix + "准备签到（" + (index + 1) + "/" + ready.size + "）")

                // 把每个超话的进度实时写回通知栏和首页。
                // 多账号下必须带账号名前缀，否则用户不知道卡在哪个号上。
                val outcome = WeiboClient.runCheckin(account) { text ->
                    Prefs.lastRunMessage = prefix + text
                    updateNotification(prefix + text)
                }

                account.lastRunAt = System.currentTimeMillis()
                account.lastRunStatus = outcome.status
                account.lastRunMessage = buildResultMessage(outcome)

                lines.add(prefix + oneLineSummary(outcome))
                val detail = outcome.summary.optString("detail")
                if (detail.isNotBlank()) lines.add(detail)

                when (outcome.status) {
                    "USER_REQUIRED" -> needsUser = true
                    "PAUSED" -> anyPaused = true
                }

                // 每签完一个账号就落盘一次：万一后面某个账号把进程搞崩了，
                // 前面已经签好的结果和刷新过的 Cookie 不会丢
                AccountStore.save()
            }

            // 没登录的账号也要在结果里说清楚，否则用户会以为「少签了一个」
            for (account in skipped) {
                account.lastRunStatus = "USER_REQUIRED"
                account.lastRunMessage = "未登录，已跳过"
                lines.add("[" + account.label + "] 未登录，已跳过")
                needsUser = true
            }
            AccountStore.save()

            Prefs.lastRunDate = today()
            val status = when {
                needsUser -> "USER_REQUIRED"
                anyPaused -> "PAUSED"
                else -> "SUCCESS"
            }
            Prefs.lastRunStatus = status
            Prefs.lastRunMessage = lines.joinToString("\n")

            when (status) {
                "SUCCESS" -> {
                    Prefs.pausedUntil = 0L
                    updateNotification("全部账号签到完成")
                    if (Prefs.scheduleEnabled) LocalScheduler.scheduleNext(this)
                }
                "USER_REQUIRED", "PAUSED" -> {
                    // 旧实现：Prefs.scheduleEnabled = false + LocalScheduler.cancel()
                    // 风控、验证码、连续失败都只是临时状态，一旦永久关闭调度，
                    // 用户就会看到「到点完全没执行」，而且界面上几乎没有任何提示。
                    // 改为限时暂停，到期自动重试。
                    Prefs.pausedUntil = System.currentTimeMillis() + PAUSE_DURATION_MS
                    updateNotification(
                        if (needsUser) "有账号需要人工处理，稍后自动重试"
                        else "部分账号被风控暂停，稍后自动重试"
                    )
                    if (Prefs.scheduleEnabled) LocalScheduler.scheduleNext(this)
                }
                else -> {
                    updateNotification("签到失败")
                    if (Prefs.scheduleEnabled) LocalScheduler.scheduleNext(this)
                }
            }
        } catch (error: Exception) {
            Prefs.lastRunStatus = "FAILED"
            Prefs.lastRunMessage = "执行失败：" + (error.message ?: "未知错误")
            updateNotification(Prefs.lastRunMessage)
            if (Prefs.scheduleEnabled) LocalScheduler.scheduleNext(this)
        } finally {
            // 无论正常结束、提前 return 还是抛异常，都要清掉「正在执行」标记，
            // 否则首页会永远停在「正在执行」上
            Prefs.running = false
            wakeLock?.release()
            wakeLock = null
        }
    }

    /**
     * 单个账号的一行汇总，用于多账号结果列表。
     * 明细（哪个超话失败、失败原因）由 summary.detail 另起一行展示。
     */
    private fun oneLineSummary(outcome: CheckinOutcome): String {
        return when (outcome.status) {
            "SUCCESS" -> {
                val total = outcome.summary.optInt("total")
                if (total == 0) {
                    "没有读到任何超话"
                } else {
                    "共 " + total + " 个超话" +
                        (if (outcome.summary.optInt("doneInList") > 0)
                            "（微博已标已签 " + outcome.summary.optInt("doneInList") + " 个，跳过）" else "") +
                        "，新签 " + outcome.summary.optInt("success") +
                        "，已签过 " + outcome.summary.optInt("already") +
                        "，失败 " + outcome.summary.optInt("failed") +
                        (if (outcome.summary.optInt("retried") > 0)
                            "（已自动补签 " + outcome.summary.optInt("retried") + " 个）" else "")
                }
            }
            "USER_REQUIRED" -> "需要人工处理：" + outcome.pauseReason.ifBlank { "验证码或登录异常" }
            "PAUSED" -> "已暂停：" + outcome.pauseReason.ifBlank { "风控" }
            else -> "失败：" + outcome.errorCode.ifBlank { outcome.status }
        }
    }

    private fun buildResultMessage(outcome: CheckinOutcome): String {
        return when (outcome.status) {
            "SUCCESS" -> {
                val total = outcome.summary.optInt("total")
                val selected = outcome.summary.optInt("selected")
                val already = outcome.summary.optInt("already")
                val failed = outcome.summary.optInt("failed")
                val retried = outcome.summary.optInt("retried")
                val doneInList = outcome.summary.optInt("doneInList")
                val detail = outcome.summary.optString("detail")
                val head = if (total == 0) {
                    "没有读到任何超话（可能是登录态或接口异常）"
                } else {
                    // ★ 数字必须能对上：共 N 个 = 微博已标已签的 + 本次需签的。
                    //   旧文案只说「共 30 个超话，待签 3」，30 和 3 之间的缺口没有任何解释，
                    //   用户会以为漏签了 27 个 —— 所以这里把「跳过多少、为什么跳过」写清楚。
                    "签到完成：共 " + total + " 个超话" +
                        (if (doneInList > 0) "（其中 " + doneInList + " 个微博显示今日已签，未重复请求）" else "") +
                        "，本次需签 " + selected + " 个：新签 " + outcome.summary.optInt("success") +
                        "，已签过 " + already + "，失败 " + failed +
                        (if (retried > 0) "（已自动补签 " + retried + " 个）" else "")
                }
                if (detail.isBlank()) head else head + "\n" + detail
            }
            "USER_REQUIRED" -> "需要人工处理：" + outcome.pauseReason.ifBlank { "验证码或登录异常" }
            "PAUSED" -> "任务暂停：" + outcome.pauseReason.ifBlank { "风控暂停" }
            else -> "签到失败：" + outcome.errorCode.ifBlank { outcome.status }
        }
    }

    private fun today(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date())
    }

    private fun acquireWakeLock(minutes: Int) {
        wakeLock?.release()
        wakeLock = null
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WeiboTask::CheckinWakeLock")
        wakeLock?.setReferenceCounted(false)
        // ★ 旧值是固定 10 分钟。多个超话逐个签到时（每个之间还要间隔几秒），
        //   很容易超过 10 分钟，唤醒锁一到期 CPU 就允许休眠，
        //   协程被挂起 → 后面的超话根本没机会签。
        //   多账号之后整轮时间成倍增长，所以改成按账号数动态计算（见 executeOnce）。
        wakeLock?.acquire(minutes * 60 * 1000L)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "星签后台执行", NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun startForegroundNotification(text: String) {
        val notification = buildNotification(text)
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
                return
            } catch (_: Exception) {
                // 类型不被系统接受时退回「不声明类型」，避免整个服务起不来
            }
        }
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, 0)
        } catch (_: Exception) {
        }
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("星签")
            .setContentText(text)
            .setContentIntent(pending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    companion object {
        const val ACTION_RUN_CHECKIN = "com.tjh.weibotask.RUN_CHECKIN"
        const val ACTION_START_SCHEDULED = "com.tjh.weibotask.START_SCHEDULED"
        const val ACTION_STOP = "com.tjh.weibotask.STOP"

        /**
         * 风控 / 验证码等临时状态的暂停时长，到期自动重试。
         *
         * ★ 旧值是 6 小时。后果是：一旦触发暂停，当天剩下的超话就**再也不会被签**，
         *   用户第二天才发现「昨天有几个没签上」。
         *   现在改成 30 分钟 —— 足够让微博的限流状态恢复，又不至于把当天剩下的一次性放弃。
         */
        private const val PAUSE_DURATION_MS = 30 * 60 * 1000L
        private const val CHANNEL_ID = "weibo_task_agent"
        private const val NOTIFICATION_ID = 1001
    }
}
