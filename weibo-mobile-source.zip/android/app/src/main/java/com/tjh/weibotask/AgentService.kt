package com.tjh.weibotask

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class AgentService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var running = false
    private var maintenanceJob: Job? = null

    /**
     * 唤醒信号：用来把正在 `delay()` 里睡觉的维护循环立刻叫醒。
     *
     * ★★ 为什么必须有它 —— 这是 v0.19.11 定位到的「必须打开 App 才执行」的真正原因：
     *
     *   维护循环的等待时长是**按当时的 nextRunAt 算出来**的，上限 15 分钟。
     *   用户点「测试自动签到」时，nextRunAt 还停在「明天」，所以循环正睡在一个
     *   接近 15 分钟的 `delay` 里。紧接着任务被排到 **2 分钟后** ——
     *   但循环不知道，它要等这次 delay 睡完（最长 15 分钟）才会重新读时间。
     *
     *   更要命的是这段时间**没有任何唤醒保护**（唤醒锁只在循环体里申请）：
     *   vivo 的后台冻结会把整个进程挂起，于是
     *     · 循环到点也不会醒；
     *     · 系统闹钟的投递也可能被一并推迟。
     *   结果就是「到点什么都不发生，一打开 App 立刻执行」。
     *
     *   有了这个信号，`startMaintenance()` 能在**排程变化的当下**把循环踢醒，
     *   循环随即按新的 nextRunAt 重新计算等待时间并申请唤醒锁 —— 等待窗口被真正保护起来。
     *
     * 用 CONFLATED 是刻意的：只需要「有人叫过我」这一个事实，
     * 连按几次测试按钮不该积压成多次唤醒。
     */
    private val maintenanceWake = Channel<Unit>(Channel.CONFLATED)
    private var wakeLock: PowerManager.WakeLock? = null
    private var standbyWakeLock: PowerManager.WakeLock? = null
    private var foregroundStartError: String = ""

    override fun onCreate() {
        super.onCreate()
        // ★ startForegroundService() 之后系统只给很短时间进入前台状态。
        //   旧顺序先初始化 Android Keystore、解密全部账号 JSON、再启动通知；
        //   冷启动 + 息屏刚唤醒时这些工作可能超过时限，服务会被系统直接杀掉。
        //   现在先占住前台服务资格，再做加密存储初始化。
        createNotificationChannel()
        foregroundStartError = startForegroundNotification(getString(R.string.state_standby)).orEmpty()
        Prefs.init(this)
        AccountStore.init(this)
        // ★ 黑匣子先接上：闹钟触发的这一轮，常常跑在一个「App 界面从没打开过」的进程里。
        //   不在这里 init 的话，验证链路的日志只会留在内存里，进程一被杀就全丢 ——
        //   而「自动签到失败」恰恰经常伴随进程被回收。
        SliderTrace.init(this)
        // ★ 把「签到判定依据」的出口挂上（见 WeiboClient.traceSink 的说明）。
        //   网络层不认识 Prefs，由服务在启动时注入 —— 这样多账号的状态隔离规则不被破坏，
        //   同时「显示成功但没签上」这类问题有了可复现的证据链。
        WeiboClient.traceSink = { line ->
            try {
                Prefs.appendCheckinTrace(line)
            } catch (_: Exception) {
            }
        }
        // 服务被重建 = 上一次执行一定已经中断，清掉可能残留的状态。
        Prefs.running = false
        Prefs.standbyProtectedUntil = 0L
        if (foregroundStartError.isNotBlank()) {
            Prefs.lastRunStatus = "FGS_FAILED"
            Prefs.lastRunMessage = getString(R.string.run_msg_fgs_failed, foregroundStartError)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 「闹钟触发」只证明广播到了；这个时间证明服务的 onStartCommand 也真的到了。
        // 两者分开记录，才能区分「闹钟没响」和「闹钟响了但服务没起来」。
        try {
            Prefs.lastServiceStartAt = System.currentTimeMillis()
        } catch (_: Exception) {
        }
        when (intent?.action) {
            ACTION_RUN_CHECKIN -> {
                // ★ 手动点「立即签到」时不分批。
                //   分批是为了「每天定时、无人值守」这个场景 —— 那种情况下把 10 个账号
                //   一次性全跑，等于在同一 IP 上打出一波密集请求。
                //   但手动点击是低频、有人值守的：用户就坐在旁边等结果，
                //   只签 3 个然后把服务停掉，剩下 7 个永远不会被跑（尤其是没开自动签到时）。
                //   所以手动 = 跑完全部可签账号，只在账号之间留间隔。
                //   ★ 用参数而不是成员变量：定时触发走的是维护循环里的 requestRun()，
                //     如果写成成员变量，上一次手动点击的 true 会残留下来，把定时任务也变成不分批。
                startForegroundNotification(getString(R.string.state_preparing_checkin))
                requestRun(allAccounts = intent?.getBooleanExtra(EXTRA_RUN_ALL, false) ?: false)
            }
            ACTION_START_SCHEDULED -> {
                startForegroundNotification(getString(R.string.state_checkin_running))
                if (Prefs.automationEnabled) {
                    LocalScheduler.ensureScheduled(this)
                    startMaintenance()
                }
            }
            ACTION_RUN_POST -> {
                startForegroundNotification(getString(R.string.state_posting))
                requestPost(allAccounts = intent?.getBooleanExtra(EXTRA_RUN_ALL, false) ?: false)
            }
            else -> {
                startForegroundNotification(getString(R.string.state_checkin_running))
                if (Prefs.automationEnabled) startMaintenance()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        maintenanceJob?.cancel()
        scope.cancel()
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        wakeLock = null
        releaseStandbyWakeLock()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /**
     * 用户从「最近任务」里划掉本应用时触发。
     *
     * ★ 为什么要在这里再拉一次服务：部分国产 ROM 在划掉任务卡片时会顺带
     *   「清理」应用进程。服务一旦死掉，到点就只能靠闹钟，而闹钟正是最容易被丢弃的一环。
     *   服务活着时维护循环会自己发现「到点了」，根本不依赖闹钟 ——
     *   所以「让服务活着」比「让闹钟更准」更根本。
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (Prefs.automationEnabled) {
            try {
                val restart = Intent(applicationContext, AgentService::class.java).apply {
                    action = ACTION_START_SCHEDULED
                }
                ContextCompat.startForegroundService(applicationContext, restart)
            } catch (error: Exception) {
                // 不再静默吞掉：START_STICKY / 闹钟仍会重试，但首页必须能看见失败原因。
                try {
                    Prefs.lastRunStatus = "BLOCKED"
                    Prefs.lastRunMessage = getString(
                        R.string.run_msg_service_restart_blocked,
                        error.javaClass.simpleName
                    )
                } catch (_: Exception) {
                }
            }
        }
        super.onTaskRemoved(rootIntent)
    }

    private fun requestRun(allAccounts: Boolean = false) {
        if (running) return
        running = true
        scope.launch {
            try {
                executeOnce(allAccounts)
            } finally {
                running = false
                if (!Prefs.automationEnabled) {
                    stopSelf()
                } else {
                    LocalScheduler.ensureScheduled(this@AgentService)
                    startMaintenance()
                }
            }
        }
    }

    /** 手动「立即发一条」：只跑发帖，不跑签到。 */
    private fun requestPost(allAccounts: Boolean = false) {
        if (running) return
        running = true
        scope.launch {
            try {
                executePostOnce(allAccounts)
            } finally {
                running = false
                if (!Prefs.automationEnabled) {
                    stopSelf()
                } else {
                    LocalScheduler.ensureScheduled(this@AgentService)
                    startMaintenance()
                }
            }
        }
    }

    private suspend fun executePostOnce(allAccounts: Boolean = false) {
        releaseStandbyWakeLock()
        AccountStore.init(this)
        Prefs.running = true
        Prefs.lastRunAt = System.currentTimeMillis()
        Prefs.lastRunMessage = getString(R.string.run_msg_posting)
        val todayStr = today()
        try {
            val ready = AccountStore.ready()
            if (ready.isEmpty()) {
                Prefs.postLastStatus = "USER_REQUIRED"
                Prefs.postLastMessage = getString(R.string.run_msg_post_no_account)
                Prefs.lastRunMessage = Prefs.postLastMessage
                updateNotification(getString(R.string.notif_post_no_account))
                return
            }
            // ★★★★ 第 80 期（用户批准）：发帖批次必须来自**发帖自己的池子**，不能用 ready。
            //
            //   ready 只回答「这个账号能不能签到」，完全不看今天发够没有。
            //   拿它取前 BATCH_SIZE 个 ⇒ 账号数 ≥ 4 时，被反复选中的永远是
            //   账号列表最前面那 3 个，第 4 个往后一直轮不到。
            //   （同一个 bug 的自动版在 runCheckin 里，见那边的长注释。）
            //
            //   postPending = 已启用 + 已登录 + 不在静置 + 无需验证 + 今天没发够，
            //   是 ready 的**子集** ⇒ 不可能放进任何 ready 之外的账号。
            //
            //   ★ allAccounts = true（手动按钮那条路）时改前改后**结果完全相同**：
            //     ready 里那些「今天已发够」的账号在 runPostPhase 里本来就被 continue 跳过，
            //     唯一的差别是少了几次空转迭代、唤醒锁按真实待发账号数申请。
            val postPool = AccountStore.postPending(todayStr, Prefs.postPerAccount)
            val batch = if (allAccounts) postPool else postPool.take(BATCH_SIZE)
            acquireWakeLock((batch.size * 5 + 10).coerceIn(10, 60))

            val lines = mutableListOf<String>()
            val remaining = runPostPhase(batch, todayStr, lines)
            AccountStore.save()

            // ★ 手动发帖不覆盖「上次签到」的状态码 —— 那是另一条链路的结果，
            //   覆盖了会让首页看不出签到到底成没成。这里只写发帖自己的记录。
            Prefs.lastRunMessage = lines.joinToString("\n").ifBlank { getString(R.string.run_msg_post_nothing) }
            if (remaining > 0) {
                if (Prefs.postEnabled) {
                    LocalScheduler.scheduleRetry(this, Prefs.postIntervalMinutes * 60_000L)
                }
            } else if (Prefs.postEnabled) {
                // ★ 今天发完了 → 排到下一个每日时间点（复用签到的时间选择器当每天发帖起点）。
                //   以前这里看 scheduleEnabled，关掉签到后就不排了 —— 第二天发帖不会自动开始。
                LocalScheduler.scheduleNext(this)
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            Prefs.postLastStatus = "INTERRUPTED"
            Prefs.postLastMessage = getString(R.string.run_msg_post_interrupted)
            try {
                updateNotification(getString(R.string.notif_post_interrupted))
            } catch (_: Exception) {
            }
            throw cancelled
        } catch (error: Exception) {
            Prefs.postLastStatus = "FAILED"
            Prefs.postLastMessage = getString(
                R.string.run_msg_post_error,
                error.message ?: getString(R.string.run_msg_unknown_error)
            )
            updateNotification(Prefs.postLastMessage)
        } finally {
            Prefs.running = false
            try {
                if (wakeLock?.isHeld == true) wakeLock?.release()
            } catch (_: Exception) {
            }
            wakeLock = null
        }
    }

    /**
     * 发帖阶段：对这一批账号，每个发**一条**帖子。
     *
     * ★★ 为什么一轮只发一条：
     *   一次连发 5 条 = 同一个账号几分钟内连续 5 次发布行为，
     *   这是微博判定「机器刷屏」最典型的形态 —— 比签到密集请求严重得多。
     *   所以拆成「每轮一条 + 间隔 N 分钟」，把发布行为拉成一条稀疏的时间线。
     *   ★ 附带好处：中途被系统冻结也不会丢进度，进度已经逐条落盘了。
     *
     * @return 本轮结束后「今天还需要发帖」的账号数（0 = 都发完了）
     */
    private suspend fun runPostPhase(
        batch: List<WeiboAccount>,
        todayStr: String,
        lines: MutableList<String>
    ): Int {
        if (!Prefs.postEnabled) return 0

        val rawLines = Prefs.postTopicsText.lineSequence()
            .map { it.trim() }.filter { it.isNotBlank() }.toList()
        // ★ 超话名单从「超话名」改成了「超话链接」：新发帖接口要 containerid，
        //   只能从链接里解析（v0.20.0）。能解析的照发，解析不了的单独报出来。
        val topics = rawLines.mapNotNull { WeiboClient.parseSuperTopicRef(it) }
        val bodies = parsePostBodies(Prefs.postContentText)
        val perAccount = Prefs.postPerAccount

        // ★ 配置不全必须明说。开启发帖却什么都没发，用户只会以为程序坏了。
        if (rawLines.isEmpty() || bodies.isEmpty()) {
            Prefs.postLastStatus = "CONFIG_MISSING"
            Prefs.postLastMessage = getString(R.string.run_msg_post_config_missing)
            lines.add(getString(R.string.post_line_config_incomplete))
            return 0
        }
        if (topics.size < rawLines.size) {
            // ★ 不中断：能解析的那几条照发，只把解析不了的行报出来。
            //   否则一行写错会让整轮发帖停提。
            val bad = getString(R.string.post_line_bad_links, rawLines.size - topics.size)
            Prefs.postLastMessage = bad
            lines.add(bad)
            if (topics.isEmpty()) return 0
        }

        val results = mutableListOf<String>()
        var anyVerify = false
        var anyPaused = false
        var posted = 0

        for ((index, account) in batch.withIndex()) {
            if (!account.loggedIn) continue
            // 跨天自动清零进度，否则新的一天一开始就被当成「已经发完了」
            account.rollPostDate(todayStr)
            if (account.postIndex >= perAccount) continue

            // 同一批里几个账号背靠背发，密度依然偏高 —— 隔开
            if (index > 0) delay(ACCOUNT_GAP_MS + Random.nextLong(ACCOUNT_GAP_JITTER_MS))

            val topic = topics[account.postIndex % topics.size]
            val body = bodies[account.postIndex % bodies.size]
            val prefix = "[" + account.displayName + "] "
            val outcome = WeiboClient.runPost(account, topic, body) { text ->
                Prefs.lastRunMessage = prefix + text
                updateNotification(prefix + text)
            }

            when (outcome.status) {
                "SUCCESS" -> {
                    account.postIndex += 1
                    account.postFailCount = 0
                    posted += 1
                }
                // 重复内容：重试没意义，跳过这条换下一个超话
                "DUPLICATE" -> {
                    account.postIndex += 1
                    account.postFailCount = 0
                }
                // 被限流 / 明确拒绝：暂停后**重试同一条**，不推进进度
                "PAUSED" -> anyPaused = true
                // 验证只能人工处理，进度保持不动，等用户验证完自动补上
                "USER_REQUIRED" -> {
                    anyVerify = true
                    Prefs.needsVerify = true
                    // 只有「需要验证」才标记待验证；登录失效走的是重新登录，不是验证
                    if (outcome.errorCode == "CAPTCHA") {
                        account.needsVerify = true
                        // 全自动：弹全屏通知直接拉起验证页
                        showVerifyNotification(account)
                    }
                }
                else -> {
                    account.postFailCount += 1
                    // ★ 同一条连续失败到上限就跳过：否则一个写错的超话名
                    //   会让程序每隔一个间隔重试它一整天，白送请求给风控。
                    if (account.postFailCount >= WeiboAccount.MAX_POST_FAILURES) {
                        account.postIndex += 1
                        account.postFailCount = 0
                        outcome.let {
                            results.add(
                                getString(
                                    R.string.post_topic_failed,
                                    prefix,
                                    topic.display,
                                    WeiboAccount.MAX_POST_FAILURES,
                                    it.message
                                )
                            )
                        }
                    }
                }
            }

            account.postStatus = outcome.status
            account.postMessage = outcome.message
            results.add(prefix + outcome.message)

            // 每发完一个账号就落盘：后面万一进程被杀，进度不会丢
            AccountStore.save()
        }

        Prefs.postLastRunAt = System.currentTimeMillis()
        Prefs.postLastStatus = when {
            anyVerify -> "USER_REQUIRED"
            anyPaused -> "PAUSED"
            posted > 0 -> "SUCCESS"
            results.isEmpty() -> "IDLE"
            else -> "FAILED"
        }
        Prefs.postLastMessage = results.joinToString("\n")
        for (line in results) lines.add(line)

        if (anyVerify || anyPaused) {
            // 发帖撞上风控比签到更严重，暂停一下让微博那边冷静
            Prefs.pausedUntil = System.currentTimeMillis() + PAUSE_DURATION_MS
        }

        return AccountStore.postPending(todayStr, perAccount).size
    }

    /**
     * 帖子正文：多段之间用**单独一行 `---`** 分隔。
     * 没有分隔符时整段算一条 —— 所有帖子共用它，靠结尾的超话话题区分。
     */
    private fun parsePostBodies(raw: String): List<String> =
        raw.split(Regex("(?m)^\\s*-{3,}\\s*$")).map { it.trim() }.filter { it.isNotBlank() }

    private fun startMaintenance() {
        // ★★ 第一步必须**同步**做，不能留给循环里的第一次迭代：
        //   循环很可能正睡在一个接近 15 分钟的 delay 里（见 maintenanceWake 的说明），
        //   而刚排上的任务可能就在 2 分钟后。这段时间不持唤醒锁，进程会被 ROM 冻结，
        //   到点既不执行、循环也不会醒 —— 用户看到的就是「必须打开 App 才执行」。
        //   所以：服务一旦被拉起，就立刻按当前 nextRunAt 决定要不要保护等待窗口。
        try {
            refreshStandbyWakeLock(Prefs.nextRunAt - System.currentTimeMillis())
        } catch (_: Exception) {
        }
        // 第二步：把可能正在睡觉的循环踢醒，让它按新的 nextRunAt 重新算等待时间。
        // 注意顺序 —— 先申请唤醒锁，再叫醒循环；反过来的话循环可能来不及重新申请。
        maintenanceWake.trySend(Unit)

        if (maintenanceJob?.isActive == true) return
        maintenanceJob = scope.launch {
            while (isActive) {
                try {
                    // 心跳只证明协程最近真正获得过 CPU，不能再把它解释成「完全不依赖闹钟」。
                    // Doze 会冻结普通 delay；因此系统闹钟仍是主触发，短时唤醒锁是第二道保险。
                    Prefs.serviceAliveAt = System.currentTimeMillis()
                    if (!Prefs.automationEnabled) {
                        releaseStandbyWakeLock()
                        stopSelf()
                        break
                    }
                    val remaining = Prefs.nextRunAt - System.currentTimeMillis()
                    refreshStandbyWakeLock(remaining)
                    if (remaining <= 0L) {
                        releaseStandbyWakeLock()
                        // ★ 只发帖、不签到：走发帖专用路径，别把签到也拉起来
                        if (Prefs.scheduleEnabled) requestRun() else requestPost()
                        delay(60000)
                    } else {
                        // ★ 用 withTimeoutOrNull 而不是裸 delay：排程被改动时（例如用户点了
                        //   「测试自动签到」把任务挪到 2 分钟后），这里能被立刻叫醒并重算，
                        //   不必等这次等待睡完（最长 15 分钟）才反应。
                        withTimeoutOrNull(min(max(remaining, 15000L), 15 * 60 * 1000L)) {
                            maintenanceWake.receive()
                        }
                    }
                } catch (error: Exception) {
                    // 旧实现中，心跳的一次加密写失败就会让 maintenanceJob 永久退出；
                    // 后台从此没人检查时间，直到用户打开 App 重新启动服务。
                    try {
                        Prefs.lastRunStatus = "MAINTENANCE_FAILED"
                        Prefs.lastRunMessage = getString(
                            R.string.run_msg_maintenance_failed,
                            error.javaClass.simpleName
                        )
                    } catch (_: Exception) {
                    }
                    delay(60000)
                }
            }
        }
    }

    private suspend fun executeOnce(allAccounts: Boolean = false) {
        // 等待阶段的短时唤醒保护到此结束；执行阶段会按本批账号数重新申请 wakeLock。
        releaseStandbyWakeLock()
        AccountStore.init(this)
        Prefs.running = true
        Prefs.lastRunAt = System.currentTimeMillis()
        Prefs.lastRunMessage = getString(R.string.state_preparing_checkin)
        try {
            val accounts = AccountStore.enabled()
            if (accounts.isEmpty()) {
                Prefs.lastRunStatus = "USER_REQUIRED"
                Prefs.lastRunMessage = getString(R.string.run_msg_no_account)
                updateNotification(getString(R.string.notif_no_account))
                if (Prefs.automationEnabled) LocalScheduler.scheduleNext(this)
                return
            }

            // ★★★ 第 41 期（用户批准，属链路④判定类）：跨天给一次重试机会 ——
            //   修「撞风控后账号被永久排除，只能手动重新授权」这个死锁。
            //
            //   死锁长这样：
            //     撞风控 → account.needsVerify = true
            //            → 被 notRunToday() / partialPending() 里的 `!it.needsVerify` 过滤掉
            //            → 永远进不了待跑池 ⇒ 再也不去签它
            //            → 也就再也不会触发验证 ⇒ needsVerify 永远清不掉
            //            → 唯一出口是用户手动「重新授权」
            //
            //   ★ 注意第 657 行那段注释说「不标记 lastRunDate ⇒ 它还留在 notRunToday 的池子里」——
            //     这个设计意图被 notRunToday 自己的 `!it.needsVerify` 过滤废掉了：
            //     不管标不标 lastRunDate，needsVerify 为真就进不了池子。这里补上真正的那一环。
            //
            //   needsVerify 的清除点全项目只有 3 个：
            //     OverlayVerifyHost.kt:931（悬浮窗验证成功）、
            //     WeiboLoginActivity.kt:372 / :475（重新登录成功）。
            //     签到成功那条路只清了 Prefs 级，见上面第 699 行附近。
            //
            //   ★ 判据用 account.lastRunAt（已持久化，WeiboAccount.kt:187），**刻意不新增字段**：
            //     WeiboAccount.kt 是四个核心文件之一，加字段会让审计第 1 层变红。
            //       lastRunAt <  今天 00:00  ⇒ 昨天或更早撞的 ⇒ 今天给它一次机会
            //       lastRunAt >= 今天 00:00  ⇒ 今天撞的       ⇒ 保持不动（当天行为一字不变）
            //     ★ 边界：lastRunAt 只在签到链路里写（629 / 644），发帖链路不写。
            //       所以「从未跑过签到、却在发帖时撞了风控」的账号 lastRunAt 仍是 0，
            //       它同样会被复活一次 —— 这正是要修的那一类，且它本来就没有时间戳可判。
            //
            //   ★ 这一行只决定「今天要不要再试一次」，不改变任何一次签到请求的内容。
            val todayStartMs = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, 0)
                set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0)
                set(java.util.Calendar.MILLISECOND, 0)
            }.timeInMillis
            // ★★★★ 第 62 期：除了「跨天」，再加一条「距上次失败已过 verifyFailRetryHours」——
            //   用户 2026-10-04 要求：验证失败后不要卡一整天，过几小时自动再试一次补签。
            //   verifyFailRetryHours = 0 ⇒ 这一条不生效，行为与第 41 期逐字相同。
            val retryGapHours = verifyFailRetryHours.coerceAtLeast(0)
            val retryGapMs = retryGapHours * 3600_000L
            val nowForRetry = System.currentTimeMillis()
            val revivedStaleVerify = accounts.filter {
                it.needsVerify && (
                    it.lastRunAt < todayStartMs ||
                        (retryGapMs > 0L && it.lastRunAt <= nowForRetry - retryGapMs)
                    )
            }
            if (revivedStaleVerify.isNotEmpty()) {
                val stampFmt = java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.CHINA)
                for (stale in revivedStaleVerify) {
                    stale.needsVerify = false
                    SliderTrace.log(
                        "[风控] " + stale.displayName + " 上次验证没走完（" +
                            (if (stale.lastRunAt > 0L) stampFmt.format(java.util.Date(stale.lastRunAt))
                            else "无记录") +
                            (if (stale.lastRunAt < todayStartMs) "），跨天自动给一次重试机会"
                            else "），已过 " + retryGapHours + " 小时，自动再试一次补签")
                    )
                }
                AccountStore.save()
                Prefs.needsVerify = AccountStore.needsVerifyAccounts().isNotEmpty()
            }

            val ready = accounts.filter { it.loggedIn && !it.resting() }
            val skipped = accounts.filter { !it.loggedIn }
            val resting = accounts.filter { it.loggedIn && it.resting() }

            if (ready.isEmpty()) {
                if (resting.isNotEmpty()) {
                    // 全部在静置期：不是故障，是验证后的保护期，报成功并继续排程
                    Prefs.lastRunStatus = "SUCCESS"
                    Prefs.lastRunMessage = getString(R.string.run_msg_all_resting)
                    updateNotification(getString(R.string.notif_all_resting))
                } else {
                    Prefs.lastRunStatus = "USER_REQUIRED"
                    Prefs.lastRunMessage = getString(R.string.run_msg_all_logged_out)
                    updateNotification(getString(R.string.notif_all_logged_out))
                }
                if (Prefs.automationEnabled) LocalScheduler.scheduleNext(this)
                return
            }

            // ★ 分批错峰（账号多时降低风控风险的关键）
            //
            //   把 10 个账号在同一时刻全部跑一遍，会在同一个 IP 上形成一次密集请求 ——
            //   这是最容易触发风控的形态。改成每轮只跑一小批（默认 3 个），
            //   跑过的账号记下日期，下一批 20 分钟后再来，几轮跑完。
            //   10 个账号 = 4 批，大约 1 小时跑完，请求密度降到 1/3 以下。
            //
            //   ★ 手动点「立即签到」时 allAccounts=true，跳过分批 ——
            //     那种场景服务跑完就 stopSelf 了，剩下的批次没人接着跑。
            val todayStr = today()
            val pendingToday = AccountStore.notRunToday(todayStr)
            // ★ 上一轮「没签完」的账号也要重新排进来。
            //   它们已经被记进 lastRunDate，光靠 notRunToday 永远选不到它们 ——
            //   界面上写着「会自动补签」，实际却没人管。这里补上这一环（次数有限，见 partialPending）。
            val partialPending = AccountStore.partialPending(todayStr)
            // 池子按优先级：今天没轮到的 > 没签完要补的
            val pool = pendingToday + partialPending
            val batch = if (allAccounts) {
                ready
            } else {
                // 池子空（今天全都跑完且都没问题）→ 兜底跑一批，不做无意义的空转
                (if (pool.isNotEmpty()) pool else ready).take(BATCH_SIZE)
            }
            val remainingAfterBatch = if (allAccounts) 0 else (pool.size - batch.size).coerceAtLeast(0)

            // ★★★★ 第 80 期（用户批准）：**发帖批次单独算**，不再沿用签到批次 batch。
            //
            //   症状（账号数 ≥ 4 + 开着自动发帖时必现）：
            //     只有账号列表最前面 3 个发得满（每人 postPerAccount 条），
            //     第 4 个往后永远停在第一条；而且此后每一轮都是「都发满了 → 20 分后再来」，
            //     每 20 分钟空转一次，一直空转到跨天。
            //
            //   根因：签到池 pool 一旦跑空（当天所有账号都签过一遍），上面那个兜底分支
            //     就恒等于 ready.take(BATCH_SIZE) —— 一个**固定不变**的前 3 个账号。
            //     发帖阶段原本直接复用这个 batch，于是每轮都在给同样 3 个账号发：
            //     它们发满之后，runPostPhase 里那个 postIndex >= perAccount 的 continue
            //     把整轮变成 no-op，而真正还欠帖子的账号一次都轮不到。
            //
            //   ★ 顺带澄清：签到池跑空后的那次兜底签到**本身是廉价的** ——
            //     WeiboClient 里 pending 为空会直接返回 SUCCESS，只拉一次超话列表。
            //     所以问题不在签到，只在「把签到批次当发帖批次传下去」这一步。
            //
            //   修法：发帖用**发帖自己的池子**。
            //     AccountStore.postPending = 已启用 + 已登录 + 不在静置 + 无需验证 + 今天没发够，
            //     是 ready 的**子集** ⇒ 不会放进任何 ready 之外的账号，只是把入参**收窄**到
            //     真正还欠帖子的账号；下一轮自然轮到后面那批。
            //
            //   ★★★ 边界（硬规则一）：**签到批次 batch 一个字节都没动** ——
            //     上面三行（pool / batch / remainingAfterBatch）逐字保持原样；
            //     本轮只新增下面两行，并把两处 runPostPhase 的入参由 batch 换成 postBatch。
            //     ⇒ 签到链路的分批、池子优先级、兜底、排程判据（含 remainingAfterBatch）
            //       全部不变，签到那一侧的行为与第 79 期逐字等价。
            //
            //   ★ 为什么 allAccounts 分支用 postPool 而不是 postPool.take(BATCH_SIZE)：
            //     与签到保持一致 —— 手动「立即签到 / 立即发帖」的语义就是跑完全部账号。
            //     allAccounts = true 时 ready 与 postPool 的差异只是「今天已发够的账号」，
            //     而它们在 runPostPhase 里本来就被跳过 ⇒ 结果完全相同。
            val postPool = AccountStore.postPending(todayStr, Prefs.postPerAccount)
            val postBatch = if (allAccounts) postPool else postPool.take(BATCH_SIZE)

            // 唤醒锁按**这一批**的时长算（不是按全部账号）。
            //
            // ★★ v19.19：系数必须跟着 WeiboClient.accountBudgetMs 一起走。
            //   旧值是 `batch.size * 12 + 10`，对应「单账号最多 10 分钟」。
            //   现在单账号预算上限已提到 40 分钟，唤醒锁却还按 12 分钟/账号申请 ——
            //   后果是签到跑到一半唤醒锁就过期，手机允许休眠，剩下的超话被冻结，
            //   最后以「超时未执行」收尾。用户的感受是「每天都签一半」。
            //
            //   ★ 这是一类容易漏的耦合：**唤醒锁时长是「预算时长的影子」**，
            //     预算改了、影子不会自己跟着改。凡是调整 accountBudgetMs，这里必须同改。
            //
            // ★ 上限由 120 分钟提到 240 分钟：手动「立即签到」时会一次跑完所有账号，
            //   10 个账号按新公式算出来是 410 分钟 —— 截到 240 分钟。
            //   真被截断也只是这一轮剩下的超话进 PARTIAL、下一轮再签，不会丢数据。
            //   （一次 4 小时的唤醒锁在手动触发时是可接受的，因为它只在这段时间内保持 CPU 清醒，
            //     不阻止息屏，且任务结束就释放。）
            acquireWakeLock((batch.size * 45 + 15).coerceIn(30, 240))

            val lines = mutableListOf<String>()
            // 需要人工处理（验证码 / 登录失效）—— 重试不会变好，要限时暂停
            var needsUser = false
            // 只是有槽位没登录 —— 这是要用户手动去登录的，跟风控是两回事
            var anyNotLoggedIn = false
            var anyPaused = false
            var anyPartial = false
            // ★ 第 15 期：有账号在**网络层**出错（超时 / 断网）—— 与风控、与登录失效都无关。
            //   单独记账：整批继续跑完，但结果要如实报 FAILED，并且 10 分钟后补一轮。
            var anyFailed = false
            var postRemaining = 0

            // ★ 发帖/签到顺序可配（见 Prefs.postFirst）。默认先签到后发帖；
            //   开了「先发帖」时，先把这一批该发的帖子发了，再回来签到。
            //   注意：仍然是**串行**，不是并发 —— 并发会让同一 IP 的请求密度翻倍，
            //   等于把前面所有降低风险的努力都抵消掉。
            if (Prefs.postFirst) {
                // ★ 第 80 期：入参由 batch 换成 postBatch（详见上面那段长注释）
                postRemaining = runPostPhase(postBatch, todayStr, lines)
            }

            // ★ 逐个账号串行签到。
            //   不做并发：微博的风控是按账号算的，但同一台设备 IP 相同，
            //   并发请求会让几个号同时被判定成异常流量，反而更容易全盘失败。
            for ((index, account) in batch.withIndex()) {
                val prefix = "[" + account.displayName + "] "
                // 批内也要隔开：同一 IP 连着发几个账号的请求，密集度依然偏高
                if (index > 0) delay(ACCOUNT_GAP_MS + Random.nextLong(ACCOUNT_GAP_JITTER_MS))
                updateNotification(
                    getString(R.string.notif_preparing_progress, prefix, index + 1, batch.size)
                )

                // 记录每个账号的耗时。用户报「某个账号超时」时，
                // 这个数字是判断「网络慢」还是「App 被系统冻结」的唯一线索。
                val accountStartedAt = System.currentTimeMillis()

                // 把每个超话的进度实时写回通知栏和首页。
                // 多账号下必须带账号名前缀，否则用户不知道卡在哪个号上。
                //
                // ★★★ 第 15 期：单个账号在**网络层**出错，不再让整批陪葬。
                //
                //   旧实现里这次调用抛出的异常会**穿出整个 for 循环**，被最外层
                //   `catch (error: Exception)` 接住，后果三条：
                //     ① 这一批剩下的账号**全部不跑**（实测 12:03 的「今日进度 2 / 5」）；
                //     ② 那个 catch **不调用 showVerifyNotification()** ⇒ 即使后面的账号
                //        本来会命中风控，也永远走不到那一步 —— 这才是「今天两个账号都没
                //        触发人工验证」的真正原因；
                //     ③ 它调的是 scheduleNext() ⇒ 下一次排到**明天**，白丢一整天。
                //   实测触发物是一次 SocketTimeoutException("timeout") ——
                //   HttpURLConnection 的 connectTimeout=8000 / readTimeout=12000 超时，
                //   okio 的 AsyncTimeout 抛出的消息就是裸的 "timeout"。
                //
                //   ★ 只包住这一次调用：风控判定、验证通知、记账、Cookie 归属全部走原路。
                val outcome = try {
                    WeiboClient.runCheckin(account) { text ->
                        Prefs.lastRunMessage = prefix + text
                        updateNotification(prefix + text)
                    }
                } catch (error: Exception) {
                    val reason = error.message ?: getString(R.string.run_msg_unknown_error)
                    // 记进黑匣子：旧实现里这类失败只进 Prefs.lastRunMessage，
                    // 而它会被后面账号的进度覆盖掉 —— 报告里连一行痕迹都留不下。
                    SliderTrace.log(
                        "[网络] " + prefix + "本次执行中断：" +
                            error.javaClass.simpleName + " " + reason +
                            "（用时 " + (System.currentTimeMillis() - accountStartedAt) + "ms）"
                    )
                    account.lastRunAt = System.currentTimeMillis()
                    account.lastRunStatus = "FAILED"
                    account.lastRunMessage = getString(R.string.run_msg_failed, reason)
                    // ★ 刻意**不写** account.lastRunDate —— 与「需要人工验证」同一个道理：
                    //   写进去这个账号今天就再也不会被选中，只能靠手动补签。
                    //   不写 ⇒ 它还留在 notRunToday 的池子里，下一批自动带它重试。
                    lines.add(prefix + getString(R.string.run_msg_failed, reason))
                    anyFailed = true
                    // 前面账号的结果先落盘，别因为这一个账号出错而回滚
                    AccountStore.save()
                    // 跳到下一个账号 —— 这就是本轮修复的全部内容
                    continue
                }

                val elapsed = System.currentTimeMillis() - accountStartedAt
                account.lastRunAt = System.currentTimeMillis()
                account.lastRunStatus = outcome.status
                account.lastRunMessage = buildResultMessage(outcome)
                // ★ 记下「今天轮到过它了」，下一批就不会重复跑它。
                //
                //   ★★ 但「需要人工验证」是例外：**不能**标记。
                //   微博判定「行为异常」后，唯一的出路是用户手动完成一次验证。
                //   如果这里照标记，那么用户验证完之后，这个账号今天再也不会被自动选中 ——
                //   只能靠手动点「立即签到」补，很容易整整一天都漏掉。
                //   不标记的话：30 分钟暂停期一过、用户下次打开 App 时，
                //   ensureScheduled 就会发现「今天还有该跑没跑的账号」并自动补跑。
                //   （不会变成空转：每次补跑只发 1~2 个请求，第一个超话就重新命中验证页并立刻停下，
                //     而且整批结束后会 scheduleNext 排到明天，不依赖用户不开 App。）
                if (outcome.status == "USER_REQUIRED") {
                    account.lastRunDate = ""
                } else {
                    account.lastRunDate = todayStr
                }
                // ★ 「没签完」的账号要单独记账，下一轮会被 partialPending 重新捞出来补跑。
                //   必须限次（见 WeiboAccount.MAX_PARTIAL_RETRIES）：
                //   一个永远签不完的超话会让它每 20 分钟空转一轮，那是白白送请求给风控。
                if (outcome.status == "PARTIAL") {
                    if (account.partialRetryDate != todayStr) {
                        account.partialRetryDate = todayStr
                        account.partialRetryCount = 0
                    }
                    account.partialRetryCount += 1
                } else {
                    // 这一轮签干净了 → 清掉历史欠账，别再把它当「没签完」反复捞
                    account.partialRetryCount = 0
                }

                lines.add(
                    prefix + oneLineSummary(outcome) + getString(
                        R.string.line_with_duration,
                        formatDuration(elapsed)
                    )
                )
                val detail = outcome.summary.optString("detail")
                if (detail.isNotBlank()) lines.add(detail)

                when (outcome.status) {
                    "USER_REQUIRED" -> needsUser = true
                    "PAUSED" -> anyPaused = true
                    "PARTIAL" -> anyPartial = true
                }

                // ★ 「需要去微博点一次验证」是一个**要用户动手**的状态，必须显式记下来，
                //   首页才能稳定地提示（而不是让界面去猜文案里有没有「验证」两个字）。
                //   签到正常完成 = 用户已经验证过了 → 清掉提示。
                if (outcome.errorCode == "CAPTCHA") {
                    Prefs.needsVerify = true
                    account.needsVerify = true
                    // 全自动：弹全屏通知直接拉起验证页，自动完成验证
                    showVerifyNotification(account)
                } else if (outcome.status == "SUCCESS" || outcome.status == "PARTIAL") {
                    // ★ 第 41 期（纯展示口径修正）：这里原来写死 `Prefs.needsVerify = false` —— 一刀切。
                    //   只要有**任意一个**账号签到成功，提示就被清掉，哪怕**别的**账号还卡在
                    //   「需要重新授权」上 ⇒ 首页与诊断报告双双漏报，表现为
                    //   「首页说没事，账号页却有一个账号写着需要重新授权」。
                    //   改成与另外两处完全一致的口径（按账号重算）：
                    //     OverlayVerifyHost.kt:959 / WeiboLoginActivity.kt:374
                    //   ★ 已核实：Prefs.needsVerify 全项目**只有界面在读**
                    //     （MainActivity.kt:1259 首页提示、:1501 诊断报告），
                    //     没有任何一处拿它做判定 ⇒ 这行改的只是「说与不说」，不是「做与不做」。
                    Prefs.needsVerify = AccountStore.needsVerifyAccounts().isNotEmpty()
                }

                // 每签完一个账号就落盘一次：万一后面某个账号把进程搞崩了，
                // 前面已经签好的结果和刷新过的 Cookie 不会丢
                AccountStore.save()
            }

            // 没登录的账号也要在结果里说清楚，否则用户会以为「少签了一个」
            for (account in skipped) {
                account.lastRunStatus = "USER_REQUIRED"
                account.lastRunMessage = getString(R.string.acct_msg_not_logged_in)
                lines.add(getString(R.string.line_not_logged_in, account.displayName))
                anyNotLoggedIn = true
            }
            // 静置中的账号单独说明：不是故障，是验证后的保护期
            for (account in resting) {
                lines.add(
                    getString(
                        R.string.line_resting,
                        account.displayName,
                        ((account.restUntil - System.currentTimeMillis()) / 3600000L).coerceAtLeast(1)
                    )
                )
            }
            AccountStore.save()

            // ★ 发帖阶段（默认跟在签到之后）：每账号本轮只发一条，剩下的等下一个间隔。
            //   「先发帖」模式下，这一批的帖子已经在签到前发过了，这里跳过。
            if (!Prefs.postFirst) {
                // ★ 第 80 期：入参由 batch 换成 postBatch（详见上面那段长注释）
                postRemaining = runPostPhase(postBatch, todayStr, lines)
            }

            // 分批执行时，必须明确告诉用户「还剩几个、什么时候继续」，
            // 否则他只看到 3 个账号的结果，会以为剩下 7 个被漏掉了
            if (remainingAfterBatch > 0) {
                lines.add(
                    getString(
                        R.string.line_batch_summary,
                        remainingAfterBatch,
                        BATCH_GAP_MS / 60000L,
                        ready.size,
                        BATCH_SIZE,
                        (ready.size + BATCH_SIZE - 1) / BATCH_SIZE
                    )
                )
            }

            Prefs.lastRunDate = todayStr
            val status = when {
                needsUser -> "USER_REQUIRED"
                // ★ 空槽位没登录 ≠ 需要人工处理。
                //   旧实现把它也报成 USER_REQUIRED，于是「10 个槽位里有 5 个没登录」这种
                //   完全正常的配置，会让每一轮的结果都显示「需要处理」——
                //   功能明明正常，报告却在报警（v0.19.9 的测试报告就是这样）。
                //   现在单独一个状态码，并且不暂停、不影响后续排程。
                anyNotLoggedIn -> "NOT_LOGGED_IN"
                anyPaused -> "PAUSED"
                // 有超话没签完也是「没做完」，不能报成功
                anyPartial -> "PARTIAL"
                // ★ 第 15 期：有账号网络出错 → 如实报 FAILED，而不是把整批说成成功。
                //   放在最后一级：风控 / 未登录 / 暂停 / 没签完这四种都比它更该先被看到。
                anyFailed -> "FAILED"
                else -> "SUCCESS"
            }
            Prefs.lastRunStatus = status
            Prefs.lastRunMessage = lines.joinToString("\n")

            // 第 1 步：决定「要不要暂停」—— 只有风控 / 需要人工处理才暂停
            when (status) {
                "USER_REQUIRED" -> {
                    // ★ 分两种情况，处理方式完全不同：
                    //   验证码 / 登录失效：重试不会变好，但也**不能永久关闭调度**
                    //     （旧实现是 scheduleEnabled=false + cancel()，用户看到「到点完全没执行」），
                    //     所以限时暂停，到期自动重试。
                    //   只是有槽位没登录：这要用户手动去登录，每 30 分钟重试一次毫无意义 ——
                    //     只会白白发请求、平白加重风控。所以**不暂停**，按正常日程走。
                    if (needsUser) {
                        Prefs.pausedUntil = System.currentTimeMillis() + PAUSE_DURATION_MS
                    } else {
                        Prefs.pausedUntil = 0L
                    }
                }
                "PAUSED" -> Prefs.pausedUntil = System.currentTimeMillis() + PAUSE_DURATION_MS
                else -> Prefs.pausedUntil = 0L
            }

            // 第 2 步：决定「下一次什么时候跑」。
            //   优先级：还有账号没轮到 > 有超话没签完 > 按用户设定的每日时间。
            //   ★ 这两件事以前是混在一起的（暂停 = 排到暂停结束），
            //     所以「还有 7 个账号没跑」这种正常情况会被当成暂停处理，节奏全乱。
            if (Prefs.automationEnabled) {
                val pauseLeft = (Prefs.pausedUntil - System.currentTimeMillis()).coerceAtLeast(0L)

                // ★★★★ 第 62 期（用户批准）：最早一个「在等重试」的账号还要等多久（毫秒）。
                //
                //   取所有 needsVerify 账号里 (lastRunAt + 重试间隔 - 现在) 的最小值。
                //   lastRunAt == 0 的账号不参与 —— 它们没有时间戳可判，会被跨天规则直接复活。
                //   已经到点（<= 0）的算 0 ⇒ 下面那个分支不成立，因为那种账号在本次
                //   运行的开头就已经被复活过了（needsVerify 已清）。
                val retryWaitMs = if (retryGapMs > 0L) {
                    val nowForSchedule = System.currentTimeMillis()
                    accounts
                        .filter { it.needsVerify && it.lastRunAt > 0L }
                        .minOfOrNull { it.lastRunAt + retryGapMs - nowForSchedule }
                        ?.coerceAtLeast(0L) ?: 0L
                } else {
                    0L
                }
                when {
                    // 还有账号今天没轮到 → 歇一会儿继续下一批
                    remainingAfterBatch > 0 -> {
                        val gap = pauseLeft + BATCH_GAP_MS + Random.nextLong(BATCH_GAP_JITTER_MS)
                        updateNotification(
                            getString(
                                R.string.notif_batch_next,
                                remainingAfterBatch,
                                gap / 60000L,
                                if (pauseLeft > 0L) getString(R.string.notif_batch_continue_suffix)
                                else ""
                            )
                        )
                        LocalScheduler.scheduleRetry(this, gap)
                    }
                    // ★ 还有账号没发完帖子 → 按**发帖间隔**再来一轮。
                    //   发帖的间隔通常比签到批次间隔大得多（默认 20 分钟，用户可以调到 4 小时），
                    //   这是故意的：发布行为比签到敏感，稀疏才有价值。
                    postRemaining > 0 -> {
                        val gap = pauseLeft + Prefs.postIntervalMinutes * 60_000L
                        updateNotification(
                            getString(R.string.notif_post_next, postRemaining, gap / 60000L)
                        )
                        LocalScheduler.scheduleRetry(this, gap)
                    }
                    // 有超话没签完 → 单独补一轮，不跟风控暂停混在一起
                    status == "PARTIAL" -> {
                        val gap = pauseLeft + PARTIAL_RETRY_DELAY_MS
                        updateNotification(getString(R.string.notif_checkin_pending, gap / 60000L))
                        LocalScheduler.scheduleRetry(this, gap)
                    }
                    // ★ 第 15 期：有账号网络出错 → 同样 10 分钟后补一轮。
                    //   旧实现让异常穿出去、直接 scheduleNext 排到明天 ⇒ 丢一整天；
                    //   网络抖动是最不该赔上一整天的故障。
                    anyFailed -> {
                        val gap = pauseLeft + PARTIAL_RETRY_DELAY_MS
                        updateNotification(getString(R.string.notif_checkin_pending, gap / 60000L))
                        LocalScheduler.scheduleRetry(this, gap)
                    }
                    // ★★★★ 第 62 期（用户批准）：有账号在「等重试」→ 到点自己醒一次。
                    //
                    //   为什么必须有这一段：第 41 期的跨天复活与本期的隔 N 小时复活
                    //   都只是**判据**，只在「刚好有一次运行」时才被求值。而一次运行结束后，
                    //   下一次要么排在 30~60 分钟后（风控暂停重跑，离失败还不够 2 小时），
                    //   要么直接排到明天的设定时间 —— 于是「2 小时后自动重试」在真机上
                    //   根本触发不到。2026-10-04 日志实证：09:49:12 停手之后，当天再没有
                    //   任何一次签到运行（日志里只剩进程被系统重启的记录），账号四一直卡到
                    //   第二天才被跨天复活。
                    //
                    //   本分支只决定「什么时候再跑一次」，**不改变任何一次签到请求的内容**：
                    //   到点那次运行仍走 runCheckin 原路，撞到验证页就立刻停手（只发 1~2 个请求）。
                    //   ★ 一键回滚：verifyFailRetryHours = 0 ⇒ retryWaitMs 恒为 0 ⇒ 本分支不成立。
                    retryWaitMs > 0L -> {
                        val gap = retryWaitMs + Random.nextLong(0L, BATCH_GAP_JITTER_MS)
                        updateNotification(getString(R.string.notif_verify_retry, gap / 60000L))
                        SliderTrace.log(
                            "[风控] 有账号在等重试，" + (gap / 60000L) + " 分钟后自动再跑一轮补签"
                        )
                        LocalScheduler.scheduleRetry(this, gap)
                    }
                    else -> {
                        when (status) {
                            "SUCCESS" -> updateNotification(getString(R.string.notif_done_all))
                            "USER_REQUIRED" ->
                                updateNotification(
                                    getString(
                                        if (needsUser) R.string.notif_needs_user
                                        else R.string.notif_needs_login
                                    )
                                )
                            "PAUSED" -> updateNotification(getString(R.string.notif_paused_partial))
                            // 空槽位没登录：已登录的都跑完了，通知里别报成失败
                            "NOT_LOGGED_IN" -> updateNotification(getString(R.string.notif_done_with_logged_out))
                            else -> updateNotification(getString(R.string.notif_checkin_failed))
                        }
                        LocalScheduler.scheduleNext(this)
                    }
                }
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            // ★ 协程被取消 ≠ 执行出错，必须单独处理。
            //
            //   最常见的来源是「服务被系统关掉」：onDestroy → scope.cancel()。
            //   国产 ROM（vivo / OPPO 尤其）在后台清理应用时非常容易触发。
            //   旧实现把它当普通异常，界面就报「执行失败：Job was cancelled」——
            //   用户看到英文报错只会以为是程序 bug，而真正该做的是加后台白名单。
            //   （v0.19.7 的诊断报告里抓到的就是这个：上次结果 FAILED / Job was cancelled。）
            Prefs.lastRunStatus = "INTERRUPTED"
            Prefs.lastRunMessage = getString(R.string.run_msg_interrupted)
            try {
                updateNotification(getString(R.string.notif_interrupted))
            } catch (_: Exception) {
            }
            // 取消必须继续往上抛，否则协程框架会认为任务「正常结束」。
            throw cancelled
        } catch (error: Exception) {
            Prefs.lastRunStatus = "FAILED"
            Prefs.lastRunMessage = getString(
                R.string.run_msg_failed,
                error.message ?: getString(R.string.run_msg_unknown_error)
            )
            updateNotification(Prefs.lastRunMessage)
            if (Prefs.automationEnabled) LocalScheduler.scheduleNext(this)
        } finally {
            // 无论正常结束、提前 return 还是抛异常，都要清掉「正在执行」标记，
            // 否则首页会永远停在「正在执行」上
            Prefs.running = false
            try {
                if (wakeLock?.isHeld == true) wakeLock?.release()
            } catch (_: Exception) {
            }
            wakeLock = null
        }
    }

    /**
     * 单个账号的一行汇总，用于多账号结果列表。
     * 明细（哪个超话失败、失败原因）由 summary.detail 另起一行展示。
     */
    private fun oneLineSummary(outcome: CheckinOutcome): String {
        return when (outcome.status) {
            // PARTIAL 也走这一支：它只是「还有几个没签完」，前面的成功/已签数字照样要报
            "SUCCESS", "PARTIAL" -> {
                val total = outcome.summary.optInt("total")
                if (total == 0) {
                    getString(R.string.summary_no_topic)
                } else {
                    getString(
                        R.string.summary_line,
                        total,
                        if (outcome.summary.optInt("doneInList") > 0)
                            getString(R.string.summary_done_in_list, outcome.summary.optInt("doneInList"))
                        else "",
                        outcome.summary.optInt("success"),
                        outcome.summary.optInt("already"),
                        outcome.summary.optInt("failed"),
                        // 已取消关注的超话要单独报，否则会被当成「失败」让用户白担心
                        if (outcome.summary.optInt("unfollowed") > 0)
                            getString(R.string.summary_unfollowed, outcome.summary.optInt("unfollowed"))
                        else "",
                        if (outcome.summary.optInt("retried") > 0)
                            getString(R.string.summary_retried, outcome.summary.optInt("retried"))
                        else "",
                        if (outcome.summary.optInt("unfinished") > 0)
                            getString(R.string.summary_unfinished, outcome.summary.optInt("unfinished"))
                        else ""
                    )
                }
            }
            "USER_REQUIRED" -> getString(
                R.string.summary_need_user,
                outcome.pauseReason.ifBlank { getString(R.string.summary_reason_captcha) }
            )
            "PAUSED" -> getString(
                R.string.summary_paused,
                outcome.pauseReason.ifBlank { getString(R.string.summary_reason_risk) }
            )
            else -> getString(R.string.summary_failed, outcome.errorCode.ifBlank { outcome.status })
        }
    }

    /** 耗时文案：90 秒以内只显示秒，超过就显示「X 分 Y 秒」 */
    private fun formatDuration(ms: Long): String {
        val seconds = (ms / 1000L).coerceAtLeast(0L)
        return if (seconds < 90L) {
            getString(R.string.dur_seconds, seconds.toString())
        } else {
            getString(R.string.dur_min_sec, (seconds / 60L).toString(), seconds % 60L)
        }
    }

    private fun buildResultMessage(outcome: CheckinOutcome): String {
        return when (outcome.status) {
            "SUCCESS", "PARTIAL" -> {
                val total = outcome.summary.optInt("total")
                val selected = outcome.summary.optInt("selected")
                val already = outcome.summary.optInt("already")
                val failed = outcome.summary.optInt("failed")
                val retried = outcome.summary.optInt("retried")
                val unfollowed = outcome.summary.optInt("unfollowed")
                val doneInList = outcome.summary.optInt("doneInList")
                val unfinished = outcome.summary.optInt("unfinished")
                val excluded = outcome.summary.optString("excluded")
                val excludedCount = outcome.summary.optInt("excludedCount")
                val detail = outcome.summary.optString("detail")
                val head = if (total == 0) {
                    getString(R.string.result_no_topic)
                } else {
                    // ★ 数字必须能对上：共 N 个 = 微博已标已签的 + 本次需签的。
                    //   旧文案只说「共 30 个超话，待签 3」，30 和 3 之间的缺口没有任何解释，
                    //   用户会以为漏签了 27 个 —— 所以这里把「跳过多少、为什么跳过」写清楚。
                    getString(
                        R.string.result_line,
                        total,
                        if (doneInList > 0) getString(R.string.result_done_in_list, doneInList) else "",
                        selected,
                        outcome.summary.optInt("success"),
                        already,
                        failed,
                        // 已取消关注的超话单独报，别让用户把它当成「签到出故障了」
                        if (unfollowed > 0) getString(R.string.summary_unfollowed, unfollowed) else "",
                        if (retried > 0) getString(R.string.summary_retried, retried) else "",
                        // 没签完必须单独说明，否则用户会把这一轮当成全部完成
                        if (unfinished > 0) getString(R.string.result_unfinished, unfinished) else "",
                        // ★ 已取消关注的超话不该被签到。把跳过的写出来，
                        //   否则用户不知道「取消关注了为什么还在列表里」是被修了还是没修。
                        if (excludedCount > 0) getString(R.string.result_excluded, excludedCount) else ""
                    )
                }
                // 明细里再补一行具体名字，用户能直接对照自己的关注列表
                val excludedLine = if (excluded.isNotBlank()) getString(R.string.result_excluded_line, excluded) else ""
                val body = listOf(detail, excludedLine).filter { it.isNotBlank() }.joinToString("\n")
                if (body.isBlank()) head else head + "\n" + body
            }
            "USER_REQUIRED" -> getString(
                R.string.summary_need_user,
                outcome.pauseReason.ifBlank { getString(R.string.summary_reason_captcha) }
            )
            "PAUSED" -> getString(
                R.string.result_paused,
                outcome.pauseReason.ifBlank { getString(R.string.summary_reason_risk_paused) }
            )
            else -> getString(R.string.result_failed, outcome.errorCode.ifBlank { outcome.status })
        }
    }

    private fun today(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date())
    }

    /**
     * 计划时间在 90 分钟内时，给「等待到点」加一层短时唤醒保护。
     *
     * 前台服务并不等于 CPU 会一直运行：息屏进入 Doze 后，普通 coroutine delay 会被冻结。
     * v19.2 错把「服务还活着」当成「到点一定执行」，这正是用户放后台一小时后不跑、
     * 一打开 App（CPU 被唤醒）才立刻执行的原因。
     *
     * 不允许持有一整天：只保护 90 分钟内的日常签到/分批间隔，降低电量影响；
     * 更远的每日时间仍由 setAlarmClock 唤醒，到达 90 分钟窗口后服务会补上这层保护。
     */
    private fun refreshStandbyWakeLock(remainingMs: Long) {
        if (remainingMs <= 0L || remainingMs > STANDBY_WAKE_WINDOW_MS) {
            releaseStandbyWakeLock()
            return
        }
        if (standbyWakeLock?.isHeld == true) return
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        val lock = power.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "WeiboTask::ScheduledWakeLock"
        )
        lock.setReferenceCounted(false)
        try {
            lock.acquire(remainingMs + STANDBY_WAKE_GRACE_MS)
        } catch (error: Exception) {
            // 申请被系统拒绝必须留痕。否则报告里只有一句「无记录」，
            // 分不清「从来没申请过」和「申请了但被系统拒绝」—— 这两种要修的地方完全不同。
            try {
                Prefs.standbyError = getString(R.string.run_msg_wakelock_failed, error.javaClass.simpleName)
            } catch (_: Exception) {
            }
            return
        }
        standbyWakeLock = lock
        try {
            val now = System.currentTimeMillis()
            Prefs.standbyProtectedUntil = now + remainingMs + STANDBY_WAKE_GRACE_MS
            // ★ 单独记「最近一次真正申请成功」的时刻。
            //   standbyProtectedUntil 会被 executeOnce 开头和 releaseStandbyWakeLock 清零，
            //   所以报告里经常是「无记录」—— 那个值说明的是「此刻是否受保护」，
            //   而这个字段说明的是「到底有没有保护过」，两者缺一不可。
            Prefs.standbyAcquiredAt = now
            Prefs.standbyError = ""
        } catch (_: Exception) {
        }
    }

    private fun releaseStandbyWakeLock() {
        try {
            if (standbyWakeLock?.isHeld == true) standbyWakeLock?.release()
        } catch (_: Exception) {
        }
        standbyWakeLock = null
        try {
            Prefs.standbyProtectedUntil = 0L
        } catch (_: Exception) {
        }
    }

    private fun acquireWakeLock(minutes: Int) {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        wakeLock = null
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WeiboTask::CheckinWakeLock")
        wakeLock?.setReferenceCounted(false)
        // 旧值是固定 10 分钟。多个超话逐个签到时很容易超过，按本批账号数动态计算。
        wakeLock?.acquire(minutes * 60 * 1000L)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)

            // ★★★ 验证通知必须走**单独一个高优先级渠道**。
            //
            //   Android 8（Oreo）以后，通知的重要级别由**渠道**决定 ——
            //   `setPriority(NotificationCompat.PRIORITY_MAX)` 只是 pre-Oreo 的提示，
            //   在 8.0+ 上**完全被忽略**。
            //
            //   上面那个渠道是 IMPORTANCE_LOW（为了让常驻的进度通知不吵），
            //   而 LOW 级别下 `setFullScreenIntent` **永远不会触发**：
            //   不响、不弹 heads-up、屏幕不亮、什么都不跳出来 ——
            //   通知只会静静躺在通知栏里。
            //
            //   ★ 渠道的重要级别**一旦创建就无法用代码修改**
            //   （系统会忽略对同名渠道的再次创建），所以只能另开一个 id。
            //
            //   这就是「四项权限全开、验证页累计仍然是 0 次」的直接原因。
            val verifyChannel = NotificationChannel(
                VERIFY_CHANNEL_ID,
                getString(R.string.notif_channel_verify_name),
                NotificationManager.IMPORTANCE_HIGH
            )
            verifyChannel.description = getString(R.string.notif_channel_verify_desc)
            manager.createNotificationChannel(verifyChannel)
        }
    }

    /** 返回 null 表示成功；返回文字表示两种启动方式都失败。 */
    private fun startForegroundNotification(text: String): String? {
        val notification = buildNotification(text)
        var typedError = ""
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
                return null
            } catch (error: Exception) {
                typedError = error.javaClass.simpleName
                // 类型不被系统接受时退回「不声明类型」；但两次都失败时必须留下诊断。
            }
        }
        return try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, 0)
            null
        } catch (error: Exception) {
            listOf(typedError, error.javaClass.simpleName).filter { it.isNotBlank() }.joinToString(" / ")
        }
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(pending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    /**
     * ★ 第 16 期：「延迟重拉」用的主线程 Handler。
     *
     *   全屏通知 / 无障碍 / 悬浮窗三条路都在通知发出的**瞬间**开火，
     *   而那一刻屏幕刚被点亮、系统还没把「显示已唤醒」传播到任务管理器 ⇒
     *   页面被创建后立刻以 `sleep` 为由暂停（实测：屏幕亮后 37 毫秒）。
     *   补一次延迟重拉，等状态传播完再拉；那时任务已经醒着，页面能活下来。
     *
     *   每来一个新通知就先清掉上一次 ⇒ 同一时刻只有一个待执行的重拉。
     */
    private val verifyRelaunchHandler = Handler(Looper.getMainLooper())

    /**
     * 弹全屏通知自动拉起验证页（100% 全自动的关键一步）。
     * 全屏通知的 fullScreenIntent 会直接打开验证页，验证页内自动点签到、
     * 自动拖滑块、验证成功后自动收尾，不需要用户任何操作。
     */
    private fun showVerifyNotification(account: WeiboAccount) {
        try {
            val intent = Intent(this, WeiboLoginActivity::class.java)
                .putExtra(WeiboLoginActivity.EXTRA_VERIFY_MODE, true)
                .putExtra(WeiboLoginActivity.EXTRA_ACCOUNT_ID, account.id)
                // ★ 第 13 期：标注来源。全屏通知和「点通知」共用这个 intent，统一记作「通知」。
                .putExtra(WeiboLoginActivity.EXTRA_LAUNCH_SOURCE, "通知")
                // ★★★ 第 16 期：CLEAR_TOP → SINGLE_TOP。
                //   CLEAR_TOP 的官方语义是「目标已在该任务里 ⇒ finish 掉它再重建」——
                //   实测 wm_create_activity .377 → wm_finish_activity .378(app-request)
                //        → wm_destroy_activity .379 → wm_restart_activity .382，
                //   即通知与悬浮窗两条路毫秒级同时开火时，后一条把前一条 kill 掉再重建。
                //   SINGLE_TOP 的语义是「已在栈顶就复用」（走 onNewIntent），正是要的。
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            val pending = PendingIntent.getActivity(
                this,
                VERIFY_NOTIFICATION_ID,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(this, VERIFY_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notif_verify_needed, account.displayName))
                // ★ 第 19 期：去掉 fullScreenIntent 自动拉起验证页。
                //   自动验证改走悬浮窗（锁屏下可用，绕开 Activity 睡眠令牌）；
                //   全屏通知自动拉起的是 WeiboLoginActivity，锁屏下会被睡眠令牌秒杀，
                //   还会凭空多记一次「验证页累计」。这里只保留 contentIntent（用户手动点开）。
                .setContentIntent(pending)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .build()
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val canFs = if (Build.VERSION.SDK_INT >= 34) manager.canUseFullScreenIntent() else true
            // ★ 原来这 6 条走的是 Dbg.log —— 而 Dbg.enabled 为 false，等于没有出口。
            //   现在全部进黑匣子，报告里能看到「通知到底发出去了没有」。
            val channelLevel = manager.getNotificationChannel(VERIFY_CHANNEL_ID)?.importance ?: -1
            SliderTrace.log(
                "[通知] 验证通知已发出：渠道=" + VERIFY_CHANNEL_ID +
                    " 级别=" + channelLevel +
                    // ★ 第 13 期订正：IMPORTANCE_HIGH 的**数值就是 4**，不是 5。
                    //   （5 是 IMPORTANCE_MAX，官方标为 unused。）
                    //   上一轮报告里印的是「级别=4（5=高）」，自相矛盾，会把人带偏。
                    "（4=高）通知权限=" + manager.areNotificationsEnabled() +
                    " 全屏通知权限=" + canFs
            )
            manager.notify(VERIFY_NOTIFICATION_ID, notification)

            // ★★★ 第 19 期：自动验证改走悬浮窗（唯一锁屏下能活的路径）。
            //   复用同一个 YidunAutoSlider（逐字节不变），只换承载它的 WebView 容器。
            //   之前的「无障碍兜底」+「悬浮窗 startActivity 兜底」是去拉起 WeiboLoginActivity，
            //   锁屏下会被睡眠令牌秒杀，已弃用。
            OverlayVerifyHost.start(this, account)
            SliderTrace.log("[通知] 已调用悬浮窗验证（是否真起来，看有没有 [悬浮窗验证] 已挂载）")

            // ★★★ 第 16 期：延迟重拉 —— 等「显示已唤醒」传播完，再补拉一次。
            //
            //   实测（2026-09-28 16:30:53）：
            //     .349 screen_toggled:1（屏幕亮）
            //     .377 wm_create_activity
            //     .386 wm_pause_activity … sleep     ← 37 毫秒就被判「睡眠」
            //   「sleep」在整个日志缓冲区里只出现 4 次，其余 3 次全都对应屏幕熄灭
            //   ⇒ 它的真实含义是「任务被判为睡眠」。屏幕亮了 37 毫秒，
            //     「显示已唤醒」还没传播到任务管理器，页面就被创建，
            //     于是被当成「睡眠期间不该显示的活动」直接暂停。
            //
            //   ★ 这不是窗口标志能救的：暂停发生在页面被显示**之前**，
            //     所以第 7 / 14 / 15 期三次改窗口标志，三次都没成。
            //   ⇒ 唯一能绕开它的办法是等：等状态传播完再拉一次。
            //     那时任务已经醒着，页面能活下来；清单里的 turnScreenOn
            //     会在这一次把屏幕点亮（第 15 期加的那条，这次才真正派上用场）。
            //
            //   ★ 页面已经活着就跳过。就算误判，配合 SINGLE_TOP 也只会走一次
            //     onNewIntent（只留痕、不做处理），不会有副作用。
            // ★ 第 19 期：延迟重拉也改查悬浮窗是否还活着。
            verifyRelaunchHandler.removeCallbacksAndMessages(null)
            verifyRelaunchHandler.postDelayed({
                if (!OverlayVerifyHost.isActive()) {
                    OverlayVerifyHost.start(this@AgentService, account)
                    SliderTrace.log(
                        "[通知] 延迟重拉：上一次悬浮窗没活下来，等屏幕唤醒后补拉一次" +
                            "（看后面有没有 [悬浮窗验证] 已挂载）"
                    )
                } else {
                    SliderTrace.log("[通知] 延迟重拉：悬浮窗还活着，跳过")
                }
            }, VERIFY_RELAUNCH_DELAY_MS)
        } catch (error: Throwable) {
            // ★ 原来这里把异常整个吞掉，「通知没发出去」是静默的。
            SliderTrace.log(
                "[通知] 拉起验证页失败：" + error.javaClass.simpleName + " " + error.message
            )
        }
    }

    companion object {
        const val ACTION_RUN_CHECKIN = "com.tjh.weibotask.RUN_CHECKIN"
        const val ACTION_START_SCHEDULED = "com.tjh.weibotask.START_SCHEDULED"

        /**
         * ★ 第 16 期：验证页「延迟重拉」的等待时长。
         *
         *   依据：实测屏幕亮起到「显示已唤醒」传播完只需要几十毫秒，
         *   这里留 1.5 秒余量 —— 足够状态传播完，又远小于任何屏幕自动熄灭的
         *   超时（最短一般也在 15 秒以上），不会因为等太久而被重新熄灭。
         */
        const val VERIFY_RELAUNCH_DELAY_MS = 1500L

        /**
         * 只发帖、不签到。
         *
         * ★ 为什么要有独立入口：发帖接口是本机**无法验证**的部分（没有 JDK/SDK，
         *   也不可能在真机上试）。必须有一个按钮能让用户当场发一条、立刻看到
         *   微博返回的原始结果，否则只能等第二天定时跑完才能知道接口对不对 ——
         *   一轮反馈就是一天。
         */
        const val ACTION_RUN_POST = "com.tjh.weibotask.RUN_POST"

        /**
         * 手动「立即签到」时带上它 → 不分批，一次跑完所有可签账号。
         * 定时自动签到不带它 → 走分批错峰（每批 [BATCH_SIZE] 个）。
         */
        const val EXTRA_RUN_ALL = "com.tjh.weibotask.EXTRA_RUN_ALL"

        /**
         * 风控 / 验证码等临时状态的暂停时长，到期自动重试。
         *
         * ★ 旧值是 6 小时。后果是：一旦触发暂停，当天剩下的超话就**再也不会被签**，
         *   用户第二天才发现「昨天有几个没签上」。
         *   现在改成 30 分钟 —— 足够让微博的限流状态恢复，又不至于把当天剩下的一次性放弃。
         */
        private const val PAUSE_DURATION_MS = 30 * 60 * 1000L

        /**
         * ★★★★ 第 62 期：验证失败后，隔几个小时自动再试一次补签。
         *
         * 原来 `needsVerify = true` 的账号会被 `!it.needsVerify` 彻底排除出待跑池，
         * 当天再也不会被自动签到。真机 2026-10-04 实证：账号四 09:48「停手」之后
         * 一整天没人管它，要等第二天「跨天复活」才重试（用户看到「今日进度 4/5」）。
         *
         * 用户 2026-10-04 明确要求：「他既然需要人工验证失败了，就再试一次重新补签」。
         *
         * 本值只放宽「什么时候再试一次」这一个条件，**不改变任何一次签到请求的内容**：
         *   · 距上次失败 >= 本值 ⇒ 清掉 needsVerify，让它重新进池子跑一轮；
         *   · 跑一轮仍然撞风控 ⇒ 再标 needsVerify、再等本值 —— 自然形成限频；
         *   · 跑成功 ⇒ onVerifySuccess 设 restUntil（默认 24 小时）⇒ 自然停止重试。
         * 每次重试只发 1~2 个请求就会撞到验证页并立刻停下（见 runCheckin 的 CAPTCHA 分支），
         * 不会变成空转刷请求。
         *
         * ★ 一键回滚：把本值改成 0 ⇒ 完全回到第 41 期行为（只剩「跨天复活」一条路）。
         */
        @Volatile var verifyFailRetryHours = 2

        /**
         * 「有超话没签完」（PARTIAL）时的补签间隔。
         *
         * 它跟风控暂停是两回事：风控要等微博那边冷静下来（30 分钟），
         * 而「时间不够」纯粹是本地预算的问题 —— 只要再给一轮就能签上，
         * 所以间隔短得多，10 分钟后再跑一遍。
         */
        private const val PARTIAL_RETRY_DELAY_MS = 10 * 60 * 1000L

        /**
         * 每批跑几个账号。
         *
         * ★ 为什么要有这个：微博的风控是**按账号**限流的，但同一台手机只有一个 IP。
         *   把 10 个账号在同一分钟里全部跑一遍，等于在同一个 IP 上瞬间发出几十次请求 ——
         *   这不是「10 个账号各自正常签到」，在微博眼里就是一次异常流量。
         *   分成小批、拉长时间，请求密度才能降下来。
         *
         * 取 3 的理由：单批耗时约 3~10 分钟（一个账号最多 10 分钟预算），
         * 20 分钟间隔下不会出现「上一批还没跑完下一批就来了」的重叠。
         */
        private const val BATCH_SIZE = 3

        /**
         * 两批之间的间隔（另加随机抖动，见 BATCH_GAP_JITTER_MS）。
         *
         * ★ v19.19：由 20 分钟拉长到 50 分钟。
         *
         *   批次是「降低单次突发密度」的手段，15 分钟一轮的节奏还是太整齐、太频繁。
         *   拉长到 50 分钟后，10 个账号会摊到 ~3 小时里慢慢跑完，
         *   更接近「一个人断断续续刷微博」的样子。
         */
        private const val BATCH_GAP_MS = 50 * 60 * 1000L

        /**
         * 批次间隔的随机抖动。
         *
         * ★ 固定间隔也是一种「机器特征」：每天都是 50 分 00 秒准时开始下一批，
         *   比随机间隔更容易被识别。加上 0~20 分钟抖动，行为更像人在用手机。
         *
         * ★ v19.19：抖动上限由 5 分钟放宽到 20 分钟，配合拉长后的 BATCH_GAP_MS。
         */
        private const val BATCH_GAP_JITTER_MS = 20 * 60 * 1000L

        /**
         * 同一批内，相邻两个账号之间的间隔。
         *
         * 分批解决了「批与批」的密度，但一批里的 3 个账号如果背靠背连着发，
         * 依然是 3 倍密度的突发流量，所以批内也要隔开。
         *
         * ★★ v19.19：由 8 秒拉长到 45 秒。
         *
         *   旧值 8~15 秒的后果，用户在 v19.18 上遇到了「需要人工处理：微博要求验证身份」。
         *   一个账号进 batch 之后要连着签十几个超话，账号之间的 8 秒根本不构成间隔 ——
         *   在微博眼里，同一台设备 IP 在几分钟内跑完几百次请求，这就是最典型的异常流量。
         */
        private const val ACCOUNT_GAP_MS = 45000L

        /** 账号间隔的抖动（同上，避免固定节奏）。45~105 秒，跨度足够大。 */
        private const val ACCOUNT_GAP_JITTER_MS = 60000L

        // 只在计划时间进入 90 分钟窗口后保持 CPU 清醒，避免整天持锁耗电。
        private const val STANDBY_WAKE_WINDOW_MS = 90 * 60 * 1000L
        private const val STANDBY_WAKE_GRACE_MS = 5 * 60 * 1000L

        private const val CHANNEL_ID = "weibo_task_agent"
        private const val NOTIFICATION_ID = 1001

        /**
         * 验证页通知专用的渠道。
         *
         * ★★ 必须是**独立渠道 + IMPORTANCE_HIGH**：Android 8 以后通知的重要级别由渠道决定，
         *   而渠道级别一旦创建就**无法用代码修改** —— 所以不能复用 CHANNEL_ID
         *   （那是 IMPORTANCE_LOW，为常驻进度通知设的），只能另开一个 id。
         *   LOW 级别下 setFullScreenIntent 永远不触发，验证页也就永远弹不出来。
         */
        private const val VERIFY_CHANNEL_ID = "weibo_task_verify"

        /** 验证页全屏通知的 ID（与常规通知分开） */
        private const val VERIFY_NOTIFICATION_ID = 1002
    }
}
