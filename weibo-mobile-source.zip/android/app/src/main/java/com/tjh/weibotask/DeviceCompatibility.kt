package com.tjh.weibotask

import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

object DeviceCompatibility {

    /**
     * ★★★ 第 69 期：最近一次「兼容性跳转」实际走到了哪一级。
     *
     * ## 为什么需要它
     * 用户报「点了没反应」时，光看界面**分不清**是：
     *   · 这个 action 在当前 ROM 上根本没有页面（resolveActivity 返回 null），还是
     *   · 页面存在但 startActivity 被拦了，还是
     *   · 页面开出来了、只是开错了地方。
     * 这三种的修法完全不同。把「实际走到第几级」记下来写进诊断报告，
     * 用户下一份报告就能直接定性，不用再靠猜。
     *
     * ★ 纯诊断用途：**只被写入、只被读出来打印**，不参与任何判定，
     *   不改签到 / 验证 / 发帖 / 数据层的任何一个决定。
     */
    @Volatile
    var compatTrace: String = ""
        private set

    /**
     * 各品牌的**具体路径**。
     *
     * ★ 为什么不再只写一句「允许自启动、后台运行」：
     *   国产 ROM 把这三项分散在三个互不相邻的设置页里，只说名字用户根本找不到，
     *   结果就是「做过一部分」—— 而少做的那一项恰好就是决定性的一项。
     *   这里直接把「设置 → 具体哪一层 → 具体哪一项」写出来。
     */
    private fun brandSteps(context: Context, brand: String): String = when {
        brand.contains("oppo") || brand.contains("oneplus") || brand.contains("realme") ->
            context.getString(R.string.compat_steps_oppo)
        brand.contains("vivo") || brand.contains("iqoo") ->
            context.getString(R.string.compat_steps_vivo)
        brand.contains("xiaomi") || brand.contains("redmi") ->
            context.getString(R.string.compat_steps_xiaomi)
        brand.contains("huawei") || brand.contains("honor") ->
            context.getString(R.string.compat_steps_huawei)
        brand.contains("samsung") ->
            context.getString(R.string.compat_steps_samsung)
        brand.contains("asus") ->
            context.getString(R.string.compat_steps_asus)
        brand.contains("meizu") ->
            context.getString(R.string.compat_steps_meizu)
        else ->
            context.getString(R.string.compat_steps_default)
    }

    fun showGuide(activity: Activity) {
        val brand = Build.MANUFACTURER.lowercase()
        val guide = brandSteps(activity, brand)
        AlertDialog.Builder(activity)
            .setTitle(activity.getString(R.string.compat_guide_title))
            .setMessage(
                guide + "\n\n" +
                    activity.getString(R.string.compat_guide_note_1) + "\n\n" +
                    activity.getString(R.string.compat_guide_note_2) + "\n\n" +
                    activity.getString(R.string.compat_guide_note_3) + "\n\n" +
                    activity.getString(R.string.compat_guide_note_4)
            )
            .setPositiveButton(activity.getString(R.string.compat_btn_app_details)) { _, _ ->
                openAppDetails(activity)
            }
            .setNeutralButton(activity.getString(R.string.compat_btn_autostart)) { _, _ ->
                openBrandAutoStart(activity)
            }
            .setNegativeButton(activity.getString(R.string.compat_btn_battery)) { _, _ ->
                // ★ 第 69 期：返回值（走到哪一级）由 compatTrace 记着，这里丢弃
                openBatterySettings(activity)
                Unit
            }
            .show()
    }

    fun openExactAlarmSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = context.getSystemService(AlarmManager::class.java)
            if (!alarmManager.canScheduleExactAlarms()) {
                // ★ 第 69 期：同样走 fire() 留痕 —— 之前这里的 catch 静默吞掉，
                //   「精确闹钟点了没反应」在报告里一个字都看不到。
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                    .setData(Uri.parse("package:" + context.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (fire(context, intent)) {
                    compatTrace = "alarm:request(package)"
                } else {
                    compatTrace = "alarm:appDetails(fallback)"
                    openAppDetails(context)
                }
            }
        }
    }

    private fun openAppDetails(context: Context) {
        val detail = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.parse("package:" + context.packageName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!fire(context, detail)) {
            // 连应用详情页都拉不起（极罕见）⇒ 最后退回系统设置首页
            fire(context, Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /**
     * ★★★ 第 69 期：三级兜底 + **每一步留痕**。
     *
     * ## 为什么必须改（用户实测症状：「点了没反应」）
     *
     * 旧实现只有两级，而且**两级都可能在「不抛异常」的情况下什么都没发生** ——
     * `startActivity()` 抛异常只是失败的一种；Intent 被解析到但目标页是空白、
     * 被 ROM 拦截、需要额外 extra 时，它**静默返回**，用户看到的就是「点了没反应」。
     *
     * 更糟的是上面套了 `catch (_: Exception)`：**连抛异常这条路都不留任何痕迹**，
     * 排查时完全不知道它走到哪一级、哪一级失败的。
     *
     * ## 三级怎么选（用 [resolveActivity] 预检，而不是靠「抛异常试错」）
     *
     *   ① `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` + `package:`
     *      —— 最精准，能直接弹出「是否允许」对话框。但国产 ROM 常把这个 action 过滤掉。
     *   ② `ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS`
     *      —— 全机电池优化**列表页**，用户还得自己翻到本应用（国产 ROM 上经常找不到本应用）。
     *   ③ `ACTION_APPLICATION_DETAILS_SETTINGS` + `package:`
     *      —— **所有 ROM 都保证存在**的应用详情页。进不去是不可能的。
     *         用户在里面找「电池 / 耗电管理 / 后台运行」即可。
     *
     * 旧实现只有 ①②，且把 ② 写在 `catch` 里 —— 于是 ② 一旦「静默失败」，
     * 就再也掉不到 ③，用户彻底卡死。现在 ③ 是**兜底的最后一级**。
     *
     * ★ 本函数只决定「把用户送到哪个系统页面」，**不参与任何判定**
     *   （不改变签到 / 验证 / 发帖 / 数据层的任何一个决定）。
     *
     * @return 真正成功拉起的那一级的代号（写进诊断报告用）；全部失败返回 "none"
     */
    fun openBatterySettings(context: Context): String {
        // ① 精确定位本应用的电池优化设置（最理想）
        val step1 = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            .setData(Uri.parse("package:" + context.packageName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (fire(context, step1)) {
            compatTrace = "battery:request(package)"
            return "request"
        }

        // ② 全机电池优化列表（次选；用户需自己找到本应用）
        val step2 = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (fire(context, step2)) {
            compatTrace = "battery:list(global)"
            return "list"
        }

        // ③ 应用详情页 —— 最后一级，任何 ROM 都保证存在
        val step3 = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.parse("package:" + context.packageName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (fire(context, step3)) {
            compatTrace = "battery:appDetails(fallback3)"
            return "appDetails"
        }

        compatTrace = "battery:none(all 3 failed)"
        return "none"
    }

    /**
     * 真正拉起一个 Intent，并**返回是否成功**。
     *
     * ★ 为什么不直接 `try { startActivity } catch { }`：
     *   ① `resolveActivity()` 返回 null ⇒ 这个 action 在当前 ROM 上**根本没有页面可开**，
     *      这种情况连试都不用试（试了会抛 ActivityNotFoundException，被 catch 吞掉）；
     *   ② resolve 到了再 startActivity，仍可能抛（权限 / 被拦截）⇒ 所以两层都要判。
     *
     * ★ 全程**不写 Prefs、不改任何状态**，只做「拉起 + 返回成败」。
     *   上一版把失败信息丢掉，就是为了这个函数里能把它留下来。
     */
    private fun fire(context: Context, intent: Intent): Boolean {
        val resolvable = try {
            intent.resolveActivity(context.packageManager) != null
        } catch (_: Throwable) {
            false
        }
        if (!resolvable) return false
        return try {
            context.startActivity(intent)
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun openBrandAutoStart(context: Context) {
        val brand = Build.MANUFACTURER.lowercase()
        val components = when {
            brand.contains("xiaomi") || brand.contains("redmi") -> listOf(
                ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
            )
            brand.contains("huawei") || brand.contains("honor") -> listOf(
                ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
                ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")
            )
            brand.contains("oppo") || brand.contains("oneplus") || brand.contains("realme") -> listOf(
                ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
                ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")
            )
            brand.contains("vivo") || brand.contains("iqoo") -> listOf(
                ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
                ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")
            )
            brand.contains("samsung") -> listOf(
                ComponentName("com.samsung.android.lool", "com.samsung.android.lool.activity.SleepingAppsActivity"),
                ComponentName("com.samsung.android.sm", "com.samsung.android.sm.ui.appsmanagement.activity.AutoStartActivity")
            )
            else -> emptyList()
        }
        // ★★★ 第 69 期：显式组件跳转在 Android 11+ 受「包可见性」限制 ——
        //   没在 Manifest 里用 <queries> 声明过的包，resolveActivity() 会返回 null
        //   （即使那个包真的装着），startActivity() 会抛 ActivityNotFoundException。
        //   旧实现在 catch 里静默吞掉，症状正好是「点了没反应」。
        //   现在两条路径都留痕：resolve 不到是「包不可见/未安装」，start 抛是「被 ROM 拦」。
        for (component in components) {
            val intent = Intent().setComponent(component).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (fire(context, intent)) {
                compatTrace = "autostart:" + component.packageName
                return
            }
        }
        compatTrace = "autostart:none(brand=" + brand + ")"
        openAppDetails(context)
    }
}
