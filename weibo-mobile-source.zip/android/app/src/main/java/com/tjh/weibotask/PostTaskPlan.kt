package com.tjh.weibotask

/**
 * ★★★★ 第 117 期：把一条 [PostTask] **解析成「能跑的样子」**。
 *
 * ★ 纯逻辑、无 UI 依赖：既被界面层 [PostTaskStarter] 用来校验 + 弹提示，
 *   也被 [AgentService.executePostTaskOnce] 用来真正取账号与正文 —— 单一数据源，避免两边各写一份。
 *
 * ★★★★ 第 118 期（用户拍板）改了两处：
 *   1. [accounts] 新增 [PostAccountScope.ROTATE] 分支（所有账号轮流）；
 *   2. [bodies] 从「取第一个非空」改成「**把所有勾中来源合并成一个池子**」。
 */
object PostTaskPlan {

    private const val LOG_TAG = "PostTaskPlan"

    /** 这条任务这趟该参与的账号。 */
    fun accounts(task: PostTask, todayStr: String, perAccount: Int): List<WeiboAccount> {
        val pending = AccountStore.postPending(todayStr, perAccount)
        return when (task.accountScope) {
            PostAccountScope.ALL -> pending
            PostAccountScope.MANUAL ->
                pending.filter { it.id in task.accountIds.toSet() }
            // ★★★★ 第 118 期：**所有账号轮流**。
            //   账号集合与 [PostAccountScope.ALL] **完全一样** —— 区别不在「选哪些账号」，
            //   而在**执行侧怎么分配**：轮流模式下每条帖子换一个账号（交错），
            //   见 [AgentService.executePostTaskOnce] 里的「拆趟」逻辑。
            //   ⇒ 本函数对它不需要任何过滤；但**必须显式列出这个分支**，
            //     否则以后 when 加了新枚举值时容易漏掉、静默掉进 else。
            PostAccountScope.ROTATE -> pending
            // ★ 「分组」第 118 期起**已无 UI 入口**（用户拍板「分组功能可以先删除」），
            //   但枚举值保留 ⇒ 老数据仍可能读出 GROUP。
            //   不能因此一条都不发（那是静默失效）⇒ 退回「全部」并留日志。
            PostAccountScope.GROUP -> {
                Dbg.log(LOG_TAG, "accountScope=GROUP 已无 UI 入口，本次按「全部」执行")
                pending
            }
        }
    }

    /**
     * 这条任务要用哪几段正文。
     *
     * ★★★★ 第 118 期（用户拍板）：**把所有勾中的来源合并成一个池子**。
     *
     *   第 117 期的规则是「按注册表顺序取**第一个**非空的来源」（`return list`）；
     *   用户 2026-10-16 明确要「**合并成一个池子**」⇒ 改成 `out.addAll(...)`，
     *   顺序 = [PostContentRegistry.all] 的顺序（= 界面上的显示顺序）。
     *
     *   · 一个来源的内容为空（例如 `Prefs.postContentText` 没填）⇒ 它不贡献任何一条，
     *     但**不影响**别的来源继续合并进来（这正是「合并」与「取第一个」的关键差别）；
     *   · 全部来源都为空 = 这条任务**跑不了**，返回空列表 ⇒ 调用方必须跳过 + 明确提示。
     *     **绝不许拿占位文案顶上**（[PostContentSource] 文件头那条铁律）。
     *   · 勾了但**注册表里没有**的 id（第 116 期的 `builtin` / `video_new` 老数据）
     *     ⇒ 记一行日志、不静默 —— 否则用户会看到「明明勾了却少了内容」而无从排查。
     */
    fun bodies(task: PostTask): List<String> {
        val out = mutableListOf<String>()
        val hit = mutableSetOf<String>()
        for (source in PostContentRegistry.all()) {
            if (source.id !in task.contentSourceIds) continue
            hit.add(source.id)
            out.addAll(source.bodies())
        }
        val unknown = task.contentSourceIds.filter { it !in hit }
        if (unknown.isNotEmpty()) {
            Dbg.log(LOG_TAG, "任务勾了未注册的文案来源，已忽略：" + unknown.joinToString(","))
        }
        return out
    }
}
