package com.tjh.weibotask

/**
 * ★★★★ 第 117 期：把一条 [PostTask] **解析成「能跑的样子」**。
 *
 * ★ 纯逻辑、无 UI 依赖：既被界面层 [PostTaskStarter] 用来校验 + 弹提示，
 *   也被 [AgentService.executePostTaskOnce] 用来真正取账号与正文 —— 单一数据源，避免两边各写一份。
 */
object PostTaskPlan {

    private const val LOG_TAG = "PostTaskPlan"

    /** 这条任务这趟该参与的账号。 */
    fun accounts(task: PostTask, todayStr: String, perAccount: Int): List<WeiboAccount> {
        val pending = AccountStore.postPending(todayStr, perAccount)
        return when (task.accountScope) {
            PostAccountScope.ALL -> pending
            PostAccountScope.MANUAL ->
                pending.filter { it.id in task.accountIds.toSet() }
            // ★ 「分组」本期置灰（用户拍板），弹窗里选不到；但老数据 / 以后可能存了 GROUP。
            //   不能因此一条都不发（那是静默失效）⇒ 退回「全部」并留日志。
            PostAccountScope.GROUP -> {
                Dbg.log(LOG_TAG, "accountScope=GROUP 尚未实现，本次按「全部」执行")
                pending
            }
        }
    }

    /**
     * 这条任务要用哪几段正文。
     *
     * ★ 规则：按注册表顺序取**第一个「勾了且非空」**的来源。
     *   5 个只读源恒返回空列表（第 116 期，用户定「先搭结构、内容留空待补」）
     *   ⇒ 现阶段实际能出内容的只有 prefs（本地文案）。
     * ★ 全部为空 = 这条任务**跑不了**，返回空列表 ⇒ 调用方必须跳过 + 明确提示。
     *   **绝不许拿占位文案顶上**（PostContentSource 文件头那条铁律）。
     * ★ 选到 prefs 时返回的列表与 parsePostBodies(Prefs.postContentText) 逐字等价（见 spec §3.3）。
     */
    fun bodies(task: PostTask): List<String> {
        for (source in PostContentRegistry.all()) {
            if (source.id !in task.contentSourceIds) continue
            val list = source.bodies()
            if (list.isNotEmpty()) return list
        }
        return emptyList()
    }
}
