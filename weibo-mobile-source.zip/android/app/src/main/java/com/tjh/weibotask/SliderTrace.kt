package com.tjh.weibotask

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 滑块 / 验证链路的「黑匣子」。
 *
 * ★ 为什么需要它：
 *   这条链路的失败点**全是静默的** —— 自动点签到没点到、验证码压根没出现、
 *   图片下载失败、缺口识别失败、拖动被拒、验证页被锁屏盖住导致页面不可见，
 *   这几种情况在界面上的表现**一模一样**（用户看到的都是「验证还是失败了」），
 *   而原来的日志出口只有两处，都拿不到：
 *     1. [Dbg.log] → 只进 logcat，本机没连 adb 就等于没有；
 *     2. onLog     → 只弹一个 Toast，一两秒就消失，事后无法回看。
 *   于是每次排查都只能靠读代码猜，一轮要等半天。
 *
 *   这里做一个环形缓冲，把链路上的关键事件按时间顺序记下来，
 *   用户回到首页点「复制排查信息」就能整段粘贴出来 —— 不用连电脑、不用 adb。
 *
 * ★★ 2026-09-27 第 8 期补：**落盘（镜像到私有 SharedPreferences）**。
 *   原来纯内存，进程一被杀就全丢 —— 而「自动签到失败」恰恰经常伴随
 *   进程被 ROM 回收 / 被用户从最近任务划掉。第一次回传的那段日志里
 *   一行验证记录都没有，正是这个原因造成的歧义：
 *   分不清「验证页压根没打开」和「打开了但日志随进程没了」。
 *   现在每次写入都镜像一份到本应用私有存储，进程重启后自动接续，
 *   并且每次进程首次接续都会留一条 `[进程]` 标记 ——
 *   有了它，「这一段日志属于哪个进程」就不用再猜。
 *
 * ★ 边界（刻意为之，不要随手扩大）：
 *   - **不碰 `Prefs`**：那是核心数据层，md5 锁死；这里另开一个私有文件。
 *   - 只写日志，不参与任何判定：本对象没有任何返回值被业务代码使用。
 *     换句话说，把它整个删掉，签到/发帖/验证的行为不会有任何变化。
 *   - 写盘失败一律静默：取证不能反过来影响主流程。
 */
object SliderTrace {

    /**
     * 环形缓冲容量：够覆盖一轮完整验证（含多次重试），又不会把报告撑爆。
     *
     * ★★ 第 40 期：80 → 400。
     *   第 39 期两次真机取证都栽在「80 条被一轮多账号风控刷满」上 ——
     *   账号 1/2 的验证会话日志被挤掉，导致「它们为什么过不去」至今无法定性。
     *   400 条 ≈ 5 轮完整验证会话，仍然只是日志：**不参与任何判定**，
     *   把整个 SliderTrace 删掉，签到/发帖/验证的行为不会有任何变化。
     */
    private const val CAP = 400

    private const val STORE_NAME = "slider_trace"
    private const val KEY_LINES = "lines"

    // ★★ 第 9 期新增：累计量。和环形缓冲**存在同一个私有文件里**，
    //   但独立成键 —— 所以不会被后续日志挤掉。
    private const val KEY_VERIFY_COUNT = "verify_count"
    private const val KEY_VERIFY_AT = "verify_at"
    private const val KEY_VERIFY_ENV = "verify_env"
    private const val KEY_FIRST_SEEN_AT = "first_seen_at"

    private val buffer = ArrayList<String>(CAP)
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private var lastAt = 0L
    private var store: SharedPreferences? = null

    /**
     * 「出现过多少次验证页」以及最近一次的环境快照。
     *
     * ★ 刻意**不放进环形缓冲**：缓冲 80 条会被一轮验证刷满，
     *   而「到底有没有出现过验证页」这个问题必须永远答得出来 ——
     *   0 次和 >0 次的排查方向完全相反，答错一次就白跑一轮。
     */
    private var verifyCount = 0
    private var verifyAt = 0L
    private var verifyEnv = ""
    private var firstSeenAt = 0L
    private val stampFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA)

    /**
     * 接上上次的记录。**必须在记日志 / 生成报告之前调用一次**（各 Activity 的 onCreate 里调）。
     *
     * 同一个进程内重复调用无副作用；每次进程首次调用会补一条 `[进程]` 标记。
     */
    @Synchronized
    fun init(context: Context) {
        if (store != null) return
        val sp = try {
            context.applicationContext.getSharedPreferences(STORE_NAME, Context.MODE_PRIVATE)
        } catch (_: Throwable) {
            null
        }
        store = sp
        val saved = try {
            sp?.getString(KEY_LINES, "").orEmpty()
        } catch (_: Throwable) {
            ""
        }
        var kept = 0
        if (saved.isNotBlank()) {
            val tail = saved.split("\n").filter { it.isNotBlank() }.takeLast(CAP - 1)
            buffer.clear()
            buffer.addAll(tail)
            kept = tail.size
        }
        // ★★ 回读累计量。它回答的是排查里最该先问的那一个问题 ——
        //   「这台机器上到底出现过验证页没有？」
        //   顺带记下「首次统计时刻」：否则「从未出现过」会被误读成
        //   「永远没出现过」，而实际上可能只是刚装了新版、统计才开始。
        verifyCount = readInt(sp, KEY_VERIFY_COUNT, 0)
        verifyAt = readLong(sp, KEY_VERIFY_AT, 0L)
        verifyEnv = readString(sp, KEY_VERIFY_ENV)
        firstSeenAt = readLong(sp, KEY_FIRST_SEEN_AT, 0L)
        if (firstSeenAt <= 0L) {
            firstSeenAt = System.currentTimeMillis()
            persistCounters()
        }
        // ★ 把计数直接写进 [进程] 行：用户回传日志时往往只截这一段，
        //   而这一段的第一行就是它 —— 于是「有没有出现过验证页」一眼可读。
        log("[进程] 新的 App 进程（接续上次 " + kept + " 条；验证页累计 " + verifyCount + " 次）")
    }

    /**
     * 记录一条。任何线程都可以调用。
     *
     * 时间戳后面跟的是**距上一条的毫秒差**，不是绝对耗时 ——
     * 排查「验证码是不是等太久才出现」「两次拖动之间隔了多久」时，差值比时刻更好读。
     */
    @Synchronized
    fun log(message: String) {
        val now = System.currentTimeMillis()
        val delta = if (lastAt == 0L) 0L else now - lastAt
        lastAt = now
        buffer.add(timeFormat.format(Date(now)) + " +" + delta + "ms  " + redact(message))
        while (buffer.size > CAP) buffer.removeAt(0)
        persist()
    }

    /** 取出全部记录；没有记录时返回空串（调用方负责给默认文案）。 */
    @Synchronized
    fun dump(): String = buffer.joinToString("\n")

    /**
     * 环形缓冲**当前条数**。
     *
     * ★ 第 49 期新增：**只给诊断报告的标题用**（`strings.xml` 的 `ma_jitter_note_40`）。
     *
     * 为什么需要它：原报告标题写死「最近 80 条」，而缓冲第 40 期就从 80 提到了 400，
     * 实际摊开的是**全量**（2026-10-02 那份报告摊了 189 行）。
     * 标题与事实不符会把读日志的人带偏 —— 看到「最近 80 条」会以为是抽样、
     * 以为更早的记录没打印出来，于是去别处找线索。
     *
     * ★ 不参与任何判定：本对象整个删掉，签到/发帖/验证的行为不会有任何变化。
     */
    @Synchronized
    fun size(): Int = buffer.size

    /** 环形缓冲**容量上限**（[CAP]）。同上，只给报告标题用。 */
    fun capacity(): Int = CAP

    /** 清空。 */
    @Synchronized
    fun clear() {
        buffer.clear()
        lastAt = 0L
        persist()
    }

    /**
     * 记一次「验证页会话」。
     *
     * ★ 为什么不靠环形缓冲里那条 `[环境]` 判断：缓冲只有 80 条，
     *   而一轮验证（含多次重试）能刷几十条，`[环境]` 在会话最开头，
     *   很容易被自己的后续日志挤掉。这个计数独立成键，挤不掉。
     */
    @Synchronized
    fun markVerifySession(environment: String) {
        verifyCount += 1
        verifyAt = System.currentTimeMillis()
        verifyEnv = environment
        persistCounters()
    }

    /**
     * 一句话小结：**这台机器上到底有没有出现过验证页**。
     *
     * ★ 这是整个排查里最该先看的一行，因为它把问题一刀切成两半：
     *   0 次 → 问题在「验证页压根没被拉起来」，和滑块、拖动、图片识别毫无关系，
     *          该去查闹钟、服务、通知、后台拉起限制；
     *   >0 次 → 页面确实打开过，接下来才轮到「可见不可见」「拖动有没有被拒」。
     */
    @Synchronized
    fun verifySummary(): String {
        if (verifyCount <= 0) {
            val since = if (firstSeenAt > 0L) {
                "（本机自 " + stampFormat.format(Date(firstSeenAt)) + " 起统计）"
            } else {
                ""
            }
            return "从未出现过" + since
        }
        val env = if (verifyEnv.isBlank()) "" else "，" + verifyEnv
        return verifyCount.toString() + " 次，最近 " + stampFormat.format(Date(verifyAt)) + env
    }

    /** 把累计量写进私有存储。失败静默。 */
    private fun persistCounters() {
        val sp = store ?: return
        try {
            sp.edit()
                .putInt(KEY_VERIFY_COUNT, verifyCount)
                .putLong(KEY_VERIFY_AT, verifyAt)
                .putString(KEY_VERIFY_ENV, verifyEnv)
                .putLong(KEY_FIRST_SEEN_AT, firstSeenAt)
                .apply()
        } catch (_: Throwable) {
        }
    }

    private fun readInt(sp: SharedPreferences?, key: String, fallback: Int): Int {
        return try {
            sp?.getInt(key, fallback) ?: fallback
        } catch (_: Throwable) {
            fallback
        }
    }

    private fun readLong(sp: SharedPreferences?, key: String, fallback: Long): Long {
        return try {
            sp?.getLong(key, fallback) ?: fallback
        } catch (_: Throwable) {
            fallback
        }
    }

    private fun readString(sp: SharedPreferences?, key: String): String {
        return try {
            sp?.getString(key, "").orEmpty()
        } catch (_: Throwable) {
            ""
        }
    }

    /** 把当前缓冲整段镜像到私有存储。失败静默 —— 取证不能反过来影响主流程。 */
    private fun persist() {
        val sp = store ?: return
        try {
            sp.edit().putString(KEY_LINES, buffer.joinToString("\n")).apply()
        } catch (_: Throwable) {
        }
    }

    /**
     * 抹掉 http(s) 地址里的 `?...` 查询串。
     *
     * ★ 验证页地址常带一次性票据，而这份内容是要贴出去给人看的，
     *   不能把会话票据一起带出去。诊断只需要域名和路径
     *   （例如判断「验证页到底在不在 security.weibo.com」）。
     *
     * 只处理地址本身，不动其它文本 —— 避免误伤「缺口x=123.4」这类正常内容。
     */
    private fun redact(text: String): String {
        val first = text.indexOf("http")
        if (first < 0) return text
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            val idx = text.indexOf("http", i)
            if (idx < 0) {
                sb.append(text, i, text.length)
                break
            }
            sb.append(text, i, idx)
            var end = idx
            while (end < text.length && !text[end].isWhitespace()) end++
            val url = text.substring(idx, end)
            val cut = url.indexOf('?')
            sb.append(if (cut >= 0) url.substring(0, cut) + "?<已隐藏>" else url)
            i = end
        }
        return sb.toString()
    }
}
