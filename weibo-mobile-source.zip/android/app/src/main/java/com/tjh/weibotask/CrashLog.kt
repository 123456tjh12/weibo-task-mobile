package com.tjh.weibotask

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 崩溃记录：把未捕获异常的堆栈落盘，供「复制诊断报告」带出来。
 *
 * ★★ 为什么必须做（v0.20.17）：
 *   用户已经**两次**报「人工验证跳转页面闪退」。上一次改的是 WebView 的跳转拦截
 *   （`shouldOverrideUrlLoading`），属于「凭经验猜根因」—— 猜对了是运气，
 *   猜错了就是再浪费用户一轮安装。
 *
 *   而「闪退」这个现象**默认什么都不留**：进程被杀，用户看到的只是「回到了桌面」，
 *   没有任何提示、没有任何文本可以发给我。没有堆栈就只能继续猜。
 *   → 按本工程既有的原则：**同一症状被反馈多次时，停止改业务逻辑，改可观测性**。
 *
 * ★ 做法：接管 `Thread.setDefaultUncaughtExceptionHandler`，把堆栈写进
 *   `filesDir/crash-last.txt`，**再把异常交回给系统原来的处理器** ——
 *   这样系统的崩溃提示与上报都不受影响，我们只是「顺手抄一份」。
 *
 * ★★ 局限（必须写在注释里，免得下次误判成「没崩」）：
 *   只能抓 **Java / Kotlin 未捕获异常**。
 *   native 层崩溃（SIGSEGV）和 **WebView 渲染进程被杀** 都到不了这里 ——
 *   后者由 `WeiboLoginActivity.onRenderProcessGone` 单独处理（那个是 API 26+ 的
 *   「默认直接杀掉整个应用」的坑，也是「跳转时闪退」最常见的真凶）。
 */
object CrashLog {
    private const val FILE_NAME = "crash-last.txt"

    /** 只留最近一次，且限长 —— 避免文件无限增长、也避免报告太长贴不动 */
    private const val MAX_CHARS = 12000

    @Volatile
    private var installed = false

    fun install(context: Context) {
        if (installed) return
        installed = true
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                write(appContext, thread, error)
            } catch (_: Throwable) {
                // ★ 记录失败绝不能盖过原始崩溃：写不进去就静默放过，继续走正常崩溃流程。
            }
            if (previous != null) {
                previous.uncaughtException(thread, error)
            } else {
                // 兜底：理论上 Android 总会装一个默认处理器，但万一没有，
                // 我们不能让应用带着坏状态继续跑 —— 自己结束进程。
                android.os.Process.killProcess(android.os.Process.myPid())
            }
        }
    }

    private fun write(context: Context, thread: Thread, error: Throwable) {
        val writer = StringWriter()
        val printer = PrintWriter(writer)
        printer.println("时间：" + SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date()))
        printer.println(
            "版本：" + BuildConfig.VERSION_NAME + "（构建号 " + BuildConfig.VERSION_CODE + "）"
        )
        printer.println(
            "机型：" + Build.MANUFACTURER + " " + Build.MODEL +
                " / Android " + Build.VERSION.RELEASE + "（API " + Build.VERSION.SDK_INT + "）"
        )
        printer.println("线程：" + thread.name)
        printer.println()
        error.printStackTrace(printer)
        printer.flush()
        var text = writer.toString()
        if (text.length > MAX_CHARS) {
            text = text.substring(0, MAX_CHARS) + "\n…（已截断）"
        }
        File(context.filesDir, FILE_NAME).writeText(text)
    }

    /** 读出上次的崩溃记录；没有记录返回空串。 */
    fun read(context: Context): String = try {
        val file = File(context.filesDir, FILE_NAME)
        if (file.exists()) file.readText().trim() else ""
    } catch (_: Throwable) {
        ""
    }

    /** 记录里的「时间：…」那一行，用来在界面上显示一个短提示。 */
    fun readTimeLine(context: Context): String =
        read(context).lineSequence().firstOrNull { it.startsWith("时间：") }.orEmpty()

    /** 记录里的异常首行（形如 `java.lang.NullPointerException: …`），给界面做短提示。 */
    fun readErrorLine(context: Context): String =
        read(context).lineSequence()
            .firstOrNull { it.contains("Exception") || it.contains("Error") }
            .orEmpty()
            .trim()

    fun clear(context: Context) {
        try {
            File(context.filesDir, FILE_NAME).delete()
        } catch (_: Throwable) {
        }
    }
}
