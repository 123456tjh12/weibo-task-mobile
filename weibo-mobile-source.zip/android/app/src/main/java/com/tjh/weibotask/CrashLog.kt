package com.tjh.weibotask

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 崩溃记录：把未捕获异常的堆栈落盘，供「复制诊断报告」带出来。
 *
 * ★★ 为什么必须做（v0.20.17）：
 *   用户已经**两次**报「人工验证跳转页面闪退」。上一次改的是 WebView 的跳转拦截
 *   （`shouldOverrideUrlLoading`），属于「凭经验猜根因」—— 猜对了是运气，
 *   猜错了就是再浪费用户一轮安装。
 *
 *   而「闪退」这个现象**默认什么都不留**：进程被杀，用户看到的只是「回到了桌面」，
 *   没有任何提示、没有任何文本可以发给我。没有堆栈就只能继续猜。
 *   → 按本工程既有的原则：**同一症状被反馈多次时，停止改业务逻辑，改可观测性**。
 *
 * ★ 做法：接管 `Thread.setDefaultUncaughtExceptionHandler`，把堆栈写进
 *   `filesDir/crash-last.txt`，**再把异常交回给系统原来的处理器** ——
 *   这样系统的崩溃提示与上报都不受影响，我们只是「顺手抄一份」。
 *
 * ★★ 局限（必须写在注释里，免得下次误判成「没崩」）：
 *   只能抓 **Java / Kotlin 未捕获异常**。
 *   native 层崩溃（SIGSEGV）和 **WebView 渲染进程被杀** 都到不了这里 ——
 *   后者由 `WeiboLoginActivity.onRenderProcessGone` 单独处理（那个是 API 26+ 的
 *   「默认直接杀掉整个应用」的坑，也是「跳转时闪退」最常见的真凶）。
 *
 * ★★★ v0.20.18 的实测结论（很重要，别再把「无记录」当成「没崩」）：
 *   用户第三次报同一个症状，装上本对象之后诊断报告显示
 *   **「无记录（本次安装后没崩过）」** —— 也就是**一次异常都没抓到**。
 *   这本身就是决定性证据：真凶是 native 崩溃 / 渲染进程被杀 / 系统杀进程，
 *   这三类**都到不了 `Thread.setDefaultUncaughtExceptionHandler`**。
 *   → 所以必须有下面的 `StepLog`：崩溃回调不执行时，只能靠「上一步已经落盘」来定位。
 */
object CrashLog {
    private const val FILE_NAME = "crash-last.txt"

    /** 只留最近一次，且限长 —— 避免文件无限增长、也避免报告太长贴不动 */
    private const val MAX_CHARS = 12000

    @Volatile
    private var installed = false

    fun install(context: Context) {
        if (installed) return
        installed = true
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                write(appContext, thread, error)
            } catch (_: Throwable) {
                // ★ 记录失败绝不能盖过原始崩溃：写不进去就静默放过，继续走正常崩溃流程。
            }
            if (previous != null) {
                previous.uncaughtException(thread, error)
            } else {
                // 兜底：理论上 Android 总会装一个默认处理器，但万一没有，
                // 我们不能让应用带着坏状态继续跑 —— 自己结束进程。
                android.os.Process.killProcess(android.os.Process.myPid())
            }
        }
    }

    private fun write(context: Context, thread: Thread, error: Throwable) {
        val writer = StringWriter()
        val printer = PrintWriter(writer)
        printer.println("时间：" + SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date()))
        printer.println(
            "版本：" + BuildConfig.VERSION_NAME + "（构建号 " + BuildConfig.VERSION_CODE + "）"
        )
        printer.println(
            "机型：" + Build.MANUFACTURER + " " + Build.MODEL +
                " / Android " + Build.VERSION.RELEASE + "（API " + Build.VERSION.SDK_INT + "）"
        )
        printer.println("线程：" + thread.name)
        printer.println()
        error.printStackTrace(printer)
        printer.flush()
        var text = writer.toString()
        if (text.length > MAX_CHARS) {
            text = text.substring(0, MAX_CHARS) + "\n…（已截断）"
        }
        File(context.filesDir, FILE_NAME).writeText(text)
    }

    /** 读出上次的崩溃记录；没有记录返回空串。 */
    fun read(context: Context): String = try {
        val file = File(context.filesDir, FILE_NAME)
        if (file.exists()) file.readText().trim() else ""
    } catch (_: Throwable) {
        ""
    }

    /** 记录里的「时间：…」那一行，用来在界面上显示一个短提示。 */
    fun readTimeLine(context: Context): String =
        read(context).lineSequence().firstOrNull { it.startsWith("时间：") }.orEmpty()

    /** 记录里的异常首行（形如 `java.lang.NullPointerException: …`），给界面做短提示。 */
    fun readErrorLine(context: Context): String =
        read(context).lineSequence()
            .firstOrNull { it.contains("Exception") || it.contains("Error") }
            .orEmpty()
            .trim()

    fun clear(context: Context) {
        try {
            File(context.filesDir, FILE_NAME).delete()
        } catch (_: Throwable) {
        }
    }
}

/**
 * 步骤留痕：把「走到哪一步」**每走一步就落盘**。
 *
 * ★★★ 为什么必须有它（v0.20.18 立）：
 *   用户第三次报「人工验证跳转页闪退」，而 `CrashLog` 抓到的结果是
 *   **「无记录（本次安装后没崩过）」** —— 一次 Java/Kotlin 异常都没有。
 *   这等于说：真凶是 native 崩溃、或 WebView 渲染进程被杀、或系统直接杀进程，
 *   三者都**不会执行我们的崩溃回调**。没有堆栈，就只能记录**过程**：
 *   最后一笔落在哪一步，那一步就是嫌疑点。
 *
 * ★★ 与 `CrashLog` 的关键区别（这是它能定位 native 崩溃的原因）：
 *   `CrashLog` 是「崩溃发生时写」—— native 崩溃时这个时机永远不会到来；
 *   本对象是「**每走一步就写**」—— 进程被瞬间干掉，但上一步早就落盘了。
 *
 * ★ 落盘方式用 `appendText`：每次调用都会重新打开并关闭文件，
 *   等于每次都 flush，代价是多几次系统调用。对「验证页」这种低频场景完全划算 ——
 *   ★ 千万不要为了省这点开销改成「先攒在内存里、最后一起写」，
 *     那样 native 崩溃时刚攒的那几行就全丢了，本对象也就白做了。
 *
 * ★ 只留最近 `MAX_LINES` 行，避免无限增长。
 */
object StepLog {
    /** 本次会话的留痕 */
    private const val FILE_NAME = "steps.log"

    /** 上一次会话的留痕（主界面启动时由 [rotate] 从 FILE_NAME 转过来） */
    private const val PREV_FILE_NAME = "steps-prev.log"

    private const val MAX_LINES = 80

    /** 正常退出的标记。上一轮末尾没有它 = 上一轮不是正常结束的。 */
    const val NORMAL_EXIT = "正常退出"

    fun step(context: Context, text: String) {
        try {
            val file = File(context.filesDir, FILE_NAME)
            val line = SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA).format(Date()) + "  " + text
            file.appendText(line + "\n")
            val lines = file.readLines()
            if (lines.size > MAX_LINES) {
                file.writeText(lines.takeLast(MAX_LINES).joinToString("\n") + "\n")
            }
        } catch (_: Throwable) {
            // ★ 留痕失败绝不能影响主流程：写不进去就静默放过。
        }
    }

    /**
     * 把上一次会话的留痕转到 `steps-prev.log`，然后开始新的一份。
     *
     * ★ 为什么要分开：如果不轮转，本次启动写的步骤会把上一轮的关键几行挤出窗口，
     *   等于「一重启证据就没了」—— 而用户排查时恰恰是先崩溃、再重启。
     */
    fun rotate(context: Context) {
        try {
            val current = File(context.filesDir, FILE_NAME)
            if (current.exists() && current.length() > 0L) {
                val prev = File(context.filesDir, PREV_FILE_NAME)
                if (prev.exists()) prev.delete()
                current.renameTo(prev)
            }
        } catch (_: Throwable) {
        }
    }

    /** 上一次会话的完整留痕；没有返回空串。 */
    fun readPrev(context: Context): String = readFile(context, PREV_FILE_NAME)

    /** 本次会话到目前为止的留痕；用于诊断报告里和上一轮做对照。 */
    fun readCurrent(context: Context): String = readFile(context, FILE_NAME)

    private fun readFile(context: Context, name: String): String = try {
        val file = File(context.filesDir, name)
        if (file.exists()) file.readText().trim() else ""
    } catch (_: Throwable) {
        ""
    }

    /** 上一次会话的最后几行，用于界面上的短提示。 */
    fun prevTail(context: Context, lines: Int): String =
        readPrev(context).lineSequence().filter { it.isNotBlank() }.toList()
            .takeLast(lines).joinToString("\n")

    /**
     * 上一次会话是否「没有正常结束」。
     *
     * ★★ 判据刻意收窄，避免把正常情况报成故障（「功能正常却报警 = 最坏噪音」）：
     *   ① 上一轮有留痕；② 末尾没有 [NORMAL_EXIT] 标记；③ 且留痕里出现过
     *   「登录页」或「渲染进程」—— 也就是用户**确实去过验证/登录页**。
     *   ③ 这一条把「后台被系统回收」这种正常情况挡在外面。
     */
    fun prevEndedBadly(context: Context): Boolean {
        val prev = readPrev(context)
        if (prev.isBlank()) return false
        if (prev.contains(NORMAL_EXIT)) return false
        return prev.contains("登录页") || prev.contains("渲染进程")
    }

    fun clearPrev(context: Context) {
        try {
            File(context.filesDir, PREV_FILE_NAME).delete()
        } catch (_: Throwable) {
        }
    }
}
