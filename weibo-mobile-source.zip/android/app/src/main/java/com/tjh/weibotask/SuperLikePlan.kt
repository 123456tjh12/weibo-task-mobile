package com.tjh.weibotask

import org.json.JSONObject

/**
 * ★★★★ 第 84 期：**超Like 一键编排**的配比。
 *
 * ## 这个配比是从哪来的
 *
 * 微博官方的「超Like」是一套**固定组合**任务，竞品「张奕然超话助手 v1.0.6」
 * 自己的界面文案写得很直白：
 *
 *     「今日超Like已完成（签到 + 4 首评 + 2 转发）」
 *
 * ⇒ 三件事 = **超话签到 ×1 + 首评 ×4 + 转发 ×2**。
 *
 * ## 为什么签到不在这里
 *
 * 用户明确选了「**编排不管签到**」。理由：
 *   · 签到是**核心链路①**（[AgentService]）的职责，它本来就按用户设的时间自动跑；
 *   · 编排再去签一次，等于把互动模块伸进核心链路 —— 而硬规则一要求
 *     四条核心链路（签到 / 发帖 / 验证 / 数据层）**一行不动**。
 * ⇒ 编排只管「首评 + 转发」这两件**本来就属于互动模块**的事。
 *
 * ## 字段
 *
 * ★ 全部字段都是**这个功能自己的**：没有一个字段是 [WeiboAccount] 上的，
 *   也没有一个字段写进 [Prefs]。落盘走 [InteractTaskStore] 的私有文件
 *   （`interact_tasks.xml`，key = `superlike_plan`），与账号数据零交集。
 */
data class SuperLikePlan(
    /** 超话链接或 ID（`InteractTarget.topicId` 会从里面抠出 `100808…`）。 */
    var topic: String = "",
    /** 首评条数。官方是 4。 */
    var firstComments: Int = 4,
    /** 转发条数。官方是 2。 */
    var reposts: Int = 2,
    /** 指定账号（按 [WeiboAccount.label]）；空串 = 所有可用账号轮流。 */
    var accountLabel: String = "",
    /** 语料分组 id；空串 = 用第一个分组。 */
    var groupId: String = ""

) {

    fun toJson(): JSONObject = JSONObject()
        .put("topic", topic)
        .put("firstComments", firstComments)
        .put("reposts", reposts)
        .put("accountLabel", accountLabel)
        .put("groupId", groupId)

    companion object {

        /**
         * 官方配比。★ 这两个数字**只在「没有存过」时才生效** ——
         * 用户改过就按用户改的走（见 [InteractTaskStore.plan]）。
         */
        const val OFFICIAL_FIRST = 4
        const val OFFICIAL_REPOST = 2

        /**
         * 上限。★ 为什么必须有：这两个数字直接决定**一次点击会发多少个写请求**。
         * 没有上限的话，手滑多打一个 0 就是几百条评论 —— 那是拿账号在赌。
         * 上限本身也是「一次点击最多 20 个写请求」这条硬边界。
         */
        const val MAX_FIRST = 10
        const val MAX_REPOST = 10

        fun fromJson(source: JSONObject): SuperLikePlan = SuperLikePlan(
            topic = source.optString("topic"),
            firstComments = source.optInt("firstComments", OFFICIAL_FIRST),
            reposts = source.optInt("reposts", OFFICIAL_REPOST),
            accountLabel = source.optString("accountLabel"),
            groupId = source.optString("groupId")
        )

        /** 把界面输入夹到合法区间。非数字 / 负数一律回落到 0（= 不做这件事）。 */
        fun clampFirst(value: Int): Int = value.coerceIn(0, MAX_FIRST)

        fun clampRepost(value: Int): Int = value.coerceIn(0, MAX_REPOST)
    }
}
