package com.tjh.weibotask

import android.app.AlarmManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * 第 20 期：开通向导（独立 Activity）。
 *
 * ★ 为什么从 MainActivity 里「一键开启（4 步）」对话框搬出来：
 *   旧向导只有 4 行、缺「电池优化 / 精确闹钟」两项真正影响全自动跑通的设置，
 *   而且第 ④ 项「全屏通知」是 Period-19 已经废弃的卡点（验证页改走悬浮窗承载）。
 *   搬成独立 Activity 后：
 *   1) 覆盖全自动真正需要的项 —— 见 buildItems()；
 *   2) 每次 onResume 都重新读系统状态，返回本应用后进度自动刷新，
 *      不用像旧向导那样靠「点完再回来手动关掉重开」；
 *   3) 用代码拼行、不新建 XML 布局 —— 少一处「改了布局忘了改代码」的机会。
 *
 * ★★ 第 42 期（2026-10-01，用户诉求「换手机要通用 + 向导要更简洁」）：
 *   ① 必选由 4 项减到 **3 项**：无障碍降为「可选（兜底）」（理由见 buildItems() 上方注释）；
 *   ② 条目**去掉 ①②③④⑤ 编号** —— 编号和「未开启排前」的排序会互相打架
 *      （③ 已开时会显示成 ① ② ④ ⑤，看着像坏了）；
 *   ③ 进度改成「还差 N 项就能全自动跑通」的大字，只数必选，分母取 REQUIRED_ITEM_COUNT；
 *   ④ 底部补回「各品牌后台设置教程」入口 —— 第 20 期搬家时漏掉的，换手机唯一的入口；
 *   ⑤ 旧对话框 showPermissionWizard 连同它的 5 个孤儿辅助函数已从 MainActivity 删除。
 *
 * ★ 只动「界面 / 文案 / 跳转」，一行核心判定都没碰：
 *   这里所有函数都是「读系统设置状态」或「拉起系统设置页」，
 *   不改变签到 / 验证 / 发帖 / 数据层里的任何决定。
 */
class SetupWizardActivity : AppCompatActivity() {

    companion object {
        /**
         * 向导里「必选」的项数 —— 设置页与向导**共用这一个数字**。
         *
         * ★ 第 42 期两个目的：
         *   ① 「无障碍」降级为**可选（兜底）**。第 36 期起点签到改走 WebView 真实触摸、
         *      第 38 期起拖动改回页面内 JS ⇒ 无障碍只剩 `YidunAutoSlider.kt:596` 那一级兜底，
         *      第 36/38 期真机黑匣子从没走到过 ⇒ 不再卡着用户必须开。
         *      必选 = 悬浮窗 + 电池优化 + 精确闹钟。
         *   ② 根治第 41 期那个显示 bug：`settings_perm_summary` 里**写死了**「/ 4 项」，
         *      而向导统计时把**可选的**通知也数进了分子 ⇒ 5 项全开时显示「已开启 5 / 4 项」。
         *      现在两边都从这个常量取分母，不会再漂移。
         *   ★ 必须与 buildItems() 里 `required = true` 的项数一致（目前 3 项）。
         */
        const val REQUIRED_ITEM_COUNT = 3
    }

    private lateinit var progressText: TextView
    private lateinit var listContainer: LinearLayout

    /** 每一项：标签、是否必选、当前是否已开启、点击「去开启」的动作 */
    private data class Item(
        val label: String,
        val required: Boolean,
        val isDone: () -> Boolean,
        val action: () -> Unit
    )

    private lateinit var items: List<Item>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.setup_wizard_title)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        val header = TextView(this).apply {
            text = getString(R.string.setup_wizard_header)
            textSize = 15f
            setTextColor(ContextCompat.getColor(this@SetupWizardActivity, R.color.text_primary))
            setPadding(0, 0, 0, dp(8))
        }

        progressText = TextView(this).apply {
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@SetupWizardActivity, R.color.brand_accent))
            setPadding(0, 0, 0, dp(12))
        }

        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val scroll = ScrollView(this).apply { addView(root) }
        root.addView(header)
        root.addView(progressText)
        root.addView(listContainer)

        // ★ 第 42 期：把「各品牌后台设置教程」搬进向导 —— 这是**换手机之后唯一的入口**。
        //
        //   第 20 期把向导从 MainActivity 的旧对话框搬成独立 Activity 时，
        //   漏掉了旧对话框上那个「各品牌设置教程」中性按钮。后果：
        //   现在这份教程只在「你第一次打开自动签到开关时」弹一次
        //   （MainActivity 的 compatGuideShown），之后**再也找不到入口** ——
        //   而换手机恰恰是最需要它的时候：各家 ROM 把「自启动 / 后台运行 / 锁屏运行」
        //   放在互不相邻的设置页里，而且**程序检测不到**，只能靠这份教程。
        //
        //   ★ 只复用已有的 DeviceCompatibility.showGuide()，不新增任何逻辑；
        //     上面那 3 项必选用的都是标准 Android API，本来就是全安卓通用的。
        val compatRow = TextView(this).apply {
            text = getString(R.string.settings_compat_open) + " ›"
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@SetupWizardActivity, R.color.brand_accent))
            setPadding(0, dp(20), 0, dp(8))
            setOnClickListener { DeviceCompatibility.showGuide(this@SetupWizardActivity) }
        }
        root.addView(compatRow)

        setContentView(scroll)

        items = buildItems()
        render()
    }

    /** 从系统设置页返回时，状态会自动刷新 */
    override fun onResume() {
        super.onResume()
        render()
    }

    /**
     * 向导的清单：**必选 3 项** + **可选 2 项**。
     *
     * ★ 第 42 期调整（用户批准）：无障碍由必选降为**可选（兜底）**。
     *   依据：第 36 期起点签到改走 `webView.dispatchTouchEvent()` 真实触摸，
     *   第 38 期起拖动改回页面内 `jsDrag` ⇒ 无障碍服务只剩「真实触摸和 JS 点击
     *   **都失败**」时的第三级兜底，而第 36/38 期真机黑匣子证明这条兜底从没被走到过。
     *   ⇒ 它不该再挡在「必选」里；但它**留在列表里**，真遇到点不动的情况还能开。
     *   ★ 只改「哪几项算必选」这个界面口径，不改任何一项的检测方式与跳转目标。
     */
    private fun buildItems(): List<Item> = listOf(
        Item(getString(R.string.setup_item_overlay), true, { canDrawOverlay() }) { openOverlay() },
        Item(getString(R.string.setup_item_battery), true, { isIgnoringBattery() }) {
            // ★ 第 69 期：openBatterySettings 返回「实际走到哪一级」，这里只丢弃返回值：
            //   走到哪一级由 DeviceCompatibility.compatTrace 记着，诊断报告会读它。
            DeviceCompatibility.openBatterySettings(this)
        },
        Item(getString(R.string.setup_item_alarm), true, { canScheduleExactAlarms() }) { DeviceCompatibility.openExactAlarmSettings(this) },
        Item(getString(R.string.setup_item_a11y), false, { isAccessibilityEnabled() }) { openAccessibility() },
        Item(getString(R.string.setup_item_notif), false, { notificationsAllowed() }) { openNotification() }
    )

    private fun render() {
        listContainer.removeAllViews()
        // ★ 第 42 期：进度**只数必选项**，分母取 REQUIRED_ITEM_COUNT。
        //   原来分子数的是全部 5 项、分母写死 4 ⇒ 全开时显示「已开启 5 / 4 项」。
        val requiredTotal = items.count { it.required }
        val done = items.count { it.required && it.isDone() }
        progressText.text = if (done >= requiredTotal) {
            getString(R.string.setup_wizard_progress_done)
        } else {
            getString(R.string.setup_wizard_progress_todo, requiredTotal - done)
        }
        // ★ 第 42 期：必选排前、没开的排前 —— 用户一眼看到「现在该做哪一项」。
        //   排序只影响**显示顺序**，每一项的检测方式与跳转目标一个字都没动。
        for (item in items.sortedWith(
            compareByDescending<Item> { it.required }.thenBy { it.isDone() }
        )) {
            listContainer.addView(buildRow(item))
        }
    }

    private fun buildRow(item: Item): View {
        val ok = item.isDone()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        val label = TextView(this).apply {
            text = if (item.required) item.label
            else item.label + getString(R.string.setup_item_optional_suffix)
            textSize = 15f
            setTextColor(
                ContextCompat.getColor(
                    this@SetupWizardActivity,
                    if (ok) R.color.state_ok else R.color.text_primary
                )
            )
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val action = TextView(this).apply {
            text = getString(if (ok) R.string.settings_perm_done else R.string.settings_perm_todo)
            textSize = 14f
            setTextColor(
                ContextCompat.getColor(
                    this@SetupWizardActivity,
                    if (ok) R.color.state_ok else R.color.brand_accent
                )
            )
            setPadding(dp(10), dp(6), 0, dp(6))
            setOnClickListener { item.action() }
        }
        row.addView(label)
        row.addView(action)
        return row
    }

    // ---- 状态检测（只读，不改动任何判定 / 数据） ----

    private fun isAccessibilityEnabled(): Boolean {
        return try {
            val expected = ComponentName(this, SliderGestureAccessibilityService::class.java)
            val enabled = Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            enabled.split(':').any { ComponentName.unflattenFromString(it) == expected }
        } catch (_: Throwable) {
            false
        }
    }

    private fun canDrawOverlay(): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        return try {
            Settings.canDrawOverlays(this)
        } catch (_: Throwable) {
            false
        }
    }

    private fun isIgnoringBattery(): Boolean = try {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.isIgnoringBatteryOptimizations(packageName)
    } catch (_: Throwable) {
        false
    }

    private fun canScheduleExactAlarms(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return try {
            val am = getSystemService(AlarmManager::class.java)
            am.canScheduleExactAlarms()
        } catch (_: Throwable) {
            false
        }
    }

    private fun notificationsAllowed(): Boolean = try {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        nm.areNotificationsEnabled()
    } catch (_: Throwable) {
        true
    }

    // ---- 去开启（只拉起系统设置页，不改变任何判定） ----

    private fun openAccessibility() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (_: Exception) {
            toast(getString(R.string.a11y_open_failed))
        }
    }

    private fun openOverlay() {
        try {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } catch (_: Exception) {
            toast(getString(R.string.overlay_open_failed))
        }
    }

    private fun openNotification() {
        try {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        } catch (_: Exception) {
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.parse("package:$packageName"))
                )
            } catch (_: Exception) {
                // 连应用详情都拉不起就放弃，不阻塞向导
            }
        }
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
