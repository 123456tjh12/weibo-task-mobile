package com.tjh.weibotask

import android.content.Context
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random
import org.json.JSONObject

/**
 * 互动功能的「接口自检」—— **只读**探测。
 *
 * ★★ 为什么需要它（第 44 期，手机刚连上电脑时定的方案）：
 *   要接「真发评论」，必须知道三件事：账号的登录态在 `m.weibo.cn` 上到底还有效吗、
 *   评论列表接口的真实返回结构长什么样、发评论要的那个一次性票据从哪来。
 *
 *   这三件事**不需要抓包也能问出来** —— 让 App 用**它自己存在手机里的 Cookie**
 *   去发几个 GET，把回包原样记下来就行。
 *   星签的 Cookie 存在 App 私有的加密存储里，PC 端读不出来，但 App 自己读得到。
 *
 * ★★★ 三条纪律：
 *   1. **全部是 GET，只读**。不评论、不点赞、不关注、不改任何状态。
 *      跑一百遍也不会在微博那边留下任何痕迹。
 *   2. **不消耗账号额度**：不调 [RateGuard.markRun]，不写任何计数。
 *   3. **不碰核心链路**：不读 [Prefs]、不写 [AccountStore]、不走 [WeiboClient]，
 *      自己用 [HttpURLConnection] 发请求。
 *      把它整个删掉，签到 / 发帖 / 验证的行为不会有任何变化。
 *
 * ★ 这个函数**会阻塞**（同步网络请求），调用方必须放在后台线程里跑。
 *
 * ★★ 第 44 期第一次真机自检的收获（记在这里，省得以后重复探）：
 *   - `GET m.weibo.cn/api/config` 一次就同时给出 **登录态 `data.login`**、
 *     **发评论要的一次性票据 `data.st`**、以及**自己的 uid** —— 鉴权链条齐了；
 *     实测 `st` **每次都不一样**（`6bc039` → `4608db`）⇒ 必须现取现用，不能缓存；
 *   - `GET m.weibo.cn/api/container/getIndex?type=uid&value=<uid>` 能拿到
 *     **任意用户的主页容器**，其中 `data.tabsInfo.tabs[]` 给出了各 tab 的 `containerid`。
 *
 * ★★ 第 45 期（本版）要验的最后一步：
 *   **「用户主页」怎么变成「一条具体微博」** —— 第 44 期只从 `tabsInfo` 里
 *   *推断*出「微博」tab 的 `containerid` 是 `107603<uid>`，但**没验证过**它真的回
 *   `cards[].mblog`。这一版就去验证它，并把解析出来的 **mid** 记下来。
 *   ⇒ 验证通过之后，`InteractRunner.send()` 就是一道**填空题**。
 */
object InteractProbe {

    private const val TIMEOUT_MS = 15_000

    /**
     * 黑匣子里每个回包最多记这么多字符 —— 够看清结构，又不会把日志刷爆。
     *
     * ★★ 实测教训：600 字符**不够**。用户主页容器的回包在 600 字符处正好卡在
     *   `cover_image_phone`，而真正有用的东西（这个人最近发过哪些微博）
     *   在后面的 `cards` 里 —— 白跑一趟。
     *   ⇒ 现在：**黑匣子里仍只记前 600 字符（给人看），完整回包另存一个文件**，
     *     并且**把解析结果单独打一条**（那才是真正要看的）。
     */
    private const val BODY_LIMIT = 600

    /** 落盘文件里每个回包最多留这么多字符。 */
    private const val FILE_LIMIT = 120_000

    /** 完整回包的落盘文件名（在 App 私有的 files/ 目录下）。 */
    private const val DUMP_FILE = "interact_probe.txt"

    /**
     * ★★★★ 第 54 期：`msg` 里出现这些词，就当成「报错口气」。
     *
     * ★ 用在哪：见 [postState] 的判据 ③ —— 那一条走的是「没报错 + 说了话 ⇒ 微博存在」。
     *   万一微博哪天把某个**软错误**也写成不带 `errno` 的友好话
     *   （例如「请求过于频繁」「请稍后重试」），就会被误当成「这条微博在」。
     *   这里把已知的错误口气挡掉。
     *
     * ★ 挡到会怎样：退回 `UNKNOWN` ⇒ 和 `NOT_EXISTS` 一样「不许发」。
     *   **方向是安全的**（最坏情况只是多挡住一次真发送，绝不会多发）。
     *
     * ★ 只服务于互动页的「试跑 / 发送前核对」这一个判据，
     *   不参与签到、发帖、自动验证的任何判断。
     */
    private val ERROR_WORDS = listOf(
        "错误", "异常", "失败", "非法", "无效",
        "频繁", "稍后", "重试", "登录", "权限"
    )

    /**
     * 「微博」tab 的 containerid 固定前缀。
     *
     * ★ 实测：`tabsInfo` 里 `tabKey == "weibo"` 的那一项，`containerid` 就是
     *   `107603` 拼上 uid。这里留一份**回退值** —— 万一哪天 `tabsInfo` 结构变了，
     *   还能靠这个前缀继续试，不至于整条链断掉。
     */
    private const val WEIBO_TAB_PREFIX = "107603"

    /**
     * ★★★★ 第 46 期「阶段 0」：探发送接口用的**一条不存在的微博**。
     *
     * ★ 为什么这是零风险的：
     *   发评论必须挂到**一条真实存在的微博**上。这里用一个 16 位的、几乎不可能存在的 mid，
     *   而且 **POST 之前会先用 GET 去确认它确实不存在**（见 [probeSend] 第 ② 步）——
     *   确认不存在之后，微博那边**没有任何一条帖子可以挂这条评论**，
     *   这个 POST 在物理上不可能产生任何内容。
     *
     * ★ 万一它竟然存在（理论上有可能），[probeSend] 会**当场中止、不发 POST**。
     */
    private const val PROBE_MID = "1111111111111111"

    /** 探测用的固定正文 —— 万一（理论上）被发出去，也一眼能看出是测试。 */
    private const val PROBE_TEXT = "星签接口探测（测试，请忽略）"

    /**
     * 发送接口候选路径（按可能性排序）。★ 这是**要验证的假设**，不是已知事实。
     *
     * ★ 第 46 期阶段 2：改成公开的 —— `InteractRunner` 的发送骨架要引用同一个常量，
     *   两边各写一份 URL 迟早会漂移（一份改了另一份没改，发出去打到别的接口）。
     */
    const val SEND_URL = "https://m.weibo.cn/api/comments/create"

    /**
     * ★★★★ 第 66 期：**回复（回楼层）** 接口 —— 已定死，不再是假设。
     *
     * ★ 证据链（两轮，缺一不可）：
     *   · 第 64 期真机探测：`POST /api/comments/reply` 回 `100013 参数缺失`
     *     ⇒ **路径存在**，只是参数名不对（同轮的 `/comments/reply` 回 404，已删）；
     *   · 第 65 期实测：补上 `reply` / `cid` / `withReply=1` 之后**真发出去了**，
     *     回包 `rootid` 等于父评论 id ⇒ 真·楼中楼回复；
     *   · 第 66 期又拿到 m 站前端 `miniComposer` 的逐字原文作旁证：
     *     `api/comments/reply` + `{content, mid, cid}`（`cid` 就是父评论 id）。
     *   ⇒ 请求体里 `cid` 是**必需**的，`reply` / `withReply` 是同义冗余（前端不带也通）。
     */
    const val REPLY_URL = "https://m.weibo.cn/api/comments/reply"

    /**
     * ★★★★ 第 66 期：**给评论点赞（楼赞）** 接口 —— 已定死，不再是假设。
     *
     * ★ 这条是**第 64/65 期两轮都没猜中**的那一条，第 66 期从 m 站前端源码里挖出来的。
     *   证据：微博移动版详情页那个包（`statusLite.<hash>.js`）里，评论组件的点赞函数
     *   逐字原文是：
     *     `var a = "api/likes/update", o = "api/likes/destroy",
     *          n = i.liked ? o : a;  this.$http.post(n, {id: i.id, type: "comment"})`
     *   同一个文件里**微博**点赞走的是另一条：
     *     `this.$http.post(this.liked ? "api/attitudes/destroy" : "api/attitudes/create",
     *                      {id: this.curWeiboData.id, attitude: "heart"})`
     *
     * ★★ 这解释了第 65 期的怪现象：候选 ④（`/api/attitudes/create` 带
     *   `id=<微博mid>&cid=<评论id>`）回了 `ok:1`，但重拉列表 `liked` 仍是 false ——
     *   因为那条路径**只认 `id` 这一栏、而且把它当微博 mid**，`cid` 被整个忽略，
     *   那一下赞**记到了微博头上**。
     *
     * ★★ 为什么不能只靠「回包 ok:1」下结论：第 65 期就是这么被坑的。
     *   真正的判据是**重拉评论列表看 `liked`** —— 见 [probeReplyLike] 第 ⑥ 步
     *   与 [InteractRunner] 里楼赞的自检。
     */
    const val LIKE_URL = "https://m.weibo.cn/api/likes/update"

    /** 楼赞时 `type` 栏的取值。前端原文就是 `type: "comment"`。 */
    private const val LIKE_TYPE = "comment"

    /**
     * ★★★★ 第 84 期：**转发接口**。
     *
     * ★★ 路径与参数名都**不是猜的** —— 用「回包差异法」零风险问出来的
     *   （不需要登录态、不需要真机）：`GET https://m.weibo.cn/api/config`
     *   现取一次性票据 `st`，再逐个删参数，看回包掉到哪一层。
     *   m 站的检查顺序是三层，每层回包都不一样：
     *     · `403 errno:100006 请求非法` = 最外层（缺 `st` / 格式不对）
     *     · `errno:100013 参数缺失`    = 参数检查没过 ⇒ **少了必需参数**
     *     · `ok:-100` + passport 地址  = **参数检查通过**，只差登录
     *   实测 `POST` 这条路径：
     *     · 删掉 `mid`     ⇒ `100013` ⇒ **`mid` 是必需参数**
     *     · 删掉 `st`      ⇒ `100006` ⇒ `st` 必需
     *     · 删掉 `content` ⇒ `ok:-100` ⇒ **`content` 可选**（纯转发合法）
     *     · 带上 `is_repost` / `comment_ori` ⇒ 回包不变 ⇒ 它们**不是**「缺失」检查项
     *   ★ 交叉验证：同法测 `/api/statuses/update`，**只 `st` 就过参数检查**
     *     ⇒ 说明「不同接口的必需集不同」、这个方法本身是有效的。
     *
     * ★ 为什么不用竞品那套 PC 版接口（`/ajax/statuses/normal_repost`）：
     *   m 版这条已经够用；PC 版要另建一套桌面 Cookie 会话，而互动模块被
     *   明令禁止引用核心链路里的 HTTP 封装，自己再实现一份只会多一份
     *   要维护的会话管理 —— 换不来任何东西。
     */
    const val REPOST_URL = "https://m.weibo.cn/api/statuses/repost"

    /**
     * ★★★★ 第 46 期「阶段 0.5」：**对照组** —— 一条**真实存在**的公开微博。
     *
     * ★ 为什么需要它：判断「一个接口到底通不通」，光看它报错是不够的 ——
     *   必须有一个**已知会成功**的对象做对照，否则分不清
     *   「接口不通」与「这个 mid 本身有问题」。
     *   本值 = 第 45 期真机解析出的、目标账号最新一条公开微博（`bid=Rk5Ji5bs9`）。
     *
     * ★ 它只被**只读**的 GET 用（[probePaths]），不参与任何写操作。
     * ★ 若这条微博日后被删，对照就会失效 —— [probePaths] 会**明说「对照失效」**，
     *   而不是把失效当成结论。
     */
    private const val CONTROL_MID = "5347885881235669"

    /**
     * ★★★★ 第 64 期：评论列表最多解析多少条。
     *
     * ★ 只取前几条就够 —— 我们要的是「父评论 id 长什么样」与「哪条是本账号自己的」，
     *   不是把整个评论区搬回来。
     */
    private const val SCOUT_MAX_COMMENTS = 20

    /**
     * ★★★★ 第 65 期：回复接口 —— **已定死，不再是假设**。
     *
     * ★ 第 64 期真机探测拿到 `{"ok":0,"errno":"100013","msg":"参数缺失"}`：
     *   **路径存在**（不是 404），只是参数名不对；同一轮的备选
     *   `/comments/reply` 回 `errno:404 链接无效` ⇒ 路径不存在，已从候选里删掉。
     *
     * ★ 参数名来自 m 站前端 SDK（`jasdk.js` 的 `wb.m_comment_reply`）的逐字原文：
     *     post("https://m.weibo.cn/api/comments/reply",
     *          {content:content, mid:mid, reply:cid, cid:cid, withReply:1, st:__st, _spr:...})
     *   ⇒ 第 64 期缺的正是 `reply` / `cid` / `withReply` 三个，与 `100013 参数缺失` 完全吻合。
     *
     * ★★ 仍然**不把** `/api/comments/create` 放进候选：那条路径已经验证过是
     *   「发新的顶层评论」。若它其实也接受父评论参数，我们发过去就会在帖子里
     *   多出一条**重复的顶层评论** —— 那不是用户批准的「一条测试回复」。
     */
    private val REPLY_URLS = listOf(
        "https://m.weibo.cn/api/comments/reply"
    )

    /**
     * ★★★★ 第 66 期：点赞接口 —— **已定死，候选表撤了**。
     *
     * ★ 第 64 期排除的两条（留着当记录，别再往回捡）：
     *   · `/api/attitudes/create` 带 `id=<评论 id>` 回 `errno:20101 该微博不存在`
     *     ⇒ 这条路径要的是**微博 mid**，它是**给微博点赞**；
     *   · `/attitudes/create` 回 `errno:404 链接无效` ⇒ 路径不存在。
     * ★ 第 65 期又试了 `/api/comments/attitudes/create`(404) 与 `/api/comments/like`(404)。
     * ⇒ 第 66 期从 m 站前端源码拿到真名（见 [LIKE_URL] 的注释），候选表**收敛成一条**。
     */
    private val LIKE_URLS = listOf(LIKE_URL)

    /**
     * ★★★★ 第 65 期：前端 JS 包的读取上限。
     *
     * ★ 为什么单独放大：m 站的前端包常有**好几 MB**，而 [FILE_LIMIT] 只有 12 万字符 ——
     *   用默认上限去抓，只会读到包开头，「评论点赞」这类**冷门接口名**根本读不到。
     * ★ 它只被**只读**的 GET 用（见 [scoutReplyLike] 第 ⑤ 步），不参与任何写操作。
     */
    private const val JS_LIMIT = 3_000_000

    /** 最多抓几个前端 JS 包（每个都可能几 MB，够用就好）。 */
    private const val JS_MAX_BUNDLES = 2

    /** 每个 JS 包里最多列几条命中（免得摘要被刷屏）。 */
    private const val JS_HIT_MAX = 14

    /**
     * ★★★★ 第 66 期：详情页 chunk 的哈希表里，同一个名字可能出现两次
     *   （两个环境各一份哈希）—— 最多试这么多个。
     */
    private const val JS_CHUNK_TRIES = 3

    /** 详情页 chunk 至少要有这么多字符才算「真拿到了」（拿不到就是 404 的小页面）。 */
    private const val JS_CHUNK_MIN = 1000

    /**
     * 从 HTML 里抠出 script 标签的 src 地址。
     *
     * ★★ 为什么写成**普通字符串**而不是三引号原始串：`_string_blob_diff.py`（闸门 6）
     *   会把每个三引号块当成「注入的 JS」摊出来比对 —— 第 44 期就因为这个误报过一次。
     *   这里只是个**只读解析用的正则**，不注入、不参与任何判定，不该触发那个警报。
     *
     * ★★★ 另外一条硬规矩（第 65 期踩过）：**本文件里不能出现连续三个引号，
     *   注释里也不行** —— 闸门 6 的扫描器不认注释，会把注释里那三个引号当成
     *   一个原始串的开头，一路吞到文件末尾，报出上千行假差异。
     */
    private const val SCRIPT_SRC_RE = "(?i)<script[^>]*\\bsrc\\s*=\\s*[\"']([^\"']+)[\"']"

    /**
     * 在前端 JS 包里搜「点赞 / 评论」相关的接口名。同上，用普通字符串避免闸门 6 误报。
     *
     * ★ 第 66 期补上 `likes` —— 第 65 期只搜 `attitudes|comments`，
     *   而「评论点赞」的真名恰恰是 `api/likes/update`，**正好被漏掉**。
     */
    private const val API_NAME_RE = "[\\w./\\-]*(?:attitudes|comments|likes)[\\w./\\-]*"

    private val stampFormat = SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA)

    /**
     * 用真机浏览器的 UA。
     *
     * ★ 为什么不发一个自定义 UA：微博对非常规 UA 会直接给验证页，
     *   那样自检结果就变成「被风控拦了」，分不清是 Cookie 的问题还是 UA 的问题。
     */
    private const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 5) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36"

    /** 一次探测的回包。 */
    private class ProbeResponse(val head: String, val full: String)

    /** 从微博列表里解析出来的第一条微博。 */
    /**
     * ★★★ 第 84 期：从 `private class` 改成**公开** —— 超Like 编排（[SuperLikeRunner]）
     *   在**另一个文件**里，它要读 `commentsCount` 来筛「0 评论」的帖子。
     *   ★ 只改可见性，字段与解析逻辑一字未动。
     */
    class LatestPost(
        val mid: String,
        val bid: String,
        val excerpt: String,
        /**
         * ★★★ 第 84 期：回包里的 `comments_count`（这条帖子有几条评论）。
         *
         * ★ 默认 **-1 = 回包没给这个字段**。这个区分是**故意的**：
         *   「0 评论」和「不知道几条评论」必须分开 —— 超Like 的「首评」只在
         *   **确实 0 评论**的帖子上做，把 -1 当成 0 会去抢一个已经有人评论过的帖子，
         *   那条评论就白发了（还占掉每天 4 次里的一次）。
         *   ⇒ 调用方判候选**只认 `== 0`**，不认 `<= 0`。
         */
        val commentsCount: Int = -1
    )

    /**
     * 跑一遍自检，逐条写进 [InteractTrace]，并返回给界面看的摘要。
     *
     * @param account 用哪个账号的登录态；null 表示没有可用账号
     * @param target  用户在任务里填的目标（用来判断该探哪几个接口）
     */
    fun run(context: Context, account: WeiboAccount?, target: String): String {
        val summary = mutableListOf<String>()

        if (account == null) {
            return note(summary, context.getString(R.string.interact_probe_no_account))
        }
        val cookie = account.cookie
        if (cookie.isBlank()) {
            return note(summary, context.getString(R.string.interact_probe_no_cookie))
        }

        // 每次自检重新开始写落盘文件：只留最近这一次，
        // 否则「上一次的回包」和「这一次的」混在一起，排查时又要靠时间戳猜。
        resetDump(context)

        val kind = InteractTarget.kind(target)
        InteractTrace.log(
            "[自检] 账号=" + account.label + " 目标类型=" + context.getString(kind.labelRes) +
                " 目标=" + target
        )
        // ★ 只记 Cookie 的**名字**，绝不记值 —— 这个日志用户会看到，也会贴给别人。
        InteractTrace.log("[自检] Cookie 字段名：" + cookieNames(cookie))
        // ★★★★ 第 52 期改：这里原来会说「账号 Cookie 里那份 XSRF-TOKEN 已放进请求头」。
        //    现在**不再用账号 Cookie 里那份**了（它属于上一次登录，会遮住服务器新下发的值），
        //    所以这里只如实报告「账号里有没有这个字段」，并点明真正的令牌是现取的 st。
        InteractTrace.log(
            "[自检] 账号 Cookie 里的 XSRF-TOKEN：" +
                (if (cookieValue(cookie, "XSRF-TOKEN").isNotBlank())
                    "有（★ 但不使用它：发 POST 用现取的 st）"
                 else "没有（不影响：发 POST 用现取的 st）")
        )

        // ① 登录态：这是最该先问的一件事。
        //    `/api/config` 是 m.weibo.cn 自己用来判断「当前是不是登录用户」的接口，
        //    体积最小、副作用为零，`data.login` 直接给答案，
        //    而且 `data.st` 就是发评论要的那个一次性票据。
        probe(
            context, "登录态 /api/config",
            "https://m.weibo.cn/api/config",
            cookie
        )

        when (kind) {
            TargetKind.POST -> {
                val id = InteractTarget.postId(target)
                if (id.isBlank()) {
                    InteractTrace.log("[自检] 没能从目标里取出微博 id，跳过后续探测")
                } else {
                    // ② 微博详情：确认这个 id 有效，顺带拿到评论数、作者 uid。
                    probe(
                        context, "微博详情 /statuses/show",
                        "https://m.weibo.cn/statuses/show?id=" + id,
                        cookie
                    )
                    // ③ 评论列表：这是「按时间找最早那层楼」和「发完回查」的数据源。
                    probe(
                        context, "评论列表 /comments/hotflow",
                        "https://m.weibo.cn/comments/hotflow?id=" + id + "&mid=" + id + "&max_id_type=0",
                        cookie
                    )
                }
            }

            TargetKind.PROFILE -> {
                val uid = InteractTarget.uid(target)
                if (uid.isBlank()) {
                    InteractTrace.log("[自检] 没能从目标里取出 uid，跳过后续探测")
                } else {
                    probeProfile(context, uid, cookie, summary)
                }
            }

            // ★★★★ 第 68 期：超话 —— 只拉一次超话容器，把原始回包落盘。
            //   ★ 这是**唯一**能在真机上看到超话回包结构的入口（PC 侧被访客墙挡住）。
            TargetKind.SUPERTOPIC -> {
                val cid = InteractTarget.topicId(target)
                if (cid.isBlank()) {
                    InteractTrace.log("[自检] 没能从目标里取出超话 id，跳过后续探测")
                } else {
                    probeTopic(context, cid, cookie, ownUid(account), summary)
                }
            }

            TargetKind.NONE, TargetKind.UNKNOWN ->
                InteractTrace.log("[自检] 目标看不懂，只做了登录态探测")
        }

        // ★ 第 59 期：这里印**给人看的名字**（displayName），不是内部序号 label。
        //   本函数里的探测与记账仍然全走 account.label（键），只有这一行是显示。
        summary.add(0, context.getString(R.string.interact_probe_summary, account.displayName))
        summary.add(context.getString(R.string.interact_probe_hint))
        return summary.joinToString("\n")
    }

    /**
     * ★★★★ 第 46 期「阶段 0」：**零风险**探测发送（POST）接口。
     *
     * 目的只有一个：把「发评论到底打哪个接口、要哪些参数」**问出来**，
     * 而不是拿用户的账号去猜着试。
     *
     * 三步，其中**只有最后一步是 POST**：
     *   ① `GET /api/config` 取一次性票据 `st`（值不记日志）；
     *   ② ★ **安全前提**：`GET /statuses/show?id=<PROBE_MID>` 先确认这条微博**不存在**；
     *   ③ 确认不存在之后，才对这个不存在的 mid 发**一个** POST。
     *
     * ★★★ 为什么这不可能发出任何东西：
     *   评论必须挂到一条真实存在的微博上。第 ② 步已经证明这条微博不存在
     *   ⇒ 微博那边**没有帖子可以挂这条评论**。
     *   万一第 ② 步发现它竟然存在，就**当场中止、不发 POST**（安全闸）。
     *
     * ★ 从回包能读出四件事：接口路径对不对、`st` 参数认不认、
     *   `id`/`mid`/`content` 认不认、以及**有没有别的必填参数**（接口会点名）。
     */
    fun probeSend(context: Context, account: WeiboAccount?, target: String): String {
        val summary = mutableListOf<String>()

        if (account == null) {
            return note(summary, context.getString(R.string.interact_probe_no_account))
        }
        val cookie = account.cookie
        if (cookie.isBlank()) {
            return note(summary, context.getString(R.string.interact_probe_no_cookie))
        }

        resetDump(context)
        InteractTrace.log("[探发送] 账号=" + account.label + " 目标=" + target)
        InteractTrace.log("[探发送] 零风险设计：先 GET 确认 mid=" + PROBE_MID + " 不存在，再对它发 POST")

        // ① 取一次性票据
        val config = httpGet("https://m.weibo.cn/api/config", cookie)
        val st = parseSt(config.full)
        if (st.isNullOrBlank()) {
            InteractTrace.log(
                "[探发送] 拿不到 st 票据，中止（回包：" + oneLine(config.full.take(BODY_LIMIT)) + "）"
            )
            return note(summary, context.getString(R.string.interact_probe_send_need_st))
        }
        InteractTrace.log("[探发送] 拿到 st（长度 " + st.length + "，值不记）")

        // ② ★ 安全前提：先证明这条微博不存在。
        //    ★★ 必须是**正面证据**（`errno=20101` 或明说「不存在」）；
        //       拿到别的 —— 包括风控报错 —— 一律**不放行**。
        //       第 46 期阶段 0 的教训：原来把 `ok:0` 当成「不存在」，
        //       而风控回包 `{"ok":0,"errno":"100006","msg":"请求非法"}` 恰好也是 `ok:0` ⇒ 闸门形同虚设。
        val check = probe(
            context, "存在性检查 /statuses/show",
            "https://m.weibo.cn/statuses/show?id=" + PROBE_MID,
            cookie
        )
        when (targetState(check.full)) {
            TargetState.NOT_EXISTS -> InteractTrace.log(
                "[探发送] 已确认这条微博不存在 ⇒ 没有帖子可以挂评论，POST 不可能发出任何东西"
            )
            TargetState.EXISTS -> {
                InteractTrace.log("[探发送] ！！这条微博竟然存在 ⇒ 中止，不发 POST（安全闸生效）")
                return note(summary, context.getString(R.string.interact_probe_send_blocked))
            }
            TargetState.UNKNOWN -> {
                InteractTrace.log(
                    "[探发送] 存在性**无法确认**（回包不是「不存在」的正面证据）⇒ 中止，不发 POST"
                )
                return note(summary, context.getString(R.string.interact_probe_send_unknown))
            }
        }

        // ③ 探 POST。★★ 第 52 期起改用**真发送同一个构造点**（[commentForm]）
        //    ⇒ 「自检跑通了」就真的等价于「真发送的请求体没问题」。
        //    ★ 原来多带的那个 id 参数去掉了：第 51 期抓到的那条**成功请求**里没有它
        //      （只有 content / mid / st / _spr），多带一个反而可能被判非法。
        //    ★ 如果接口还要求别的参数，它会**点名**说出来，那正是我们想知道的。
        val body = commentForm(context, PROBE_MID, PROBE_TEXT, st)
        val response = probePost(context, "发送接口 POST " + SEND_URL, SEND_URL, cookie, body)
        val verdict = parseSendVerdict(response.full)
        InteractTrace.log("[探发送] 判读：" + verdict)
        summary.add(context.getString(R.string.interact_probe_send_title))
        summary.add(verdict)
        summary.add(context.getString(R.string.interact_probe_hint))
        return summary.joinToString("\n")
    }

    /**
     * ★★★★ 第 84 期：**零风险**探测转发（POST）接口。
     *
     * 与 [probeSend] **同一套设计**，只有 URL 与请求体构造点不同：
     *   ① `GET /api/config` 取一次性票据 `st`（值不记日志）；
     *   ② ★ **安全前提**：`GET /statuses/show?id=<PROBE_MID>` 先确认这条微博**不存在**；
     *   ③ 确认不存在之后，才对这个不存在的 mid 发**一个** POST。
     *
     * ★★★ 为什么这不可能转发出去任何东西：
     *   转发必须作用到一条真实存在的微博上。第 ② 步已经证明这条微博不存在
     *   ⇒ 微博那边**没有帖子可以转发**。
     *   万一第 ② 步发现它竟然存在，就**当场中止、不发 POST**（安全闸）。
     *
     * ★ 真机跑一次能确证两件事：接口路径对不对、参数名认不认。
     *   「该微博不存在」= 参数已被接受；「参数缺失」= 还缺东西（回包会点名）。
     */
    fun probeRepost(context: Context, account: WeiboAccount?, target: String): String {
        val summary = mutableListOf<String>()

        if (account == null) {
            return note(summary, context.getString(R.string.interact_probe_no_account))
        }
        val cookie = account.cookie
        if (cookie.isBlank()) {
            return note(summary, context.getString(R.string.interact_probe_no_cookie))
        }

        resetDump(context)
        InteractTrace.log("[探转发] 账号=" + account.label + " 目标=" + target)
        InteractTrace.log(
            "[探转发] 零风险设计：先 GET 确认 mid=" + PROBE_MID + " 不存在，再对它发 POST"
        )

        // ① 取一次性票据
        val config = httpGet("https://m.weibo.cn/api/config", cookie)
        val st = parseSt(config.full)
        if (st.isNullOrBlank()) {
            InteractTrace.log(
                "[探转发] 拿不到 st 票据，中止（回包：" + oneLine(config.full.take(BODY_LIMIT)) + "）"
            )
            return note(summary, context.getString(R.string.interact_probe_send_need_st))
        }
        InteractTrace.log("[探转发] 拿到 st（长度 " + st.length + "，值不记）")

        // ② ★ 安全前提：先证明这条微博不存在（必须是正面证据，规则见 targetState）
        val check = probe(
            context, "存在性检查 /statuses/show",
            "https://m.weibo.cn/statuses/show?id=" + PROBE_MID,
            cookie
        )
        when (targetState(check.full)) {
            TargetState.NOT_EXISTS -> InteractTrace.log(
                "[探转发] 已确认这条微博不存在 ⇒ 没有帖子可以转发，POST 不可能发出任何东西"
            )
            TargetState.EXISTS -> {
                InteractTrace.log("[探转发] ！！这条微博竟然存在 ⇒ 中止，不发 POST（安全闸生效）")
                return note(summary, context.getString(R.string.interact_probe_repost_blocked))
            }
            TargetState.UNKNOWN -> {
                InteractTrace.log(
                    "[探转发] 存在性无法确认（回包不是「不存在」的正面证据）⇒ 中止，不发 POST"
                )
                return note(summary, context.getString(R.string.interact_probe_repost_unknown))
            }
        }

        // ③ 探 POST —— 与真转发共用同一个构造点 repostForm
        val body = repostForm(context, PROBE_MID, PROBE_TEXT, st)
        val response = probePost(context, "转发接口 POST " + REPOST_URL, REPOST_URL, cookie, body)
        val verdict = parseSendVerdict(response.full)
        InteractTrace.log("[探转发] 判读：" + verdict)
        summary.add(context.getString(R.string.interact_probe_repost_title))
        summary.add(verdict)
        summary.add(context.getString(R.string.interact_probe_hint))
        return summary.joinToString("\n")
    }

    // ---------------------------------------------------------------- 真发送

    /**
     * ★★★★ 第 52 期新增：**发评论请求体的唯一构造点**。
     *
     * ★ 为什么必须只有一个构造点：
     *   真发送（[postComment]）与零风险自检（[probeSend]）用的是**同一个**函数
     *   ⇒ 「自检跑通了」就真的等价于「真发送的请求体没问题」，
     *     而不是「两处各写一份、看着像但其实不一样」。
     *
     * ★ 四个参数全部来自第 51 期抓到的那条**成功请求**（回包 ok:1）：
     *   content / mid / st / _spr。
     *   `st` 是 `/api/config` 现取的一次性票据 —— 实测每次都不一样，**不能缓存**。
     *
     * ★★ `_spr` 是微博 Web 端带的**屏幕参数**（形如 screen:宽x高）。
     *   抓包里看到的是 361x801，而真机 1080x2400 @3.0 换算成 dp 正好是 360x800
     *   ⇒ 这里按「dp 宽 x dp 高」算。
     *   ★ 这是整个请求里**唯一一个还没被正面验证过**的值 ——
     *     若真机抓包发现它不一样，改这一行即可（别处都不用动）。
     */
    private fun commentForm(
        context: Context,
        mid: String,
        content: String,
        st: String
    ): Map<String, String> = linkedMapOf(
        "content" to content,
        "mid" to mid,
        "st" to st,
        "_spr" to sprOf(context)
    )

    /**
     * ★★★★ 第 84 期：**转发请求体的唯一构造点**。
     *
     * ★ 与 [commentForm] 的四个字段**逐字相同**（`content` / `mid` / `st` / `_spr`），
     *   依据见 [REPOST_URL] 的注释（`mid` 必需、`st` 必需、`content` 可选）。
     * ★★ 那为什么还**另开一个函数**而不是直接复用 `commentForm`：
     *   两者的参数集**将来会分叉** —— 转发若要加 `is_repost` 之类的开关，
     *   改这里不会波及评论；反过来也一样。共用一份，迟早要为
     *   「只给转发加一个字段」而打架。
     * ★ 与 [postRepost] / [probeRepost] 的关系同样是「自检与真发共用同一个构造点」
     *   ⇒ 「自检跑通了」就真的等价于「真发的请求体没问题」。
     */
    private fun repostForm(
        context: Context,
        mid: String,
        content: String,
        st: String
    ): Map<String, String> = linkedMapOf(
        "content" to content,
        "mid" to mid,
        "st" to st,
        "_spr" to sprOf(context)
    )

    /**
     * ★★★★ 第 66 期：`_spr`（屏幕参数）的**唯一算法** —— 形如 `screen:360x800`。
     *
     * ★ 为什么抽出来：第 66 期起有**三个**请求体要带它（评论 / 回复 / 楼赞）。
     *   三处各算一份，迟早一处改了另两处没改；而它是整个请求里
     *   **唯一一个还没被正面验证过**的值（见 [commentForm] 的注释）
     *   ⇒ 必须只有一处能改。
     */
    private fun sprOf(context: Context): String {
        val dm = context.resources.displayMetrics
        val density = if (dm.density > 0f) dm.density else 1f
        return "screen:" + (dm.widthPixels / density).toInt() + "x" + (dm.heightPixels / density).toInt()
    }

    /**
     * ★★★★ 第 66 期：**回复（回楼层）请求体的唯一构造点**。
     *
     * ★ 与 [commentForm] 一样：自检与真发送共用同一个函数
     *   ⇒ 「自检跑通了」就真的等价于「真发的请求体没问题」。
     * ★ 参数名有**两条独立来源**，互相印证：
     *   ① 第 65 期真机实测**成功**的那一条：`content / mid / reply / cid / withReply / st / _spr`
     *      （回包 `rootid` = 父评论 id ⇒ 真·楼中楼）；
     *   ② 第 66 期读到的 m 站前端原文（`miniComposer`）：
     *      `api/comments/reply` + `{content, mid, cid}` —— 前端**只带 `cid`**。
     *   ⇒ `cid` 是必需项，`reply` / `withReply` 是同义冗余。
     *     这里保持与①**逐字一致**（多带两个不影响，且已被实测证明能通）。
     */
    private fun replyForm(
        context: Context,
        mid: String,
        cid: String,
        content: String,
        st: String
    ): Map<String, String> {
        val form = LinkedHashMap<String, String>(commentForm(context, mid, content, st))
        form["reply"] = cid
        form["cid"] = cid
        form["withReply"] = "1"
        return form
    }

    /**
     * ★★★★ 第 66 期：**楼赞（给评论点赞）请求体的唯一构造点**。
     *
     * ★ 参数名来自 m 站前端 `statusLite` chunk 的**逐字原文**：
     *     `this.$http.post("api/likes/update", {id: i.id, type: "comment"})`
     * ★★ `id` 是**评论** id，**不是**微博 mid —— 微博点赞走的是
     *   `/api/attitudes/create` + `{id: <微博mid>, attitude: "heart"}`（另一条路径）。
     *   第 65 期就是在这里搞混的（把微博 mid 填进 `id`，赞记到了微博上）。
     */
    private fun likeForm(context: Context, cid: String, st: String): Map<String, String> =
        linkedMapOf(
            "id" to cid,
            "type" to LIKE_TYPE,
            "st" to st,
            "_spr" to sprOf(context)
        )

    /**
     * ★★★★ 第 87 期：本地哨兵 —— `GET /api/config` 没给出 `st`，**一个字节都没发出去**。
     *
     * ★ 为什么用字符串而不是数字：微博的真实 `errno` 全是数字，
     *   用 `no_st` 这种形状**不可能撞车**，同时一眼能看出是本地产生的。
     */
    const val ERRNO_NO_ST = "no_st"

    /**
     * 真发送的结果。`ok` 只由**回包**决定，与界面提示无关。
     *
     * ★★★★ 第 87 期新增 [errno]：微博回包里的错误码，**原样**带出来（判读失败时为 `""`）。
     *
     * ★ 为什么必须有它：调用方要分清两种失败 ——
     *   · 「**这条内容**不行」（例如 `20130` 这条微博不让评）⇒ 换下一条是对的；
     *   · 「**整个账号**被限制了」（例如 `20016` 操作频繁）⇒ 换哪条都一样，**必须停手**。
     *   而 [detail] 是**给人看的、已经拼好的文案**，拿它做判断就是「认文案」
     *   （第 20 条纪律明令禁止）—— 文案会改、会翻译、会加装饰，判据一认它就随时可能失效。
     *   [errno] 是**结构**：数字原样透传，判据只认它。
     *
     * @param errno 微博回包里的 `errno`；`""` = 回包没给（网络失败 / 非 JSON / 解析失败）
     *              ⇒ 判不出类型，调用方一律按「目标级」处理（继续换下一条）。
     *              [ERRNO_NO_ST] = 连一次性票据都没取到，请求根本没发出去。
     */
    class SendOutcome(val ok: Boolean, val detail: String, val errno: String = "")

    /**
     * ★★★★ 第 52 期新增：**真发一条评论**。
     *
     * 流程与 [probeSend] 一模一样，只有目标 mid 不同：
     *   ① `GET /api/config` 取**现**的一次性票据 `st`；
     *   ② `POST /api/comments/create`，请求体用 [commentForm] 构造；
     *   ③ 判读只看回包里的 **ok 字段**，**不看界面提示**（第 51 期的教训：
     *      「发送成功」的提示和「真的建了评论」是两件事）。
     *
     * ★★ 安全边界（**调用方负责**）：
     *   本函数**不做**「目标是否存在」的判断 —— 那是 [InteractRunner.send] 的职责，
     *   而且必须做（第 46 期的教训：宁可不发，也不发到不确定的地方）。
     *
     * ★ 会阻塞，必须在后台线程调用。
     */
    fun postComment(
        context: Context,
        account: WeiboAccount,
        mid: String,
        content: String
    ): SendOutcome {
        val cookie = account.cookie
        if (cookie.isBlank()) {
            return SendOutcome(false, context.getString(R.string.interact_rehearse_no_cookie))
        }

        // ① 现取一次性票据。★ 每次都要现取 —— 实测 st 每次都不一样。
        val config = httpGet("https://m.weibo.cn/api/config", cookie)
        val st = parseSt(config.full)
        if (st.isNullOrBlank()) {
            InteractTrace.log(
                "[发送] 拿不到 st 票据，中止（回包：" + oneLine(config.full.take(BODY_LIMIT)) + "）"
            )
            // ★ 第 87 期：连票据都没取到 ⇒ 请求根本没发出去，调用方应据此停手。
            return SendOutcome(
                false, context.getString(R.string.interact_send_need_st), errno = ERRNO_NO_ST
            )
        }

        // ② 真发。★ 请求头里的 X-XSRF-TOKEN 与请求体里的 st 是**同一个**值（见 httpPost）。
        val form = commentForm(context, mid, content, st)
        val response = httpPost(SEND_URL, cookie, form)
        InteractTrace.log("[发送] POST " + SEND_URL + " → " + response.head)
        dump(context, "发送接口 POST " + SEND_URL, SEND_URL, response, form)

        // ③ 只认回包 —— 不看界面说什么。
        return judgeCreate(context, response.full)
    }

    /**
     * 判读 `/api/comments/create` 的回包。
     *
     * ★★★ 只看 JSON 里的 ok 字段。第 51 期的教训：
     *   WebView 那边弹出的「发送成功」可以是假的（JS 没等到回包也会弹），
     *   唯一可信的证据是**回包 ok:1 且带新评论 id**。
     */
    private fun judgeCreate(context: Context, body: String): SendOutcome = try {
        val json = JSONObject(body)
        if (json.optInt("ok") == 1) {
            val id = json.optJSONObject("data")?.optString("id").orEmpty()
            SendOutcome(true, context.getString(R.string.interact_send_ok, id.ifBlank { "—" }))
        } else {
            val errno = json.optString("errno")
            val msg = json.optString("msg")
            val why = listOf(errno, msg).filter { it.isNotBlank() }.joinToString(" / ")
            SendOutcome(
                false,
                context.getString(
                    R.string.interact_send_failed,
                    why.ifBlank { oneLine(body.take(BODY_LIMIT)) }
                ),
                // ★ 第 87 期：把错误码**原样**带出去，供调用方判「账号级还是目标级」。
                errno = errno
            )
        }
    } catch (_: Throwable) {
        SendOutcome(
            false,
            context.getString(R.string.interact_send_failed, oneLine(body.take(BODY_LIMIT)))
        )
    }

    // ---------------------------------------------------------------- 第 84 期：转发 真发送

    /**
     * ★★★★ 第 84 期：**真转发一条微博**。
     *
     * 流程与 [postComment] 一模一样，只有接口与构造点不同：
     *   ① `GET /api/config` 取**现**的一次性票据 `st`（★ 不能缓存，实测每次都变）；
     *   ② `POST /api/statuses/repost`，请求体用 [repostForm] 构造；
     *   ③ 判读只看回包里的 **ok 字段**，**不看界面提示**。
     *
     * ★★ 安全边界（**调用方负责**）：本函数**不做**「目标微博是否存在」的判断 ——
     *   那是 [InteractRunner.send] 的职责，而且必须做（第 46 期被 `ok:0` 骗开过闸门）。
     * ★ 会阻塞，必须在后台线程调用。
     */
    fun postRepost(
        context: Context,
        account: WeiboAccount,
        mid: String,
        content: String
    ): SendOutcome {
        val cookie = account.cookie
        if (cookie.isBlank()) {
            return SendOutcome(false, context.getString(R.string.interact_rehearse_no_cookie))
        }

        val config = httpGet("https://m.weibo.cn/api/config", cookie)
        val st = parseSt(config.full)
        if (st.isNullOrBlank()) {
            InteractTrace.log(
                "[转发] 拿不到 st 票据，中止（回包：" + oneLine(config.full.take(BODY_LIMIT)) + "）"
            )
            // ★ 第 87 期：连票据都没取到 ⇒ 请求根本没发出去，调用方应据此停手。
            return SendOutcome(
                false, context.getString(R.string.interact_send_need_st), errno = ERRNO_NO_ST
            )
        }

        val form = repostForm(context, mid, content, st)
        val response = httpPost(REPOST_URL, cookie, form)
        InteractTrace.log("[转发] POST " + REPOST_URL + " → " + response.head)
        dump(context, "转发接口 POST " + REPOST_URL, REPOST_URL, response, form)

        return judgeRepost(context, response.full)
    }

    /**
     * 判读 `/api/statuses/repost` 的回包。
     *
     * ★★★ 只看 JSON 里的 ok 字段 —— 与 [judgeCreate] 同一条原则：
     *   唯一可信的证据是**回包 ok:1 且带新微博 id**，界面提示不算数。
     * ★ 转发与评论的回包形状**都**是 `{ok:1, data:{id:...}}`，但这里**故意不合并**：
     *   转发将来要接竞品那套「核对」机制（读个人时间线确认这条转发真的在），
     *   到那时判据会从「看回包」变成「看回包 + 看时间线」，与评论分道扬镳。
     */
    private fun judgeRepost(context: Context, body: String): SendOutcome = try {
        val json = JSONObject(body)
        if (json.optInt("ok") == 1) {
            val id = json.optJSONObject("data")?.optString("id").orEmpty()
            SendOutcome(
                true,
                context.getString(R.string.interact_send_repost_ok, id.ifBlank { "—" })
            )
        } else {
            val errno = json.optString("errno")
            val msg = json.optString("msg")
            val why = listOf(errno, msg).filter { it.isNotBlank() }.joinToString(" / ")
            SendOutcome(
                false,
                context.getString(
                    R.string.interact_send_failed,
                    why.ifBlank { oneLine(body.take(BODY_LIMIT)) }
                ),
                // ★ 第 87 期：同上 —— 错误码原样透传。
                errno = errno
            )
        }
    } catch (_: Throwable) {
        SendOutcome(
            false,
            context.getString(R.string.interact_send_failed, oneLine(body.take(BODY_LIMIT)))
        )
    }

    // ---------------------------------------------------------------- 第 66 期：互评 / 楼赞 真发送

    /**
     * ★★★★ 第 66 期：**真发一条「回复楼层」（互评）**。
     *
     * 流程与 [postComment] 一模一样，只有接口与请求体不同：
     *   ① `GET /api/config` 取**现**的一次性票据 `st`（★ 不能缓存，实测每次都变）；
     *   ② `POST /api/comments/reply`，请求体用 [replyForm] 构造（`cid` = 父评论 id）；
     *   ③ 判读**只认结构**：`ok:1` **且** `data.rootid == cid`（见 [judgeReply]）。
     *
     * ★★ 安全边界（**调用方负责**）：本函数**不做**「目标微博是否存在 / 父评论是否还在」
     *   的判断 —— 那是 [InteractRunner] 的职责，而且必须做。
     * ★ 会阻塞，必须在后台线程调用。
     */
    fun postReply(
        context: Context,
        account: WeiboAccount,
        mid: String,
        cid: String,
        content: String
    ): SendOutcome {
        val cookie = account.cookie
        if (cookie.isBlank()) {
            return SendOutcome(false, context.getString(R.string.interact_rehearse_no_cookie))
        }
        val config = httpGet("https://m.weibo.cn/api/config", cookie)
        val st = parseSt(config.full)
        if (st.isNullOrBlank()) {
            InteractTrace.log(
                "[发送] 拿不到 st 票据，中止（回包：" + oneLine(config.full.take(BODY_LIMIT)) + "）"
            )
            return SendOutcome(false, context.getString(R.string.interact_send_need_st))
        }
        val form = replyForm(context, mid, cid, content, st)
        val response = httpPost(REPLY_URL, cookie, form)
        InteractTrace.log("[发送] POST " + REPLY_URL + " → " + response.head)
        dump(context, "发送接口 POST " + REPLY_URL, REPLY_URL, response, form)
        return judgeReply(context, response.full, cid)
    }

    /**
     * 判读 `/api/comments/reply` 的回包。
     *
     * ★★★ 只看 JSON 里的**结构**：`ok:1` **且** `data.rootid == 父评论 id`。
     *   · 第 51 期的教训：界面上的「发送成功」可以是假的（JS 没等到回包也会弹）；
     *   · 第 65 期实测：真回复成功时 `rootid` 恰好等于父评论 id；
     *   · ★ 反过来，若 `rootid` 等于**新评论自己的 id**，说明接口把这条当成了
     *     **新的顶层评论** —— 那是一条公开可见的错内容（用户以为在回复某个人）
     *     ⇒ 必须按**失败**处理，绝不能算成功。
     */
    private fun judgeReply(context: Context, body: String, cid: String): SendOutcome = try {
        val json = JSONObject(body)
        val data = json.optJSONObject("data")
        val newId = data?.optString("id").orEmpty()
        val rootId = data?.optString("rootid").orEmpty()
        when {
            json.optInt("ok") == 1 && rootId == cid -> SendOutcome(
                true,
                context.getString(
                    R.string.interact_send_reply_ok,
                    newId.ifBlank { "—" },
                    cid
                )
            )
            json.optInt("ok") == 1 -> SendOutcome(
                false,
                context.getString(
                    R.string.interact_send_reply_wrong,
                    newId.ifBlank { "—" },
                    rootId.ifBlank { "—" }
                )
            )
            else -> {
                val errno = json.optString("errno")
                val msg = json.optString("msg")
                val why = listOf(errno, msg).filter { it.isNotBlank() }.joinToString(" / ")
                SendOutcome(
                    false,
                    context.getString(
                        R.string.interact_send_failed,
                        why.ifBlank { oneLine(body.take(BODY_LIMIT)) }
                    )
                )
            }
        }
    } catch (_: Throwable) {
        SendOutcome(
            false,
            context.getString(R.string.interact_send_failed, oneLine(body.take(BODY_LIMIT)))
        )
    }

    /**
     * ★★★★ 第 66 期：**真给一条评论点赞（楼赞）**。
     *
     * ★★★ 判据**不是**回包的 `ok` —— 第 65 期就是被这个坑掉的：
     *   候选④ 回了 `ok:1`，重拉列表 `liked` 仍是 `false`（那一下赞其实记到了**微博**上）。
     *   ⇒ 这里**发完立刻重拉评论列表**，只有看到 `liked = true` 才算成功。
     *   ★ 重拉一次只是只读 GET，成本很低；「没验到」一律按失败处理 ——
     *     宁可不认，也不假报成功（第 51 / 62 期的同一条规矩）。
     *
     * ★ 会阻塞（1 次 config + 1 次 POST + 1 次 GET），必须在后台线程调用。
     */
    fun postLikeComment(
        context: Context,
        account: WeiboAccount,
        mid: String,
        cid: String
    ): SendOutcome {
        val cookie = account.cookie
        if (cookie.isBlank()) {
            return SendOutcome(false, context.getString(R.string.interact_rehearse_no_cookie))
        }
        val config = httpGet("https://m.weibo.cn/api/config", cookie)
        val st = parseSt(config.full)
        if (st.isNullOrBlank()) {
            InteractTrace.log(
                "[发送] 拿不到 st 票据，中止（回包：" + oneLine(config.full.take(BODY_LIMIT)) + "）"
            )
            return SendOutcome(false, context.getString(R.string.interact_send_need_st))
        }
        val form = likeForm(context, cid, st)
        val response = httpPost(LIKE_URL, cookie, form)
        InteractTrace.log("[发送] POST " + LIKE_URL + " → " + response.head)
        dump(context, "发送接口 POST " + LIKE_URL, LIKE_URL, response, form)

        // 回包判读只用来「记账」和排错，**不作为成败判据**。
        val verdict = judgeAction(response.full, cid)
        InteractTrace.log("[发送] 楼赞回包判读（不作为判据）：" + verdict)

        // ★★★ 真正的判据：重拉列表看 liked。
        val after = listComments(context, account, mid)
        val now = after.firstOrNull { it.id == cid }
        InteractTrace.log(
            "[发送] 楼赞自检：重拉列表 " + after.size + " 条，目标楼层 " +
                (if (now == null) "不在列表里" else "liked=" + now.liked + " like_count=" + now.likeCount)
        )
        return when {
            now == null -> SendOutcome(
                false,
                context.getString(R.string.interact_send_like_gone, cid, verdict)
            )
            now.liked -> SendOutcome(
                true,
                context.getString(R.string.interact_send_like_ok, cid, now.likeCount)
            )
            else -> SendOutcome(
                false,
                context.getString(R.string.interact_send_like_unverified, cid, verdict)
            )
        }
    }

    // ---------------------------------------------------------------- 第 64 期：回复 / 点赞 接口侦察

    /**
     * ★★★★ 第 64 期：**回复 / 点赞** 接口的「只读侦察」（第 66 期修好并扩了第 ④ 步）。
     *
     * 为什么会有这一步（历史）：
     *   第 55~65 期，「互评 / 楼赞」只做了一半 —— 任务模型里有这两个动作、
     *   任务行也照实显示，但真发送那条路只打 `/api/comments/create` 一个接口，
     *   请求体固定是 `content / mid / st / _spr`，**没有任何「回哪一层」的字段**。
     *   要把它做真，缺的是两样：① **父评论 id**（回哪一层）；② 两个接口的路径与参数名。
     *   ★ **第 66 期两样都补齐了**，互评 / 楼赞已经能真发（见 [postReply] / [postLikeComment]）——
     *     本函数与 [probeReplyLike] 保留下来当**可重复的自检工具**：
     *     接口要是哪天变了，点一下就能看出是哪一步变的。
     *
     *   第 56~59 期报告一直写「必须真机抓包」。其实**不必** ——
     *   本 App 自己就存着这个账号的 Cookie，让它自己发几个请求去问微博就行，
     *   与第 44 期「接口自检」、第 46 期「路径探测」是同一套路子。
     *
     * ★★ 本函数**全只读**（只用 GET）⇒ 物理上不可能创建任何内容。它做四件事：
     *     ① 把「目标」解析成一条具体的微博（复用 [resolveTarget]，与「真预演」同一套规则）；
     *     ② GET 评论列表拿**真实评论** ⇒ 定死父评论 id 的字段名与取值；
     *     ③ 把回复 / 点赞的路径各 GET 一次 ⇒ 确认**路径真的存在**，
     *        再谈要不要花那一次 POST（写请求在 [probeReplyLike] 里，单独一颗按钮）；
     *     ④ ★ 第 66 期：**前端线索** —— 从 H5 详情页跟到打包表里的「详情页 chunk」，
     *        在里面搜出接口名。楼赞的真名（`api/likes/update`）就是这么挖到的。
     *
     * ★ 会阻塞（网络请求），调用方**必须**放在后台线程。
     */
    fun scoutReplyLike(context: Context, account: WeiboAccount?, target: String): String {
        val summary = mutableListOf<String>()
        if (account == null) {
            return note(summary, context.getString(R.string.interact_probe_no_account))
        }
        val cookie = account.cookie
        if (cookie.isBlank()) {
            return note(summary, context.getString(R.string.interact_probe_no_cookie))
        }

        resetDump(context)
        InteractTrace.log("[探回复] 账号=" + account.label + " 目标=" + target)
        InteractTrace.log("[探回复] 全只读（只用 GET）⇒ 不可能创建任何内容")

        // ① 目标 → 一条具体的微博
        val check = resolveTarget(context, account, target)
        summary.add(context.getString(R.string.interact_scout_title))
        summary.add(context.getString(R.string.interact_scout_target, check.mid.ifBlank { "—" }))
        summary.add(check.detail)
        if (check.state != TargetState.EXISTS || check.mid.isBlank()) {
            summary.add(context.getString(R.string.interact_scout_need_post))
            return summary.joinToString("\n")
        }

        // ② 评论列表 —— 「父评论 id」只能从这里拿
        val comments = fetchComments(context, check.mid, cookie, summary)

        // ③ 候选路径是否真的存在（仍然只读）
        summary.add(context.getString(R.string.interact_scout_paths))
        for (url in REPLY_URLS + LIKE_URLS) {
            val response = probe(context, "（探回复）路径 " + url, url, cookie)
            summary.add("  " + url + " → " + parsePathVerdict(response.full))
        }

        // ④ 前端线索（仍然只读）—— 第 65 期新增，第 66 期修好。
        //   ★ 为什么要有这一步：第 64 期把「评论点赞」的候选路径全试遍都没命中，
        //     公开代码里也查不到 ⇒ 唯一可靠的办法，是从 m 站**自己的前端 JS** 里
        //     读出它真正调用的路径。这里先问出「JS 包在哪」，再进包里搜接口名。
        //   ★ 全程只有 GET ⇒ 物理上不可能创建任何内容。
        //   ★★★ 第 66 期修掉两个 bug（第 65 期就是被它们坑的）：
        //     ① **抓错了包**：直接取前两个 .js，拿到的是极验库与性能埋点，
        //        真正的业务包排在第 3、4 个 ⇒ 现在按 [jsPriority] 排序后再取；
        //     ② **业务包里根本没有接口调用**：页面 HTML 引用的 app.js 只管路由，
        //        真正的接口调用在它**按需加载的 chunk** 里（`statusLite.<hash>.js`）。
        //        好在 app.js 自己带着那张「chunk 哈希表」⇒ 顺手把详情页 chunk 也抓来搜。
        summary.add(context.getString(R.string.interact_scout_h5))
        val h5 = probe(context, "（探回复）H5 详情页", "https://m.weibo.cn/detail/" + check.mid, cookie)
        summary.add("  " + h5.head)
        val scripts = Regex(SCRIPT_SRC_RE)
            .findAll(h5.full)
            .map { it.groupValues[1] }
            .distinct()
            .sortedBy { jsPriority(it) }
            .toList()
        if (scripts.isEmpty()) {
            summary.add("  " + context.getString(R.string.interact_scout_h5_none))
        }
        var jsCount = 0
        var chunkUrl = ""
        for (script in scripts) {
            val jsUrl = absolutizeJs(script)
            if (jsUrl.isBlank() || !jsUrl.endsWith(".js")) continue
            if (jsCount >= JS_MAX_BUNDLES) break
            jsCount++
            val js = httpGet(jsUrl, cookie, JS_LIMIT)
            scanJs(context, "前端 JS " + jsCount, jsUrl, js, summary)
            if (chunkUrl.isBlank()) chunkUrl = statusChunkUrl(js.full, jsUrl)
        }
        // ★ 详情页 chunk —— 「评论点赞」的真名就藏在这里（第 66 期就是这么挖到的）。
        if (chunkUrl.isNotBlank()) {
            val js = httpGet(chunkUrl, cookie, JS_LIMIT)
            scanJs(context, "详情页 chunk", chunkUrl, js, summary)
        }

        summary.add(
            if (comments.isEmpty()) {
                context.getString(R.string.interact_scout_no_comment)
            } else {
                context.getString(R.string.interact_scout_found, comments.first().id)
            }
        )
        summary.add(context.getString(R.string.interact_probe_hint))
        return summary.joinToString("\n")
    }

    /**
     * ★★★★ 第 66 期：`<script src>` 的优先级 —— **真正的业务包优先**。
     *
     * ★ 第 65 期的 bug：按出现顺序直接取前两个 `.js`，抓到的是
     *   `static.geetest.com/v4/gt4.js`（极验滑块库）与
     *   `h5.sinaimg.cn/upload/.../wbp.js`（性能埋点，2.4KB）——
     *   两个都不可能含接口调用，于是白白得出「lite 版没有评论互动」这种半截结论。
     * ★ 真正的业务包是 `//h5.sinaimg.cn/m/weibo-lite/js/app.<hash>.js` 与 `vendor.<hash>.js`，
     *   它们写在 HTML 的 `<link rel=preload>` 与靠后的 `<script>` 里，位置**在后面**。
     */
    private fun jsPriority(url: String): Int = when {
        url.contains("/js/app.") -> 0
        url.contains("/js/vendor.") -> 1
        url.contains("weibo-lite/") || url.contains("/m/weibo/") -> 2
        url.contains("gt4.js") || url.contains("geetest") || url.contains("wbp.js") -> 9
        else -> 5
    }

    /** 把 `<script src>` 里的相对地址补成绝对地址。补不出来返回空串。 */
    private fun absolutizeJs(script: String): String = when {
        script.startsWith("http") -> script
        script.startsWith("//") -> "https:" + script
        script.startsWith("/") -> "https://m.weibo.cn" + script
        else -> ""
    }

    /**
     * ★★★★ 第 66 期：从业务包里抠出「微博详情页 chunk」的地址。
     *
     * ★ 原理：打包器把**按需加载的 chunk 名 → 内容哈希**做成一张表塞在入口包里，
     *   形如 `{...,statusLite:"573aed89",...}`，取用时拼成
     *   `<入口包所在目录>/statusLite.<哈希>.js`。
     * ★★ 为什么非要跟到 chunk：接口调用**不在**入口包里 —— 入口包只管路由。
     *   第 66 期那条「评论点赞 = `/api/likes/update` + `{id, type:comment}`」
     *   就是在这个 chunk 里读到的，入口包里**一个字都搜不到**。
     * ★ 表里同一个 chunk 可能出现两次（两个环境各一份哈希）⇒ 逐个试，
     *   第一个真能取到内容的就用；全取不到返回空串（**不编造**）。
     * ★ 只读（GET），不可能创建任何内容。
     */
    private fun statusChunkUrl(entryBody: String, entryUrl: String): String {
        if (!entryBody.contains("statusLite")) return ""
        val base = entryUrl.substringBeforeLast('/') + "/"
        val hashes = Regex("\"statusLite\"\\s*:\\s*\"([0-9a-f]{6,16})\"")
            .findAll(entryBody)
            .map { it.groupValues[1] }
            .distinct()
            .take(JS_CHUNK_TRIES)
            .toList()
        for (hash in hashes) {
            val candidate = base + "statusLite." + hash + ".js"
            val head = httpGet(candidate, "", JS_CHUNK_MIN + 1)
            if (head.head.contains("200") && head.full.length > JS_CHUNK_MIN) return candidate
        }
        return ""
    }

    /**
     * ★★★★ 第 66 期：抓一个 JS 包并在里面搜接口名（只读）。
     *
     * ★ 抽成一个函数，是为了让「入口包」与「详情页 chunk」走**同一套**搜法 ——
     *   两处各写一份，迟早一个搜 `likes` 另一个不搜（第 65 期就是这个毛病）。
     */
    private fun scanJs(
        context: Context,
        label: String,
        url: String,
        js: ProbeResponse,
        summary: MutableList<String>
    ) {
        InteractTrace.log("[自检] （探回复）" + label + " → " + js.head)
        dump(context, "（探回复）" + label, url, js)
        summary.add("  " + url + " → " + js.head)
        val hits = Regex(API_NAME_RE)
            .findAll(js.full)
            .map { it.value }
            .filter { it.length >= 10 }
            .distinct()
            .take(JS_HIT_MAX)
            .toList()
        if (hits.isEmpty()) {
            summary.add("      " + context.getString(R.string.interact_scout_h5_nohit))
        } else {
            for (hit in hits) {
                InteractTrace.log("[自检] （探回复）JS命中 " + hit)
                summary.add("      " + hit)
            }
        }
    }

    /**
     * ★★★★ 第 64 期：**试发**一条测试回复 + 一个测试赞，把两个接口定死。
     *
     * ★ 与 [scoutReplyLike] 的唯一区别：**这一颗会发 POST**。所以设了四道闸，缺一不可：
     *     ① 目标必须解析成一条**存在**的微博（[resolveTarget] 是三态，只有 `EXISTS` 放行）；
     *     ② 评论列表里必须有一条**本账号自己发的**评论 ⇒ 只回自己的楼，绝不碰陌生人；
     *     ③ 候选路径**按可能性排序、命中即停**（第一个 `ok:1` 就收手，绝不连发）；
     *     ④ **绝不重试**（[httpPost] 本身就不重试）。
     *
     * ★ 判据只认回包里的 `ok` —— 第 51 期的教训：「发送成功」这种界面提示可以是假的。
     *   回复成功时回包的 `rootid` 应等于**父评论 id**；若 `rootid` 等于新评论自己的 `id`，
     *   说明那个接口把它当成了一条**新的顶层评论**（不是回复）—— 一并报出来。
     *
     * ★ 会阻塞（最多 1 次 config + 1 次列表 + 4 次 POST），调用方必须放后台线程。
     */
    fun probeReplyLike(context: Context, account: WeiboAccount?, target: String): String {
        val summary = mutableListOf<String>()
        if (account == null) {
            return note(summary, context.getString(R.string.interact_probe_no_account))
        }
        val cookie = account.cookie
        if (cookie.isBlank()) {
            return note(summary, context.getString(R.string.interact_probe_no_cookie))
        }

        resetDump(context)
        InteractTrace.log("[探回复] ★ 本函数会发 POST（试发 1 条回复 + 1 个赞，命中即停）")

        // ① 目标必须真的存在
        val check = resolveTarget(context, account, target)
        summary.add(context.getString(R.string.interact_scout_target, check.mid.ifBlank { "—" }))
        if (check.state != TargetState.EXISTS || check.mid.isBlank()) {
            summary.add(context.getString(R.string.interact_scout_need_post))
            return summary.joinToString("\n")
        }

        // ② 现取一次性票据（★ 每次现取 —— 实测 st 每次都不一样，不能缓存）
        val config = httpGet("https://m.weibo.cn/api/config", cookie)
        val st = parseSt(config.full)
        if (st.isNullOrBlank()) {
            return note(summary, context.getString(R.string.interact_send_need_st))
        }
        val ownUid = parseUid(config.full)

        // ③ 找一条**本账号自己**的评论 —— 只回自己的楼
        val comments = fetchComments(context, check.mid, cookie, summary)
        val mine = comments.firstOrNull { ownUid.isNotBlank() && it.uid == ownUid }
        if (mine == null) {
            summary.add(context.getString(R.string.interact_scout_no_own_comment))
            return summary.joinToString("\n")
        }
        summary.add(context.getString(R.string.interact_scout_own, mine.id, mine.user))

        // ★ 第 66 期：`_spr` 的算法收敛到 [sprOf] 一处（三个请求体共用）。
        val spr = sprOf(context)

        // ④ 试回复：候选按可能性排序，命中即停
        // ★★★★ 第 65 期修正参数名。第 64 期用的是 `id`（沿用发评论的写法），
        //   被回 `100013 参数缺失`。真名来自 m 站前端 SDK `jasdk.js` 的
        //   `wb.m_comment_reply` 逐字原文 ——
        //     {content, mid, reply:cid, cid:cid, withReply:1, st, _spr}
        //   ⇒ 父评论 id 要**同时**填进 `reply` 和 `cid`，并带上 `withReply=1`。
        var replied = false
        for (url in REPLY_URLS) {
            val form = linkedMapOf(
                "content" to PROBE_TEXT,
                "mid" to check.mid,
                "reply" to mine.id,
                "cid" to mine.id,
                "withReply" to "1",
                "st" to st,
                "_spr" to spr
            )
            val verdict = judgeAction(probePost(context, "试回复 POST " + url, url, cookie, form).full, mine.id)
            summary.add("  " + url + " → " + verdict)
            if (verdict.startsWith("★")) {
                replied = true
                break
            }
        }
        summary.add(
            if (replied) context.getString(R.string.interact_scout_reply_ok)
            else context.getString(R.string.interact_scout_reply_bad)
        )

        // ⑤ 试点赞 —— ★★★★ 第 66 期：**只剩一条，而且是已验证的那一条**。
        //   第 64/65 期试遍的 6 条路径全部作废（两条 404、一条 20101、一条赞到了微博上）。
        //   真名与参数来自 m 站前端源码（见 [LIKE_URL] 的注释）：
        //     POST /api/likes/update   体：{id: <评论 id>, type: "comment"}
        //   ★ 仍然**只发一次**，绝不连发、绝不重试。
        val likeBody = likeForm(context, mine.id, st)
        val likeResponse = probePost(context, "试点赞 POST " + LIKE_URL, LIKE_URL, cookie, likeBody)
        summary.add("  " + LIKE_URL + " → " + judgeAction(likeResponse.full, mine.id))

        // ⑥ ★★★★ 第 66 期新增：**重拉列表看 liked** —— 这才是楼赞的判据。
        //   ★ 为什么不能只看回包：第 65 期的候选④ 回了 `ok:1`，重拉列表 `liked` 仍是 false，
        //     那一下赞其实**记到了微博头上**。只看 ok 会把错的说成对的。
        summary.add(context.getString(R.string.interact_scout_like_verify))
        val after = fetchComments(context, check.mid, cookie, summary)
        val mineAfter = after.firstOrNull { it.id == mine.id }
        summary.add(
            "  " + if (mineAfter == null) {
                context.getString(R.string.interact_scout_like_gone)
            } else {
                "liked=" + mineAfter.liked + "  like_count=" + mineAfter.likeCount
            }
        )
        summary.add(
            if (mineAfter?.liked == true) context.getString(R.string.interact_scout_like_ok)
            else context.getString(R.string.interact_scout_like_bad)
        )

        summary.add(context.getString(R.string.interact_probe_hint))
        return summary.joinToString("\n")
    }

    /**
     * ★★★★ 第 66 期：一条评论里我们关心的字段。
     *
     * ★ 为什么从 `private class ScoutComment` 改成公开的 `CommentBrief`：
     *   真发送（[InteractRunner] 的互评 / 楼赞）也要挑楼层、也要**自检**，
     *   两处必须看**同一份**结构 —— 各解析一份，判据迟早不一致。
     * ★ 新增 `liked` / `likeCount` 是**楼赞的唯一判据**：
     *   第 65 期的教训 —— 光看「回包 ok:1」会得出错误结论（那一下赞其实记到了微博上），
     *   只有重拉列表看到 `liked` 变 true，才算真点到评论上。
     */
    class CommentBrief(
        /** 评论 id —— **这就是「回哪一层」要填的值**。 */
        val id: String,
        /** 作者 uid（用来判断「这条是不是本账号自己发的」）。 */
        val uid: String,
        /** 作者昵称（给人看）。 */
        val user: String,
        /** 正文前若干字（给人看）。 */
        val text: String,
        /** 本账号是否已赞过这条评论（楼赞的成败判据）。 */
        val liked: Boolean,
        /** 这条评论已有的赞数（只读，用来给人看「有没有涨」）。 */
        val likeCount: Int,
        /**
         * ★★★ 第 84 期：回包里的 `floor_number`（这条评论在第几楼）。
         *
         * ★ 这是「首评」的**唯一判据** —— 超Like 要的是「抢到第 1 楼」，
         *   所以发完评论必须读回来核对 `floor_number == 1`，光看「发出去的
         *   回包 ok:1」证明不了楼层（可能刚被抢了）。
         *   ★ 默认 **-1 = 回包没给这个字段**：`-1` 必须当成「**不知道**」，
         *     绝不能在判据里写成 `!= 1` 就当「没抢到」—— 那是拿未知当否。
         */
        val floorNumber: Int = -1
    )

    /** 评论列表接口（只读）。★ 参数名来自第 64 期实测；`max_id_type=0` 是第一页。 */
    private fun commentsUrl(mid: String): String =
        "https://m.weibo.cn/comments/hotflow?id=" + mid + "&mid=" + mid + "&max_id_type=0"

    /**
     * 只解析回包，不发请求。
     *
     * ★★ 判据只认**结构**（`ok` 与 `data.data[]`），**不认文案** ——
     *   第 47 / 62 期的教训：同一个状态微博会换说法，靠中文关键词判读会**静默失效**。
     * ★ 空列表有两种回包：一种 `ok:0` 加一句「还没有人评论」，另一种 `ok:1` 但数组为空。
     *   两者都当「没拿到」，不做任何区分 —— 区分它们对结论没有用。
     */
    private fun parseComments(body: String): List<CommentBrief> {
        val result = mutableListOf<CommentBrief>()
        try {
            val json = JSONObject(body)
            if (json.optInt("ok") != 1) return result
            val arr = json.optJSONObject("data")?.optJSONArray("data") ?: return result
            for (i in 0 until minOf(arr.length(), SCOUT_MAX_COMMENTS)) {
                val item = arr.optJSONObject(i) ?: continue
                val id = item.optString("id")
                if (id.isBlank()) continue
                val user = item.optJSONObject("user")
                result.add(
                    CommentBrief(
                        id = id,
                        uid = user?.optString("id").orEmpty(),
                        user = user?.optString("screen_name").orEmpty(),
                        text = oneLine(item.optString("text")).take(40),
                        liked = item.optBoolean("liked"),
                        likeCount = item.optInt("like_count"),
                        // ★★★ 第 84 期：楼层号。回包没给就是 -1（见 CommentBrief.floorNumber）。
                        floorNumber = item.optInt("floor_number", -1)
                    )
                )
            }
        } catch (_: Throwable) {
        }
        return result
    }

    /**
     * GET 评论列表，解析出每条评论的 id / 作者 uid / 作者昵称 / 正文 / 已赞 / 赞数。
     *
     * ★ 只读（GET）⇒ 物理上不可能创建任何内容。
     */
    private fun fetchComments(
        context: Context,
        mid: String,
        cookie: String,
        summary: MutableList<String>
    ): List<CommentBrief> {
        val response = probe(context, "（探回复）评论列表 mid=" + mid, commentsUrl(mid), cookie)
        summary.add(context.getString(R.string.interact_scout_list, response.head))
        val result = parseComments(response.full)
        for (comment in result.take(5)) {
            summary.add("  " + comment.id + "  @" + comment.user + "  " + comment.text)
        }
        if (result.size > 5) {
            summary.add(context.getString(R.string.interact_scout_more, result.size - 5))
        }
        return result
    }

    /**
     * ★★★★ 第 66 期：**给真发送用的**评论列表读取（只读）。
     *
     * ★ 与 [fetchComments] 是同一套解析，区别只在：不往界面摘要里写行，
     *   而是写进互动日志 + 落盘 —— 因为互评 / 楼赞要在**后台**挑楼层，
     *   那里没有「摘要」这种东西，出问题时得靠日志回溯。
     */
    fun listComments(context: Context, account: WeiboAccount, mid: String): List<CommentBrief> {
        val cookie = account.cookie
        if (cookie.isBlank()) return emptyList()
        val url = commentsUrl(mid)
        val response = httpGet(url, cookie)
        InteractTrace.log("[互动] 评论列表 mid=" + mid + " → " + response.head)
        dump(context, "互动评论列表 mid=" + mid, url, response)
        return parseComments(response.full)
    }

    /** 从 `/api/config` 的回包里取本账号 uid。拿不到返回空串。 */
    private fun parseUid(body: String): String = try {
        JSONObject(body).optJSONObject("data")?.optString("uid").orEmpty()
    } catch (_: Throwable) {
        ""
    }

    /**
     * ★★★★ 第 66 期：取**本账号 uid**（只读 GET `/api/config`）。
     *
     * ★ 用途只有一个：判断「这条评论是不是本账号自己发的」，好让互评 / 楼赞
     *   **优先挑别人的楼**（自己回复自己看起来最假）。
     * ★ 拿不到就返回空串 —— 调用方按「不分彼此」处理，**绝不因为拿不到 uid 就中止**。
     *   宁可少一层偏好，也不要因为一次读失败就把功能停掉。
     */
    fun ownUid(account: WeiboAccount): String {
        val cookie = account.cookie
        if (cookie.isBlank()) return ""
        val uid = parseUid(httpGet("https://m.weibo.cn/api/config", cookie).full)
        InteractTrace.log("[互动] 本账号 uid=" + (if (uid.isBlank()) "（没取到）" else uid))
        return uid
    }

    /**
     * 判读一次「回复 / 点赞」的写请求回包。
     *
     * ★ 只认 `ok` —— 与 [judgeCreate] 同一条规矩（第 51 期教训）。
     * ★ 额外区分一件事：回复成功时 `rootid` 应等于**父评论 id**；
     *   若 `rootid` 等于新评论自己的 `id`，说明它被当成了一条新的**顶层评论**。
     *   点赞类接口的 `data` 里通常没有 `id` / `rootid`，那就只报 `ok`。
     */
    private fun judgeAction(body: String, parentId: String): String {
        if (body.isBlank()) return "空回包（网络失败或超时）"
        return try {
            val json = JSONObject(body)
            if (json.optInt("ok") != 1) {
                val errno = json.optString("errno")
                val msg = oneLine(json.optString("msg"))
                val why = listOf(errno, msg).filter { it.isNotBlank() }.joinToString(" / ")
                "被拒：" + why.ifBlank { oneLine(body.take(BODY_LIMIT)) }
            } else {
                val data = json.optJSONObject("data")
                val newId = data?.optString("id").orEmpty()
                val rootId = data?.optString("rootid").orEmpty()
                when {
                    rootId.isNotBlank() && rootId == parentId ->
                        "★ ok:1 且 rootid=父评论 id ⇒ 真·回复成功（新 id=" + newId + "）"
                    rootId.isNotBlank() && newId.isNotBlank() && rootId == newId ->
                        "★ ok:1 但 rootid=自己的 id ⇒ 被当成新的**顶层评论**（不是回复，id=" + newId + "）"
                    else -> "★ ok:1" + (if (newId.isNotBlank()) "（新 id=" + newId + "）" else "")
                }
            }
        } catch (_: Throwable) {
            "无法解析回包：" + oneLine(body.take(BODY_LIMIT))
        }
    }

    /**
     * ★★★★ 第 46 期「阶段 0.5」：**全只读**的「路径 + 票据」探测。
     *
     * 为什么要有这一步：
     *   阶段 0 的 POST 拿回 `HTTP 403 {"errno":"100006","msg":"请求非法"}`，
     *   而**同一个路径**在 PC 上（无 Cookie）却回
     *   `{"errno":"20101","msg":"该微博不存在"}` —— 一个完全正常的回答。
     *   同一套请求头在 `/api/config`、`/container/getIndex` 上都是 200。
     *   ⇒ 问题**既不在路径、也不在请求头**，而在「带 Cookie 的请求」这个组合上。
     *
     * 于是做一张对照表，一次问清三件事：
     *   ① `st` 到底该放 body 还是放 query？（③/⑤ 与 ②/④ 对照）
     *   ② **真实存在的 mid 会不会也被 100006 拦掉？**（④ 是最关键的一格）
     *   ③ 假 mid 在**已知可用**的 `/comments/hotflow` 上长什么样？（⑦ —— 这可能是
     *      比 `/statuses/show` 更好用的「存在性判据」）
     *
     * ★★★ 全部是 GET ⇒ **物理上不可能创建任何内容**，比阶段 0 还安全。
     */
    fun probePaths(context: Context, account: WeiboAccount?, target: String): String {
        val summary = mutableListOf<String>()

        if (account == null) {
            return note(summary, context.getString(R.string.interact_probe_no_account))
        }
        val cookie = account.cookie
        if (cookie.isBlank()) {
            return note(summary, context.getString(R.string.interact_probe_no_cookie))
        }

        resetDump(context)
        InteractTrace.log("[探路径] 账号=" + account.label + " 目标=" + target)
        InteractTrace.log("[探路径] 全只读（只用 GET）⇒ 不可能创建任何内容")

        // 取一次性票据。拿不到也不中止 —— 正好可以观察「不带 st」那一组。
        val config = httpGet("https://m.weibo.cn/api/config", cookie)
        val st = parseSt(config.full)
        InteractTrace.log(
            if (st.isNullOrBlank()) {
                "[探路径] 没拿到 st ⇒ ③⑤ 会退化成与 ②④ 相同"
            } else {
                "[探路径] 拿到 st（长度 " + st.length + "，值不记）"
            }
        )
        val suffix = if (st.isNullOrBlank()) "" else "&st=" + st

        // ★ 对照表。needSt = true 的步骤会在 URL 后面拼 `&st=<票据>`。
        val steps = listOf(
            ProbeStep("① 对照·登录态", "https://m.weibo.cn/api/config", false),
            ProbeStep("② 假mid·show·无st", "https://m.weibo.cn/statuses/show?id=" + PROBE_MID, false),
            ProbeStep("③ 假mid·show·有st", "https://m.weibo.cn/statuses/show?id=" + PROBE_MID, true),
            ProbeStep("④ ★真mid·show·无st", "https://m.weibo.cn/statuses/show?id=" + CONTROL_MID, false),
            ProbeStep("⑤ ★真mid·show·有st", "https://m.weibo.cn/statuses/show?id=" + CONTROL_MID, true),
            ProbeStep(
                "⑥ 对照·真mid评论列表",
                "https://m.weibo.cn/comments/hotflow?id=" + CONTROL_MID +
                    "&mid=" + CONTROL_MID + "&max_id_type=0",
                false
            ),
            ProbeStep(
                "⑦ ★假mid评论列表",
                "https://m.weibo.cn/comments/hotflow?id=" + PROBE_MID +
                    "&mid=" + PROBE_MID + "&max_id_type=0",
                false
            ),
        )

        val lines = mutableListOf<String>()
        for (step in steps) {
            val url = if (step.needSt) step.url + suffix else step.url
            val response = probe(context, step.label, url, cookie)
            val line = step.label + " → " + parsePathVerdict(response.full)
            lines.add(line)
            InteractTrace.log("[探路径] " + line)
        }

        // ★ 对照是否成立：④（真实存在的微博）必须拿到预期结果（见 parsePathVerdict 的「★ 成功」档）。
        //   拿不到 ⇒ 这张表整体不作数，绝不当成结论用。
        val controlOk = lines.any { it.startsWith("④") && it.contains("成功") }
        summary.add(context.getString(R.string.interact_probe_paths_title))
        summary.addAll(lines)
        summary.add(
            if (controlOk) {
                context.getString(R.string.interact_probe_paths_control_ok)
            } else {
                context.getString(R.string.interact_probe_paths_control_bad)
            }
        )
        summary.add(context.getString(R.string.interact_probe_hint))
        return summary.joinToString("\n")
    }

    /** 对照表里的一步。 */
    private class ProbeStep(val label: String, val url: String, val needSt: Boolean)

    /**
     * 把回包归成一句人话。
     *
     * ★ 与 [parseSendVerdict] 不同，这里敢下结论 ——
     *   因为这些类别**互斥且可判**（都是微博自己给的 errno），不是推测。
     *
     * ★★ 判读顺序有讲究：`errno` 类别必须排在 `"ok":1` 之前，
     *   否则一个既含 errno 又含别的东西的回包会被误判成成功。
     */
    private fun parsePathVerdict(body: String): String {
        if (body.isBlank()) return "空回包（网络失败或超时）"
        val text = oneLine(body)
        return when {
            text.contains("\"errno\":404") || (text.contains("链接") && text.contains("无效")) ->
                "路径不存在（errno 404）"
            text.contains("20101") || text.contains("该微博不存在") ->
                "★ 明确回答：该微博不存在"
            text.contains("100006") || text.contains("请求非法") ->
                "被拦：请求非法（errno 100006）"
            text.contains("100013") || text.contains("参数缺失") ->
                "参数缺失（errno 100013）"
            text.contains("\"errno\":\"20000\"") || text.contains("未知错误") ->
                "★ 无法解析这条微博（errno 20000）—— 假 mid 就是这一档"
            text.contains("passport") || text.contains("\"ok\":-100") ->
                "要登录（跳 passport）"
            text.contains("\"ok\":1") ->
                "★ 成功（ok:1）"
            // ★ 第 54 期：原来这里认死一句文案「快来发表你的评论」，
            //   而微博换过说法（2026-10-03 实测回的是「还没有人评论哦~快来抢沙发！」）
            //   ⇒ 一个完全正常的回包会掉进下面的「未归类」，看着像出了问题。
            //   改成认**结构**：ok:0 + 有 msg + 无 errno（判据与 [postState] 的 ③ 一致）。
            //   ★ 这一条只决定**给人看的那句话**，不参与任何「发不发」的判断。
            text.contains("\"ok\":0") && !text.contains("errno") && text.contains("\"msg\"") ->
                "该微博存在，且当前没有评论（ok:0 + msg、无 errno）"
            else -> "未归类，看回包原文"
        }
    }

    /**
     * 读 POST 回包，给一句人话结论。
     *
     * ★ 这里的四种结论都是**推测**，所以措辞上要留余地 —— 真正的判据是黑匣子里的回包原文。
     */
    private fun parseSendVerdict(body: String): String {
        if (body.isBlank()) return "没有回包（网络失败或超时）—— 看黑匣子里的报错原文"
        val text = oneLine(body)
        return when {
            text.contains("不存在") || text.contains("已删除") ->
                "接口认了这些参数（否则不会去查微博）⇒ 路径与参数名大概率正确，只是这条微博不存在"
            text.contains("参数") || text.contains("缺少") ->
                "接口报参数问题 ⇒ 路径对了，但还缺/多了参数，按回包点名的补"
            text.contains("404") || text.contains("接口不存在") || text.contains("Not Found") ->
                "接口路径不对 ⇒ 要换路径再试"
            text.contains("ok\":1") || text.contains("\"ok\":1") ->
                "★ 竟然成功了 —— 立刻去微博确认有没有多出评论（正常不该发生）"
            else -> "看回包原文判断（已记进黑匣子与落盘文件）"
        }
    }

    /**
     * 从 `/api/config` 的回包里取一次性票据 `st`。
     *
     * ★ 只把值交给调用方去用，**不写进日志**（日志用户会看到、也会贴给别人）。
     */
    private fun parseSt(body: String): String? = try {
        JSONObject(body).optJSONObject("data")?.optString("st")?.takeIf { it.isNotBlank() }
    } catch (_: Throwable) {
        null
    }

    /**
     * 目标微博的存在性 —— ★ 三态，不是布尔。
     *
     * ★ 第 46 期阶段 2：去掉 `private` —— `TargetCheck` 要把它交给 `InteractRunner`，
     *   而调用方必须能区分「不存在」和「没确认」，否则又会把 UNKNOWN 当成可以发。
     */
    enum class TargetState { EXISTS, NOT_EXISTS, UNKNOWN }

    /**
     * 从 `/statuses/show` 的回包判断目标微博的存在性。
     *
     * ★★★★ 第 46 期修正（一次真实的教训，值得留着）：
     *   原来这里返回 `Boolean`，而且把 `ok:0` **一律**当成「不存在」。
     *   第 46 期「阶段 0」真机实测发现这是个**假闸门**：
     *   当接口因为风控回了 `{"ok":0,"errno":"100006","msg":"请求非法"}` 时，
     *   `ok:0` 同样成立 ⇒ 闸门被**错误地打开**。
     *   「接口报错」与「微博不存在」被混成了一件事。
     *
     * ★ 现在的规则：**只有拿到正面证据才认定「不存在」**，
     *   其余一律 `UNKNOWN`，而 `UNKNOWN` 在 [probeSend] 里**等同「不许发」**。
     *   宁可探测不出结果，也不在一个存在性未确认的帖子下面留评论。
     */
    private fun targetState(body: String): TargetState = try {
        val json = JSONObject(body)
        val errno = json.optString("errno")
        val msg = json.optString("msg")
        when {
            // 正面证据①：微博那边明确说「这条不存在」
            errno == "20101" || msg.contains("不存在") || msg.contains("已删除") ->
                TargetState.NOT_EXISTS
            // 正面证据②：确实拿到了这条微博
            json.optString("id").isNotBlank() ||
                (json.optJSONObject("data")?.optString("id")?.isNotBlank() == true) ->
                TargetState.EXISTS
            else -> TargetState.UNKNOWN
        }
    } catch (_: Throwable) {
        TargetState.UNKNOWN
    }

    /**
     * 「用户主页 → 最新一条微博」的四步链（本版新增，**全部只读**）。
     *
     * ① 拉主页容器 → 从 `tabsInfo` 里**解析**出「微博」tab 的 `containerid`；
     * ② 用那个 `containerid` 拉微博列表 → 从 `cards[].mblog` 里取出第一条的 **mid**；
     * ③ 拿这个 mid 再拉一次评论列表 —— 这才是「抢首评」真正要操作的接口。
     *
     * ★ 为什么要绕这一圈：用户手上往往只有「某人的主页」，
     *   而「评论」必须作用在**一条具体的微博**上。
     */
    private fun probeProfile(
        context: Context,
        uid: String,
        cookie: String,
        summary: MutableList<String>
    ) {
        // ① 主页容器（顺带把 tabsInfo 解析出来）
        val profile = probe(
            context, "用户主页 /container/getIndex",
            "https://m.weibo.cn/api/container/getIndex?type=uid&value=" + uid,
            cookie
        )
        val parsed = parseWeiboContainer(profile.full)
        val containerId = parsed ?: (WEIBO_TAB_PREFIX + uid)
        val source = if (parsed != null) "从 tabsInfo 解析" else "回退到固定前缀"
        InteractTrace.log("[自检] 微博列表容器 containerid=" + containerId + "（" + source + "）")
        summary.add(context.getString(R.string.interact_probe_container, containerId))

        // ② 微博列表 —— 这一步就是本版要验证的东西
        val listUrl = "https://m.weibo.cn/api/container/getIndex?type=uid&value=" + uid +
            "&containerid=" + containerId
        val list = probe(context, "微博列表 /container/getIndex", listUrl, cookie)
        val latest = parseLatestPost(list.full)
        if (latest == null) {
            InteractTrace.log("[自检] 没解析出微博列表（可能这个人没发过微博，或接口结构变了）")
            summary.add(context.getString(R.string.interact_probe_no_post))
            return
        }
        InteractTrace.log(
            "[自检] ★ 最新微博 mid=" + latest.mid + " bid=" + latest.bid +
                " 摘要=" + latest.excerpt
        )
        summary.add(context.getString(R.string.interact_probe_post_found, latest.mid))

        // ③ 对这条最新微博拉评论列表 —— 「抢首评」真正要打的接口
        probe(
            context, "评论列表 /comments/hotflow",
            "https://m.weibo.cn/comments/hotflow?id=" + latest.mid +
                "&mid=" + latest.mid + "&max_id_type=0",
            cookie
        )
    }

    /**
     * ★★★★ 第 68 期：超话自检 —— 拉一次超话容器，把回包原样落盘。
     *
     * ★ 为什么单开：超话接口**没法在电脑上先验证** —— `m.weibo.cn` 对无 Cookie 请求
     *   一律 302 到访客墙（`visitor.passport.weibo.cn`），跟过去只拿到 HTTP 432；
     *   网页版 `weibo.com/p/100808…` 同样返回访客系统页。⇒ 只能靠**真机上这个账号的
     *   Cookie** 实测。这个按钮跑一次，原始回包就会写进 `filesDir/interact_probe.txt`，
     *   我们据此确认「帖子挂在哪一层」（`cards[].mblog` 还是 `cards[].card_group[].mblog`）。
     *
     * ★ 只读：一个 GET，不发任何写请求 ⇒ 不消耗任何额度。
     * ★ 会阻塞，必须在后台线程调用。
     */
    private fun probeTopic(
        context: Context,
        containerId: String,
        cookie: String,
        ownUid: String,
        summary: MutableList<String>
    ) {
        val body = probe(
            context, "超话容器 /container/getIndex",
            "https://m.weibo.cn/api/container/getIndex?containerid=" + containerId,
            cookie
        )
        // ★ 复用与真发送同源的解析 ⇒ 自检看到几条，发送时就能用几条（不会两套判据）。
        val posts = parseTopicPosts(body.full, ownUid)
        summary.add(context.getString(R.string.interact_probe_topic, containerId, posts.size))
        if (posts.isEmpty()) {
            InteractTrace.log("[自检] 超话里没解析出可评论的帖子（接口结构可能变了，或全是你自己发的）")
            return
        }
        InteractTrace.log("[自检] ★ 超话随机挑帖会在这 " + posts.size + " 条里选，例如 mid=" + posts[0].mid)
    }

    // ---------------------------------------------------------------- 目标核对

    /**
     * 目标核对的结果。
     *
     * ★ `state` 是**三态**：只有 `EXISTS` 才表示「可以发」。
     *   `UNKNOWN` 必须和 `NOT_EXISTS` 一样被当成「不许发」——
     *   第 46 期就是被 `ok:0` 骗开过一次闸门（报错的回包同样也是 `ok:0`）。
     */
    class TargetCheck(
        /** 最终要操作的那条微博 mid；空串 = 没拿到。 */
        val mid: String,
        /** 存在性。 */
        val state: TargetState,
        /** 一句话给人看。 */
        val detail: String
    )

    /**
     * ★★★★ 第 46 期阶段 2：把「用户填的目标」变成「一条可以操作的微博」。
     *
     * 为什么单开一个函数：`InteractRunner` 的「真预演」和「发送」都要它，
     * 而 [run] / [probeProfile] 是给人看的自检（往 summary 里塞话）。
     * 同一个解析写两份，迟早一份改了另一份没改 ⇒ 只写这一份，两边都用。
     *
     * ★ **全部 GET**，不发任何写请求 ⇒ **不消耗 POST 额度**。
     * ★ 会阻塞（网络请求），调用方**必须**放在后台线程。
     */
    fun resolveTarget(context: Context, account: WeiboAccount, target: String): TargetCheck {
        val cookie = account.cookie
        return when (InteractTarget.kind(target)) {
            TargetKind.NONE -> TargetCheck(
                "", TargetState.UNKNOWN, context.getString(R.string.interact_check_no_target)
            )
            TargetKind.UNKNOWN -> TargetCheck(
                "", TargetState.UNKNOWN, context.getString(R.string.interact_check_unknown_target)
            )
            TargetKind.POST -> {
                val mid = InteractTarget.postId(target)
                if (mid.isBlank()) {
                    TargetCheck("", TargetState.UNKNOWN, context.getString(R.string.interact_check_no_mid))
                } else {
                    checkPost(context, mid, cookie, "")
                }
            }
            TargetKind.PROFILE -> {
                val uid = InteractTarget.uid(target)
                if (uid.isBlank()) {
                    TargetCheck("", TargetState.UNKNOWN, context.getString(R.string.interact_check_no_uid))
                } else {
                    val latest = latestPostOf(context, uid, cookie)
                    if (latest == null) {
                        TargetCheck(
                            "", TargetState.UNKNOWN,
                            context.getString(R.string.interact_check_no_latest, uid)
                        )
                    } else {
                        InteractTrace.log("[预演] 主页 uid=" + uid + " → 最新微博 mid=" + latest.mid)
                        checkPost(context, latest.mid, cookie, context.getString(R.string.interact_check_of_latest))
                    }
                }
            }
            TargetKind.SUPERTOPIC -> {
                // ★★★★ 第 68 期：超话 —— 拉它的帖子列表，**随机挑一条**。
                //   ★ 排除「本账号自己发的」：官方规则「评论自己的帖子不加分」，
                //     挑到自己的就是白评一次（还占掉每天 4 次里的一次）。
                val cid = InteractTarget.topicId(target)
                if (cid.isBlank()) {
                    TargetCheck("", TargetState.UNKNOWN, context.getString(R.string.interact_check_no_topic))
                } else {
                    val picked = randomTopicPost(context, cid, cookie, ownUid(account))
                    if (picked == null) {
                        TargetCheck(
                            "", TargetState.UNKNOWN,
                            context.getString(R.string.interact_check_no_topic_post, cid)
                        )
                    } else {
                        InteractTrace.log(
                            "[预演] 超话 " + cid + " → 随机挑中 mid=" + picked.mid +
                                "（" + picked.excerpt + "）"
                        )
                        checkPost(
                            context, picked.mid, cookie,
                            context.getString(R.string.interact_check_of_topic)
                        )
                    }
                }
            }
        }
    }

    /** 拉某个人最新一条微博；拉不到返回 null。 */
    private fun latestPostOf(context: Context, uid: String, cookie: String): LatestPost? {
        val profile = probe(
            context, "（预演）主页容器",
            "https://m.weibo.cn/api/container/getIndex?type=uid&value=" + uid, cookie
        )
        val containerId = parseWeiboContainer(profile.full) ?: (WEIBO_TAB_PREFIX + uid)
        val list = probe(
            context, "（预演）微博列表",
            "https://m.weibo.cn/api/container/getIndex?type=uid&value=" + uid +
                "&containerid=" + containerId,
            cookie
        )
        return parseLatestPost(list.full)
    }

    // ---------------------------------------------------------------- 第 68 期：超话随机挑帖

    /**
     * ★★★★ 第 68 期：从一个**超话**的帖子列表里**随机挑一条**。
     *
     * 接口与「用户主页」那条链路是**同一个**（`getIndex` + `containerid`），
     * 只是 container 前缀不同：主页微博 tab 是 `107603`，超话是 `100808`。
     *
     * ★ 拉不到、或列表里一条能用的都没有 ⇒ 返回 null（调用方如实报错，**不猜**）。
     * ★ 排除自己发的（见 [collectMblog]）—— 官方规则「评论自己的帖子不加分」。
     * ★ 会阻塞，必须在后台线程调用。
     */
    private fun randomTopicPost(
        context: Context,
        containerId: String,
        cookie: String,
        ownUid: String
    ): LatestPost? {
        val body = probe(
            context, "（预演）超话容器 " + containerId,
            "https://m.weibo.cn/api/container/getIndex?containerid=" + containerId,
            cookie
        )
        val posts = parseTopicPosts(body.full, ownUid)
        InteractTrace.log(
            "[预演] 超话 " + containerId + " 候选帖子 " + posts.size + " 条（已排除自己发的）"
        )
        if (posts.isEmpty()) return null
        return posts[Random.nextInt(posts.size)]
    }

    /**
     * 解析超话容器的回包，取出所有可评论的帖子。
     *
     * ★★★ 这里**同时看两层**：`cards[].mblog` 与 `cards[].card_group[].mblog`。
     *   用户主页那条链路（[parseLatestPost]）只看顶层就够，但超话的卡片
     *   常常是「一个 card 里套一组 card_group」—— 只找顶层会**一条都拿不到**。
     *   这一层**没法在 PC 侧验证**（`m.weibo.cn` 对无 Cookie 一律 302 到访客墙），
     *   所以两层都收：宁可多找，不可漏。
     */
    private fun parseTopicPosts(body: String, ownUid: String): List<LatestPost> {
        val out = mutableListOf<LatestPost>()
        // ★ 分层计数**只为取证**：真机上第一次跑要能一眼看出帖子到底挂在哪一层。
        var topLevel = 0
        var grouped = 0
        try {
            val cards = JSONObject(body).optJSONObject("data")?.optJSONArray("cards")
                ?: return out
            for (i in 0 until cards.length()) {
                val card = cards.optJSONObject(i) ?: continue
                if (card.optJSONObject("mblog") != null) topLevel++
                collectMblog(card.optJSONObject("mblog"), ownUid, out)
                val group = card.optJSONArray("card_group")
                if (group != null) {
                    for (j in 0 until group.length()) {
                        val mblog = group.optJSONObject(j)?.optJSONObject("mblog")
                        if (mblog != null) grouped++
                        collectMblog(mblog, ownUid, out)
                    }
                }
            }
        } catch (_: Throwable) {
        }
        InteractTrace.log(
            "[预演] 超话回包分层：顶层 mblog=" + topLevel + " 条，card_group 内 mblog=" +
                grouped + " 条，可用 " + out.size + " 条"
        )
        return out
    }

    /** 收一条 mblog：去重、跳过空 id、★ **跳过本账号自己发的**。 */
    private fun collectMblog(mblog: JSONObject?, ownUid: String, out: MutableList<LatestPost>) {
        if (mblog == null) return
        val mid = mblog.optString("id")
        if (mid.isBlank()) return
        if (out.any { it.mid == mid }) return
        val author = mblog.optJSONObject("user")?.optString("id").orEmpty()
        if (ownUid.isNotBlank() && author == ownUid) {
            InteractTrace.log("[预演] 跳过一条自己发的帖子 mid=" + mid)
            return
        }
        out.add(
            LatestPost(
                mid,
                mblog.optString("bid"),
                mblog.optString("text").replace(Regex("<[^>]+>"), " ").trim().take(40),
                mblog.optInt("comments_count", -1)
            )
        )
    }

    // ---------------------------------------------------------------- 第 84 期：超Like 编排专用

    /**
     * ★★★ 第 84 期：超Like 编排读回包用的上限。
     *
     * ★ 为什么比 [FILE_LIMIT]（12 万字符）大：超话帖子列表和**个人时间线**
     *   都是一整页 JSON，每条微博自带正文 / 用户 / 图片等一大堆字段，
     *   12 万字符经常**在数组中间就被截断** ⇒ JSON 解析失败 ⇒ 一条都拿不到。
     *   ★ 截断的后果是「安静地拿不到东西」（解析异常被吞成空列表），
     *     不会误判成「成功」，所以这里放宽是**只增不减**的纯改进。
     */
    private const val SUPERLIKE_LIMIT = 600_000

    /**
     * ★★★★ 第 89 期：超话**排序后缀只读试探**要试的后缀（见 [probeSortVariants]）。
     *
     * ★ 为什么是「试探」而不是「直接拿来取数」：第 20 条纪律 ——
     *   判据只认**结构**、不认**猜测**。超话 feed 的排序 containerid 后缀
     *   **从未被实测确认过**（PC 侧也复现不了：m 站无 Cookie 一律 302 到访客墙，
     *   带 Cookie 也被风控回 432）⇒ 直接拿一个猜的后缀去取数，最坏结果是
     *   **安静地**拿到另一批数据（甚至一条都拿不到），比不猜更危险。
     *   所以这一轮只**读**、只**打印**：`topicPosts` 的返回值**一个字节都没变**。
     *
     * ★ `_-_sort_time` = 按时间（用户要的「最新」）；`_-_sort_hot` = 按热度。
     *   后者是**对照组**：若 hot 与基准一致、time 明显不同，说明后缀机制生效。
     */
    private val SORT_PROBE_SUFFIXES = listOf("_-_sort_time", "_-_sort_hot")

    /** 第 89 期诊断：日志里单个字段最多打多少字符（互动日志是 300 条环形缓冲，不能撑爆）。 */
    private const val DIAG_TEXT_LIMIT = 120

    /** 第 89 期诊断：日志里最多打多少行 tab / 多少行 card_group（同上）。 */
    private const val DIAG_LINE_LIMIT = 12

    /**
     * ★★★★ 第 84 期：**捞帖** —— 把一个超话的帖子列表整批取回来（只读）。
     *
     * ★ 与 [randomTopicPost] 的区别：那个只随机挑**一条**（给「评论一条」用），
     *   这个把**整页**交出来（超Like 要从里面筛「0 评论」的帖子，一条不够）。
     * ★ 两者共用 [parseTopicPosts] ⇒ 「自检看到几条」与「编排能筛出几条」**同源**。
     * ★ 全部只读（GET）⇒ 不消耗任何额度、不产生任何内容。
     * ★ 会阻塞，必须在后台线程调用。
     *
     * ★★ 刻意**不收 `context`**（本文件里少见的例外）：
     *   它既不需要弹任何东西，也**不 dump 落盘** —— 超话整页 JSON 能到 60 万字符，
     *   每次编排都往探测文件里追加一份会把它撑到几 MB。真机排查要看的是
     *   「拉到几条 / 其中几条 0 评论」，那两行已经进**互动日志**了，
     *   而互动日志在界面上就能读（release 包也看得见）。
     *   ★ 所以这不是「漏了参数」，是**故意不要**：加上去只会多一条
     *     `Parameter 'context' is never used` 告警（基线是 9 条，不许涨）。
     */
    fun topicPosts(account: WeiboAccount, containerId: String): List<LatestPost> {
        val cookie = account.cookie
        if (cookie.isBlank()) return emptyList()
        val url = "https://m.weibo.cn/api/container/getIndex?containerid=" + containerId
        val body = httpGet(url, cookie, SUPERLIKE_LIMIT)
        InteractTrace.log("[超Like] 捞帖 containerid=" + containerId + " → " + body.head)
        // ★★★ 第 89 期：把 uid **存一次**再复用（原来是在下一句里就地求值的）。
        //   求值时机**完全没变**（仍在同一条语句的位置），只是把结果留下来，
        //   免得后面的排序试探为同一个 uid 再发一次 `/api/config`。
        val uid = ownUid(account)
        val posts = parseTopicPosts(body.full, uid)
        // ★★★ 第 88 期：把「0 评论 0 条」的两种可能**拆开**（纯诊断，不改任何判定）。
        //
        //   原日志只印 `count { commentsCount == 0 }`，于是「候选 0 条」既可能是
        //     ① 那批帖子**真的**都有人评论过（`comments_count` 都是正数），也可能是
        //     ② 回包**根本没给** `comments_count` 字段（`optInt(..., -1)` 全判 -1 ⇒ 全落选）。
        //   两者对「首评 0 条」的含义完全相反，必须能分开 ⇒ 补三分类计数 + 分布 + 字段名检测。
        //   ★ 顺带的价值：若三分类显示「0 评论 > 0 条」而首评仍是 0 条，
        //     说明拦下它的**不是候选门**，而是**限流门**（`isResting` 在 `while` 顶部 break）。
        //   ★ 分布只给人眼看：`eachCount()` 后按 key 排序（条数少，不会撑爆日志）。
        val zeroCount = posts.count { it.commentsCount == 0 }
        val missingCount = posts.count { it.commentsCount < 0 }
        val positiveCount = posts.count { it.commentsCount > 0 }
        val distribution = posts.groupingBy { it.commentsCount }.eachCount()
            .toSortedMap().entries.joinToString(" ") { it.key.toString() + "×" + it.value }
        InteractTrace.log(
            "[超Like] 可用帖子 " + posts.size + " 条（已排除自己发的）：0 评论 " + zeroCount +
                " 条，回包没给评论数 " + missingCount + " 条，有评论 " + positiveCount +
                " 条；评论数分布 { " + distribution.ifBlank { "-" } + " }；回包含 " +
                "comments_count 字段名=" + body.full.contains("\"comments_count\"")
        )
        // ★★★ 第 89 期：两段**只读诊断** —— 目的只有一个：查清「怎么切到『最新』流」。
        //   ★ 两段都**不改 [posts]**，返回值一个字节都没变（硬规则二自检：不会让程序做出不同决定）。
        //   ① 结构诊断：**零额外请求**，只解析**已经拿到的那一份回包**；
        //   ② 排序试探：**+2 个只读 GET**（★ 用户已批准的诊断包内容），对照基准看哪个后缀能切到「最新」。
        diagnoseTopicCards(body.full)
        probeSortVariants(cookie, containerId, uid)
        return posts
    }

    /**
     * ★★★★ 第 89 期：超话回包**结构诊断**（只读、零额外请求、无返回值）。
     *
     * ★ 起因（第 88 期真机实测）：`[超Like] 可用帖子 15 条 … 有评论 15 条`，
     *   评论数分布 `{ 5×1 10×1 … 879×1 }` —— 最少 5 条、最多 879 条。
     *   若真是「按最新排」的 feed，最新几条的评论数应当从 0 往上递增；
     *   而这里是**按热度**排的 ⇒ **这个 feed 根本不是「最新」流**，热门帖当然条条
     *   都有评论 ⇒ 候选天然为 0。★ 星签的判据（只认 `commentsCount == 0`）**没错**，
     *   错的是**取数的那个流**。
     *
     * ★ 用户的要求：**首评要从「最新」里找帖子**。
     * ★ 但「切到最新的 containerid 长什么样」**在 PC 侧验证不了**（m 站无 Cookie 一律
     *   302 到访客墙，带 Cookie 也被风控回 432）⇒ 只能从真机取证。
     *
     * ★ 这一轮**只诊断、不改取数**：先把「回包里有没有现成的切换线索」查清楚。
     *   四处都在**已经拿到的那一份回包**里，**不发新请求**：
     *     ① `data.cards[].card_type` 分布 —— 超话页的 tab 卡通常是某个固定 card_type；
     *     ② `data.tabsInfo.tabs[]` —— m 站分页 tab 的**标准结构**，**每项自带 containerid**
     *        （用户主页的「微博/相册」就是它）⇒ 超话的「最新/热门/精华」极可能也在这里；
     *     ③ `data.cardlistInfo` —— 分页元信息，可能带 `containerid` / `since_id`；
     *     ④ 对**不带 `mblog`** 的卡，把 `card_group` 各项的 title / scheme 打出来
     *        （tab 的跳转链接有时只挂在这里，不单独成卡）。
     *
     * ★ 判据纪律：这里打出来的**只是线索**，不是判据。真要切取数来源之前，
     *   必须先拿到真机回包、确认结构，再**单独提出来问用户**。
     * ★ 异常一律吞掉：诊断失败绝不能影响主流程（本函数**没有任何返回值**）。
     */
    private fun diagnoseTopicCards(body: String) {
        try {
            val data = JSONObject(body).optJSONObject("data") ?: run {
                InteractTrace.log("[超Like·诊断] 回包里没有 data（可能被 302 / 风控拦了）")
                return
            }

            // ① card_type 分布
            val cards = data.optJSONArray("cards")
            val typeCount = mutableMapOf<Int, Int>()
            if (cards != null) {
                for (i in 0 until cards.length()) {
                    val type = cards.optJSONObject(i)?.optInt("card_type", -1) ?: -1
                    typeCount[type] = (typeCount[type] ?: 0) + 1
                }
            }
            InteractTrace.log(
                "[超Like·诊断] cards=" + (cards?.length() ?: 0) + " 张；card_type 分布 " +
                    typeCount.toSortedMap().entries.joinToString(" ") {
                        it.key.toString() + "×" + it.value
                    }
            )

            // ② tabsInfo：m 站分页 tab 的标准结构，每项自带 containerid
            val tabs = data.optJSONObject("tabsInfo")?.optJSONArray("tabs")
            if (tabs == null) {
                InteractTrace.log("[超Like·诊断] tabsInfo.tabs 不存在")
            } else {
                InteractTrace.log("[超Like·诊断] tabsInfo.tabs=" + tabs.length() + " 项：")
                for (i in 0 until tabs.length().coerceAtMost(DIAG_LINE_LIMIT)) {
                    val tab = tabs.optJSONObject(i) ?: continue
                    InteractTrace.log(
                        "[超Like·诊断]   tab[" + i + "] title=" +
                            oneLine(tab.optString("title")).take(DIAG_TEXT_LIMIT) +
                            " type=" + tab.optString("tab_type") +
                            " containerid=" + tab.optString("containerid")
                    )
                }
            }

            // ③ cardlistInfo：分页元信息
            val info = data.optJSONObject("cardlistInfo")
            val infoText =
                if (info == null) "不存在" else oneLine(info.toString()).take(DIAG_TEXT_LIMIT * 2)
            InteractTrace.log("[超Like·诊断] cardlistInfo=" + infoText)

            // ④ 不带 mblog 的卡里的 card_group 线索
            if (cards != null) {
                var printed = 0
                for (i in 0 until cards.length()) {
                    if (printed >= DIAG_LINE_LIMIT) break
                    val card = cards.optJSONObject(i) ?: continue
                    if (card.optJSONObject("mblog") != null) continue
                    val group = card.optJSONArray("card_group") ?: continue
                    for (j in 0 until group.length()) {
                        if (printed >= DIAG_LINE_LIMIT) break
                        val item = group.optJSONObject(j) ?: continue
                        InteractTrace.log(
                            "[超Like·诊断]   卡[" + i + "]组[" + j + "] title=" +
                                oneLine(item.optString("title")).take(DIAG_TEXT_LIMIT) +
                                " type=" + item.optInt("card_type", -1) +
                                " itemid=" + item.optString("itemid") +
                                " scheme=" +
                                oneLine(item.optString("scheme")).take(DIAG_TEXT_LIMIT * 2)
                        )
                        printed++
                    }
                }
                if (printed == 0) {
                    InteractTrace.log("[超Like·诊断] 不带 mblog 的卡里没有 card_group 线索")
                }
            }
        } catch (_: Throwable) {
            // 诊断失败一律静默：它绝不能影响主流程。
        }
    }

    /**
     * ★★★★ 第 89 期：超话**排序后缀**只读试探（+2 个 GET，**不改任何返回值**）。
     *
     * ★ 为什么需要它：见 [diagnoseTopicCards] —— 第 88 期实测证明当前 feed 是
     *   **按热度**排的（15 条帖子全有评论），而首评要的是**刚发出、还没人评论**的帖子，
     *   只有「最新」流里才有 ⇒ 需要一个能切到「最新」的 containerid。
     *
     * ★ 为什么是「试探」：后缀**从未被实测确认过**，而第 20 条纪律要求
     *   「判据只认结构、不认猜测」⇒ 直接拿猜的后缀去取数，最坏是**安静地**
     *   拿到另一批数据，比不猜更危险。所以这一轮只**读**、只**打印**：
     *   [topicPosts] 返回的仍然是**基准 containerid 那一份**，一个字节都没变。
     *
     * ★ 每个后缀只发 **1 次** GET，全部只读 ⇒ 不消耗任何额度、不产生任何内容。
     * ★ 会阻塞，必须在后台线程调用（由 [topicPosts] 保证）。
     *
     * ★ 复用 [parseTopicPosts] 解析是**故意的**：这样「试探看到的条数」与
     *   「编排实际能筛出的条数」**同源**，不会出现两套口径。
     */
    private fun probeSortVariants(cookie: String, containerId: String, uid: String) {
        for (suffix in SORT_PROBE_SUFFIXES) {
            val url = "https://m.weibo.cn/api/container/getIndex?containerid=" +
                containerId + suffix
            val body = httpGet(url, cookie, SUPERLIKE_LIMIT)
            val posts = parseTopicPosts(body.full, uid)
            InteractTrace.log(
                "[超Like] 排序试探 " + suffix + " → " + body.head + "；可用 " + posts.size +
                    " 条，其中 0 评论 " + posts.count { it.commentsCount == 0 } + " 条"
            )
        }
    }

    /**
     * ★★★ 第 84 期：自己时间线上的一条微博。
     *
     * ★ `repostedMid` 非空 = 这条**是转发**，值是**被转发的原微博 id**。
     *   这是「有没有重复转发」的判据来源。
     */
    class TimelinePost(
        val mid: String,
        val excerpt: String,
        val repostedMid: String
    )

    /**
     * ★★★★ 第 84 期：读**自己**的时间线（只读）。
     *
     * ★ 用途：转发之前先看「这条我最近是不是已经转过了」。
     *   竞品的原则是「宁可漏做，绝不重复转发」—— 重复转发是同一条内容刷两遍，
     *   对账号的伤害比少做一次大得多。星签这里用**自己的时间线**做只读核对，
     *   和竞品从 `mymblog` 核对是同一个思路，只是换成了 m 站的接口
     *   （`containerid=107603<uid>`，与 [latestPostOf] 走的是同一条链路）。
     *
     * ★ 接口与「用户主页 → 微博列表」**完全同一个**，只是 uid 换成自己的。
     * ★ 只读（GET），不消耗额度。
     * ★ 会阻塞，必须在后台线程调用。
     *
     * ★★ 与 [topicPosts] 同理，刻意**不收 `context`**：不弹东西、也不 dump 落盘
     *   （时间线整页 JSON 同样很大）。要看的是「读到几条 / 其中几条是转发」，
     *   那两行已经进互动日志，界面上就能读。
     *
     * ★★★ 返回值**可空**，这个区分是**故意的**：
     *   · `null`      = **拿不到**（没 Cookie / 取不到自己的 uid / 回包解析不了）
     *   · `空列表`    = 真的读到了，只是最近一条微博都没有
     *   ⇒ 调用方对 `null` 必须按 **UNKNOWN** 处理（宁可这一步不做，
     *     也不能把「不知道转没转过」当成「没转过」去重复转发）。
     *
     * @param limit 最多解析多少条（只读最近这些条；再往前的历史不管）
     */
    fun ownTimeline(account: WeiboAccount, limit: Int = 20): List<TimelinePost>? {
        val cookie = account.cookie
        val uid = ownUid(account)
        if (cookie.isBlank() || uid.isBlank()) {
            InteractTrace.log("[超Like] 时间线读不到：cookie 或 uid 为空")
            return null
        }
        val profile = httpGet(
            "https://m.weibo.cn/api/container/getIndex?type=uid&value=" + uid,
            cookie, SUPERLIKE_LIMIT
        )
        val containerId = parseWeiboContainer(profile.full) ?: (WEIBO_TAB_PREFIX + uid)
        val list = httpGet(
            "https://m.weibo.cn/api/container/getIndex?type=uid&value=" + uid +
                "&containerid=" + containerId,
            cookie, SUPERLIKE_LIMIT
        )
        InteractTrace.log("[超Like] 个人时间线 containerid=" + containerId + " → " + list.head)
        val out = mutableListOf<TimelinePost>()
        try {
            val cards = JSONObject(list.full).optJSONObject("data")?.optJSONArray("cards")
                ?: run {
                    InteractTrace.log("[超Like] 时间线读不到：回包里没有 data.cards")
                    return null
                }
            for (i in 0 until cards.length()) {
                val card = cards.optJSONObject(i) ?: continue
                collectTimeline(card.optJSONObject("mblog"), out, limit)
                val group = card.optJSONArray("card_group")
                if (group != null) {
                    for (j in 0 until group.length()) {
                        collectTimeline(group.optJSONObject(j)?.optJSONObject("mblog"), out, limit)
                    }
                }
                if (out.size >= limit) break
            }
        } catch (_: Throwable) {
            InteractTrace.log("[超Like] 时间线读不到：回包解析失败")
            return null
        }
        InteractTrace.log(
            "[超Like] 时间线解析出 " + out.size + " 条，其中转发 " +
                out.count { it.repostedMid.isNotBlank() } + " 条"
        )
        return out
    }

    /** 收一条时间线 mblog：去重、跳过空 id、取出「被转发的原微博 id」。 */
    private fun collectTimeline(mblog: JSONObject?, out: MutableList<TimelinePost>, limit: Int) {
        if (mblog == null || out.size >= limit) return
        val mid = mblog.optString("id")
        if (mid.isBlank()) return
        if (out.any { it.mid == mid }) return
        out.add(
            TimelinePost(
                mid,
                oneLine(mblog.optString("text")).take(30),
                mblog.optJSONObject("retweeted_status")?.optString("id").orEmpty()
            )
        )
    }

    /** 用评论列表接口核对一条微博在不在。 */
    private fun checkPost(context: Context, mid: String, cookie: String, suffix: String): TargetCheck {
        val response = probe(
            context, "（预演）评论列表 mid=" + mid,
            "https://m.weibo.cn/comments/hotflow?id=" + mid + "&mid=" + mid + "&max_id_type=0",
            cookie
        )
        val state = postState(response.full)
        val detail = when (state) {
            TargetState.EXISTS -> context.getString(R.string.interact_check_exists, mid)
            TargetState.NOT_EXISTS -> context.getString(R.string.interact_check_not_exists, mid)
            TargetState.UNKNOWN -> context.getString(R.string.interact_check_unknown_post, mid)
        } + suffix
        return TargetCheck(mid, state, detail)
    }

    /**
     * 从 `/comments/hotflow` 的回包判断微博在不在。
     *
     * ★★★★ 第 54 期**重写判据**。
     *
     * ★ 起因：2026-10-03 19:34 用户点「试跑一次」，一条**真实存在**的微博
     *   被判成「没能确认」（`UNKNOWN`），试跑当场中止。
     *
     * ★ 病因：第 46 期的判据写死了一句文案「快来发表你的评论吧」，
     *   而微博对「这条微博还没有评论」这件事**会换着说法回**：
     *     · 2026-10-02 实测：msg = 「快来发表你的评论吧」
     *     · 2026-10-03 实测：msg = 「还没有人评论哦~快来抢沙发！」
     *   同一个状态、两种文案 ⇒ **按字面匹配的判据迟早会烂**。
     *
     * ★ 第 54 期把「合法 mid / 非法 mid」的回包逐条测了一遍
     *   （**不带 Cookie 也能复现** ⇒ 结论不依赖任何账号状态）：
     *
     *     输入                        回包要点                            结论
     *     --------------------------  ---------------------------------  ----------
     *     真 mid、有评论              ok:1 + data.data 数组               EXISTS
     *     真 mid、没评论（文案 A）    ok:0 + msg（快来发表…）             EXISTS
     *     真 mid、没评论（文案 B）    ok:0 + msg（还没有人评论…）         EXISTS
     *     假 mid（1111…）             errno:20000 + extra:param error     NOT_EXISTS
     *     数字超范围（9999…9）        errno:20000 + extra:value invalid   NOT_EXISTS
     *     合法格式但查不到（4e15）    只有 ok:0，**没有 msg、没有 errno**  UNKNOWN
     *     空 mid                      errno:100013 + msg:参数缺失          UNKNOWN
     *
     *   ⇒ 判据从「认一句文案」改成「认**结构**」：
     *     · **报错就是不在**：`errno` 有值（20000 = 参数非法）⇒ `NOT_EXISTS`；
     *     · **答了话就是在**：`errno` 缺失 **且** `msg` 非空 **且** 不像报错
     *       ⇒ `EXISTS`。依据：微博对非法 mid **一律**带 `errno` + `extra`
     *       （extra 里明写 param error / value invalid）；肯回一句友好话，
     *       说明它认得这个 mid；
     *     · 其余 ⇒ `UNKNOWN`。
     *
     *   ★ 为什么最后那条必须留在 `UNKNOWN`：上表「只有 ok:0」那一行就是反例 ——
     *     它既没有 `errno` 也没有 `msg`，**不许用「没报错 ⇒ 存在」蒙过去**。
     *     ok:0 也可能是「这条微博不能评论」，宁可挡住，也不许猜。
     *
     * ★ 仍然是三态、**只认正面证据**：`UNKNOWN` 与 `NOT_EXISTS` 一样是「不许发」。
     *   第 46 期被 ok:0 骗开过闸门，这条规矩不松。
     * ★ 本函数是**纯解析**：不联网、不写任何状态、不碰任何核心链路。
     */
    private fun postState(body: String): TargetState = try {
        val json = JSONObject(body)
        val errno = json.optString("errno")
        val msg = json.optString("msg")
        when {
            // ① 明确报错 ⇒ 不在（20000 = 参数非法；两个中文短语是旧判据，留着兜底）
            errno == "20000" || msg.contains("不存在") || msg.contains("已删除") ->
                TargetState.NOT_EXISTS
            // ② 真拉到了评论列表 ⇒ 在
            json.optInt("ok", -1) == 1 ||
                json.optJSONObject("data")?.optJSONArray("data") != null ->
                TargetState.EXISTS
            // ③ 没报错、而且答了话 ⇒ 在（★ 第 54 期新增，修的就是这一条）
            errno.isBlank() && msg.isNotBlank() && !looksLikeError(msg) ->
                TargetState.EXISTS
            else -> TargetState.UNKNOWN
        }
    } catch (_: Throwable) {
        TargetState.UNKNOWN
    }

    /**
     * `msg` 看着像「报错口气」吗？词表见 [ERROR_WORDS]。
     *
     * ★ 第 54 期加的一层保险，只服务于 [postState] 的判据 ③。
     *   挡到 ⇒ 退回 `UNKNOWN` ⇒ 不许发。**方向是安全的**：
     *   最坏情况只是多挡住一次真发送，绝不会多发。
     * ★ 纯字符串判断，不联网、不写状态。
     */
    private fun looksLikeError(msg: String): Boolean =
        ERROR_WORDS.any { msg.contains(it) }

    /**
     * 从主页容器回包里解析「微博」tab 的 `containerid`。
     *
     * 走的是 `data.tabsInfo.tabs[]`，找 `tabKey == "weibo"` 那一项。
     * ★ 解析失败一律返回 null（调用方有回退值），**不让自检因为结构变了就崩**。
     */
    private fun parseWeiboContainer(body: String): String? = try {
        val tabs = JSONObject(body)
            .optJSONObject("data")
            ?.optJSONObject("tabsInfo")
            ?.optJSONArray("tabs")
        var found: String? = null
        if (tabs != null) {
            for (index in 0 until tabs.length()) {
                val tab = tabs.optJSONObject(index) ?: continue
                if (tab.optString("tabKey") != "weibo") continue
                val id = tab.optString("containerid")
                if (id.isNotBlank()) {
                    found = id
                    break
                }
            }
        }
        found
    } catch (_: Throwable) {
        null
    }

    /**
     * 从微博列表回包里解析**第一条**微博。
     *
     * ★ `cards` 里不全是微博：还有主页头、关注卡片、`card_group` 等，
     *   所以要**逐张找带 `mblog` 的那一张**，不能直接取 `cards[0]`。
     * ★ `mblog.id` 是**字符串**（`optString` 对数字也兼容，防止哪天变成数字）。
     * ★ 正文是 HTML，顺手把标签剥掉再截断 —— 这是给人看的摘要。
     */
    private fun parseLatestPost(body: String): LatestPost? = try {
        val cards = JSONObject(body).optJSONObject("data")?.optJSONArray("cards")
        var found: LatestPost? = null
        if (cards != null) {
            for (index in 0 until cards.length()) {
                val mblog = cards.optJSONObject(index)?.optJSONObject("mblog") ?: continue
                val mid = mblog.optString("id")
                if (mid.isBlank()) continue
                found = LatestPost(
                    mid,
                    mblog.optString("bid"),
                    mblog.optString("text").replace(Regex("<[^>]+>"), " ").trim().take(40),
                    mblog.optInt("comments_count", -1)
                )
                break
            }
        }
        found
    } catch (_: Throwable) {
        null
    }

    /**
     * 列出 Cookie 的**字段名**（不取值），逗号分隔。
     *
     * ★ 用途：确认发 POST 需要的字段在不在（例如 CSRF 类的 token）。
     *   **只记名字**，因为这个日志用户会看到、也会贴给别人。
     */
    private fun cookieNames(cookie: String): String =
        cookie.split(";")
            .map { it.trim().substringBefore("=").trim() }
            .filter { it.isNotEmpty() }
            .joinToString(", ")

    /** 从 Cookie 串里取某个字段的值；取不到返回空串。 */
    private fun cookieValue(cookie: String, name: String): String =
        cookie.split(";")
            .map { it.trim() }
            .firstOrNull { it.substringBefore("=").trim() == name }
            ?.substringAfter("=", "")
            ?.trim()
            .orEmpty()

    /** 发一个 GET，把「状态码 + 回包开头」记进黑匣子，完整回包写进落盘文件，并返回回包。 */
    private fun probe(context: Context, label: String, url: String, cookie: String): ProbeResponse {
        val response = httpGet(url, cookie)
        InteractTrace.log("[自检] " + label + " → " + response.head)
        if (response.full.isNotBlank()) {
            InteractTrace.log("[自检] 回包：" + oneLine(response.full.take(BODY_LIMIT)))
        }
        dump(context, label, url, response)
        return response
    }

    /**
     * 发一个 POST，把「状态码 + 回包开头」记进黑匣子，完整回包写进落盘文件，并返回回包。
     *
     * ★ 与 [probe] 的唯一区别：会把**请求体**也记进落盘文件 ——
     *   探接口的时候，「发了什么」和「回了什么」一样重要。
     */
    private fun probePost(
        context: Context,
        label: String,
        url: String,
        cookie: String,
        form: Map<String, String>
    ): ProbeResponse {
        val response = httpPost(url, cookie, form)
        InteractTrace.log("[自检] " + label + " → " + response.head)
        if (response.full.isNotBlank()) {
            InteractTrace.log("[自检] 回包：" + oneLine(response.full.take(BODY_LIMIT)))
        }
        dump(context, label, url, response, form)
        return response
    }

    /**
     * 只读 GET。
     *
     * ★ 刻意**关掉自动跳转**（`instanceFollowRedirects = false`）：
     *   没登录时微博会 302 跳到 `visitor.passport.weibo.cn`，
     *   看见这个 302 本身就是结论（「这个账号的登录态在 m.weibo.cn 上没了」）。
     *   自动跟过去只会拿到一个登录页的 HTML，反而看不出发生了什么。
     *
     * ★★ 第 65 期：加了 [limit]（默认 [FILE_LIMIT]）—— 抓 m 站前端 JS 包时
     *   默认上限只够读到包开头，「评论点赞」这类冷门接口名读不到。
     *   调用方按需放大（见 [JS_LIMIT]），其余调用一律沿用默认值，行为不变。
     */
    private fun httpGet(url: String, cookie: String, limit: Int = FILE_LIMIT): ProbeResponse {
        return try {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                instanceFollowRedirects = false
                setRequestProperty("Cookie", cookie)
                setRequestProperty("User-Agent", UA)
                setRequestProperty("Referer", "https://m.weibo.cn/")
                setRequestProperty("X-Requested-With", "XMLHttpRequest")
                setRequestProperty("MWeibo-Pwa", "1")
                // ★★★★ 第 52 期**撤掉**（原第 45 期加的）：这里原来把账号 Cookie 里那份
                //    XSRF-TOKEN 塞进请求头 X-XSRF-TOKEN。第 51 期把「能看不能发」查清之后，
                //    这条已经不成立了 ——
                //    账号 Cookie 里那份属于**上一次登录**，服务器会在页面加载时下发当前会话的新值；
                //    按 RFC 6265，同名同 path 的 Cookie「创建更早的排前面」，浏览器取第一个
                //    ⇒ 拿旧值去发写请求，会被服务器当成非法令牌（403 / errno 100006）。
                //    ★ 而 GET 本来就不做这个校验 ⇒ 这个头在只读请求上**始终是空转**，
                //      留着只会误导后来的人以为「Cookie 里那份令牌是可信的」。
                //    ⇒ 只读请求干脆不带它；真正需要它的写请求见 httpPost（用**现取的** st）。
            }
            try {
                val code = connection.responseCode
                val stream: InputStream? =
                    if (code in 200..299) connection.inputStream else connection.errorStream
                val body = readLimited(stream, limit)
                val location = connection.getHeaderField("Location").orEmpty()
                val head = if (location.isNotBlank()) {
                    "HTTP " + code + " → " + location
                } else {
                    "HTTP " + code + " · " + body.length + " 字符"
                }
                ProbeResponse(head, body)
            } finally {
                try {
                    connection.disconnect()
                } catch (_: Throwable) {
                }
            }
        } catch (error: Throwable) {
            ProbeResponse("请求失败：" + (error.message ?: error.javaClass.simpleName), "")
        }
    }

    /**
     * ★★★★ 第 46 期新增：**带副作用的 POST**（本文件里唯一的写操作入口）。
     *
     * ★★ 安全设计（三件事，缺一不可）：
     *   1. **调用方必须先证明目标微博不存在**（[probeSend] 第 ② 步）。
     *      这个函数自己不做这个判断 —— 它只是个通道，判断在调用方，且必须做。
     *   2. **关掉自动跳转**：与 GET 同理，302 跳登录页本身就是结论。
     *   3. **不重试**：失败就是失败，把原因原样记下来。
     *      自动重试在写操作上是危险的 —— 第一次可能其实成功了，只是回包没读到。
     */
    private fun httpPost(
        url: String,
        cookie: String,
        form: Map<String, String>
    ): ProbeResponse {
        return try {
            val payload = form.entries.joinToString("&") { entry ->
                URLEncoder.encode(entry.key, "UTF-8") + "=" + URLEncoder.encode(entry.value, "UTF-8")
            }
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                instanceFollowRedirects = false
                setRequestProperty("Cookie", cookie)
                setRequestProperty("User-Agent", UA)
                setRequestProperty("Referer", "https://m.weibo.cn/")
                setRequestProperty("X-Requested-With", "XMLHttpRequest")
                setRequestProperty("MWeibo-Pwa", "1")
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                // ★★★★ 第 52 期修正：X-XSRF-TOKEN 必须用**现取的** st（请求体里那个），
                //    绝不能用账号 Cookie 里那份 —— 后者是**上一次登录**留下的，
                //    按 RFC 6265 会**遮住**服务器新下发的值 ⇒ 写操作必被拒（403 / errno 100006）。
                //    ★ 头与体用**同一个值**：微博 Web 端就是这么发的
                //      （浏览器里 XSRF-TOKEN 这个 Cookie 与 st 本来就是同一个值的两面）。
                //    ★ 取不到 st 就**不发这个头** —— 宁可不带，也不带一个陈旧的。
                val xsrf = form["st"].orEmpty()
                if (xsrf.isNotBlank()) setRequestProperty("X-XSRF-TOKEN", xsrf)
            }
            try {
                connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream: InputStream? =
                    if (code in 200..299) connection.inputStream else connection.errorStream
                val body = readLimited(stream, FILE_LIMIT)
                val location = connection.getHeaderField("Location").orEmpty()
                val head = if (location.isNotBlank()) {
                    "HTTP " + code + " → " + location
                } else {
                    "HTTP " + code + " · " + body.length + " 字符"
                }
                ProbeResponse(head, body)
            } finally {
                try {
                    connection.disconnect()
                } catch (_: Throwable) {
                }
            }
        } catch (error: Throwable) {
            ProbeResponse("请求失败：" + (error.message ?: error.javaClass.simpleName), "")
        }
    }

    /** 读前 [limit] 个字符就停 —— 不要把几 MB 的 JSON 整个读进内存。 */
    private fun readLimited(stream: InputStream?, limit: Int): String {
        if (stream == null) return ""
        return try {
            stream.bufferedReader(Charsets.UTF_8).use { reader ->
                val buffer = CharArray(limit)
                var total = 0
                while (total < limit) {
                    val read = reader.read(buffer, total, limit - total)
                    if (read <= 0) break
                    total += read
                }
                String(buffer, 0, total)
            }
        } catch (_: Throwable) {
            ""
        }
    }

    // ---------------------------------------------------------------- 落盘

    /**
     * 完整回包写到 App 私有的 `files/interact_probe.txt`。
     *
     * ★ 为什么不直接塞进黑匣子：`/container/getIndex` 的回包动辄几十 KB，
     *   塞进去会把黑匣子（300 条环形缓冲）一次刷满，
     *   用户想看的那几条「动作 / 结果」全被挤掉 —— 日志就废了。
     *   分开存：**黑匣子给人看，这个文件给排查用**。
     *
     * ★ 写盘失败一律静默：自检不能反过来把界面搞崩。
     *
     * ★★ 第 46 期补：POST 的**请求体**也会记下来（探接口时「发了什么」同样重要），
     *   但 `st` 的值会被换成 `<不记录>` —— 它是会话票据，和 Cookie 一样不该落进任何文件。
     */
    private fun dump(
        context: Context,
        label: String,
        url: String,
        response: ProbeResponse,
        form: Map<String, String>? = null
    ) {
        try {
            val file = File(context.filesDir, DUMP_FILE)
            val request = if (form == null) {
                ""
            } else {
                "【请求体】" + form.entries.joinToString("&") { entry ->
                    entry.key + "=" + (if (entry.key == "st") "<不记录>" else entry.value)
                } + "\n"
            }
            file.appendText(
                "========== " + stampFormat.format(Date()) + "  " + label + "\n" +
                    url + "\n" +
                    request +
                    response.head + "\n" +
                    response.full + "\n\n"
            )
        } catch (_: Throwable) {
        }
    }

    private fun resetDump(context: Context) {
        try {
            val file = File(context.filesDir, DUMP_FILE)
            if (file.exists()) file.delete()
        } catch (_: Throwable) {
        }
    }

    /**
     * 把回包里的 `\uXXXX` 转义还原成真汉字。
     *
     * ★★★★ 第 46 期教训（很隐蔽，值得记）：
     *   微博的 JSON 里中文是 **`\uXXXX` 转义**的 —— 回包原文是
     *   `{"ok":0,"msg":"\u8bf7\u6c42\u975e\u6cd5"}`，而不是 `{"ok":0,"msg":"请求非法"}`。
     *   于是所有「拿中文关键词判读回包」的规则**全部静默失效**：
     *   代码里比的是 `请求非法`，回包里躺的是 `\u8bf7\u6c42\u975e\u6cd5`，永远对不上。
     *
     * ★ 为什么难发现：黑匣子落盘时把 `&` 之类还原了，人眼看到的是**汉字**，
     *   会以为判读规则也在比汉字 —— 只有工具报「未归类」时才露馅。
     *   第 46 期正是靠这个「未归类」才没漏掉 ⑥ 那一格的关键结论。
     *   ⇒ **判读之前必须先还原。**
     */
    private fun unescapeUnicode(text: String): String =
        Regex("""\\u([0-9a-fA-F]{4})""").replace(text) { m ->
            m.groupValues[1].toInt(16).toChar().toString()
        }

    /** 压成一行：黑匣子是「一行一条」的结构，回包里的换行会把日志拆散。 */
    private fun oneLine(body: String): String =
        unescapeUnicode(body).replace(Regex("""\s+"""), " ").trim()

    /** 记一条「还没开始探就结束了」的原因，并作为摘要返回。 */
    private fun note(summary: MutableList<String>, line: String): String {
        InteractTrace.log("[自检] " + line)
        summary.add(line)
        return summary.joinToString("\n")
    }
}
