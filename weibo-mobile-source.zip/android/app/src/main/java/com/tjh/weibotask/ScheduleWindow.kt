package com.tjh.weibotask

import java.util.Calendar

/**
 * ★★★★ 第 120 期：**时间窗（限制运行时间段）的公共判定数学**。
 *
 * ## 为什么单独一个文件
 *
 * ① 签到排程（[Prefs] 里的**全局**窗口 `windowEnabled` / `windowStartMinute` /
 *   `windowEndMinute`）与 ② 发帖任务（[PostTask] 每条任务自己的 `limitWindow` /
 *   `windowStartMinute` / `windowEndMinute`）都要回答同一个问题：
 *   「现在这个『当天第几分钟』，落不落在 [start, end] 这个窗口里？」
 *
 * 这两处**必须共用同一份口径** —— 尤其「跨午夜」（`start > end`，如 22:00–02:00）
 *   的边界。各写一套，迟早有一处把 22:00–02:00 判成「全天不在窗内」，
 *   表现就是「设了夜间窗口却一次都不跑」，而且不报错、不出告警、编译通过。
 *
 * ## 硬纪律
 *
 * - 本对象**纯函数**：只做时间数学，不读不写 [Prefs]、不碰闹钟、不碰四条核心链路。
 * - 删掉它不影响任何核心功能（①/② 各自内联一份等价逻辑即可，只是会重复）。
 */
object ScheduleWindow {

    /** 取 [calendar] 的「当天第几分钟」（0..1439）。 */
    fun minuteOfDay(calendar: Calendar): Int =
        calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)

    /**
     * 某分钟 [minute] 是否落在窗口 [start, end] 内；**支持跨午夜**。
     *
     * - 同日内（`start < end`）：`start <= minute <= end`。
     * - 跨午夜（`start > end`）：`minute >= start || minute <= end`
     *   （如 22:00–02:00 ⇒ 22:00 之后或 02:00 之前都算窗内）。
     * - 退化窗口（`start == end`）：视为**不限制**（恒在窗内）。
     *   ★ 调用方（② [PostTask] / ① [Prefs]）在读取窗口字段时都应把
     *     `start == end` 当成「窗口没设」，这里兜底再挡一次，双保险。
     */
    fun inWindow(minute: Int, start: Int, end: Int): Boolean {
        if (start == end) return true
        return if (start < end) minute in start..end
        else minute >= start || minute <= end
    }

    /**
     * 当前**在窗外**时，下一次窗口**起点**的时刻（毫秒时间戳）。
     *
     * ★ 只应在 [inWindow] 为 false 时调用（P2「等窗口开启再跑」的重挂目标）。
     *
     * - 同日内（`start <= end`）：
     *   · 今天还没到起点 → 返回**今天**的起点；
     *   · 今天已过整段窗口 → 返回**明天**的起点（顺延次日）。
     * - 跨午夜（`start > end`）：窗外只可能是「今天已过 end 但还没到 start」
     *   （如 03:00，窗口 22:00–02:00）或「今天还没到 start」（如 15:00）——
     *   两种情况的下一起点都是**今天 start 时刻**（今晚），故直接返回今天起点。
     *
     * ★ 返回的时刻总是**严格晚于 now 的未来时刻**：同日内「今天还没到起点」时
     *   今天起点 > now；「今天已过」时顺延到明天；跨午夜「今晚」也 > now。
     *   ⇒ 重挂后闹钟到点必然落在窗内（`now >= start`），不会无限重挂。
     */
    fun nextWindowStartMillis(now: Calendar, start: Int, end: Int): Long {
        val todayStart = Calendar.getInstance().apply {
            timeInMillis = now.timeInMillis
            set(Calendar.HOUR_OF_DAY, start / 60)
            set(Calendar.MINUTE, start % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return if (start <= end) {
            if (now.before(todayStart)) {
                todayStart.timeInMillis
            } else {
                todayStart.add(Calendar.DAY_OF_YEAR, 1)
                todayStart.timeInMillis
            }
        } else {
            todayStart.timeInMillis
        }
    }
}
