package com.tjh.weibotask

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 滑块样本采集器（第 70 期新增）。
 *
 * ## 它解决什么问题
 *
 * 要把 OpenCV 从包里拿掉（.so 归零 ⇒ 16KB 页面对齐问题消失、体积再降约 16.6 MB），
 * 前提是先用纯 Kotlin 复刻 `TM_CCORR_NORMED` + mask，并且**证明复刻结果与 OpenCV 逐像素一致**。
 * 而「证明一致」需要**真实样本**：网易易盾的 bg / front 图。
 *
 * 而现实是：`桌面\weibo-captcha\images\` 只有 **2 组**（2026-09-25 抓的），
 * 那份 `offline-analysis.json` 自己写着 `"success_baseline_status": "insufficient"`。
 * 手机侧**没有任何机制**把验证图留下来 —— 图片只活在内存里，
 * `downloadImage()` 用完即弃，`SliderTrace` 也刻意不含二进制。
 *
 * 本对象就是补上这一环：在**识别之前**把 bg/front 原图落盘，攒够样本再谈删 OpenCV。
 *
 * ## 为什么必须挂在 [OverlayVerifyHost.shouldInterceptRequest] 上
 *
 * `downloadImage()` 走的是 `HttpURLConnection`，它**不经过 WebView 的资源加载**，
 * 所以 JS 钩子（`NET_HOOK_JS`）根本看不到这两张图 —— 钩子 hook 的是页面自己发的 XHR/fetch。
 * 真正能拿到原始字节的位置只有一处：WebView 请求图片资源时的 `shouldInterceptRequest`。
 * 而且那里拿到的是**原始响应体**，避免了 `downloadImage()` 解码后
 * `inPreferredConfig = ARGB_8888` 带来的颜色空间转换 —— 样本必须与 OpenCV 看到的完全一致。
 *
 * ## ★ 行为零变化（这一条是硬约束，不要随手扩大）
 *
 * - `shouldInterceptRequest` **返回 null** ⇒ WebView 照常自己发请求、自己加载。
 *   本对象只**旁观**字节流，不改 URL、不改 header、不改响应、不注入任何东西。
 * - 不写 `Prefs`（核心数据层）、不写 `weibo_task_secure.xml`；另开本应用私有目录。
 * - 采样失败一律静默；目录写满/无权限/磁盘满都只影响采样，**不影响验证流程**。
 * - **不参与任何判定**：没有任何业务代码读它的返回值。整个删掉，
 *   签到/发帖/验证行为逐字节不变。
 *
 * ## 怎么开关
 *
 * [enabled] 交付态应为 `false`（不落盘、不占空间；正常用户根本用不到）。
 * 本包（第 71 期采集包）临时置 `true`，平时过滑块自动攒样本，攒够后改回 `false` 出交付包。
 * 拉取目录：`/sdcard/Android/data/com.tjh.weibotask/files/slider_samples/`。
 *
 * > 用外部私有目录而不是 `filesDir`：`adb pull` 不用 root，也不受 `run-as` 限制。
 * > 卸载 App 会一起清掉，正是想要的语义。
 *
 * ## 一键回滚
 *
 * 把 [enabled] 置回 `false` ⇒ 采集静默、行为等同第 69 期。
 */
object SliderSampler {

    /**
     * 采样总开关。
     *
     * ★ 交付态应为 `false`（不落盘、不占空间；正常用户根本用不到）。
     *
     * ★★★ 本包是**自用采集包**：`enabled = true`，平时过滑块就自动攒样本。
     *   出正式交付包时必须改回 `false`（参见 `_backup_before_sampler_on_20261005/`）。
     *
     * 改这个值需要重新装包（是编译期常量语义的开关，不做运行时切换，
     * 避免「以为开了其实没开」这种取证事故）。
     *
     * ★ 第 73 期 A：样本已采够（8 组 > 需求 5 组），**交付态改回 `false`**。
     */
    @Volatile
    var enabled: Boolean = false

    /** 单次会话最多落盘多少组（bg+front 算一组）。防止长时间挂着把空间吃光。 */
    private const val MAX_SETS = 60

    /** 单张图最大字节数，超过就跳过（正常易盾图 10~40 KB）。 */
    private const val MAX_BYTES = 512 * 1024

    /** 目录名（外部私有 files 下）。 */
    private const val DIR_NAME = "slider_samples"

    /** 同一次页面会话内，同一张图的指纹记账，避免同一张图落盘 N 次。 */
    private val seen = LinkedHashSet<String>()

    /** 页面加载过的 necaptcha 图 URL 清单（只记条数用）。 */
    private val urlList = ArrayList<String>()

    /** 已落盘张数（bg 和 front 分开计数）。 */
    private var savedCount = 0

    private val idFormat = SimpleDateFormat("MMdd-HHmmss", Locale.US)
    private var seq = 0

    /**
     * 只记「页面加载过哪些 necaptcha 图 URL」，不取字节。
     *
     * ★ 为什么只记 URL 不在这里落盘：`WebResourceResponse` 的流只能读一次，
     *   在 `shouldInterceptRequest` 里读走 body 再返回自定义响应，等于**接管**资源加载 ——
     *   那是行为变化，越界了。而如果为了拿字节在拦截器里另开一条 `HttpURLConnection`，
     *   又会产生**第二次网络请求**（易盾可能因重复请求给不同图，采样反而污染）。
     *
     *   所以：URL 清单在这里记（零成本、零请求），**字节在
     *   [YidunAutoSlider.downloadImage] 里顺手落盘** —— 那边本来就要下载原图，
     *   字节已经完整回来，落盘只是多一次 `FileOutputStream`，不多发一个请求。
     */
    @Synchronized
    fun noteUrl(url: String) {
        if (!enabled) return
        if (classify(url) == null) return
        if (urlList.size < MAX_SETS * 2) urlList.add(url)
    }

    /** 已知的 necaptcha 图 URL（只给诊断报告显示条数用）。 */
    @Synchronized
    fun urlCount(): Int = urlList.size

    /**
     * 从一张已下载好的原图字节里采一份。
     *
     * ★ 由 [YidunAutoSlider.downloadImage] 在**拿到原始响应体之后**调用 ——
     *   那里是唯一「字节已经在手上、且没有多花一次请求」的位置。
     *   本方法只写文件，不参与任何判定。
     *
     * ★ 第 71 期取证补丁：新增 [kindHint]。
     *
     *   为什么：第 70 期的 `classify()` 是**读 URL 猜**（「bg 在 .../get、拼图在 .../jigsaw」），
     *   真机上跑完两轮撞滑块、样本恒 0，说明 URL 结构和推论不符。
     *   而 `solveOnce()` 里 `downloadImage(bgUrl)` / `downloadImage(jigsawUrl)`
     *   **调用位置本身就百分之百知道这张图是什么** —— 这是结构判据，比猜 URL 可靠。
     *   [kindHint] 非空时直接采用，`classify()` 只作为兜底（供 `noteUrl()` 用）。
     *
     * @param context  宿主 Context（取外部私有目录）
     * @param url      图片 URL（用来区分 bg / front，也用于留痕）
     * @param bytes    原始响应体（HttpURLConnection 回来的原文，未解码）
     * @param kindHint 调用方告知的图片种类（`bg` / `front`），可为 null
     */
    @Synchronized
    fun capture(context: Context?, url: String?, bytes: ByteArray?, kindHint: String?) {
        if (!enabled) return
        // ★ 第 71 期取证补丁：**无条件**留一行「拿到了什么 URL」，再谈分类。
        //
        //   为什么必须先记 URL：第 70 期 `classify()` 里「bg 在 .../get、拼图在 .../jigsaw」
        //   是**没有实测证据的推论**（MEMORY 坑 4：注释里的推论大多是错的）。
        //   真机上跑完两轮撞滑块，样本数恒为 0，说明分类把两张图都漏了。
        //   要定位到底是「URL 结构判断错」还是「根本没调到这里」，就得先看到原样 URL。
        //   ★ 只记结构，不记查询串内容（`redact()` 会隐藏 `?...`），符合取证规约。
        val guessed = kindHint ?: url?.let { classify(it) }
        if (url != null && url.isNotBlank()) {
            // ★ 单独把「路径最后一段（去掉查询串）」也打出来：易盾图片常是
            //   `https://necaptcha.nosdn.127.net/<hash>.png?...`，查询串里才是票据。
            //   `SliderTrace.redact()` 会把 `?...` 整段换成 `<已隐藏>`，于是文件名
            //   会连查询串一起被吃掉；这里先用 `substringBefore('?')` 切出来再记。
            val pathTail = url.substringBefore('?').substringAfterLast('/')
            SliderTrace.log(
                "[采样探测] kind=" + (guessed ?: "未识别") + " hint=" + (kindHint ?: "-") +
                    " bytes=" + (bytes?.size ?: -1) + " tail=" + pathTail + " url=" + url
            )
        }
        if (context == null || url.isNullOrBlank() || bytes == null || bytes.isEmpty()) return
        if (bytes.size > MAX_BYTES) return
        val kind = guessed ?: return
        if (savedCount >= MAX_SETS) return
        val fp = kind + "|" + bytes.size + "|" + url.substringAfterLast('/').substringBefore('?')
        if (!seen.add(fp)) return
        try {
            val dir = File(context.getExternalFilesDir(null), DIR_NAME)
            if (!dir.exists() && !dir.mkdirs()) return
            seq += 1
            savedCount += 1
            val name = idFormat.format(Date()) + "-" + String.format(Locale.US, "%02d", seq) + "-" + kind
            FileOutputStream(File(dir, name + ".jpg")).use { it.write(bytes) }
            File(dir, name + ".txt").writeText(url)
            SliderTrace.log("[采样] " + kind + " " + bytes.size + "B -> " + name)
        } catch (_: Throwable) {
            // 采样失败一律静默：取证不能反过来影响主流程。
        }
    }

    /**
     * 判断这张图是不是我们关心的滑块素材。
     *
     * ★ 只认**路径结构**，不认文案（第 60 期教训）：
     *   易盾的图都在 `necaptcha` 域下，bg 在 `.../get`，拼图块在 `.../jigsaw`。
     *   这里用「域名含 necaptcha / 路径含 jigsaw」的结构特征，不依赖任何中文或 UI 文案。
     */
    private fun classify(url: String): String? {
        val u = url.lowercase(Locale.US)
        if (!u.contains("necaptcha")) return null
        return when {
            u.contains("jigsaw") -> "front"
            u.contains("/get") -> "bg"
            else -> null
        }
    }

    /**
     * 把当前已采到的样本打成**一个可粘贴的字符串**。
     *
     * 手机上没有 adb 时，用「复制排查信息」那种方式把样本带出来（base64），
     * 在 PC 侧还原成文件。这是备用通道 —— 首选还是 `adb pull`。
     *
     * ★ 只在用户主动点按钮时调用；不参与任何判定。
     */
    @Synchronized
    fun dumpBase64(context: Context?): String {
        val dir = try {
            context?.let { File(it.getExternalFilesDir(null), DIR_NAME) }
        } catch (_: Throwable) {
            null
        } ?: return ""
        if (!dir.exists()) return ""
        val files = dir.listFiles()?.filter { it.isFile && it.name.endsWith(".jpg") }
            ?.sortedBy { it.name } ?: return ""
        if (files.isEmpty()) return ""
        val sb = StringBuilder()
        sb.append("count=").append(files.size).append('\n')
        for (f in files) {
            try {
                val b64 = Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
                sb.append(f.name).append('\n').append(b64).append('\n')
                val txt = File(dir, f.name.removeSuffix(".jpg") + ".txt")
                if (txt.exists()) sb.append("url=").append(txt.readText().trim()).append('\n')
            } catch (_: Throwable) {
            }
        }
        return sb.toString()
    }

    /** 已采组数（只给诊断报告显示用）。 */
    @Synchronized
    fun count(context: Context?): Int {
        return try {
            val dir = File(context?.getExternalFilesDir(null), DIR_NAME)
            dir.listFiles()?.count { it.isFile && it.name.endsWith(".jpg") } ?: 0
        } catch (_: Throwable) {
            0
        }
    }

    /** 复位记账（每次新的验证会话开始时调一次），避免 seen 无限增长。 */
    @Synchronized
    fun resetSession() {
        seen.clear()
    }

    /** 供调试：把字节流压成 PNG 存下（仅当需要无损对照时用，当前未启用）。 */
    @Suppress("unused")
    private fun pngBytes(bmp: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        return out.toByteArray()
    }
}
