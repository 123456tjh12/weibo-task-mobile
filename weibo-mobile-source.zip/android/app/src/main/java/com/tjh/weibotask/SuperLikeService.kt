package com.tjh.weibotask

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.ArrayDeque

/**
 * ★★★★ 第 115 期（用户批准）：**超Like 编排的独立前台服务**。
 *
 * ## 为什么必须有它（用户原话）
 *
 * 「一届超like必须在这个页面待着，挂后台和切换到发帖或签到会立刻停止」。
 *
 * 改前编排跑在 [InteractActivity] 自己开的**普通后台线程**上（见它原来的
 * `launchSuperLike()`）。普通后台线程在应用退到后台后会被 Android 随时冻结 / 回收 ⇒
 * 用户一切走它就停。签到 / 发帖之所以稳，是因为它们跑在 [AgentService]
 * （前台服务 + 常驻通知，系统不会随便杀）。
 *
 * ## 为什么**不**复用 [AgentService]
 *
 * [AgentService] 是**核心链路①签到**的宿主，`onCreate` / `onStartCommand` 里
 * 全是签到 / 发帖 / 验证的状态（`Prefs.running`、维护循环、闹钟……）。
 * 把超Like 塞进去，就得在那几个方法里加分支 —— 那等于**动了核心链路**，
 * 而硬规则一要求四条核心链路（签到 / 发帖 / 验证 / 数据层）一行不动。
 * ⇒ 另起一个**只服务超Like**的前台服务：它只读写互动模块自己的
 * `interact_tasks.xml`（[InteractTaskStore]），对账号只做只读，不碰 [Prefs]、
 * 不碰 [AccountStore].save()、不碰 [WeiboClient]。
 *
 * ## 与 [InteractActivity] 的分工
 *
 * · 服务 = **执行**（跑 [SuperLikeRunner]）+ 持有运行态快照 [live]；
 * · 页面 = **显示**（每 500ms 轮询 [live]）+ 两个开关（[requestPause] / [requestStop]）。
 * ★ 页面**不再**自己开线程；`onDestroy` 也不再取消编排（这正是一开始要修的病）。
 *
 * ## 硬边界
 *
 * ★ 执行体与第 114 期的 [InteractActivity.launchSuperLike] 里的线程**逐字节等价**
 *   （只是宿主从 Activity 换成 Service、界面回调用 [live] 代替 `runOnUiThread`）。
 *   `100006` / [InteractProbe.ERRNO_NO_ST] 与用户点「停止」的收手语义一个字没变。
 * ★ 防重入标志（[running]）放在 companion object 里 —— **进程级、跨 Activity 实例有效**，
 *   这是修「同一帖子被评论两次」那个真 bug 的关键（见 [running] 的注释）。
 * ★ `START_NOT_STICKY`：**故意不自动重启**。一趟编排重启会重复发内容。
 */
class SuperLikeService : Service() {

    // ================================================================
    // ★★★★ 第 115 期（编译修正）：`Flags` 与 `Live` 必须是 [SuperLikeService] 的
    //   **直接嵌套类**，不能放进 `companion object` ——
    //   Kotlin 里 companion object 内的嵌套类**无法**用「外层类名.嵌套类」引用：
    //   `SuperLikeService.Live` 会报 `Unresolved reference: Live`
    //   （真编实测：InteractActivity.kt:609），而界面那侧正需要这个类型。
    //   ★ 放进类体后 `SuperLikeService.Live` 就是标准嵌套类引用，两侧都通。
    // ================================================================

    /**
     * ★★★ 第 115 期：**暂停 / 停止标志**。
     *
     * ★ 界面只翻这两个布尔，**绝不杀线程** —— 这一趟的落盘与收尾照常在
     *   原线程里做完（用户要能看到「停之前成了几条」）。
     * ★ 每次点「开始」都新建一个：上一趟的标志留着会让「停止」误伤下一趟。
     */
    class Flags {
        @Volatile var paused = false
        @Volatile var stopped = false
    }

    /**
     * ★★★★ 第 115 期：**运行态快照**（不可变）。
     *
     * ★ 页面可见时每 500ms 读一次 [live]。整对象替换（不是改字段）⇒
     *   读到的永远是一个自洽的快照，不会读到「一半新一半旧」。
     * ★ 判据全是**结构**（[runId] / [done]），界面**不许**去解析任何文案
     *   （本项目第 20 条纪律）。
     */
    class Live(
        /** 这一趟的唯一编号。界面靠它做「结果只处理一次」的凭据。 */
        val runId: Long,
        /** 这一趟一共几个账号（分母 = 账号数 × 每号目标）。 */
        val accountTotal: Int,
        /** 每个账号的首评目标数。 */
        val firstTargetEach: Int,
        /** 每个账号的转发目标数。 */
        val repostTargetEach: Int,
        /** 正在跑的账号 `label`（逐账号行靠它标「正在跑」）。 */
        val runningLabel: String,
        /** **已经跑完**的那些账号的首评成果。 */
        val firstBase: Int,
        /** **已经跑完**的那些账号的转发成果。 */
        val repostBase: Int,
        /** 当前账号这一趟的首评数。 */
        val firstOk: Int,
        /** 当前账号这一趟的转发数。 */
        val repostOk: Int,
        /** 给界面显示的一行动态文本（跑到哪一步了）。 */
        val message: String,
        /** 明细最近 3 行（刚发生了什么）。 */
        val logLines: List<String>,
        /** 这一趟是否已经收工（true = 可以显示结果了）。 */
        val done: Boolean,
        /** 整趟首评合计（收工后填，给通知 / toast 用）。 */
        val firstDone: Int,
        /** 整趟转发合计（收工后填，给通知 / toast 用）。 */
        val repostDone: Int,
        /** 收工后要单独弹的「怎么做」（空 = 一切正常，只 toast 数字）。 */
        val alerts: List<String>,
        /**
         * ★★ 第 115 期（相对规格的**必要新增**）：这一趟是否真的跑完过至少一个账号
         *   （= 原来的 `real.isNotEmpty()`）。界面靠它区分「只 toast 数字」与
         *   「原样弹出整段结果」两条路（见 [InteractActivity] 的收工处理）。
         */
        val hasReal: Boolean,
        /**
         * ★★ 第 115 期（相对规格的**必要新增**）：整段给人看的结果文字。
         *   只在「一个账号都没跑成」时由界面原样弹出（原来的兜底分支）。
         */
        val resultText: String
    )

    companion object {

        /** 启动一趟超Like 编排。 */
        const val ACTION_RUN = "com.tjh.weibotask.action.SUPERLIKE_RUN"

        /** 超话链接 / ID。 */
        const val EXTRA_TOPIC = "superlike_topic"

        /** 首评条数。 */
        const val EXTRA_FIRST = "superlike_first"

        /** 转发条数。 */
        const val EXTRA_REPOST = "superlike_repost"

        /** 指定账号（[WeiboAccount.label]）；空串 = 所有可用账号轮流。 */
        const val EXTRA_ACCOUNT_LABEL = "superlike_account_label"

        /** 语料分组 id；空串 = 第一个分组。 */
        const val EXTRA_GROUP_ID = "superlike_group_id"

        /**
         * 常驻通知的 id。
         *
         * ★ 必须与 [AgentService] 的 1001（签到）/ 1002（验证）**不同** ——
         *   撞了就会互相顶掉对方的通知。
         */
        private const val NOTIFICATION_ID = 1003

        /** 通知渠道 id。★ 与 [AgentService] 的渠道不同（渠道级别一旦创建不可改）。 */
        private const val CHANNEL_ID = "weibo_task_superlike"

        /**
         * ★★★★ 第 115 期（用户批准）：**进程级防重入标志**。
         *
         * ## 为什么要修（已证实的真 bug）
         *
         * 真机日志里同一个帖子（mid=5354308855925097）在 15:42:57 与 15:42:58
         * 被发了**两次**评论、两次都记「首评第 1 条抢到」；还有两次
         * `POST comments/create` 只隔 **26ms**。而 `postComment` 每次调用只发一个
         * POST、内部无重试 ⇒ 单线程不可能打出这种日志 ⇒ **有两个 run 同时在跑**。
         *
         * ## 为什么放 companion（进程级）
         *
         * 改前标志挂在 Activity 实例上（`superlikeFlags`）⇒ 换个 Activity 实例
         * （比如从「发帖」页切回来）就看不到上一个实例还在跑，于是又起一趟。
         * 放 companion object 里，**同一个进程内**任何地方看到的都是同一份 ⇒
         * 起第二趟之前先看 [running]，已在跑就直接返回。
         */
        @Volatile var flags: Flags? = null
            private set

        /** 当前运行态快照；没在跑的时候是 null（收工后**保留** done 快照，见 [onDestroy]）。 */
        @Volatile var live: Live? = null
            private set

        /** 有没有一趟正在跑（进程级，跨 Activity 实例有效）。 */
        @Volatile var running: Boolean = false
            private set

        /** 这一趟的编号自增器（只在主线程的 [onStartCommand] 里 +1）。 */
        private var runSeq = 0L

        /** 界面点「暂停 / 继续」。 */
        fun requestPause(paused: Boolean) {
            flags?.paused = paused
        }

        /** 界面点「停止」。 */
        fun requestStop() {
            flags?.stopped = true
        }
    }

    /** 跑编排的后台线程（[onDestroy] 时 interrupt）。 */
    private var worker: Thread? = null

    // ---------------------------------------------------------------- 运行态（只有 worker 线程读写）
    // ★ 这些字段只有 worker 线程读写；界面只读 companion 的 [live]（整对象、@Volatile）。
    //   写完之后 [publishLive] 会把它们拼成一个不可变的 Live 挂上去。
    private var runId = 0L
    private var plan: SuperLikePlan = SuperLikePlan()
    private var accountTotal = 0
    private var firstTargetEach = 0
    private var repostTargetEach = 0
    private var runningLabel = ""
    private var firstBase = 0
    private var repostBase = 0
    private var curFirstOk = 0
    private var curRepostOk = 0
    private var message = ""
    private var doneFirst = 0
    private var doneRepost = 0
    private var hasReal = false
    private var resultText = ""
    private var alerts: List<String> = emptyList()
    private var isDone = false
    private val logLines = ArrayDeque<String>()

    /** 「本趟合计」的上一次读数（只报变化，同一条不重复追加）。★ 跨账号不归零。 */
    private var liveFirstPrev = 0
    private var liveRepostPrev = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_RUN) return START_NOT_STICKY
        // ★★★★ 第 115 期（用户批准）：**每次 startForegroundService() 都必须在 5 秒内
        //   进入前台状态** —— 连下面「已在跑」这条**早退路径**也要满足。否则系统会抛
        //   ForegroundServiceDidNotStartInTimeException 把进程干掉。
        //   ★ 触发窗口：页面 `launchSuperLike` 的 `running` 检查与服务真正置
        //     `running = true` 之间有几十毫秒；用户在这窗口内连点两次「开始」，
        //     第二次 onStartCommand 就会走到早退分支 ⇒ 不 startForeground 就崩。
        //   ★ 对照 AgentService：它的每个 action 分支都是**先 startForeground 再干活**，
        //     从没有「早退且不进前台」的写法。
        //   ★ createNotificationChannel 是幂等的（渠道已存在时创建等于 no-op）。
        createNotificationChannel()
        // ★★★★ 第 115 期：**防重入**。已在跑就直接返回，绝不起第二趟
        //   （这是修「同一帖子被评论两次」那个真 bug 的落点）。
        //   ★ 但必须先占住前台资格（见上）——「已在跑」不等于「这次不用进前台」。
        if (running) {
            startForegroundNotification(getString(R.string.superlike_notif_preparing))
            return START_NOT_STICKY
        }
        running = true
        // ★ startForegroundService() 之后系统只给很短时间进入前台状态 ⇒ 先占住前台资格。
        startForegroundNotification(getString(R.string.superlike_notif_preparing))
        val value = SuperLikePlan(
            topic = intent.getStringExtra(EXTRA_TOPIC).orEmpty(),
            firstComments = intent.getIntExtra(EXTRA_FIRST, SuperLikePlan.OFFICIAL_FIRST),
            reposts = intent.getIntExtra(EXTRA_REPOST, SuperLikePlan.OFFICIAL_REPOST),
            accountLabel = intent.getStringExtra(EXTRA_ACCOUNT_LABEL).orEmpty(),
            groupId = intent.getStringExtra(EXTRA_GROUP_ID).orEmpty()
        )
        beginRun(value)
        // ★ START_NOT_STICKY：**故意不自动重启**。一趟编排重启会重复发内容。
        return START_NOT_STICKY
    }

    /**
     * 起一趟编排：装好标志、清好运行态、开 worker 线程。
     *
     * ★ 单独抽出来是因为 [onStartCommand] 的参数名 `flags` 会**遮蔽** companion 里的
     *   [SuperLikeService.flags] —— 在这个方法里没有遮蔽，赋值干净。
     */
    private fun beginRun(value: SuperLikePlan) {
        val runFlags = Flags()
        flags = runFlags
        runId = ++runSeq
        plan = value
        resetRunState()
        val thread = Thread {
            try {
                // ★ 整段兜异常：每个账号单独兜的逻辑在 [runOrchestration] 里，这里再兜一层
                //   （例如账号列表本身出问题）。
                runOrchestration(value, runFlags)
            } catch (error: Throwable) {
                try {
                    InteractTrace.log(
                        "[超Like·服务] 编排异常退出：" +
                            (error.message ?: error.javaClass.simpleName)
                    )
                } catch (_: Throwable) {
                }
            } finally {
                running = false
            }
        }
        worker = thread
        thread.start()
    }

    /** 把这一趟的运行态字段全部归零（上一趟的快照会被下面第一次 [publishLive] 覆盖）。 */
    private fun resetRunState() {
        accountTotal = 0
        firstTargetEach = 0
        repostTargetEach = 0
        runningLabel = ""
        firstBase = 0
        repostBase = 0
        curFirstOk = 0
        curRepostOk = 0
        message = ""
        doneFirst = 0
        doneRepost = 0
        hasReal = false
        resultText = ""
        alerts = emptyList()
        isDone = false
        logLines.clear()
        liveFirstPrev = 0
        liveRepostPrev = 0
    }

    /**
     * 编排主流程 —— 就是第 114 期 [InteractActivity.launchSuperLike] 里那个线程体，
     * 只是宿主换成了服务、界面回调换成了 [live]。
     */
    private fun runOrchestration(value: SuperLikePlan, runFlags: Flags) {
        // ★ 幂等 init：正常路径下 Activity.onCreate 已经调过，这里是 no-op；
        //   但让服务自足，不依赖「页面一定先打开过」。
        InteractTrace.init(this)
        CommentLib.init(this)
        InteractTaskStore.init(this)
        RateGuard.init(this)
        AccountStore.init(this)

        // ★ 账号列表：可用账号；plan 指定了账号就只留它（与 [InteractActivity.superlikeAccounts] 同一条规则）。
        val accounts = AccountStore.all()
            .filter { it.enabled }
            .filter { value.accountLabel.isBlank() || it.label == value.accountLabel }

        accountTotal = accounts.size
        firstTargetEach = value.firstComments
        repostTargetEach = value.reposts
        // ★★★★ 第 140 期：超话 id 在这里归一化**一次**，下面「今天做没做完」要用它去查。
        //   空串 = 没填超话 ⇒ 查不到任何记录（与 InteractActivity.refreshSuperlikeAccounts
        //   第 3 条纪律同一条规矩：宁可当"没跑过"，也别把别的超话的成绩算进来）。
        val topicId0 = InteractTarget.topicId(value.topic)
        message = getString(R.string.interact_superlike_live_preparing)
        publishLive()

        if (accounts.isEmpty()) {
            // ★ 与原来 launchSuperLike 里「没账号 ⇒ 弹框说清」等价，只是现在由服务收尾、
            //   界面轮询到 done 后再弹。
            val text = getString(R.string.interact_superlike_no_account)
            message = text
            finishRun(emptyList(), text, listOf(text))
            return
        }

        val outcomes = mutableListOf<Pair<WeiboAccount, SuperLikeRunner.Outcome>>()
        val resultTexts = mutableListOf<String>()
        for ((position, account) in accounts.withIndex()) {
            // ★ 用户在账号之间点了「停止」⇒ 不再领下一个账号。
            if (runFlags.stopped) break
            // ★★★★ 第 126 期（用户拍板）：**这个账号正被签到 / 发帖链路占用 ⇒ 跳过**。
            //
            //   超Like 跑在独立前台服务里，和 AgentService 之间**没有任何互斥**
            //   （两个服务各有一个 `running`）。而超Like 发的首评 / 转发都是**写请求**，
            //   同一账号在同一时间被签到 / 发帖链路也打一串写请求，撞风控、
            //   触发滑块验证的概率明显更高 —— 微博的限流是按账号算的。
            //
            //   ★ 只让超Like 这一侧避让：[AgentService] 的两条链路照旧跑自己的账号，
            //     一行判定都没改（它们只是把批次登记进 [AccountBusy]）。
            //   ★ 跳过而不是等待：等待可能把一个前台服务挂到签到跑完（十几分钟），
            //     期间用户看到的只有「不动」；跳过并如实记一行，用户立刻知道发生了什么。
            if (AccountBusy.isBusy(account.id)) {
                val skipped = getString(
                    R.string.interact_superlike_acct_busy,
                    account.displayName
                )
                resultTexts.add(skipped)
                appendLog(skipped)
                publishLive()
                continue
            }
            // ============================================================
            // ★★★★ 第 140 期（用户拍板）：**今天已经做完 / 只差一部分的账号，不再从头重跑**。
            //
            //   用户原话：「一届超like停止之后，重新点击超like，他还会从第一个账号开始，
            //   但第一个账号已经完成了首评和转发，再一次点击，应该从首评或者转发
            //   未完成的账号开始」。
            //
            //   改前这里**不看任何「今天做了多少」**，[SuperLikeRunner.run] 每一趟的
            //   firstOk / repostOk 也都从 0 起算 ⇒ 停止后再点 = 第一个号重新抢 4 条
            //   首评 + 2 条转发，第二名、第三名…全部重来。今天累计那张卡看着还是 4/4
            //   （[InteractTaskStore.addTodayDone] 有 minOf(累计,目标) 的上限），
            //   但**真实的写请求已经翻倍**。
            //
            //   口径（只读这个模块自己的 `interact_tasks.xml`，不碰任何账号字段）：
            //     · 两个都达标 ⇒ **整号跳过**，并如实记一行（不然用户只看到「没动」，
            //       不知道是被跳过了）；
            //     · 只差一条 ⇒ 用**剩余条数**跑（4 条里做成了 3 条，这一趟只做 1 条）；
            //     · 一条都没做过 ⇒ 原样全量跑（行为与第 139 期逐字节等价）。
            // ============================================================
            val doneToday = if (topicId0.isBlank()) {
                null
            } else {
                InteractTaskStore.todayDone(topicId0, account.label)
            }
            val remainFirst = (value.firstComments - (doneToday?.firstOk ?: 0)).coerceAtLeast(0)
            val remainRepost = (value.reposts - (doneToday?.repostOk ?: 0)).coerceAtLeast(0)
            if (doneToday != null && remainFirst == 0 && remainRepost == 0) {
                val already = getString(
                    R.string.interact_superlike_acct_already_done,
                    account.displayName
                )
                resultTexts.add(already)
                appendLog(already)
                publishLive()
                continue
            }
            // ★ 只跑剩余的那一份计划（原计划一个字节都不动，拷贝一份出来改）。
            val runPlan = if (remainFirst == value.firstComments && remainRepost == value.reposts) {
                value
            } else {
                value.copy(firstComments = remainFirst, reposts = remainRepost)
            }
            if (runPlan !== value) {
                val partial = getString(
                    R.string.interact_superlike_acct_remaining,
                    account.displayName,
                    remainFirst,
                    remainRepost
                )
                resultTexts.add(partial)
                appendLog(partial)
                publishLive()
            }
            runningLabel = account.label
            curFirstOk = 0
            curRepostOk = 0
            publishLive()
            updateNotification(
                getString(R.string.superlike_notif_running, position + 1, accounts.size)
            )
            val monitor = monitorFor(account, value, runFlags)
            try {
                val outcome = SuperLikeRunner.run(this, runPlan, account, monitor)
                outcomes.add(account to outcome)
                resultTexts.add(outcome.text)
                // ★ 这个号跑完了 ⇒ 把它这一趟的成绩并进「已完成」那一份，
                //   下一个号接着往上加 ⇒ 进度**只涨不归零**。
                firstBase += outcome.firstOk
                repostBase += outcome.repostOk
            } catch (error: Throwable) {
                // ★ 一个账号失败**不影响**后面的账号。
                resultTexts.add(
                    account.displayName + "：" + getString(
                        R.string.interact_superlike_aborted,
                        error.message ?: error.javaClass.simpleName
                    )
                )
            }
            curFirstOk = 0
            curRepostOk = 0
            publishLive()
        }

        finishRun(outcomes, resultTexts.joinToString("\n\n"), emptyList())
    }

    /**
     * ★★★★ 第 111 期（第 115 期搬到服务）：给**某一个账号**造一个运行态监视器。
     *
     * ## 用户批准的「发一条记一条」
     *
     * 每成功一条就落一次盘。★ 关键在**只写增量**：`onProgress` 报的是
     * **这个账号这一趟的累计**，所以这里用 [bankedFirst] / [bankedRepost]
     * 记住「已经落过盘多少」，每次只把差值写进去 —— 绝不能把整趟累计重复累加
     * （`addTodayDone` 是**累加**语义，重复调用会变成 1+2+3+4 = 10 条）。
     *
     * ## 与第 114 期的差异
     *
     * 回调**不再走 `runOnUiThread`** —— 改成把状态写进运行态字段、由 [publishLive]
     * 挂到 [live] 上（界面自己轮询）。判据与落盘逻辑**逐字节不变**。
     */
    private fun monitorFor(
        account: WeiboAccount,
        value: SuperLikePlan,
        runFlags: Flags
    ): SuperLikeRunner.Monitor {
        val topicId = InteractTarget.topicId(value.topic)
        // ★ 这个账号**已经落过盘**的首评 / 转发数（用来算增量，见上面那段说明）。
        var bankedFirst = 0
        var bankedRepost = 0
        return object : SuperLikeRunner.Monitor {

            override fun onStart(firstTarget: Int, repostTarget: Int) {
                runningLabel = account.label
                // ★★★★ 第 140 期：分母一律用**用户填的目标数**（`value`），不用回调里的。
                //   原因：只跑剩余条数时回调给的是「剩余量」（例如 1），
                //   而界面「本趟合计」那一行是 `账号数 × 每号目标` 的口径 ——
                //   拿剩余量当分母会把总数凭空压小（4 个号显示成 4 条而不是 16 条）。
                firstTargetEach = value.firstComments
                repostTargetEach = value.reposts
                curFirstOk = 0
                curRepostOk = 0
                // ★ 明细只清「刚发生了什么」，不归零 liveFirstPrev / liveRepostPrev
                //   （它们是「本趟合计」的上一次读数，归零会凭空多印一行「0 / 16」）。
                logLines.clear()
                // ★ 第一行点明「轮到谁了」—— 否则动态文本马上被「正在提交第 1 条」盖掉。
                appendLog(
                    getString(R.string.interact_superlike_acct_running, account.displayName)
                )
                message = getString(R.string.interact_superlike_live_preparing)
                publishLive()
            }

            override fun onProgress(
                firstOk: Int,
                firstTarget: Int,
                repostOk: Int,
                repostTarget: Int
            ) {
                // ★ 先落盘再刷界面：进程随时可能被划掉，界面晚十几毫秒无所谓。
                val deltaFirst = firstOk - bankedFirst
                val deltaRepost = repostOk - bankedRepost
                if (deltaFirst > 0 || deltaRepost > 0) {
                    bankedFirst = firstOk
                    bankedRepost = repostOk
                    InteractTaskStore.addTodayDone(
                        topicId,
                        account.label,
                        SuperLikeRunner.Outcome(
                            firstOk = deltaFirst.coerceAtLeast(0),
                            firstTarget = firstTarget,
                            repostOk = deltaRepost.coerceAtLeast(0),
                            repostTarget = repostTarget,
                            at = System.currentTimeMillis()
                        )
                    )
                }
                runningLabel = account.label
                curFirstOk = firstOk
                curRepostOk = repostOk
                // ★★★★ 第 140 期：同 [onStart] —— 分母用用户填的目标数，不用剩余量。
                firstTargetEach = value.firstComments
                repostTargetEach = value.reposts
                // ★ 明细：本趟合计涨了就补一行（只报变化）。
                val sumFirst = firstBase + firstOk
                val sumRepost = repostBase + repostOk
                val totalFirst = accountTotal * firstTargetEach
                val totalRepost = accountTotal * repostTargetEach
                if (sumFirst != liveFirstPrev) {
                    liveFirstPrev = sumFirst
                    appendLog(getString(R.string.interact_superlike_log_first, sumFirst, totalFirst))
                }
                if (sumRepost != liveRepostPrev) {
                    liveRepostPrev = sumRepost
                    appendLog(
                        getString(R.string.interact_superlike_log_repost, sumRepost, totalRepost)
                    )
                }
                publishLive()
            }

            override fun onMessage(text: String) {
                runningLabel = account.label
                message = text
                publishLive()
            }

            override fun shouldStop(): Boolean = runFlags.stopped

            /**
             * 用户按了「暂停」时阻塞到这里。
             *
             * ★ 200ms 醒一次：既不会空转到烫手，点「继续」后的延迟人也感觉不到。
             * ★ 返回 true = 别等了（用户在暂停期间点了停止，或线程被中断）。
             */
            override fun awaitResume(): Boolean {
                while (runFlags.paused && !runFlags.stopped) {
                    try {
                        Thread.sleep(200)
                    } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                        return true
                    }
                }
                return runFlags.stopped
            }
        }
    }

    /** 往明细里补一行，只留最近 3 行。 */
    private fun appendLog(line: String) {
        logLines.addLast(line)
        while (logLines.size > 3) logLines.removeFirst()
    }

    /** 把当前运行态拼成一个不可变的 [Live] 挂上去（界面可见时每 500ms 读一次）。 */
    private fun publishLive() {
        live = Live(
            runId = runId,
            accountTotal = accountTotal,
            firstTargetEach = firstTargetEach,
            repostTargetEach = repostTargetEach,
            runningLabel = runningLabel,
            firstBase = firstBase,
            repostBase = repostBase,
            firstOk = curFirstOk,
            repostOk = curRepostOk,
            message = message,
            logLines = logLines.toList(),
            done = isDone,
            firstDone = doneFirst,
            repostDone = doneRepost,
            alerts = alerts,
            hasReal = hasReal,
            resultText = resultText
        )
    }

    /**
     * 收工：补目标数 → 汇总 → 挂收工快照 → 刷新通知 → 撤前台 → 停自己。
     *
     * ★ 与第 114 期收尾逻辑逐条等价（`real` / `alerts` / 两条 toast 判据都一样）。
     */
    private fun finishRun(
        outcomes: List<Pair<WeiboAccount, SuperLikeRunner.Outcome>>,
        result: String,
        extraAlerts: List<String>
    ) {
        val topicId = InteractTarget.topicId(plan.topic)
        // ★ 只记**真的跑完了一趟**的那些（`at > 0` 是**结构**标记，不是看文字）。
        val real = outcomes.filter { it.second.at > 0L }
        // ★★★★ 第 111 期（用户批准「发一条记一条」）：进度**已经在 [monitorFor] 里
        //   逐条落过盘了** ⇒ 这里**只补目标数**，已完成数一律传 0，绝不重复累加。
        //   ★ 补目标数还有用：这一趟一条都没成时，「今天累计」也要显示 `0 / 4` 而不是 `0 / 0`。
        for ((account, outcome) in real) {
            InteractTaskStore.addTodayDone(
                topicId,
                account.label,
                SuperLikeRunner.Outcome(
                    firstOk = 0,
                    firstTarget = outcome.firstTarget,
                    repostOk = 0,
                    repostTarget = outcome.repostTarget,
                    // ★★★★ 第 140 期：失败数在这里落盘（成功数已经在 [monitorFor] 里
                    //   逐条记过了，这里传 0 绝不重复累加；失败是收工时一次结清）。
                    firstFail = outcome.firstFail,
                    repostFail = outcome.repostFail,
                    at = outcome.at
                )
            )
        }

        val firstOk = real.sumOf { it.second.firstOk }
        val firstTarget = real.sumOf { it.second.firstTarget }
        val repostOk = real.sumOf { it.second.repostOk }
        val repostTarget = real.sumOf { it.second.repostTarget }
        // ★★★★ 第 140 期（用户批准）：这一趟的失败合计（收工那行要写出来）。
        val firstFail = real.sumOf { it.second.firstFail }
        val repostFail = real.sumOf { it.second.repostFail }

        doneFirst = firstOk
        doneRepost = repostOk
        hasReal = real.isNotEmpty()
        resultText = result
        alerts = (real.flatMap { it.second.alerts } + extraAlerts).distinct()
        message = when {
            flags?.stopped == true -> getString(R.string.interact_superlike_live_stopped)
            real.isNotEmpty() -> getString(
                R.string.interact_superlike_live_done,
                firstOk,
                firstTarget,
                repostOk,
                repostTarget,
                firstFail + repostFail
            )
            else -> message
        }
        isDone = true
        publishLive()

        updateNotification(getString(R.string.superlike_notif_done, firstOk, repostOk))
        // ★ 撤掉前台资格但**保留通知**（DETACH）⇒ 用户还能在通知栏看到结果。
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    override fun onDestroy() {
        // ★ 让还在睡的 worker 尽快收手（中断 [SuperLikeRunner] 里那些 sleep）。
        flags?.stopped = true
        worker?.interrupt()
        worker = null
        flags = null
        running = false
        // ★★ 第 115 期（相对规格的**必要偏离**）：收工快照（done）**不清** ——
        //   界面每 500ms 才轮询一次，而 `stopSelf()` → `onDestroy` 可能在两次轮询之间
        //   就把 live 清掉 ⇒ 结果（尤其 alerts）会丢。保留 done 快照，界面读到后
        //   用 runId 去重（只处理一次）；下一趟开始时被覆盖。运行中的快照照常清掉。
        if (live?.done != true) live = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- 通知（照抄 AgentService 的写法）

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.superlike_notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }
    }

    /** 返回 null 表示成功；返回文字表示两种启动方式都失败。 */
    private fun startForegroundNotification(text: String): String? {
        val notification = buildNotification(text)
        var typedError = ""
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
                return null
            } catch (error: Exception) {
                typedError = error.javaClass.simpleName
                // 类型不被系统接受时退回「不声明类型」；但两次都失败时必须留下诊断。
            }
        }
        return try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, 0)
            null
        } catch (error: Exception) {
            listOf(typedError, error.javaClass.simpleName).filter { it.isNotBlank() }
                .joinToString(" / ")
        }
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        // 点通知回到互动页（编排就在那儿看着）。
        val intent = Intent(this, InteractActivity::class.java)
        val pending = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(pending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }
}
