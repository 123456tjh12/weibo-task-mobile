package com.tjh.weibotask

/**
 * ★★★★ 第 121 期：**发帖任务（PostTask）的 FIFO 排队**。
 *
 * ## 为什么需要它
 *
 * 第 117~120 期的行为：每条任务一个独立闹钟，两个任务几乎同时到点时
 * （或「保存后立即开始」撞上另一个任务的闹钟），
 * [AgentService.requestPostTask] 撞上 `if (running) return` ⇒
 * **后到的任务被静默丢弃**（只有一行日志，用户无感知，任务永久失效）。
 *
 * 本对象把「后到」改成「**排队**」：先到的跑完，队列里的自动接上。
 *
 * ## 边界（硬纪律）
 *
 * - **纯内存**：不落盘、不读不写 [Prefs] / [PostTaskStore] ——
 *   进程被杀的恢复由 [PostTaskScheduler.remountPending] 兜底
 *   （`ranAt == null` 的任务开机重挂闹钟，见该函数的说明）。
 * - **只装 taskId 字符串**：任务本体任何时候从 [PostTaskStore] 现取
 *   （可能已被用户删除 ⇒ 出队时先 `get(id)` 判 null 再跑）。
 * - **一个任务只入队一次**（去重）：闹钟异常残留 + 用户连点保存
 *   会让同一个 id 多次到达，队列里躺两份会跑两遍。
 * - 全部方法 `@Synchronized`：主线程（onStartCommand）与协程线程
 *   （requestPostTask 的 scope.launch）都会碰它。
 */
object TaskQueue {

    private val pending = ArrayDeque<String>()

    /** 入队；已在队列里则忽略（去重）。返回 true = 真的进去了。 */
    @Synchronized
    fun offer(taskId: String): Boolean {
        if (taskId.isBlank()) return false
        if (pending.contains(taskId)) return false
        pending.addLast(taskId)
        return true
    }

    /** 看下一个要跑的 taskId（不移除）；队列空返回 null。 */
    @Synchronized
    fun peek(): String? = pending.firstOrNull()

    /** 出队并返回；队列空返回 null。 */
    @Synchronized
    fun poll(): String? = if (pending.isEmpty()) null else pending.removeFirst()

    /** 队列里还有几个。 */
    @Synchronized
    fun size(): Int = pending.size

    /** 某任务是否在排队（卡片显示「排队中」用）。 */
    @Synchronized
    fun contains(taskId: String): Boolean = pending.contains(taskId)

    /** 清空（任务被用户删除 / 改配置时调用，避免队列里躺着已失效的 id）。 */
    @Synchronized
    fun remove(taskId: String) {
        pending.remove(taskId)
    }

    /** 全清（只用于「用户手动停掉一切」这类明确动作）。 */
    @Synchronized
    fun clear() {
        pending.clear()
    }
}
