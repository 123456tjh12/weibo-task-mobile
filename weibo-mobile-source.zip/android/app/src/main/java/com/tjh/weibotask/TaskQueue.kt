package com.tjh.weibotask

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/**
 * ★★★★ 第 121 期：**发帖任务（PostTask）的 FIFO 排队**。
 *
 * ## 为什么需要它
 *
 * 第 117~120 期的行为：每条任务一个独立闹钟，两个任务几乎同时到点时
 * （或「保存后立即开始」撞上另一个任务的闹钟），
 * [AgentService.requestPostTask] 撞上 `if (running) return` ⇒
 * **后到的任务被静默丢弃**（只有一行日志，用户无感知，任务永久失效）。
 *
 * 本对象把「后到」改成「**排队**」：先到的跑完，队列里的自动接上。
 *
 * ## ★★★★ 第 126 期（用户 2026-10-17 拍板）：**从「纯内存」改成「落盘」**
 *
 * ### 为什么必须改
 *
 * 第 121 期把队列刻意做成纯内存，注释里写的兜底是
 * 「进程被杀的恢复由 [PostTaskScheduler.remountPending] 兜底」——
 * **这个兜底覆盖不到最常见的那一类任务**。
 *
 * `remountPending` 只重挂三种任务：`retryAtMillis != null` / `scheduleStart` /
 * `limitWindow`。而用户最常建的是「**立即开始、不限时间窗**」的一次性任务 ——
 * 它三类都不属于。于是：
 *
 *   20:47 点「开始」→ 签到正在跑 ⇒ 进队列、卡片「排队中」
 *   → 21:07 进程被系统回收（用户 2026-10-17 那份 OPPO 诊断报告里的
 *     「新的 App 进程（接续上次 82 条）」就是这一刻）
 *   → 队列在内存里，随进程一起没了
 *   → 没有任何人重挂它，`ranAt` 永远是 null
 *   → 卡片从「排队中」变回「待运行」，**任务永久丢失**。
 *
 * ### 改成什么样
 *
 * 入队 / 出队 / 删除 / 清空**每次都落盘**（独立 SP 文件 `post_queue`），
 * 进程重启后由 [init] 读回来；恢复后由
 * `PostTaskScheduler.remountPending` 给「还在队列里」的任务挂一个「现在」的
 * 一次性闹钟，等它自己把队列跑空。
 *
 * ### 语义没变的地方（重要）
 *
 * - **仍然只装 taskId 字符串**：任务本体任何时候从 [PostTaskStore] 现取
 *   （可能已被用户删除 ⇒ 出队时先 `get(id)` 判 null 再跑）。
 * - **仍然一个任务只入队一次**（去重）。
 * - **出队发生在「开跑前」**：`poll()` 拿到的 id 立刻从盘上消失，随后
 *   `executePostTaskOnce` 第一件事就是写 `ranAt` ⇒ 就算这时进程被杀，
 *   这个任务也**不会被恢复后重跑一遍**（不会重复发帖）。
 *   被恢复的只有「还没轮到、一次都没开跑」的那些。
 *
 * ### 边界（硬纪律）
 *
 * - **不读不写 [Prefs]**：另开一个私有 SP 文件，与 [PostTaskStore] 同一思路。
 * - **不读不写 [PostTaskStore]**：任务本体不归这里管。
 * - 解析失败一律**当成空队列**，绝不抛异常 —— 一份坏数据不该让服务起不来。
 * - 全部方法 `@Synchronized`：主线程（onStartCommand）与协程线程
 *   （requestPostTask 的 scope.launch）都会碰它。
 */
object TaskQueue {

    /** 独立 SP 文件名（与 `post_tasks` / `slider_trace` / `interact_tasks` 并列）。 */
    private const val STORE_NAME = "post_queue"
    private const val KEY_PENDING = "pending"

    private val pending = ArrayDeque<String>()

    private var store: SharedPreferences? = null
    private var loaded = false

    /**
     * 读盘。**必须在任何 offer / poll / contains 之前调用一次**；
     * 同一进程内重复调用无副作用（第 126 期新增）。
     *
     * 调用点：`AgentService.onCreate`、`MainActivity.renderPostTaskList`、
     * `PostTaskScheduler.remountPending`（开机广播）。
     */
    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        val sp = try {
            context.applicationContext.getSharedPreferences(STORE_NAME, Context.MODE_PRIVATE)
        } catch (_: Throwable) {
            null
        }
        store = sp
        pending.clear()
        try {
            val raw = sp?.getString(KEY_PENDING, "").orEmpty()
            if (raw.isNotBlank()) {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    // ★ 单条坏数据只跳过它自己，不把整条队列清掉。
                    val id = array.optString(i, "")
                    if (id.isNotBlank() && !pending.contains(id)) pending.addLast(id)
                }
            }
        } catch (_: Throwable) {
            // 整份 JSON 都坏了才当成空队列。
            pending.clear()
        }
        loaded = true
    }

    /** 入队；已在队列里则忽略（去重）。返回 true = 真的进去了。 */
    @Synchronized
    fun offer(taskId: String): Boolean {
        if (taskId.isBlank()) return false
        if (pending.contains(taskId)) return false
        pending.addLast(taskId)
        persist()
        return true
    }

    /** 看下一个要跑的 taskId（不移除）；队列空返回 null。 */
    @Synchronized
    fun peek(): String? = pending.firstOrNull()

    /** 出队并返回；队列空返回 null。★ 出队**立即落盘**（见类注释「语义没变的地方」）。 */
    @Synchronized
    fun poll(): String? {
        if (pending.isEmpty()) return null
        val head = pending.removeFirst()
        persist()
        return head
    }

    /** 队列里还有几个。 */
    @Synchronized
    fun size(): Int = pending.size

    /** 某任务是否在排队（卡片显示「排队中」用）。 */
    @Synchronized
    fun contains(taskId: String): Boolean = pending.contains(taskId)

    /** 清空（任务被用户删除 / 改配置时调用，避免队列里躺着已失效的 id）。 */
    @Synchronized
    fun remove(taskId: String) {
        if (pending.remove(taskId)) persist()
    }

    /** 全清（只用于「用户手动停掉一切」这类明确动作）。 */
    @Synchronized
    fun clear() {
        pending.clear()
        persist()
    }

    /**
     * 落盘。
     *
     * ★ 写盘失败**静默**：界面上这一趟照常走完，只是「重启后恢复」这一步会少几条 ——
     *   比抛异常把服务搞崩好得多。与 [PostTaskStore.persist] 同一处理。
     */
    private fun persist() {
        val sp = store ?: return
        try {
            val array = JSONArray()
            for (id in pending) array.put(id)
            sp.edit().putString(KEY_PENDING, array.toString()).apply()
        } catch (_: Throwable) {
        }
    }
}
