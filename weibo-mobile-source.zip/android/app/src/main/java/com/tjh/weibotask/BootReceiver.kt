package com.tjh.weibotask

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            Prefs.init(context)
            // ★★★★ 第 120 期：恢复「发帖任务」的一次性闹钟（scheduleStart）。
            //   ★ 与签到排程**独立**，且**不受 scheduleEnabled 限制** —— 用户可能只用了
            //     发帖任务的定时开始、没开自动签到；把这段放在 scheduleEnabled 守卫之前，
            //     否则那种情况下开机后发帖闹钟永远不重挂。
            //   ★ 它不写 Prefs.nextRunAt，绝不影响签到链路。
            PostTaskScheduler.remountPending(context)
            if (!Prefs.scheduleEnabled) return
            // 重启/应用更新会清掉 AlarmManager 里的登记，先恢复闹钟；
            // 服务若被 Android 14+ 拒绝，闹钟链仍然存在，不会一起断掉。
            LocalScheduler.scheduleNext(context)
            val serviceIntent = Intent(context, AgentService::class.java).apply {
                action = AgentService.ACTION_START_SCHEDULED
            }
            try {
                androidx.core.content.ContextCompat.startForegroundService(context, serviceIntent)
            } catch (error: Exception) {
                Prefs.lastRunStatus = "BLOCKED"
                Prefs.lastRunMessage = context.getString(
                    R.string.run_msg_boot_blocked,
                    error.javaClass.simpleName
                )
            }
        } catch (_: Exception) {
            // Receiver 不能崩；用户解锁后打开 App 时 ensureScheduled 会再次自愈。
        }
    }
}
