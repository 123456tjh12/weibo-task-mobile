package com.tjh.weibotask

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 互动（评论 / 互评 / 楼赞）功能的「黑匣子」。
 *
 * ★ 为什么单独再开一个，而不是复用 [SliderTrace]：
 *   两者虽然形状一样（环形缓冲 + 私有落盘），但**归属不同**。
 *   `slider_trace` 记的是签到链路的验证页，是排查「今天为什么没签上」用的；
 *   这里记的是互动功能自己干了什么。混在一个文件里，用户复制排查信息时
 *   会把互动的几百行噪音一起带走，反而把签到那条线索淹掉。
 *
 * ★ 边界（和 SliderTrace 同一条纪律，刻意为之，不要随手扩大）：
 *   - **不碰 [Prefs]**：那是核心数据层（签到 / 发帖 / 验证 / 账号全在里面），
 *     md5 锁死；这里另开一个私有文件 `interact_trace`。
 *   - **不碰 [AccountStore]**：不读不写账号，不调 `save()`。
 *   - 只写日志，不参与任何判定：本对象没有任何返回值被业务代码使用。
 *     换句话说，把它整个删掉，签到 / 发帖 / 验证的行为不会有任何变化。
 *   - 写盘失败一律静默：日志不能反过来影响主流程。
 */
object InteractTrace {

    /** 环形缓冲容量。互动一轮通常只有几条，300 条够看很多轮了。 */
    private const val CAP = 300

    private const val STORE_NAME = "interact_trace"
    private const val KEY_LINES = "lines"

    private val buffer = ArrayList<String>(CAP)
    private val timeFormat = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)
    private var lastAt = 0L
    private var store: SharedPreferences? = null

    /**
     * 接上上次的记录。**必须在记日志 / 读日志之前调用一次**（各入口的 onCreate 里调）。
     *
     * 同一个进程内重复调用无副作用；每次进程首次调用会补一条 `[进程]` 标记 ——
     * 有了它，「这一段日志属于哪个进程」就不用再猜（覆盖安装后尤其重要）。
     */
    @Synchronized
    fun init(context: Context) {
        if (store != null) return
        val sp = try {
            context.applicationContext.getSharedPreferences(STORE_NAME, Context.MODE_PRIVATE)
        } catch (_: Throwable) {
            null
        }
        store = sp
        val saved = try {
            sp?.getString(KEY_LINES, "").orEmpty()
        } catch (_: Throwable) {
            ""
        }
        var kept = 0
        if (saved.isNotBlank()) {
            val tail = saved.split("\n").filter { it.isNotBlank() }.takeLast(CAP - 1)
            buffer.clear()
            buffer.addAll(tail)
            kept = tail.size
        }
        log("[进程] 新的 App 进程（接续上次 " + kept + " 条互动日志）")
    }

    /**
     * 记录一条。任何线程都可以调用。
     *
     * 时间戳后面跟的是**距上一条的毫秒差**，不是绝对耗时 ——
     * 排查「两条评论之间隔了多久」时，差值比时刻更好读。
     */
    @Synchronized
    fun log(message: String) {
        val now = System.currentTimeMillis()
        val delta = if (lastAt == 0L) 0L else now - lastAt
        lastAt = now
        buffer.add(timeFormat.format(Date(now)) + " +" + delta + "ms  " + message)
        while (buffer.size > CAP) buffer.removeAt(0)
        persist()
    }

    /** 取出全部记录；没有记录时返回空串（调用方负责给默认文案）。 */
    @Synchronized
    fun dump(): String = buffer.joinToString("\n")

    /** 清空。 */
    @Synchronized
    fun clear() {
        buffer.clear()
        lastAt = 0L
        persist()
    }

    /** 把当前缓冲整段镜像到私有存储。失败静默。 */
    private fun persist() {
        val sp = store ?: return
        try {
            sp.edit().putString(KEY_LINES, buffer.joinToString("\n")).apply()
        } catch (_: Throwable) {
        }
    }
}
