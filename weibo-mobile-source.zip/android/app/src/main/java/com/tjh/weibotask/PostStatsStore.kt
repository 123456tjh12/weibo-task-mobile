package com.tjh.weibotask

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

/**
 * ★★★★ 第 103 期（用户批准）：**发帖**的按账号战绩（今天发了几条 / 成功几次 / 失败几次）。
 *
 * ## 为什么需要它
 *
 * 用户原话：「发帖也是的，**要显示哪个账号，发了几条，成功了几次，失败了几次**，
 * 让客户更加直观的看到」。
 *
 * 现有数据答不了这个问题：
 *   · `account.postIndex` 只回答「今天推进了几条」（成功和「重复跳过」都算），
 *     分不出成功与失败；
 *   · `account.postFailCount` 是**连续**失败计数，一旦成功就归零 —— 不是当天累计；
 *   · `Prefs.postLastMessage` 是**上一轮**的原文，下一轮就被覆盖。
 *
 * ⇒ 必须有一份**当天累计**的战绩。用户已批准用「独立的统计文件」存。
 *
 * ## ★★ 为什么另开一个私有文件（与 [InteractTaskStore] 同一条纪律）
 *
 * `AccountStore.save()` 是**整表覆盖**（把内存里那份账号列表整个写回去）。
 * 把统计塞进账号表，就会出现「记一次发帖战绩 ⇒ 顺带把账号表重写一遍」——
 * 而账号表里躺着 `restUntil` / `needsVerify` / `lastRunDate` / `lastRunAt`
 * 这四个**签到链路正在用的判定字段**，一旦写回时机和签到链路撞上，
 * 账号的当日状态就会被回滚。
 *
 * ⇒ 统计全部自包含在 `post_stats.xml`：**不读不写 [Prefs]、不读不写 [AccountStore]、
 *   不调 `AccountStore.save()`**。删掉这个文件，四条核心链路一个字都不受影响。
 *
 * ## 存储形状
 *
 * `{"date":"2026-10-11","items":{"<account.id>":{"posted":3,"ok":3,"fail":0,"dup":0}}}`
 *   —— 整张表共用一个 `date`，跨天一次性作废（比逐条带日期简单，也不会漏清某一条）。
 *
 * ## 三个数字的口径
 *
 * | 字段 | 含义 | 什么时候 +1 |
 * |---|---|---|
 * | `posted` | 今天**推进**了几条 | `SUCCESS` 与 `DUPLICATE`（与 `account.postIndex` 同口径） |
 * | `ok` | 微博**明确回发成功** | `SUCCESS` |
 * | `fail` | 失败（限流 / 内容被拒 / 网络 / 验证） | 其余所有状态 |
 *
 * ★ 判据全部来自 `WeiboClient.runPost` 回包解析出的**结构化 `status`**，
 *   **绝不解析任何文案**（第 20 条纪律：判据不许认文案）。
 */
object PostStatsStore {

    private const val STORE_NAME = "post_stats"
    private const val KEY_TODAY = "post_stats_today"

    /** 一个账号今天的战绩。`posted = ok + dup + fail`（三项口径见文件头）。 */
    class Stats(
        /** 今天推进了几条（成功 + 重复跳过）。 */
        val posted: Int,
        /** 微博明确回发成功的次数。 */
        val ok: Int,
        /** 失败次数（限流 / 内容被拒 / 网络 / 验证）。 */
        val fail: Int,
        /** 「内容重复，跳过」的次数。 */
        val dup: Int
    )

    /** 今天战绩所在的那一天（`yyyy-MM-dd`）。空 = 还没记过。 */
    private var date = ""

    /** 今天战绩。键 = `account.id`，值 = `{posted, ok, fail, dup}`。 */
    private var items: JSONObject? = null

    private var store: SharedPreferences? = null
    private var loaded = false

    /** 读盘。**必须在用之前调用一次**；同一进程内重复调用无副作用。 */
    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        val sp = try {
            context.applicationContext.getSharedPreferences(STORE_NAME, Context.MODE_PRIVATE)
        } catch (_: Throwable) {
            null
        }
        store = sp
        // ★ 读坏了就当没记过 —— 一份坏数据绝不该让发帖卡片打不开。
        date = ""
        items = null
        try {
            val raw = sp?.getString(KEY_TODAY, "").orEmpty()
            if (raw.isNotBlank()) {
                val root = JSONObject(raw)
                val stored = root.optString("date")
                // ★ 跨天自动作废：只认「今天」那一份，旧的连读都不读（也就自然归零）。
                if (stored == todayKey()) {
                    date = stored
                    items = root.optJSONObject("items") ?: JSONObject()
                }
            }
        } catch (_: Throwable) {
            date = ""
            items = null
        }
        loaded = true
    }

    /**
     * 记一次发帖结果。`status` 用 `WeiboClient.runPost` 回包里的**结构状态码**。
     *
     * ★ 只写这个模块自己的 `post_stats.xml` —— 不碰 [Prefs]、不碰 [AccountStore]。
     * ★ `accountId` 为空 ⇒ 直接忽略（没有 id 就没法归属，宁可少记也不错记）。
     */
    @Synchronized
    fun record(accountId: String, status: String) {
        if (accountId.isBlank()) return
        resetIfNeeded()
        val map = items ?: return
        val prev = try {
            map.optJSONObject(accountId)
        } catch (_: Throwable) {
            null
        }
        var posted = prev?.optInt("posted") ?: 0
        var ok = prev?.optInt("ok") ?: 0
        var fail = prev?.optInt("fail") ?: 0
        var dup = prev?.optInt("dup") ?: 0
        when (status) {
            "SUCCESS" -> {
                posted += 1
                ok += 1
            }
            "DUPLICATE" -> {
                posted += 1
                dup += 1
            }
            else -> fail += 1
        }
        try {
            map.put(
                accountId,
                JSONObject()
                    .put("posted", posted)
                    .put("ok", ok)
                    .put("fail", fail)
                    .put("dup", dup)
            )
        } catch (_: Throwable) {
            return
        }
        save()
    }

    /**
     * 今天的按账号战绩。键 = `account.id`。
     *
     * ★ 界面拿它按账号顺序渲染（`AccountStore.enabled()` 的顺序），
     *   这样和账号页看到的顺序一致。
     */
    @Synchronized
    fun statsByAccount(): Map<String, Stats> {
        resetIfNeeded()
        val map = items ?: return emptyMap()
        val result = LinkedHashMap<String, Stats>()
        val keys = map.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val obj = try {
                map.optJSONObject(key)
            } catch (_: Throwable) {
                null
            } ?: continue
            result[key] = Stats(
                posted = obj.optInt("posted"),
                ok = obj.optInt("ok"),
                fail = obj.optInt("fail"),
                dup = obj.optInt("dup")
            )
        }
        return result
    }

    /**
     * ★ 跨天了就把今天的账清空（**惰性**，不需要任何定时器）。
     *
     * ★ 判据是**日期串相等**，不是「过了多少小时」——
     *   用户要的是「每天重置」，按自然日算最不容易误解。
     */
    private fun resetIfNeeded() {
        val today = todayKey()
        if (date == today && items != null) return
        date = today
        items = JSONObject()
    }

    /** 把今天的账落盘。 */
    private fun save() {
        val sp = store ?: return
        try {
            val root = JSONObject()
                .put("date", date)
                .put("items", items ?: JSONObject())
            sp.edit().putString(KEY_TODAY, root.toString()).apply()
        } catch (_: Throwable) {
            // 写盘失败静默：这一趟界面上照常看得到，只是下次打开要重跑。
        }
    }

    /**
     * ★ 今天的日期串（`yyyy-MM-dd`，本地时区）。
     *
     * ★ 刻意**在本文件内自造**、不去依赖 [LocalScheduler]：
     *   本文件的头号纪律是「统计完全自包含，删掉它不影响四条核心链路」，
     *   为一个日期串把统计挂到调度器上不值得。
     * ★ 这个串只和它自己比较（今天 vs 存下来的那天）⇒ 格式怎么定都自洽。
     */
    private fun todayKey(): String =
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
            .format(java.util.Date())
}
