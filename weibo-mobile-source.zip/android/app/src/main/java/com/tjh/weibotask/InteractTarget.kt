package com.tjh.weibotask

/**
 * 用户填的「目标」到底是哪一种。
 *
 * ★★ 为什么必须区分（第 44 期实测踩到的）：
 *   用户填的是 `https://weibo.com/u/6986999782` —— 这是**用户主页**，
 *   而「评论」这个动作需要的是**某一条微博**。原来的干跑只检查「填没填」，
 *   于是打印「以上检查全部通过」，**等于骗了用户**。
 *
 *   但也不能简单地把主页判成错 —— 因为「抢首评」这个功能要的恰恰就是
 *   「给我一个人，我去评论他最新那条微博」。所以这里做的是**分类 + 说清楚**，
 *   而不是拦下来。
 */
enum class TargetKind(val labelRes: Int) {
    /** 没填。 */
    NONE(R.string.interact_target_none),

    /** 一条具体的微博：能直接拿到 mid，评论 / 互评 / 楼赞都对着它做。 */
    POST(R.string.interact_target_post),

    /** 一个用户主页：要先去拉他「最新一条微博」，再对那条做动作。 */
    PROFILE(R.string.interact_target_profile),

    /**
     * ★★★★ 第 68 期：一个**超话** —— 先去它的帖子列表里**随机挑一条**，再对那条做动作。
     *
     * ★ 为什么加它：用户的目的是**涨超话经验**，而官方规则里涨经验的主力是
     *   「在当前超话评论帖子 +1/次（每日最多 4 次）」。要评论就得先有帖子 ——
     *   让用户一条条去复制链接不现实，贴一个超话链接就够了。
     */
    SUPERTOPIC(R.string.interact_target_supertopic),

    /** 看不懂 —— 抓包接入后大概率发不出去，先说清楚。 */
    UNKNOWN(R.string.interact_target_unknown)
}

/**
 * 目标字符串的解析。
 *
 * 支持的写法（都是微博真实在用的链接形态）：
 * - 纯数字 ID：`5012345678`（当作微博 mid）
 * - `m.weibo.cn/status/5012345678`、`m.weibo.cn/detail/5012345678`
 * - `weibo.com/9080022869/5345638346654862`（uid + **数字 mid**，★ 第 60 期补上）
 * - `weibo.com/1234567890/AbCdEfGh`（uid + base62 短 id）
 * - `weibo.com/u/6986999782`、`weibo.com/profile/6986999782`、`m.weibo.cn/u/6986999782`
 * - `weibo.com/6986999782`（只有一段数字 = uid）
 *
 * ★ 纯函数，不联网、不读存储、不碰任何共享状态。
 */
object InteractTarget {

    private val STATUS_PATH = Regex("""/(?:status|detail)/([A-Za-z0-9]+)""")
    private val PROFILE_PATH = Regex("""/(?:u|profile|n)/(\d{5,20})""")
    private val PURE_ID = Regex("""^\d{5,20}$""")
    private val BARE_PROFILE = Regex("""^(?:https?://)?(?:www\.|m\.)?weibo\.(?:com|cn)/(\d{5,20})/?$""")
    private val WEIBO_HOST = Regex("""weibo\.(?:com|cn)""", RegexOption.IGNORE_CASE)

    /**
     * ★★★★ 第 60 期新增：**两段路径** `weibo.com/<uid>/<mid>` —— 第二段就是微博 id。
     *
     * ★ 起因（真机实测踩到的）：用户把微博网页上「复制链接」拿到的地址
     *   `https://weibo.com/9080022869/5345638346654862` 填进目标，
     *   结果被判成**用户主页**，接着报「这条链接里没解析出用户 uid」直接中止。
     *
     * ★ 病因：原来的判断只看**最后一段是不是纯数字** ——
     *     `weibo.com/6986999782`            1 段、末段纯数字 ⇒ 主页   ✅
     *     `weibo.com/9080022869/5345638…`   2 段、末段也是纯数字 ⇒ **被判成主页**  ❌
     *   两种链接的末段长得一模一样，只看末段**根本区分不开**。
     *   ⇒ 必须改看**路径有几段**：host 后面还有第二段，就是「uid + 微博 id」。
     *
     * ★ 为什么这条链接非支持不可：它是微博网页端「复制链接」给出的**默认形态**，
     *   也是最常见的一种；不支持等于「按正常方式复制来的链接用不了」。
     *
     * ★ 第二段既可能是**数字 mid**，也可能是 base62 短 id，两种都收。
     */
    private val UID_POST_PATH =
        Regex("""weibo\.(?:com|cn)/(\d{5,20})/([A-Za-z0-9]+)""", RegexOption.IGNORE_CASE)

    /**
     * ★★★★ 第 68 期：超话的 container id —— `100808` + 32 位 hex。
     *
     * 支持的写法（用户实测给的就是第一种）：
     * - `m.weibo.cn/p/100808db807a7a7c131532c93920af92091f0e`
     * - `weibo.com/p/100808<hex>` / `weibo.com/page/100808<hex>`
     * - `m.weibo.cn/p/index?containerid=100808<hex>`（带查询串的那种）
     *
     * ★ 为什么用 `[0-9a-fA-F]{16,}` 而不是「必须 32 位」：超话 id 是 32 位 hex，
     *   但这里放宽下限 —— 多收几种总比漏掉强，反正 `100808` 这个前缀本身
     *   已经足够特异（微博的 mid 是纯数字、base62 短 id 不会以 `100808` 打头）。
     */
    private val TOPIC_PATH = Regex("""/(?:p|page)/(100808[0-9a-fA-F]{16,})""")
    private val TOPIC_CID = Regex("""containerid=(100808[0-9a-fA-F]{16,})""")

    /** 判断类型。 */
    fun kind(raw: String): TargetKind {
        val text = raw.trim()
        if (text.isBlank()) return TargetKind.NONE
        // ★★★★ 第 68 期：超话**必须最先判**。
        //   `m.weibo.cn/p/100808db807a…` 的末段是「数字+字母」，落到下面
        //   `WEIBO_HOST` 分支里会被判成 **POST**（末段不是全数字 ⇒ 当微博），
        //   然后 `postId()` 返回 `100808db807a…` 拿去当 mid 请求 ⇒ 必然失败。
        //   所以这条判断的位置**不能往后挪**。
        if (TOPIC_PATH.containsMatchIn(text) || TOPIC_CID.containsMatchIn(text)) {
            return TargetKind.SUPERTOPIC
        }
        if (PURE_ID.matches(text)) return TargetKind.POST
        if (STATUS_PATH.containsMatchIn(text)) return TargetKind.POST
        if (PROFILE_PATH.containsMatchIn(text)) return TargetKind.PROFILE
        if (BARE_PROFILE.matches(text)) return TargetKind.PROFILE
        if (WEIBO_HOST.containsMatchIn(text)) {
            // ★ 第 60 期：先看**段数**（`weibo.com/<uid>/<mid>` 是两段），再退回到
            //   「末段是不是纯数字」的老判断。顺序不能反 —— 反了就会把
            //   `weibo.com/9080022869/5345638346654862` 当成主页（正是第 60 期那个 bug）。
            if (UID_POST_PATH.containsMatchIn(text)) return TargetKind.POST
            // `weibo.com/<uid>` —— 只有一段；末段不是纯数字就当微博。
            val segment = text.trimEnd('/').substringAfterLast('/')
            return if (segment.isNotEmpty() && !segment.all { it.isDigit() }) {
                TargetKind.POST
            } else {
                TargetKind.PROFILE
            }
        }
        return TargetKind.UNKNOWN
    }

    /** 取微博 id（mid 或 base62 短 id）。取不到返回空串。 */
    fun postId(raw: String): String {
        val text = raw.trim().trimEnd('/')
        if (PURE_ID.matches(text)) return text
        STATUS_PATH.find(text)?.let { return it.groupValues[1] }
        // ★ 第 60 期：`weibo.com/<uid>/<mid>` 取第二段。
        //   ★ 顺带修掉一个潜在 bug：老代码走下面的「取最后一段」时，
        //     会把 `?from=page_100505` 这种查询串**一起**当成 mid 返回
        //     （`5345638346654862?from=page_100505`），发出去必然失败。
        //     这条正则只吃 `[A-Za-z0-9]+`，查询串自然被挡在外面。
        UID_POST_PATH.find(text)?.let { return it.groupValues[2] }
        val segment = text.substringAfterLast('/')
        return if (segment.isNotEmpty() && !segment.all { it.isDigit() }) segment else ""
    }

    /** 取用户 uid。取不到返回空串。 */
    fun uid(raw: String): String {
        val text = raw.trim().trimEnd('/')
        PROFILE_PATH.find(text)?.let { return it.groupValues[1] }
        BARE_PROFILE.find(text)?.let { return it.groupValues[1] }
        if (PURE_ID.matches(text)) return text
        return ""
    }

    /**
     * ★★★★ 第 68 期：取超话的 container id（形如 `100808<hex>`）。取不到返回空串。
     *
     * ★ 这里**刻意不 `trimEnd('/')`** —— 带查询串的形态（`…/p/index?containerid=100808…`）
     *   裁尾斜杠没有意义，而两个正则都是 `find`，前后多什么字符都不影响匹配。
     */
    fun topicId(raw: String): String {
        val text = raw.trim()
        TOPIC_PATH.find(text)?.let { return it.groupValues[1] }
        TOPIC_CID.find(text)?.let { return it.groupValues[1] }
        return ""
    }
}
