package com.tjh.weibotask

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * ★★★★ 第 117 期：**把一条 PostTask 启动起来**（界面层入口）。
 *
 * ★ 与 [AgentService] 的关系：本对象**只负责校验 + 拉起前台服务**，不碰任何发帖逻辑。
 *   真正的发帖循环在 [AgentService.runPostPhase] 里（单一数据源）。
 * ★ 本函数会**弹 toast** —— 它是「界面层发起」的专用入口；后续期次的定时启动
 *   不该走它（那条路要的是静默 + 状态回写），会另写入口。
 */
object PostTaskStarter {

    private const val LOG_TAG = "PostTaskStarter"

    /** 校验 + 启动。返回 true = 服务已拉起。 */
    fun start(context: Context, taskId: String): Boolean {
        Dbg.log(LOG_TAG, "请求启动发帖任务 id=" + taskId)
        AccountStore.init(context)
        PostTaskStore.init(context)
        val task = PostTaskStore.get(taskId)
        if (task == null) {
            toast(context, context.getString(R.string.pt_task_missing))
            return false
        }
        val todayStr = LocalScheduler.todayString()
        val totalPerAccount = task.perAccountPerRound.coerceAtLeast(1) * task.rounds.coerceAtLeast(1)
        if (PostTaskPlan.accounts(task, todayStr, totalPerAccount).isEmpty()) {
            toast(context, context.getString(R.string.pt_task_no_account))
            return false
        }
        if (PostTaskPlan.bodies(task).isEmpty()) {
            toast(context, context.getString(R.string.pt_task_no_content))
            return false
        }
        val intent = Intent(context, AgentService::class.java).apply {
            action = AgentService.ACTION_RUN_POST_TASK
            putExtra(AgentService.EXTRA_POST_TASK_ID, taskId)
        }
        ContextCompat.startForegroundService(context, intent)
        return true
    }

    /**
     * ★★★★ 第 126 期（用户拍板）：**静默续跑落盘的排队任务**。
     *
     * ## 与 [start] 的区别
     *
     * **不校验、不弹 toast**。队列里的 id 都是「用户已经点过开始 / 闹钟已经响过」的
     * 任务，恢复它的目的是「接着把它跑完」，不是「再问用户一次」——
     * 每次回前台都校验失败弹一次 toast，只会变成噪音。
     *
     * ## 为什么重复调用是安全的
     *
     * - **同一条正在跑** ⇒ `AgentService.requestPostTask` 里新增的「同 id 忽略」挡掉；
     * - **不同 id** ⇒ [TaskQueue.offer] 自带去重，排两份不会跑两遍。
     *
     * ★ 真正能不能跑由 `AgentService.executePostTaskOnce` 自己把关
     *   （任务已被用户删除 ⇒ `PostTaskStore.get` 返回 null ⇒ 记 IDLE 后返回）。
     * ★ 只在**队列非空**时调用；队列空 ⇒ 返回 false，什么都不做。
     */
    fun resumeQueued(context: Context): Boolean {
        TaskQueue.init(context)
        val head = TaskQueue.peek() ?: return false
        val intent = Intent(context, AgentService::class.java).apply {
            action = AgentService.ACTION_RUN_POST_TASK
            putExtra(AgentService.EXTRA_POST_TASK_ID, head)
        }
        return try {
            ContextCompat.startForegroundService(context, intent)
            Dbg.log(LOG_TAG, "恢复排队中的发帖任务 id=" + head)
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun toast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
