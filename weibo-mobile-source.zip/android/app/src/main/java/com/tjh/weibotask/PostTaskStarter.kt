package com.tjh.weibotask

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * ★★★★ 第 117 期：**把一条 PostTask 启动起来**（界面层入口）。
 *
 * ★ 与 [AgentService] 的关系：本对象**只负责校验 + 拉起前台服务**，不碰任何发帖逻辑。
 *   真正的发帖循环在 [AgentService.runPostPhase] 里（单一数据源）。
 * ★ 本函数会**弹 toast** —— 它是「界面层发起」的专用入口；后续期次的定时启动
 *   不该走它（那条路要的是静默 + 状态回写），会另写入口。
 */
object PostTaskStarter {

    private const val LOG_TAG = "PostTaskStarter"

    /** 校验 + 启动。返回 true = 服务已拉起。 */
    fun start(context: Context, taskId: String): Boolean {
        Dbg.log(LOG_TAG, "请求启动发帖任务 id=" + taskId)
        AccountStore.init(context)
        PostTaskStore.init(context)
        val task = PostTaskStore.get(taskId)
        if (task == null) {
            toast(context, context.getString(R.string.pt_task_missing))
            return false
        }
        val todayStr = LocalScheduler.todayString()
        val totalPerAccount = task.perAccountPerRound.coerceAtLeast(1) * task.rounds.coerceAtLeast(1)
        if (PostTaskPlan.accounts(task, todayStr, totalPerAccount).isEmpty()) {
            toast(context, context.getString(R.string.pt_task_no_account))
            return false
        }
        if (PostTaskPlan.bodies(task).isEmpty()) {
            toast(context, context.getString(R.string.pt_task_no_content))
            return false
        }
        val intent = Intent(context, AgentService::class.java).apply {
            action = AgentService.ACTION_RUN_POST_TASK
            putExtra(AgentService.EXTRA_POST_TASK_ID, taskId)
        }
        ContextCompat.startForegroundService(context, intent)
        return true
    }

    private fun toast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
