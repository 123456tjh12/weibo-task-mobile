package com.tjh.weibotask

import android.util.Log

/**
 * 调试日志总开关。
 *
 * ★ 为什么是「开关」而不是直接删掉：
 *   验证链路（无障碍点签到 → 滑块拖动）出错时**没有别的线索** ——
 *   本工程没有 CrashLog / StepLog，logcat 里的这几行就是唯一能取证的东西。
 *   所以默认不输出（logcat 干净），需要时把 [enabled] 改成 true 再装包。
 *
 * 排查步骤：
 *   1. 把 [enabled] 改成 true
 *   2. 装包、复现问题
 *   3. `adb logcat -s Dbg`（标签仍是 AutoVerify / CheckinBtn / DragDebug / YidunFlow）
 */
object Dbg {
    /**
     * 需要排查时改成 true。
     * ★ 故意不用 `const val` —— 常量会被编译器折成「条件恒为 false」并给警告，
     *   而这个警告在只做静态检查、出不了包的环境里很难被发现。
     *
     * ★★ 第 40 期：默认改为 `true`。第 39 期两次真机取证都因为「拿不到证据」而无法定性
     *   （黑匣子 80 条被挤掉 + logcat 里一行应用日志都没有）。排查期先开着，
     *   交付时再改回 false。★ 它只决定「日志打不打」，不参与任何判定。
     *
     * ★ 第 73 期 A：交付态，改回 `false`。
     */
    @Volatile
    var enabled: Boolean = false

    fun log(tag: String, message: String) {
        if (enabled) {
            Log.e(tag, message)
        }
    }
}
