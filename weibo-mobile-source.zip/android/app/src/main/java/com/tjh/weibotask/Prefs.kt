package com.tjh.weibotask

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object Prefs {
    private const val FILE_NAME = "weibo_task_secure"
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        prefs = EncryptedSharedPreferences.create(
            context,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    var cloudUrl: String
        get() = prefs.getString("cloud_url", "") ?: ""
        set(value) = prefs.edit().putString("cloud_url", value).apply()

    var deviceToken: String
        get() = prefs.getString("device_token", "") ?: ""
        set(value) = prefs.edit().putString("device_token", value).apply()

    var deviceId: String
        get() = prefs.getString("device_id", "") ?: ""
        set(value) = prefs.edit().putString("device_id", value).apply()

    val paired: Boolean
        get() = deviceToken.isNotBlank()

    var cookieHeader: String
        get() = prefs.getString("weibo_cookie", "") ?: ""
        set(value) = prefs.edit().putString("weibo_cookie", value).apply()

    var weiboVerified: Boolean
        get() = prefs.getBoolean("weibo_verified", false)
        set(value) = prefs.edit().putBoolean("weibo_verified", value).apply()

    var riskScore: Int
        get() = prefs.getInt("risk_score", 0)
        set(value) = prefs.edit().putInt("risk_score", value.coerceIn(0, 100)).apply()

    var consecutiveFailures: Int
        get() = prefs.getInt("consecutive_failures", 0)
        set(value) = prefs.edit().putInt("consecutive_failures", value.coerceAtLeast(0)).apply()

    var scheduleEnabled: Boolean
        get() = prefs.getBoolean("schedule_enabled", false)
        set(value) = prefs.edit().putBoolean("schedule_enabled", value).apply()

    var baseHour: Int
        get() = prefs.getInt("base_hour", 8)
        set(value) = prefs.edit().putInt("base_hour", value.coerceIn(0, 23)).apply()

    var baseMinute: Int
        get() = prefs.getInt("base_minute", 5)
        set(value) = prefs.edit().putInt("base_minute", value.coerceIn(0, 59)).apply()

    var nextRunAt: Long
        get() = prefs.getLong("next_run_at", 0L)
        set(value) = prefs.edit().putLong("next_run_at", value).apply()

    var lastRunDate: String
        get() = prefs.getString("last_run_date", "") ?: ""
        set(value) = prefs.edit().putString("last_run_date", value).apply()

    var lastRunStatus: String
        get() = prefs.getString("last_run_status", "") ?: ""
        set(value) = prefs.edit().putString("last_run_status", value).apply()

    val weiboLoggedIn: Boolean
        get() = weiboVerified && cookieHeader.contains("SUB=")
}
