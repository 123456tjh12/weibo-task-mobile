package com.tjh.weibotask

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object Prefs {
    private const val FILE_NAME = "weibo_task_secure"
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        prefs = EncryptedSharedPreferences.create(
            context,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    var cloudUrl: String
        get() = prefs.getString("cloud_url", "") ?: ""
        set(value) = prefs.edit().putString("cloud_url", value).apply()

    var deviceToken: String
        get() = prefs.getString("device_token", "") ?: ""
        set(value) = prefs.edit().putString("device_token", value).apply()

    var deviceId: String
        get() = prefs.getString("device_id", "") ?: ""
        set(value) = prefs.edit().putString("device_id", value).apply()

    val paired: Boolean
        get() = deviceToken.isNotBlank()

    var cookieHeader: String
        get() = prefs.getString("weibo_cookie", "") ?: ""
        set(value) = prefs.edit().putString("weibo_cookie", value).apply()

    /**
     * 多账号列表（整段 JSON 一起加密）。
     * 下面是 v16 及以前的单账号字段，保留它们只为了**一次性迁移**，
     * 迁移完成后所有读写都走 accountsJson。
     */
    var accountsJson: String
        get() = prefs.getString("accounts_json", "") ?: ""
        set(value) = prefs.edit().putString("accounts_json", value).apply()

    var weiboVerified: Boolean
        get() = prefs.getBoolean("weibo_verified", false)
        set(value) = prefs.edit().putBoolean("weibo_verified", value).apply()

    var lastLoginCheckAt: Long
        get() = prefs.getLong("last_login_check_at", 0L)
        set(value) = prefs.edit().putLong("last_login_check_at", value).apply()

    var lastLoginCheckMessage: String
        get() = prefs.getString("last_login_check_message", "") ?: ""
        set(value) = prefs.edit().putString("last_login_check_message", value).apply()

    var cookieExpiryAt: Long
        get() = prefs.getLong("cookie_expiry_at", 0L)
        set(value) = prefs.edit().putLong("cookie_expiry_at", value).apply()

    var riskScore: Int
        get() = prefs.getInt("risk_score", 0)
        set(value) = prefs.edit().putInt("risk_score", value.coerceIn(0, 100)).apply()

    var consecutiveFailures: Int
        get() = prefs.getInt("consecutive_failures", 0)
        set(value) = prefs.edit().putInt("consecutive_failures", value.coerceAtLeast(0)).apply()

    var scheduleEnabled: Boolean
        get() = prefs.getBoolean("schedule_enabled", false)
        set(value) = prefs.edit().putBoolean("schedule_enabled", value).apply()

    /**
     * 自动签到开关**最近一次变化**的时间。
     *
     * ★ 为什么必须记：诊断报告里出现「设定时间已保存、但开关是关的」这种组合时，
     *   完全无法判断到底是用户自己关的、还是程序某条路径把它关掉了 ——
     *   而这决定了接下来该修界面还是修逻辑，猜错就是白改一轮。
     *   有了这个时间戳，报告里能直接写出「什么时候被关的、关了多久」。
     */
    var scheduleEnabledChangedAt: Long
        get() = prefs.getLong("schedule_enabled_changed_at", 0L)
        set(value) = prefs.edit().putLong("schedule_enabled_changed_at", value).apply()

    /**
     * 自动签到开关**是被谁改的**（一句中文说明，直接显示给用户看）。
     *
     * ★ 所有改动开关的地方都必须经过 `MainActivity.setScheduleEnabled()` 写入原因，
     *   否则这个字段就是空的 —— 空值本身就是「有未知路径在改开关」的信号。
     */
    var scheduleEnabledChangedBy: String
        get() = prefs.getString("schedule_enabled_changed_by", "") ?: ""
        set(value) = prefs.edit().putString("schedule_enabled_changed_by", value).apply()

    var baseHour: Int
        get() = prefs.getInt("base_hour", 8)
        set(value) = prefs.edit().putInt("base_hour", value.coerceIn(0, 23)).apply()

    var baseMinute: Int
        get() = prefs.getInt("base_minute", 5)
        set(value) = prefs.edit().putInt("base_minute", value.coerceIn(0, 59)).apply()

    var startDate: String
        get() = prefs.getString("start_date", "") ?: ""
        set(value) = prefs.edit().putString("start_date", value).apply()

    var skipDate: String
        get() = prefs.getString("skip_date", "") ?: ""
        set(value) = prefs.edit().putString("skip_date", value).apply()

    /**
     * 风控 / 验证码等场景的「限时暂停」截止时间。
     * 旧实现遇到这些情况直接把 scheduleEnabled 置 false 并取消闹钟，
     * 等于一次偶发风控就永久废掉自动签到。改为暂停一段时间后自动重试。
     */
    var pausedUntil: Long
        get() = prefs.getLong("paused_until", 0L)
        set(value) = prefs.edit().putLong("paused_until", value).apply()

    var nextRunAt: Long
        get() = prefs.getLong("next_run_at", 0L)
        set(value) = prefs.edit().putLong("next_run_at", value).apply()

    /**
     * 闹钟**最近一次真正触发**的时间。
     *
     * ★ 为什么需要它：用户报「到点没执行」时，有两种完全不同的原因 ——
     *   (a) 闹钟根本没触发（被系统省电策略丢弃 / 应用被强制停止）；
     *   (b) 闹钟触发了，但后台启动前台服务被系统拒绝。
     *   以前这两种情况在界面上长得一模一样，只能靠猜。
     *   有了这个时间戳，「闹钟有没有响过」一眼可辨：
     *     首页显示「闹钟最近触发：XX:XX」→ 说明 (a) 不成立，问题在 (b) 或执行环节；
     *     这个时间停在昨天 → 闹钟压根没响，要去做后台白名单设置。
     */
    var lastAlarmAt: Long
        get() = prefs.getLong("last_alarm_at", 0L)
        set(value) = prefs.edit().putLong("last_alarm_at", value).apply()

    /**
     * 后台服务的心跳时间（维护循环每一轮刷新一次）。
     *
     * ★ 这是「到点会不会执行」的分水岭：
     *   服务活着 → 维护循环会发现「到点了」并直接执行，**根本不依赖闹钟**；
     *   服务死了 → 只能靠闹钟，而闹钟在国产 ROM 的省电策略下很容易被丢弃。
     *   以前首页完全看不出服务是死是活，用户只能反复猜「为什么没签」。
     */
    var serviceAliveAt: Long
        get() = prefs.getLong("service_alive_at", 0L)
        set(value) = prefs.edit().putLong("service_alive_at", value).apply()

    /**
     * 是否有账号正卡在微博的「请先验证身份」上。
     *
     * ★ 为什么单独用一个标记，而不是让界面去猜 `lastRunMessage` 里有没有「验证」两个字：
     *   这是**需要用户动手**的状态（去微博点一次验证），必须稳定地显示出来。
     *   靠字符串匹配来判断，微博改一次文案、或文案被 400 字截断，提示就消失了 ——
     *   用户又会回到「设了时间却没签，也不知道为什么」的状态。
     *
     * 置 true：某次签到收到验证拦截。
     * 置 false：某次签到正常完成（说明用户已经验证过了）。
     */
    var needsVerify: Boolean
        get() = prefs.getBoolean("needs_verify", false)
        set(value) = prefs.edit().putBoolean("needs_verify", value).apply()

    /** 最近一次成功登记的闹钟档位：alarm_clock / exact / inexact / failed。 */
    var lastAlarmMode: String
        get() = prefs.getString("last_alarm_mode", "") ?: ""
        set(value) = prefs.edit().putString("last_alarm_mode", value).apply()

    /** 闹钟登记失败或降级时的最后一个异常名，供首页诊断。 */
    var lastAlarmError: String
        get() = prefs.getString("last_alarm_error", "") ?: ""
        set(value) = prefs.edit().putString("last_alarm_error", value).apply()

    /** Receiver 已调用 startForegroundService 的时间；不等于服务已经真正启动。 */
    var lastAlarmAcceptedAt: Long
        get() = prefs.getLong("last_alarm_accepted_at", 0L)
        set(value) = prefs.edit().putLong("last_alarm_accepted_at", value).apply()

    /** AgentService.onStartCommand 最近一次真正执行的时间。 */
    var lastServiceStartAt: Long
        get() = prefs.getLong("last_service_start_at", 0L)
        set(value) = prefs.edit().putLong("last_service_start_at", value).apply()

    /** 等待阶段的短时唤醒保护截止时间；0 表示当前未保护。 */
    var standbyProtectedUntil: Long
        get() = prefs.getLong("standby_protected_until", 0L)
        set(value) = prefs.edit().putLong("standby_protected_until", value).apply()

    /**
     * 短时唤醒保护**最近一次真正申请成功**的时刻（只增不清，纯诊断用）。
     *
     * ★ 为什么不能只看 [standbyProtectedUntil]：它会被 `executeOnce` 开头和
     *   `releaseStandbyWakeLock()` 清零，所以报告里经常显示「无记录」。
     *   那个值回答的是「**此刻**是否受保护」，而这个字段回答的是
     *   「**到底有没有保护过**」—— 排查「到点不执行」时需要的正是后者。
     */
    var standbyAcquiredAt: Long
        get() = prefs.getLong("standby_acquired_at", 0L)
        set(value) = prefs.edit().putLong("standby_acquired_at", value).apply()

    /** 唤醒锁申请失败的原因；空字符串表示没有失败过。 */
    var standbyError: String
        get() = prefs.getString("standby_error", "") ?: ""
        set(value) = prefs.edit().putString("standby_error", value).apply()

    /**
     * 看门狗闹钟的下一次触发时间（**与 nextRunAt 完全独立**）。
     *
     * ★ 单独存一份，绝不能用它覆盖 `nextRunAt` —— v19.4 就是因为看门狗写进了 nextRunAt，
     *   导致维护循环一直以为「下次执行还早」，任务永远不开始。
     */
    var lastWatchdogAt: Long
        get() = prefs.getLong("last_watchdog_at", 0L)
        set(value) = prefs.edit().putLong("last_watchdog_at", value).apply()

    var lastRunDate: String
        get() = prefs.getString("last_run_date", "") ?: ""
        set(value) = prefs.edit().putString("last_run_date", value).apply()

    var lastRunStatus: String
        get() = prefs.getString("last_run_status", "") ?: ""
        set(value) = prefs.edit().putString("last_run_status", value).apply()

    var lastRunAt: Long
        get() = prefs.getLong("last_run_at", 0L)
        set(value) = prefs.edit().putLong("last_run_at", value).apply()

    var lastRunMessage: String
        get() = prefs.getString("last_run_message", "") ?: ""
        set(value) = prefs.edit().putString("last_run_message", value).apply()

    /**
     * 当前是否正在执行签到。
     * 首页用它把「正在执行：…」和「上次执行：…」区分开 ——
     * 否则一轮签到跑一两分钟，界面一直显示旧结果，用户会以为没反应。
     */
    var running: Boolean
        get() = prefs.getBoolean("running", false)
        set(value) = prefs.edit().putBoolean("running", value).apply()

    val weiboLoggedIn: Boolean
        get() = weiboVerified && cookieHeader.contains("SUB=")
}
