package com.tjh.weibotask

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.PowerManager
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.DatePicker
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val handler = Handler(Looper.getMainLooper())

    /** 账号 id -> 该行视图。列表结构变化时重建，状态变化时只改文字。 */
    private val rowViews = mutableMapOf<String, View>()

    private val refreshRunnable = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        AccountStore.init(this)
        AccountStore.ensureAtLeastOne()
        setContentView(R.layout.activity_main)

        val datePicker = findViewById<DatePicker>(R.id.datePicker)
        val timePicker = findViewById<TimePicker>(R.id.timePicker)
        timePicker.setIs24HourView(true)

        datePicker.minDate = System.currentTimeMillis() - 1000L
        val startCalendar = Calendar.getInstance()
        if (Prefs.startDate.isNotBlank()) {
            try { startCalendar.time = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).parse(Prefs.startDate) ?: Date() } catch (_: Exception) {}
        }
        datePicker.updateDate(
            startCalendar.get(Calendar.YEAR),
            startCalendar.get(Calendar.MONTH),
            startCalendar.get(Calendar.DAY_OF_MONTH)
        )

        timePicker.hour = Prefs.baseHour
        timePicker.minute = Prefs.baseMinute

        requestNotificationPermission()

        findViewById<Button>(R.id.addAccountButton).setOnClickListener {
            // 先建一个空账号槽位，再带它的 id 去登录页，
            // 登录成功后 Cookie 会精确写回这个槽位，不会覆盖其它账号
            val account = AccountStore.add()
            renderAccounts()
            updateStatus()
            openLogin(account)
        }

        findViewById<Button>(R.id.checkLoginButton).setOnClickListener {
            checkAllLogins()
        }

        findViewById<Button>(R.id.saveScheduleButton).setOnClickListener {
            Prefs.startDate = String.format(
                Locale.CHINA,
                "%04d-%02d-%02d",
                datePicker.year,
                datePicker.month + 1,
                datePicker.dayOfMonth
            )
            Prefs.skipDate = ""
            Prefs.baseHour = timePicker.hour
            Prefs.baseMinute = timePicker.minute
            Prefs.scheduleEnabled = true
            // 用户手动重新开启时，清掉风控暂停状态，否则会被顺延到暂停结束时间
            Prefs.pausedUntil = 0L
            requestExactAlarmPermissionIfNeeded()
            LocalScheduler.scheduleNext(this)
            val serviceIntent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_START_SCHEDULED
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            updateStatus()
            toast("自动签到已开启")
        }

        findViewById<Button>(R.id.skipTodayButton).setOnClickListener {
            if (!Prefs.scheduleEnabled) {
                toast("请先开启自动签到")
                return@setOnClickListener
            }
            LocalScheduler.skipToday(this)
            val serviceIntent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_START_SCHEDULED
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            updateStatus()
            toast("今天不签到，已安排到下一天")
        }

        findViewById<Button>(R.id.disableScheduleButton).setOnClickListener {
            Prefs.scheduleEnabled = false
            Prefs.pausedUntil = 0L
            LocalScheduler.cancel(this)
            stopService(Intent(this, AgentService::class.java))
            updateStatus()
            toast("自动签到已关闭")
        }

        findViewById<Button>(R.id.compatibilityButton).setOnClickListener {
            DeviceCompatibility.showGuide(this)
        }

        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        findViewById<Button>(R.id.runNowButton).setOnClickListener {
            val ready = AccountStore.ready()
            if (ready.isEmpty()) {
                findViewById<TextView>(R.id.logText).text = "没有可用的微博账号，请先登录"
                toast("请先添加并登录微博账号")
                return@setOnClickListener
            }
            Prefs.lastRunAt = System.currentTimeMillis()
            Prefs.lastRunMessage = "已启动签到任务（" + ready.size + " 个账号），正在执行……"
            findViewById<TextView>(R.id.logText).text = Prefs.lastRunMessage
            val intent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_RUN_CHECKIN
            }
            ContextCompat.startForegroundService(this, intent)
            toast("已开始立即签到")
        }

        renderAccounts()
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        Prefs.init(this)
        AccountStore.init(this)
        if (Prefs.scheduleEnabled) {
            LocalScheduler.ensureScheduled(this)
            val serviceIntent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_START_SCHEDULED
            }
            ContextCompat.startForegroundService(this, serviceIntent)
        }
        // 从登录页返回时账号状态会变，重建一次行视图
        renderAccounts()
        updateStatus()
        // 有账号超过 12 小时没检查过登录态，就顺手查一遍
        val stale = AccountStore.all().any {
            it.cookie.isNotBlank() &&
                System.currentTimeMillis() - it.lastCheckAt > 12L * 60L * 60L * 1000L
        }
        if (stale) checkAllLogins()
        handler.removeCallbacks(refreshRunnable)
        handler.post(refreshRunnable)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshRunnable)
        super.onPause()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun updateStatus() {
        val accounts = AccountStore.all()
        val readyCount = accounts.count { it.enabled && it.loggedIn }
        findViewById<TextView>(R.id.weiboStatus).text = when {
            accounts.isEmpty() -> "还没有添加微博账号"
            readyCount == 0 -> "共 " + accounts.size + " 个账号，暂时没有可签到的（未登录或已停用）"
            else -> "共 " + accounts.size + " 个账号，" + readyCount + " 个可签到"
        }

        val checkLines = mutableListOf<String>()
        for (account in accounts) {
            if (account.cookie.isBlank()) continue
            val time = if (account.lastCheckAt > 0L) {
                SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(account.lastCheckAt)) + " "
            } else {
                ""
            }
            val expiry = if (account.expiryAt > 0L) {
                "（会话到期 " + SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(account.expiryAt)) + "）"
            } else {
                ""
            }
            checkLines.add(
                account.label + "：" + time + account.lastCheckMessage.ifBlank { "尚未检查" } + expiry
            )
        }
        findViewById<TextView>(R.id.loginCheckStatus).text =
            if (checkLines.isEmpty()) "尚未检查登录状态" else checkLines.joinToString("\n")

        refreshAccountRows()

        val exactAllowed = LocalScheduler.exactAlarmAllowed(this)
        val power = getSystemService(PowerManager::class.java)
        val batteryAllowed = power.isIgnoringBatteryOptimizations(packageName)

        val scheduleText = StringBuilder()
        if (Prefs.scheduleEnabled) {
            scheduleText.append(LocalScheduler.formatNextRun(this))
            if (Prefs.pausedUntil > System.currentTimeMillis()) {
                scheduleText.append("\n状态：风控暂停中，")
                    .append(SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(Prefs.pausedUntil)))
                    .append(" 后自动重试")
            }
            scheduleText.append("\n上次结果：").append(Prefs.lastRunStatus.ifBlank { "暂无" })
            if (Prefs.lastRunMessage.isNotBlank()) {
                scheduleText.append("\n上次信息：").append(Prefs.lastRunMessage)
            }
        } else {
            scheduleText.append("自动签到未开启")
        }
        scheduleText.append("\n精确闹钟：")
            .append(if (exactAllowed) "已允许" else "未允许（定时会被系统延迟甚至拦截）")
        scheduleText.append("\n电池优化：")
            .append(if (batteryAllowed) "已关闭" else "未关闭（后台可能被冻结）")
        if (!exactAllowed || !batteryAllowed) {
            scheduleText.append("\n⚠ 请点下方「全安卓后台兼容设置」完成配置，否则定时任务可能不执行")
        }
        findViewById<TextView>(R.id.scheduleStatus).text = scheduleText.toString()

        // 区分「正在执行」和「上次执行」：
        // 旧实现整轮都显示上一轮的结果，签到跑起来后界面毫无变化，像是没反应。
        // 这里再加一层时间兜底 —— 万一进程被杀，「正在执行」标记不会永远挂着。
        val runningNow = Prefs.running &&
            System.currentTimeMillis() - Prefs.lastRunAt < 6 * 60 * 1000L
        val lastText = when {
            runningNow -> "正在执行…\n" + Prefs.lastRunMessage.ifBlank { "正在执行微博签到" }
            Prefs.lastRunAt > 0L -> {
                val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date(Prefs.lastRunAt))
                "上次执行：" + time + "\n" + Prefs.lastRunMessage.ifBlank { "无结果" }
            }
            else -> "等待操作"
        }
        findViewById<TextView>(R.id.logText).text = lastText
    }

    /**
     * 逐个检查所有账号的登录态。
     *
     * ★ 与旧版的区别：某个账号掉线**不再关闭整个自动签到**。
     *   多账号场景下，一个号掉线不该拖累其它号继续签到。
     */
    private fun checkAllLogins() {
        val accounts = AccountStore.all()
        if (accounts.isEmpty()) {
            findViewById<TextView>(R.id.logText).text = "还没有添加微博账号"
            return
        }
        scope.launch {
            findViewById<TextView>(R.id.logText).text =
                "正在检查 " + accounts.size + " 个账号的登录状态……"
            val lines = mutableListOf<String>()
            for (account in accounts) {
                val result = withContext(Dispatchers.IO) {
                    try {
                        val config = WeiboClient.fetchConfig(account)
                        when {
                            !config.has("login") -> LoginCheck.UNKNOWN
                            config.optBoolean("login") -> LoginCheck.OK
                            else -> LoginCheck.EXPIRED
                        }
                    } catch (_: Exception) {
                        // 网络异常 / 超时 / 无网，都归为「未知」，不能据此判定掉线
                        LoginCheck.UNKNOWN
                    }
                }
                account.lastCheckAt = System.currentTimeMillis()
                when (result) {
                    LoginCheck.OK -> {
                        account.verified = true
                        account.lastCheckMessage = "登录正常"
                    }
                    LoginCheck.EXPIRED -> {
                        account.verified = false
                        account.lastCheckMessage = "登录已失效，需要重新登录"
                    }
                    LoginCheck.UNKNOWN -> {
                        // 旧实现在这里把 scheduleEnabled 置 false 并取消闹钟，
                        // 导致一次网络抖动就会让自动签到永久停摆，且用户毫无感知。
                        account.lastCheckMessage = "检查未完成（网络异常）"
                    }
                }
                lines.add(account.label + "：" + account.lastCheckMessage)
            }
            AccountStore.save()
            findViewById<TextView>(R.id.logText).text = lines.joinToString("\n")
            renderAccounts()
            updateStatus()
        }
    }

    /** 账号列表结构变化（增删/启停/登录返回）时重建所有行 */
    private fun renderAccounts() {
        val container = findViewById<LinearLayout>(R.id.accountList)
        container.removeAllViews()
        rowViews.clear()

        val accounts = AccountStore.all()
        if (accounts.isEmpty()) {
            val empty = TextView(this)
            empty.text = "还没有账号，点下面「添加微博账号」"
            empty.setTextColor(Color.parseColor("#667085"))
            empty.textSize = 13f
            container.addView(empty)
            return
        }

        val inflater = LayoutInflater.from(this)
        for (account in accounts) {
            val row = inflater.inflate(R.layout.item_account, container, false)
            rowViews[account.id] = row

            row.findViewById<Button>(R.id.accountLoginButton).setOnClickListener {
                openLogin(account)
            }
            row.findViewById<Button>(R.id.accountToggleButton).setOnClickListener {
                account.enabled = !account.enabled
                AccountStore.save()
                refreshAccountRows()
                updateStatus()
                toast(account.label + (if (account.enabled) " 已启用" else " 已停用"))
            }
            row.findViewById<Button>(R.id.accountRemoveButton).setOnClickListener {
                confirmRemove(account)
            }
            container.addView(row)
        }
        refreshAccountRows()
    }

    /** 只刷新已有行的文字，不重建视图（每 2 秒调一次，重建会打断滚动和点击） */
    private fun refreshAccountRows() {
        for (account in AccountStore.all()) {
            val row = rowViews[account.id] ?: continue

            row.findViewById<TextView>(R.id.accountName).text = account.label

            val state = row.findViewById<TextView>(R.id.accountState)
            when {
                !account.enabled -> {
                    state.text = "已停用"
                    state.setTextColor(Color.parseColor("#667085"))
                }
                account.loggedIn -> {
                    state.text = "已登录"
                    state.setTextColor(Color.parseColor("#067647"))
                }
                account.cookie.isNotBlank() -> {
                    state.text = "登录已失效"
                    state.setTextColor(Color.parseColor("#B54708"))
                }
                else -> {
                    state.text = "未登录"
                    state.setTextColor(Color.parseColor("#B54708"))
                }
            }

            val summary = account.lastRunMessage.lineSequence().firstOrNull().orEmpty()
            row.findViewById<TextView>(R.id.accountInfo).text = when {
                summary.isNotBlank() -> summary
                account.cookie.isBlank() -> "尚未登录"
                else -> "尚未签到"
            }

            row.findViewById<Button>(R.id.accountLoginButton).text =
                if (account.loggedIn) "重新登录" else "登录"
            row.findViewById<Button>(R.id.accountToggleButton).text =
                if (account.enabled) "停用" else "启用"
        }
    }

    private fun openLogin(account: WeiboAccount) {
        startActivity(
            Intent(this, WeiboLoginActivity::class.java)
                .putExtra(WeiboLoginActivity.EXTRA_ACCOUNT_ID, account.id)
        )
    }

    private fun confirmRemove(account: WeiboAccount) {
        AlertDialog.Builder(this)
            .setTitle("删除「" + account.label + "」？")
            .setMessage("会同时删除该账号的登录信息，之后需要重新扫码。其它账号不受影响。")
            .setNegativeButton("取消", null)
            .setPositiveButton("删除") { _, _ ->
                AccountStore.remove(account.id)
                renderAccounts()
                updateStatus()
                toast("已删除 " + account.label)
            }
            .show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    private fun requestExactAlarmPermissionIfNeeded() {
        DeviceCompatibility.openExactAlarmSettings(this)
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}

/** 登录检查结果：必须区分「确实掉线」和「这次没查成」 */
private enum class LoginCheck { OK, EXPIRED, UNKNOWN }
