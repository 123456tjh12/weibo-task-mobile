package com.tjh.weibotask

import android.Manifest
import android.app.ActivityManager
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.PowerManager
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val handler = Handler(Looper.getMainLooper())

    /** 账号 id -> 该行视图。列表结构变化时重建，状态变化时只改文字。 */
    private val rowViews = mutableMapOf<String, View>()

    /**
     * 本次启动是否已经提示过「闹钟和提醒」权限。
     *
     * ★ 必须只提示一次：这个提示的按钮会跳到系统设置页，
     *   如果每次回到前台都弹，用户点「返回」就又弹一次，会变成退不出去的死循环。
     */
    private var exactAlarmPrompted = false

    /**
     * 本次启动是否已经提示过「自动签到还没开启」。
     *
     * ★ 同样只弹一次：横幅是常驻的，弹窗只是「第一次打开时确保被看见」。
     *   每次都弹会让用户烦，但一次都不弹又可能整轮排查方向都是错的。
     */
    private var schedulePrompted = false

    /**
     * 本次启动是否已经提示过「全自动验证的前置设置」（无障碍 + 全屏通知）。
     *
     * ★ 和上面两个同样的理由：只提示一次，避免「点去设置 → 返回 → 又弹」的死循环。
     *   见 checkAutoVerifySetup()。
     */
    private var autoVerifyPrompted = false

    /**
     * 使用说明是否展开（首页 4 处灰色小字）。
     *
     * ★ 默认收起：对已经会用的人来说，那些说明每次打开都要越过才能看到状态，
     *   是纯噪音；但对第一次用的人又必须能看到。一个开关同时满足两边。
     *   ★ 收起只是「不显示」，不改变任何行为 —— 警示横幅、状态块、按钮全都不受影响。
     */
    private var notesExpanded = false

    /**
     * 状态块的详细部分是否展开。
     *
     * ★ 默认收起：那一块会长到十几行（执行链 + 每轮账号明细），
     *   而每天要看的只有「下次什么时候跑 / 今天签了几个 / 上次成没成」。
     * ★ 但收起**只针对正常时的细节** —— 需要用户动手的告警由 updateStatus()
     *   用 alerts 列表提升到摘要区，不受这个开关影响。
     */
    private var statusExpanded = false

    /**
     * 「更多设置」是否展开（测试自动签到 / 今天跳过）。
     *
     * ★ 默认收起：这两个是**低频**动作 —— 一个只在排查时用，一个一天最多用一次。
     *   但「自动签到开关」和「每天几点」必须常驻可见，它们属于「不设置就一定不执行」。
     */
    private var advancedExpanded = false

    /**
     * 程序自己在改 [R.id.scheduleSwitch] 的选中状态时置 true。
     *
     * ★ 为什么必须有这个闸：SwitchCompat 的 setOnCheckedChangeListener 在**代码**
     *   改 isChecked 时同样会触发。updateStatus() 每 2 秒跑一次并同步开关状态，
     *   没有这个闸就会变成「同步 → 触发监听 → 再次开启/关闭 → 再同步」的死循环，
     *   而且会在用户什么都没点的情况下反复登记闹钟。
     */
    private var syncingScheduleSwitch = false

    /**
     * 设置页当前是否可见。
     *
     * ★ 为什么需要这个标记：设置页那行「已开启 N / 3 项」要读三个系统设置
     *   （无障碍服务列表、通知开关、悬浮窗开关），全是**跨进程调用**；
     *   而 updateStatus() 每 2 秒跑一次 —— 常驻计算等于每 2 秒做三次 binder 往返，
     *   纯属浪费。只在设置页真的显示时才刷新。
     */
    private var settingsPageVisible = false

    private val refreshRunnable = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 2000)
        }
    }

    // ---------------------------------------- 第 107 期：发帖页「任务信息卡片」

    /**
     * ★★★★ 第 107 期：**任务信息卡片**的六个格子 + 一个轮询开关。
     *   （取代第 106 期的「发帖实况卡」—— 同一个位置，四区结构，信息更完整。）
     *
     * 为什么单独做一个轮询器，而不是搭 `refreshRunnable`（那支每 2 秒刷全页状态）：
     *   · 这支**只在发帖页可见时跑**，0.8 秒一拍 —— 后台通常一两秒才发完一个账号，
     *     再快就只是空转；2 秒又嫌慢，用户点了「立即发一条试试」看不出反应。
     *   · 成本也小得多：它只读 AccountStore / PostStatsStore / Prefs / 系统设置这几处，
     *     全是内存里已 init 过的对象，一次都不落盘、一个网络请求都不发。
     *
     * ★★★ 命名一律改成 `postTask*`（不再沿用 `postLive*`）：本期换掉的是**整张卡**
     *   （第 106 期那张的 5 个 id 已删），旧名字留着会让人以为还是同一张卡。
     */
    /** 发帖页当前是否可见（第 42 期 `settingsPageVisible` 的同款写法，见 [showPage]） */
    private var postPageVisible = false

    /** 轮询是否正在跑。stop 之后必须置回 false，否则 onPause/onResume 会叠出多条 Runnable。 */
    private var postTaskPolling = false

    private val postTaskRunnable = object : Runnable {
        override fun run() {
            // ★★★★ 第 122 期：逐任务卡搭同一支轮询（同一可见性纪律，不另起一支）。
            renderPostTaskList()
            // ★ 先判可见再排下一拍：切到别的页 / 退到后台时这一串自己就断了
            if (postPageVisible && !isFinishing) {
                handler.postDelayed(this, postTaskIntervalMs)
            } else {
                postTaskPolling = false
            }
        }
    }

    /** 0.8 秒一拍：比 2 秒的全页刷新快，又远低于「每个账号一发完就动」的下限。 */
    private val postTaskIntervalMs = 800L

    // ---------------------------------------- 第 122 期：发帖任务逐任务卡

    /**
     * ★★★★ 第 122 期：**逐任务卡列表容器**（activity_main.xml 的 `postTaskList`）。
     *
     * 用户原话（2026-10-17，附竞品截图）：「创建发帖，发帖页面应该这样显示，
     * 而且发帖也不完善」⇒ 上面那张全局状态卡（postTaskCard）**原样保留**，
     * 本容器在它下面装「一条任务一张卡」（item_post_task_card.xml）。
     */
    private lateinit var postTaskList: LinearLayout

    /** taskId -> 那张卡的行视图。id 集合变化时重建，字段变化时只改文字（同 `rowViews` 纪律）。 */
    private val postTaskItemViews = mutableMapOf<String, View>()

    /** 上一拍渲染时的任务 id 集合；`null` = 还没渲染过（首次必然重建）。 */
    private var postTaskItemIds: Set<String>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        AccountStore.init(this)
        // ★ 接上上次的黑匣子记录。进程被 ROM 回收 / 被从最近任务划掉之后，
        //   原来纯内存的那份就没了 —— 于是「验证页压根没打开」和
        //   「打开了但日志随进程丢了」分不清。现在落盘并接续。
        SliderTrace.init(this)
        AccountStore.ensureAtLeastOne()
        setContentView(R.layout.activity_main)

        setupSchedulePanel()

        requestNotificationPermission()
        // 自动引导改到设置页手动入口，不再启动时强制弹窗

        // 左侧导航抽屉
        // ★ 第 83 期：把「重建前在哪一页」传进去 —— 切深色模式会让 Activity 重建，
        //   不传的话用户刚在设置页点完开关就会被弹回签到页。
        setupDrawer(savedInstanceState?.getInt(STATE_PAGE_ITEM_ID) ?: R.id.nav_checkin)

        findViewById<Button>(R.id.addAccountButton).setOnClickListener {
            // 先建一个空账号槽位，再带它的 id 去登录页，
            // 登录成功后 Cookie 会精确写回这个槽位，不会覆盖其它账号
            val account = AccountStore.add()
            renderAccounts()
            updateStatus()
            openLogin(account)
        }

        // ★★★ 第 96 期**已删除**（用户 2026-10-11 明确批准）：
        //   这里原来是「验证后休息多久」输入框的初始化 + 失焦保存监听
        //   （findViewById<EditText>(R.id.verifyCooldownEdit) → setText →
        //     setOnFocusChangeListener { … Prefs.verifyCooldownHours = hours … }）。
        //   用户原话：「还有这个自动验证过后休息多少时间把删了吧，我感觉没有什么用」。
        //
        //   ★ 为什么连监听一起删：那个 EditText 已从 activity_main.xml 移除，
        //     findViewById 会返回 null（Kotlin 平台类型下 `!!` 会直接崩），必须同去。
        //   ★ 删掉的只是「让用户改这个数」的入口；**静置时长本身的取值**改由
        //     `Prefs.verifyCooldownHours` 固定为 0（见 Prefs.kt），
        //     三处 `now + verifyCooldownHours * 3600_000L` 的算式一行未动。
        //   ★ 相关字符串（verify_cooldown_label / _invalid / _saved / _saved_zero）
        //     全部保留在 strings.xml，一条没删。

        // ★★ 「测试自动签到」：一键把整条自动链路原样跑一遍。
        //
        //   用户想验证的是「到点程序会不会自己动起来」，而不是「点按钮能不能签到」——
        //   这两件事走的根本不是同一条路（「立即签到」是直接拉起服务，完全不经过闹钟）。
        //   所以必须有一个按钮，让闹钟那条路也能量一次，而且不用去跟日期/时间选择器较劲。
        //
        //   它做三件事：
        //     ① 开启自动签到（不开启的话服务起来后会立刻自己停掉，什么都测不到）
        //     ② 把闹钟登记到 2 分钟后 —— 走 setAlarmClock，和日常定时完全同一条通道
        //     ③ 明确告诉用户「现在可以息屏等」，以及回来之后看哪一行
        findViewById<Button>(R.id.testScheduleButton).setOnClickListener {
            val ready = AccountStore.ready()
            if (ready.isEmpty()) {
                toast(getString(R.string.need_account))
                return@setOnClickListener
            }
            setScheduleEnabled(true, getString(R.string.ma_ready_1))
            // 清掉风控暂停，否则测试这一轮会被顺延到暂停结束时间
            Prefs.pausedUntil = 0L
            LocalScheduler.scheduleTest(this, TEST_DELAY_MINUTES * 60_000L)
            val serviceIntent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_START_SCHEDULED
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            updateStatus()

            val dailyTime = String.format(Locale.CHINA, "%02d:%02d", Prefs.baseHour, Prefs.baseMinute)
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.dialog_test_scheduled, TEST_DELAY_MINUTES))
                .setMessage(
                    getString(R.string.ma_daily_time_1, TEST_DELAY_MINUTES, dailyTime)
                )
                .setPositiveButton(getString(R.string.dialog_ok), null)
                .show()
        }

        // ★ 第 75 期：**已删除**「悬浮窗实验」按钮（第 18 期加的一次性实验装置）。
        //   它测的是「安全锁屏下，悬浮窗里的 WebView 还能不能跑定时器」，结论早已用于
        //   第 37 期的设计（悬浮窗改隐形、不占系统触摸面）。使命完成，留着只是噪音。
        //   连带删除：`OverlayProbe.kt`（全工程只被这个按钮调用）+ 3 条 `probe_overlay*` 文案。
        //   回退：`_backup_before_p75_remove_probe_20261006/`（5 文件）。
        findViewById<Button>(R.id.skipTodayButton).setOnClickListener {
            if (!Prefs.scheduleEnabled) {
                toast(getString(R.string.need_schedule_on))
                return@setOnClickListener
            }
            LocalScheduler.skipToday(this)
            val serviceIntent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_START_SCHEDULED
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            updateStatus()
            toast(getString(R.string.skip_today_done))
        }

        // ★ 关闭自动签到现在由「自动签到」开关触发（见 confirmTurnOffSchedule()）。
        //   二次确认保留的原因不变：关掉之后程序一个闹钟都不登记，
        //   用户只会看到「到点不执行」，根本想不到是自己碰了开关。
        //   （v0.19.7 的诊断报告抓到的正是这个状态：scheduleEnabled=false，但用户以为开着。）

        // 设置页：权限进度**本身就是入口** —— 一行可点的状态行，点它进开通向导。
        //
        // ★ 第 42 期（用户诉求「换手机也要通用 + 向导更方便简洁，把不需要的设置删掉」）：
        //   原来是「已开启 N / 4 项」一行文字 + 下面一个「开通向导」按钮，两行说的是
        //   同一件事；而且分母写死 4、向导里必选实际只有 3 项 ⇒ 全部开完时显示
        //   「已开启 5 / 4 项」。现在合成一行，分母与向导共用
        //   `SetupWizardActivity.REQUIRED_ITEM_COUNT`，不会再漂移。
        //   ★ 原「一键开启（4 步）」对话框 `showPermissionWizard` 连同它的 5 个
        //     孤儿辅助函数已删除 —— 第 20 期起它就是未调用代码（它自己的注释也写着
        //     「保留为未调用代码，后续可删」），而且只列 4 项、缺电池优化 / 精确闹钟，
        //     还含 Period-19 已废弃的「全屏通知」卡点。
        //   ★ 「各品牌设置教程」入口搬进了开通向导底部 —— 第 20 期把向导搬出旧对话框时
        //     漏掉了它，导致这份教程只在首次打开开关时弹一次、之后再也找不到；
        //     而换手机时各家 ROM 的「自启动 / 后台运行 / 锁屏运行」只能靠它（程序检测不到）。
        //   ★ 只换入口与文案，不改变任何判定。
        findViewById<TextView>(R.id.permissionSummary).setOnClickListener {
            startActivity(Intent(this, SetupWizardActivity::class.java))
        }

        // ★★ 第 83 期：外观开关（默认浅色，可手动切深色）。
        //
        //   ① 初始值来自 UiTheme —— 一份**独立于 Prefs** 的界面偏好文件，默认 false = 浅色。
        //      所以「所有手机看到的都是浅色」不是靠用户去系统设置里调，而是由
        //      这里的默认值 + 主题里的 android:forceDarkAllowed=false 一起保证的。
        //   ② 切换时**先落盘、再改主题**：AppCompatDelegate.setDefaultNightMode() 会让
        //      所有 Activity 重建（系统行为，绕不开）。重建后 onCreate 会重新读这份偏好，
        //      值必须已经写进去，否则会来回横跳。
        //   ③ 重建后要回到设置页 —— 靠 setupDrawer 收到的 STATE_PAGE_ITEM_ID。
        //
        //   ★ 判据自检：它只改像素颜色，不参与签到 / 发帖 / 验证 / 账号里的任何判断，
        //     也不读写 Prefs 的任何一个键。
        val darkModeSwitch: SwitchCompat = findViewById(R.id.darkModeSwitch)
        darkModeSwitch.isChecked = UiTheme.isDark(this)
        darkModeSwitch.setOnCheckedChangeListener { _, checked ->
            if (checked == UiTheme.isDark(this)) return@setOnCheckedChangeListener
            UiTheme.setDark(this, checked)
            AppCompatDelegate.setDefaultNightMode(UiTheme.mode(this))
        }

        // ★ 「复制诊断报告」：把「到点到底卡在哪一段」变成一段可以直接粘贴的文本。
        //
        //   用户报「还是不行」时，以前只能靠来回追问（有没有这一行？显示什么？），
        //   一轮就要等半天，而且用户看到的和程序实际状态经常对不上。
        //   这里一次性把所有关键状态拼成文本复制到剪贴板，用户直接粘贴过来即可定位。
        findViewById<Button>(R.id.diagnoseButton).setOnClickListener {
            val report = buildDiagnosticReport()
            copyToClipboard(report)
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.dialog_diag_copied))
                .setMessage(report)
                .setPositiveButton(getString(R.string.dialog_ok), null)
                .show()
        }

        findViewById<Button>(R.id.runNowButton).setOnClickListener {
            val ready = AccountStore.ready()
            if (ready.isEmpty()) {
                // ★★★★ 第 133 期：**区分「真的没有账号」与「有账号但都在等验证」**。
                //
                //   旧行为：一律弹「请先添加并登录微博账号」+ 日志栏写「没有可用的微博账号」。
                //   而账号明明就在列表里、状态还写着「验证没过，稍后自动重试」——
                //   用户看到的是「账号丢了」，实际是 `AccountStore.ready()`（:388）
                //   里的 `!it.needsVerify` 把它们过滤掉了。点「立即签到」毫无反应，
                //   而「稍后自动重试」又要求签到链路先跑起来 —— 自锁。
                val waiting = AccountStore.needsVerifyAccounts()
                if (waiting.isEmpty()) {
                    findViewById<TextView>(R.id.logText).text = getString(R.string.log_no_account)
                    toast(getString(R.string.need_account))
                    return@setOnClickListener
                }
                val names = waiting.joinToString("、") { it.displayName }
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.p133_verify_block_title))
                    .setMessage(
                        getString(
                            R.string.p133_verify_block_msg,
                            names,
                            AgentService.verifyFailRetryHours
                        )
                    )
                    .setPositiveButton(getString(R.string.p133_verify_block_go)) { _, _ ->
                        startCheckinNow(waiting.size)
                    }
                    .setNegativeButton(getString(R.string.dialog_cancel), null)
                    .show()
                return@setOnClickListener
            }
            startCheckinNow(ready.size)
        }

        setupNotesToggle()
        setupStatusToggle()
        setupPostPanel()

        renderAccounts()
        updateStatus()
    }

    /**
     * ★★★★ 第 133 期：**手动「立即签到」的唯一启动出口**。
     *
     * 抽出来的原因：第 133 期让「有账号在等验证」时也能走这条路（见 [onCreate] 里
     * `runNowButton` 的分支），两处必须发**逐字节相同**的 Intent ——
     * 复制一份就等于埋一个「改了一边忘了另一边」的坑。
     *
     * ★ 函数体与第 132 期 `runNowButton` 里的那段**逐字一致**，只把 `ready.size`
     *   换成入参 [accountCount]（强制路径下 `ready` 是空的，数量要报待验证账号数）。
     * ★ `EXTRA_RUN_ALL = true` 的语义一字未改：手动点击 = 明确要求「现在就签」，
     *   跳过分批错峰。第 133 期起它还额外意味着「待验证账号也强制复活一次」，
     *   见 `AgentService.executeOnce` 的 `revivedStaleVerify`。
     */
    private fun startCheckinNow(accountCount: Int) {
        Prefs.lastRunAt = System.currentTimeMillis()
        Prefs.lastRunMessage =
            getString(R.string.ma_ready_2, accountCount)
        findViewById<TextView>(R.id.logText).text = Prefs.lastRunMessage
        val intent = Intent(this, AgentService::class.java).apply {
            action = AgentService.ACTION_RUN_CHECKIN
            putExtra(AgentService.EXTRA_RUN_ALL, true)
        }
        ContextCompat.startForegroundService(this, intent)
        toast(getString(R.string.run_now_started))
    }

    /**
     * ★★★★ 第 133 期：发帖任务卡「开始」被拒时，**说清原因 + 给一个能立刻点的按钮**。
     *
     * ★ 为什么需要它：发帖链路自己**没有任何清 `needsVerify` 的出口** ——
     *   `AgentService.executeOnce` 里那个 `revivedStaleVerify` 只在**签到链路**跑；
     *   发帖撞 CAPTCHA 标上的 `needsVerify` 只能靠签到链路顺带清掉。
     *   于是「发帖卡点开始 → 没反应 → 用户不知道下一步做什么」就必然发生。
     *
     * ★ 本函数**只读**：`needsVerifyAccounts()` 是纯过滤，不写任何账号/Prefs；
     *   点「立即强制重试」后走的也是既有路径（[startCheckinNow] → 签到链路）。
     *   没有任何账号在等验证时直接 return，不弹空对话框。
     */
    private fun showPostStartBlockedHelp() {
        val waiting = AccountStore.needsVerifyAccounts()
        if (waiting.isEmpty()) return
        val names = waiting.joinToString("、") { it.displayName }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.p133_verify_block_title))
            .setMessage(
                getString(
                    R.string.p133_post_block_msg,
                    names,
                    AgentService.verifyFailRetryHours
                )
            )
            .setPositiveButton(getString(R.string.p133_verify_block_go)) { _, _ ->
                // 切回签到页再跑：强制路径下 `ready` 是空的，首页日志栏那句
                // 「已启动签到任务（共 N 个账号）」就是唯一的可见反馈，得让用户看见。
                navViewCheckedTo(R.id.nav_checkin)
                startCheckinNow(waiting.size)
            }
            .setNegativeButton(getString(R.string.dialog_ok), null)
            .show()
    }

    /** 第 133 期：把左侧菜单与页面一起切到 [itemId]（不触发菜单点击回调）。 */
    private fun navViewCheckedTo(itemId: Int) {
        try {
            findViewById<NavigationView>(R.id.navView).setCheckedItem(itemId)
        } catch (_: Throwable) {
            // 菜单还没就绪也不影响下面切页；纯界面，失败静默。
        }
        currentPageItemId = itemId
        showPage(itemId)
    }

    override fun onResume() {
        super.onResume()
        Prefs.init(this)
        AccountStore.init(this)

        // ★ 没有「闹钟和提醒」权限时，AlarmManager 会退化成非精确闹钟：
        //   在深度休眠下它可以被推迟到**下次亮屏**才触发 —— 表现出来就是
        //   「放后台不执行，一打开 App 就执行」。这个权限只靠首页那行小字很容易被忽略，
        //   所以在开启自动签到的情况下主动问一次（每次启动只问一次）。
        if (Prefs.scheduleEnabled && !exactAlarmPrompted && !LocalScheduler.exactAlarmAllowed(this)) {
            exactAlarmPrompted = true
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.dialog_need_permission))
                .setMessage(
                    getString(R.string.ma_on_resume_1)
                )
                .setPositiveButton(getString(R.string.dialog_go_allow)) { _, _ -> requestExactAlarmPermissionIfNeeded() }
                .setNegativeButton(getString(R.string.dialog_later), null)
                .show()
        }

        // ★★ 自动签到没开启时，必须**主动**告诉用户，不能等他自己往下翻。
        //
        //   真实案例（v0.19.7 的诊断报告）：用户把时间设成 18:07、以为已经在自动签到了，
        //   实际 scheduleEnabled 还是 false —— 程序一个闹钟都没登记（「下次自动执行：尚未登记」）。
        //   他连续反馈「到点不执行」，排查方向全被带偏，真正的原因只是「没点保存并开启」。
        //   所以这里打开 App 就直接弹一次，并给一个「立即开启」按钮，一键按当前选择开启。
        if (!Prefs.scheduleEnabled && !schedulePrompted) {
            schedulePrompted = true
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.dialog_schedule_not_on))
                .setMessage(
                    getString(R.string.ma_on_resume_2, String.format(Locale.CHINA, "%02d:%02d", Prefs.baseHour, Prefs.baseMinute))
                )
                .setPositiveButton(getString(R.string.dialog_enable_now)) { _, _ ->
                    turnOnSchedule(getString(R.string.schedule_on_by_dialog))
                }
                .setNegativeButton(getString(R.string.dialog_later), null)
                .show()
        }

        // ★★★ 全自动签到的前置设置（必选 3 项：悬浮窗 / 电池优化 / 精确闹钟）
        //   —— 见 checkAutoVerifySetup()。
        //
        //   第 11 期实测发现：这个检查函数**从来没有被调用过**，是一段死代码
        //   （`grep -rn checkAutoVerifySetup` 只命中定义、没有任何调用点）；
        //   第 20 期起接回来，第 42 期起判据从「无障碍」改成「必选项没开齐」。
        //
        //   条件与上面两个提示错开（闹钟权限缺失时先提示那个），
        //   避免同一次 onResume 连弹两个对话框。只弹提示，不改变任何判定。
        if (Prefs.scheduleEnabled && LocalScheduler.exactAlarmAllowed(this) && !autoVerifyPrompted) {
            autoVerifyPrompted = true
            checkAutoVerifySetup()
        }

        if (Prefs.scheduleEnabled) {
            // ★ 先判断「是不是已经错过了」再重排。
            //   ensureScheduled 会把错过的这一轮改成「1 分钟后执行」，如果这里仍用
            //   ACTION_START_SCHEDULED，用户点开 App 后还要干等一分钟才开始 —— 观感就是「没反应」。
            //   已经错过就直接开跑。
            val overdue = Prefs.nextRunAt > 0L && Prefs.nextRunAt <= System.currentTimeMillis()
            LocalScheduler.ensureScheduled(this)
            val serviceIntent = Intent(this, AgentService::class.java).apply {
                action = if (overdue) AgentService.ACTION_RUN_CHECKIN else AgentService.ACTION_START_SCHEDULED
            }
            ContextCompat.startForegroundService(this, serviceIntent)
        }
        // 从登录页返回时账号状态会变，重建一次行视图
        renderAccounts()
        updateStatus()
        // ★★★ 第 107 期：回前台就把任务信息卡片的轮询拉起来（停在哪个页由 postPageVisible 决定）。
        //   放这里而不是 onCreate：从登录页 / 验证页返回时也要能继续跟上后台进度。
        startPostTaskPoll()
        // ★★★★ 第 126 期（用户拍板）：**落盘的排队任务在回前台时续跑**。
        //   队列只在「进程被杀时还没轮到」的情况下留得下东西 —— 那种时候没有任何
        //   闹钟会再把它叫醒（纯「立即跑一次」的任务本来就没有定时）。
        //   不在这里续跑的话，卡片会从「排队中」变成永远不动的「排队中」，比丢了更难懂。
        resumeQueuedPostTasks()
        // 有账号超过 12 小时没检查过登录态，就顺手查一遍
        val stale = AccountStore.all().any {
            it.cookie.isNotBlank() &&
                System.currentTimeMillis() - it.lastCheckAt > 12L * 60L * 60L * 1000L
        }
        if (stale) checkAllLogins()
        handler.removeCallbacks(refreshRunnable)
        handler.post(refreshRunnable)
    }

    override fun onPause() {
        // ★ 发帖面板的自动保存只挂在「失焦」上，有个死角：
        //   用户改完输入框直接按 Home、或从最近任务划掉 App，输入框**从未失焦**
        //   → 改动根本没落盘。这里补一次**静默**落盘兜住这种情况。
        //   静默的理由：onPause 也会被「切应用、弹系统对话框」等与改配置无关的场景触发，
        //   每次都弹 toast 只会变成噪音。非法值仍然不写（persistPostConfig 内部保证）。
        silentSavePostConfig()
        handler.removeCallbacks(refreshRunnable)
        // ★★★ 第 107 期：退到后台就停任务信息卡片的轮询 —— 那一卡看不见了，
        //   继续每 0.8 秒读一次纯属白耗电。onResume 会再拉起来。
        stopPostTaskPoll()
        super.onPause()
    }

    /**
     * onPause() 的兜底保存：把发帖面板的当前内容**静默**落盘。
     *
     * ★ 与失焦自动保存共用同一个 persistPostConfig，写入规则完全一致，差别只有两点：
     *   ① 不出声（不弹 toast、也不把非法输入回退成原值）；
     *   ② 只在内容**确实变了**时才写 —— 否则每次切前后台都会做一次无谓的磁盘写入。
     * ★ 控件找不到就直接返回：这是兜底逻辑，绝不能因为控件缺失把 onPause 弄崩。
     */
    private fun silentSavePostConfig() {
        // ★★ 第 113 期：超话框本身已不再被**读取**（值改由 PostTarget 常量给出），
        //   但「控件必须在」这个兜底判断**保留** —— 少一个控件说明这一页没建好，
        //   那就不要做兜底保存。（写成 if 而不是 `val x = … ?: return`，
        //   是为了不留下一个「声明了却没人读」的局部变量。）
        if (findViewById<EditText>(R.id.postTopicsEdit) == null) return
        // ★★★★ 第 116 期：这里原有两行 ——
        //     `val countEdit = findViewById<EditText>(…) ?: return`
        //     `val intervalEdit = findViewById<EditText>(…) ?: return`
        //   那两个输入框（id 名 postCountEdit / postIntervalEdit）已随「绿色框」
        //   一起删掉（第 10 次获准删控件）。
        //   ★★ 必须**连这两行一起删**，不能只删控件：控件不存在时 findViewById 返回
        //      null，那句 `?: return` 会让本函数**直接返回** ⇒ 这个 onPause 兜底保存
        //      （含发帖内容的落盘）**整段静默失效** —— 不报错、不出告警，
        //      只有用户某天发现「改了内容没保存」才会暴露。
        // ★★★ 第 113 期：超话框只读（里面是超话名，不是链接）⇒ 兜底保存也写常量，
        //   绝不能把「张奕然超话」这四个字写进 Prefs.postTopicsText（那是超话链接列表）。
        val topics = PostTarget.TARGET_SUPER_TOPIC_URL
        // ★ 第 81 期：正文改成逐条语料库后，不能只读第一行那个输入框（会漏掉第 2..N 条），
        //   统一由 collectPostBodies() 把所有行拼回 --- 分隔的字符串再落盘。
        val content = collectPostBodies()
        // ★★★ 第 116 期：比较条件里去掉了 countText / intervalText 两项 ——
        //   那两个输入框已删，界面不再产生这两个值。
        if (topics == Prefs.postTopicsText && content == Prefs.postContentText) {
            return
        }
        persistPostConfig(topics, content)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    /**
     * 改自动签到开关，并记下「什么时候、因为什么」。
     *
     * ★ 所有改动开关的地方都必须走这里。
     *   起因：诊断报告里反复出现「设定时间已保存、但开关是关的」——
     *   从报告上完全看不出是谁关的，只能猜（是用户点的？还是程序某条路径？）。
     *   记下来之后，报告里会直接写出「19:13:58 由「点了「关闭自动签到」并确认」关闭」，
     *   一眼就能定性，不用再猜。
     */
    private fun setScheduleEnabled(enabled: Boolean, by: String) {
        Prefs.scheduleEnabled = enabled
        Prefs.scheduleEnabledChangedAt = System.currentTimeMillis()
        Prefs.scheduleEnabledChangedBy = by
    }

    /**
     * 签到页顶部：一行时间 + 一个开关。
     *
     * ★ 为什么把两个常驻滚轮收起来：
     *   DatePicker / TimePicker 各占 3 行，加起来把首屏塞满了 —— 用户打开 App
     *   第一眼看到的是「选日期」和「选时间」，而不是「今天签没签成」。
     *   而这两件事里，时间一年改一次，日期几乎不用改。
     *   所以：常驻只留一行文字，点它才弹出滚轮。
     */
    private fun setupSchedulePanel() {
        findViewById<TextView>(R.id.scheduleTimeLine).setOnClickListener {
            showScheduleTimeDialog()
        }

        // ★★★★ 第 125 期：scheduleWindowLine（「时间窗 / 定时开始　›」入口行）已随
        //   用户圈定的绿色框删除（第 13 次获准删控件）⇒ 这里原来的三行
        //     findViewById(scheduleWindowLine).setOnClickListener { showScheduleWindowDialog() }
        //   一并删除。★ 这里**必须连监听一起删**：控件没了，findViewById 返回 null，
        //   对 null 调 setOnClickListener 会当场 NPE（TextView 是不可空类型，
        //   编译器不会拦，只在运行时炸）。
        //   ★ showScheduleWindowDialog() 本身保留（见布局里的说明），当前无调用点。
        //   ★ 本注释刻意**不写** R.id. / @string/ 形式的名字 —— 闸门 2 是扫原文的，
        //     写了就会被当成「引用了不存在的控件/字符串」而报红（本期实测）。

        val sw: SwitchCompat? = findViewById(R.id.scheduleSwitch)
        sw?.setOnCheckedChangeListener { _, checked ->
            // ★ 程序自己同步状态时不响应，否则 updateStatus() 每 2 秒一次会把开关变成死循环
            if (syncingScheduleSwitch) return@setOnCheckedChangeListener
            if (checked) {
                turnOnSchedule(getString(R.string.schedule_on_by_switch))
            } else {
                confirmTurnOffSchedule()
            }
        }

        findViewById<TextView>(R.id.advancedToggle).setOnClickListener {
            advancedExpanded = !advancedExpanded
            renderAdvanced()
        }
        renderAdvanced()
    }

    /** 「更多设置」折叠区（测试自动签到 / 今天跳过） */
    private fun renderAdvanced() {
        findViewById<View>(R.id.advancedBox).visibility =
            if (advancedExpanded) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.advancedToggle).text = getString(
            if (advancedExpanded) R.string.checkin_advanced_hide
            else R.string.checkin_advanced_show
        )
    }

    /**
     * 弹出日期 / 时间滚轮（原来常驻在首屏的那两个）。
     *
     * ★ 确定后的分支很关键：
     *   - 自动签到**没开** → 顺手打开。否则「选了时间却什么都没发生」，
     *     正是 v0.19.7 那份报告里反复出现的故障（用户以为设了时间就等于开了）。
     *   - 自动签到**已开** → 只重排闹钟，不碰开关（用户只是改时间）。
     */
    private fun showScheduleTimeDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_schedule_time, null)
        val picker = view.findViewById<DatePicker>(R.id.dialogDatePicker)
        val clock = view.findViewById<TimePicker>(R.id.dialogTimePicker)
        clock.setIs24HourView(true)

        picker.minDate = System.currentTimeMillis() - 1000L
        val startCalendar = Calendar.getInstance()
        if (Prefs.startDate.isNotBlank()) {
            try {
                startCalendar.time = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA)
                    .parse(Prefs.startDate) ?: Date()
            } catch (_: Exception) {
            }
        }
        picker.updateDate(
            startCalendar.get(Calendar.YEAR),
            startCalendar.get(Calendar.MONTH),
            startCalendar.get(Calendar.DAY_OF_MONTH)
        )
        clock.hour = Prefs.baseHour
        clock.minute = Prefs.baseMinute

        // ★ 109（2026-10-03）：选的日期在未来时，把那行提示换成警告。
        //   ★ 为什么必须有：日期滚轮**没有上限**（上面只设了 `minDate`），
        //     而日期落在未来的代价是 `baseRunAt()` 一路等到那天 —— 即「这一天之前
        //     一次都不会自动签到」。原先这个弹窗对此毫无提示，一次误触滑动
        //     就能把排程推到两周后，且**界面上三处都不显示日期** ⇒ 用户无从发现。
        //   ★ 只改这一个 TextView 的文字，**不碰下面确定按钮里的写入逻辑**
        //     （日期/时间的写入时机属于核心约束）。
        val hint = view.findViewById<TextView>(R.id.dialogDateHint)
        fun refreshHint() {
            val picked = String.format(
                Locale.CHINA, "%04d-%02d-%02d", picker.year, picker.month + 1, picker.dayOfMonth
            )
            hint.text = if (picked > LocalScheduler.todayString()) {
                getString(R.string.checkin_time_dialog_hint_future, picked)
            } else {
                getString(R.string.checkin_time_dialog_hint)
            }
        }
        picker.setOnDateChangedListener { _, _, _, _ -> refreshHint() }
        refreshHint()

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.checkin_time_dialog_title))
            .setView(view)
            .setPositiveButton(getString(R.string.dialog_ok)) { _, _ ->
                Prefs.startDate = String.format(
                    Locale.CHINA,
                    "%04d-%02d-%02d",
                    picker.year,
                    picker.month + 1,
                    picker.dayOfMonth
                )
                Prefs.baseHour = clock.hour
                Prefs.baseMinute = clock.minute
                val timeText = clockText()
                if (Prefs.scheduleEnabled) {
                    // ★ 只是改时间，不动开关 —— 也**不碰 skipDate**：
                    //   旧版没有这条路径（改时间必须走「保存并开启」），所以这里刻意
                    //   不发明新行为。用户点过「今天跳过」就该继续跳过。
                    LocalScheduler.scheduleNext(this)
                    updateStatus()
                    toast(getString(R.string.schedule_time_saved, timeText))
                } else {
                    turnOnSchedule(getString(R.string.schedule_on_by_time))
                }
            }
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .show()
    }

    /**
     * 打开自动签到。
     *
     * ★ 抽成独立函数的原因：「时间弹窗确定」「首页开关」「自动签到还没开启」弹窗里的
     *   「立即开启」必须是**同一段逻辑**。如果各写一份，两边迟早不一致 ——
     *   而这类不一致正是「点了按钮却什么都没发生」的经典来源。
     *
     * ★ 时间来源统一改成 Prefs：滚轮已经收进弹窗，弹窗在确定的那一刻就把值写进 Prefs 了，
     *   这里不再读任何视图 —— 视图只在弹窗存在的那一瞬间才有值。
     */
    private fun turnOnSchedule(by: String) {
        setScheduleEnabled(true, by)
        // 用户手动重新开启时，清掉风控暂停状态，否则会被顺延到暂停结束时间
        Prefs.pausedUntil = 0L
        // ★★ 这两行是**行为等价性**要求，不是新功能 —— 改动前每一次「开启自动签到」
        //    都必须经过 enableScheduleFromPickers()，而它开头就是：
        //        Prefs.startDate = <滚轮上的日期，滚轮初值来自 Prefs.startDate，空白时取今天>
        //        Prefs.skipDate = ""
        //    滚轮收进弹窗之后，这两句的落点必须补回来，否则：
        //      · skipDate 残留 → 用户点过「今天跳过」再关开一次开关，今天仍然被跳过（旧版不会）
        //      · startDate 空白 → 诊断报告「设定时间：」那行会变空（旧版会写今天）
        //    注意 LocalScheduler 里 startDate 用的是 ifBlank { todayString() }，
        //    所以「空白」和「今天」在调度上等价，但报告上不等价。
        Prefs.skipDate = ""
        if (Prefs.startDate.isBlank()) Prefs.startDate = LocalScheduler.todayString()
        // 开启后展示一次设备白名单引导（自启动/后台/锁定，不同品牌路径不同）
        if (!compatGuideShown) {
            compatGuideShown = true
            DeviceCompatibility.showGuide(this)
        }
        requestExactAlarmPermissionIfNeeded()
        LocalScheduler.scheduleNext(this)
        val serviceIntent = Intent(this, AgentService::class.java).apply {
            action = AgentService.ACTION_START_SCHEDULED
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        updateStatus()

        // ★ 关键提示：如果用户选的时间点**今天已经过了**，程序会把它顺延到明天。
        //   旧实现只 toast 一句「自动签到已开启」，用户会以为今天到点就会跑，
        //   结果等到超时也没动静 —— 这就是「设置时间自动签到过了 30 分钟都没签」的常见来源。
        val picked = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, Prefs.baseHour)
            set(Calendar.MINUTE, Prefs.baseMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val todayPassed = !picked.after(Calendar.getInstance())
        val nextText = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(Prefs.nextRunAt))
        toast(
            if (todayPassed) {
                getString(R.string.schedule_on_today_passed, clockText(), nextText)
            } else {
                getString(R.string.schedule_on, nextText)
            }
        )
    }

    /** 「08:30」这种两段式时间文本（Prefs 里的基准时间） */
    private fun clockText(): String =
        String.format(Locale.CHINA, "%02d:%02d", Prefs.baseHour, Prefs.baseMinute)

    /**
     * ★★★★ 第 120 期：**时间窗 + 定时开始**设置弹窗（P4 / P5 拍板）。
     *
     * 与 [showScheduleTimeDialog]（每日固定时刻）正交：
     *   · 时间窗：只在 [windowStartMinute, windowEndMinute] 内签，支持跨午夜；
     *   · 定时开始：首次精确落在 scheduleStartAt，之前不排每日闹钟。
     *
     * ★ 写入后：签到开着就 `LocalScheduler.scheduleNext` 重排（新窗口/定时开始即刻生效）；
     *   没开则只存值，等用户开启时由 turnOnSchedule 应用。
     * ★ 全程只写 Prefs 这 4 个键 + 重排闹钟，**不碰**四条核心链路的其它字段。
     */
    private fun showScheduleWindowDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_schedule_window, null)
        val winSwitch = view.findViewById<SwitchCompat>(R.id.winSwitch)
        val winStartPicker = view.findViewById<TimePicker>(R.id.winStartPicker)
        val winEndPicker = view.findViewById<TimePicker>(R.id.winEndPicker)
        val startAtSwitch = view.findViewById<SwitchCompat>(R.id.startAtSwitch)
        val startAtPickBtn = view.findViewById<Button>(R.id.startAtPickBtn)
        val startAtHint = view.findViewById<TextView>(R.id.startAtHint)
        winStartPicker.setIs24HourView(true)
        winEndPicker.setIs24HourView(true)

        // 初值一律取自 Prefs（唯一数据源），与每日时间弹窗同纪律。
        winSwitch.isChecked = Prefs.windowEnabled
        winStartPicker.hour = Prefs.windowStartMinute / 60
        winStartPicker.minute = Prefs.windowStartMinute % 60
        winEndPicker.hour = Prefs.windowEndMinute / 60
        winEndPicker.minute = Prefs.windowEndMinute % 60
        var pickedStartAt: Long = Prefs.scheduleStartAt
        startAtSwitch.isChecked = pickedStartAt > 0L

        fun refreshStartAtHint() {
            startAtHint.text = if (pickedStartAt > 0L) {
                getString(
                    R.string.schedule_start_at_hint_set,
                    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA).format(Date(pickedStartAt))
                )
            } else {
                getString(R.string.schedule_start_at_hint_unset)
            }
        }
        refreshStartAtHint()

        // 「设定时开始时刻」：弹日期 + 时间滚轮，选中即写 pickedStartAt 并自动打开开关。
        startAtPickBtn.setOnClickListener {
            val pv = layoutInflater.inflate(R.layout.dialog_schedule_time, null)
            val dp = pv.findViewById<DatePicker>(R.id.dialogDatePicker)
            val tp = pv.findViewById<TimePicker>(R.id.dialogTimePicker)
            tp.setIs24HourView(true)
            val init = Calendar.getInstance().apply {
                timeInMillis = if (pickedStartAt > 0L) pickedStartAt else System.currentTimeMillis()
            }
            dp.updateDate(
                init.get(Calendar.YEAR),
                init.get(Calendar.MONTH),
                init.get(Calendar.DAY_OF_MONTH)
            )
            tp.hour = init.get(Calendar.HOUR_OF_DAY)
            tp.minute = init.get(Calendar.MINUTE)
            // 复用 dialog_schedule_time 的提示控件，换成定时开始说明（原来那句是每日时间的抖动说明，不适用）。
            pv.findViewById<TextView>(R.id.dialogDateHint).text =
                getString(R.string.schedule_start_at_hint_unset)
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.schedule_start_at_pick_title))
                .setView(pv)
                .setPositiveButton(getString(R.string.dialog_ok)) { _, _ ->
                    val c = Calendar.getInstance().apply {
                        set(dp.year, dp.month, dp.dayOfMonth, tp.hour, tp.minute, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    pickedStartAt = c.timeInMillis
                    startAtSwitch.isChecked = true
                    refreshStartAtHint()
                }
                .setNegativeButton(getString(R.string.dialog_cancel), null)
                .show()
        }

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.schedule_window_dialog_title))
            .setView(view)
            .setPositiveButton(getString(R.string.dialog_ok)) { _, _ ->
                Prefs.windowEnabled = winSwitch.isChecked
                Prefs.windowStartMinute = winStartPicker.hour * 60 + winStartPicker.minute
                Prefs.windowEndMinute = winEndPicker.hour * 60 + winEndPicker.minute
                Prefs.scheduleStartAt =
                    if (startAtSwitch.isChecked && pickedStartAt > 0L) pickedStartAt else 0L
                // 签到开着 → 立刻重排，新窗口 / 定时开始即刻生效；没开 → 只存值。
                if (Prefs.scheduleEnabled) LocalScheduler.scheduleNext(this)
                updateStatus()
                toast(getString(R.string.schedule_window_saved))
            }
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .show()
    }

    // ★★★★ 第 125 期：refreshScheduleWindowLine() **已删除** ——
    //   它唯一服务的控件 scheduleWindowLine 已随用户圈定的绿色框删掉，
    //   函数体第一行就是 findViewById(scheduleWindowLine) ?: return，
    //   控件没了 ⇒ 每次都早退，纯空转。连它专属的 4 条字符串
    //   （schedule_window_line_off / _window / _start / _both）一起删除。
    //   ★ 删的是「显示」，不是「排程」：Prefs.windowEnabled / Prefs.scheduleStartAt
    //     与 LocalScheduler 的读取点一行未动。

    /**
     * 「开始日期」是不是一个**未来**日期（纯展示判断，不参与任何调度计算）。
     *
     * ★ 为什么需要它：`LocalScheduler.baseRunAt()`（`:129`）写的是
     *   `if (startDate.after(now)) startDate.time else now.time`
     *   —— 未来日期会被当成基准日，于是「下次自动执行」被推到那天。
     *   而界面原先**三处都不显示这个日期**（首页行 / 报告 `ma_report_14` /
     *   `jitterNote()` 在差值为负时整行不输出）⇒ 用户没有任何办法核对。
     *   2026-10-03 实测：排程被推到 10-17，用户只能来问「这是你设的吗」。
     *
     * ★ 为什么不解析日期：两个值都是**固定宽度的 `yyyy-MM-dd`**
     *   （写入见弹窗确定按钮里那个 `%04d-%02d-%02d` 格式串，今天见 `LocalScheduler.todayString()`），
     *   所以字符串比较与时间比较等价 —— 而且**不引入任何新的日期格式字面量**。
     *   空白视为「未设」（`LocalScheduler` 用 `ifBlank { todayString() }`，等价于今天）。
     */
    private fun startDateIsFuture(): Boolean {
        val d = Prefs.startDate
        return d.isNotBlank() && d > LocalScheduler.todayString()
    }

    /**
     * 关闭自动签到（先二次确认）。
     *
     * ★ 二次确认保留的原因：开关误触一下就会把自动签到整个关掉，
     *   而关掉之后程序一个闹钟都不登记，用户只会看到「到点不执行」，
     *   根本想不到是自己碰了开关。（v0.19.7 的诊断报告抓到的正是这个状态。）
     */
    private fun confirmTurnOffSchedule() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.dialog_disable_title))
            .setMessage(
                getString(R.string.dialog_disable_message) +
                    if (Prefs.postEnabled) getString(R.string.dialog_disable_post_note) else ""
            )
            .setPositiveButton(getString(R.string.dialog_confirm_disable)) { _, _ ->
                applyScheduleOff()
            }
            .setNegativeButton(getString(R.string.dialog_cancel)) { _, _ ->
                // ★ 用户点了「取消」→ 把开关拨回去。
                //   不拨回去的话，界面显示「关」而实际还是开着的，
                //   下次 updateStatus() 又会把它拨回来 —— 看起来像开关自己乱跳。
                syncScheduleSwitch()
            }
            .show()
    }

    /** 真正落地「关闭自动签到」 */
    private fun applyScheduleOff() {
        setScheduleEnabled(false, getString(R.string.schedule_off_by_switch))
        Prefs.pausedUntil = 0L
        LocalScheduler.cancel(this)
        if (Prefs.postEnabled) {
            // ★ 发帖还开着：不能把调度一锅端。重新登记成「立刻补一发」
            //   并拉起守护循环 —— 否则就会出现「关了签到连发帖也停」。
            LocalScheduler.scheduleRetry(this, 60_000L)
            val restart = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_START_SCHEDULED
            }
            ContextCompat.startForegroundService(this, restart)
            updateStatus()
            toast(getString(R.string.schedule_off_post_on))
            return
        }
        // ★ 正在签到时不立刻 stopService：那会把跑了一半的任务掐断，
        //   界面报「INTERRUPTED（被系统中断）」，看起来像程序出错 ——
        //   而 v19.8 那份报告里出现的 INTERRUPTED 正是这么来的。
        //   服务会在这一轮跑完后自己停（requestRun 的 finally 里有判断）。
        if (!Prefs.running) {
            stopService(Intent(this, AgentService::class.java))
        }
        updateStatus()
        toast(getString(R.string.schedule_off))
    }

    /** 把开关的显示状态与 Prefs.scheduleEnabled 对齐（不触发监听里的业务逻辑） */
    private fun syncScheduleSwitch() {
        val sw: SwitchCompat? = findViewById(R.id.scheduleSwitch)
        if (sw == null) return
        syncingScheduleSwitch = true
        sw.isChecked = Prefs.scheduleEnabled
        syncingScheduleSwitch = false
    }

    /** 通知是否可用（Android 13 的运行时权限也体现在这个返回值里） */
    private fun notificationsAllowed(): Boolean {
        return try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.areNotificationsEnabled()
        } catch (_: Throwable) {
            true
        }
    }

    /** 悬浮窗（弹出窗口）权限 */
    private fun canDrawOverlay(): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        return try {
            Settings.canDrawOverlays(this)
        } catch (_: Throwable) {
            false
        }
    }

    /** 是否已在电池优化白名单（不被系统杀后台） —— 只读检测，不改变任何判定 */
    private fun isIgnoringBatteryOptimizations(): Boolean {
        return try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.isIgnoringBatteryOptimizations(packageName)
        } catch (_: Throwable) {
            false
        }
    }

    /** 是否能登记精确闹钟（Android 12+ 需要用户授予的「闹钟和提醒」权限） —— 只读检测 */
    private fun canScheduleExactAlarms(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return try {
            val am = getSystemService(AlarmManager::class.java)
            am.canScheduleExactAlarms()
        } catch (_: Throwable) {
            false
        }
    }

    /** 诊断报告里用的「有 / 无」 */
    private fun yesNo(ok: Boolean): String =
        getString(if (ok) R.string.state_yes else R.string.state_no)

    /**
     * ★★★ 第 69 期：当前 WebView 内核版本（诊断报告用）。
     *
     * ★ 只读静态 API：`WebView.getCurrentWebViewPackage()` 是 `android.webkit.WebView`
     *   的 public static 方法，**不创建 WebView 实例、不加载页面、不联网**。
     *   API 26 起可用（本工程 minSdk=26，正好满足）。
     *
     * ★ 为什么值得单独做一行：滑块验证整条链路跑在 WebView 里（页面内派发 PointerEvent），
     *   WebView 内核版本是最容易被忽略、又最常是「滑块不动」真因的变量。
     *   取不到时返回中文占位，绝不让报告出现英文堆栈。
     */
    private fun webViewVersion(): String = try {
        android.webkit.WebView.getCurrentWebViewPackage()?.versionName
            ?: getString(R.string.ma_report_webview_none)
    } catch (_: Throwable) {
        getString(R.string.ma_report_webview_none)
    }

    /** 设置页那行「已开启 N / 3 项 ›」（这一行本身可点，点它进开通向导） */
    private fun refreshPermissionSummary() {
        findViewById<TextView>(R.id.permissionSummary).text = getString(
            R.string.settings_perm_summary,
            permissionDoneCount(),
            SetupWizardActivity.REQUIRED_ITEM_COUNT
        )
    }

    /**
     * 已开启的**必选**项数（0~3），用于设置页那行「已开启 2 / 3 项」。
     *
     * ★★ 第 42 期：无障碍从必选降为**可选（兜底）**，因此不再计入分子。
     *   依据：第 36 期起点签到改走 `webView.dispatchTouchEvent()` 真实触摸、
     *   第 38 期起拖动改回页面内 JS ⇒ 无障碍服务只剩「真实触摸和 JS 点击**都失败**」
     *   时的第三级兜底（`YidunAutoSlider.kt:596`），第 36/38 期真机黑匣子从没走到过。
     *   ⇒ 它不该再挡在「必选」里，但**留在向导列表里**，真遇到点不动的情况还能开。
     *
     * ★ 第 20 期：必选 4 项 = 无障碍 + 悬浮窗 + 电池优化 + 精确闹钟。
     *   通知改为可选（不计入分母）；全屏通知是 Period-19 废弃的卡点，已移除。
     * ★ 分母取 `SetupWizardActivity.REQUIRED_ITEM_COUNT`，与向导**共用同一个数字**，
     *   根治第 41 期那个「已开启 5 / 4 项」的显示 bug。
     */
    private fun permissionDoneCount(): Int {
        var done = 0
        if (canDrawOverlay()) done++
        if (isIgnoringBatteryOptimizations()) done++
        if (canScheduleExactAlarms()) done++
        return done
    }

    /** dp → px */
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    /**
     * 首页顶部那行版本号。
     *
     * ★ 为什么值得单独做一行：用户反馈「改了还是不行」时，第一件必须排除的事是
     *   「手机上装的还是旧包」。以前没有任何办法在界面上确认，只能靠来回问，
     *   一问一答就是半天。现在版本号直接写在标题下面。
     */
    /**
     * 「显示 / 隐藏使用说明」总开关。
     *
     * ★ 只控制 4 处**解释性**灰色小字：
     *   introNote（本机运行）、jitterExplainText（随机延迟）、
     *   compatNoteText（后台权限）、reportNoteText（诊断报告用途）。
     *
     * ★ 绝不碰任何**状态**：warningBanner 警示横幅、scheduleStatus 状态块、
     *   所有按钮始终可见。它们的显示规则是「不处理就一定不会执行」，
     *   如果跟着说明一起被藏起来，用户就会重复 v19.8 之前的排查弯路。
     */
    private fun setupNotesToggle() {
        val toggle = findViewById<TextView>(R.id.notesToggle)
        val noteIds = listOf(
            R.id.introNote,
            R.id.jitterExplainText,
            R.id.compatNoteText,
            R.id.reportNoteText,
        )

        fun renderNotes(expanded: Boolean) {
            for (id in noteIds) {
                findViewById<TextView>(id).visibility = if (expanded) View.VISIBLE else View.GONE
            }
            toggle.text = getString(if (expanded) R.string.settings_notes_hide else R.string.settings_notes_show)
        }

        renderNotes(notesExpanded)
        toggle.setOnClickListener {
            notesExpanded = !notesExpanded
            renderNotes(notesExpanded)
        }
    }

    /**
     * 状态块的「显示 / 隐藏详细状态」开关。
     *
     * ★ 只切换 [R.id.statusDetail] 的可见性，内容仍由 updateStatus() 每 2 秒刷新，
     *   所以展开状态下时间也会实时更新，不会变成一张死图。
     */
    private fun setupStatusToggle() {
        findViewById<TextView>(R.id.statusToggle).setOnClickListener {
            statusExpanded = !statusExpanded
            updateStatus()
        }
    }

    /**
     * 「4. 自动发帖」面板。
     *
     * ★ 发帖是**高风险动作**，约束必须在界面上立住：
     *   ① 默认关闭，且打开开关时当场校验配置（空名单 / 空正文不许开）——
     *      「开了却什么都不发」是最难排查的一类状态；
     *   ② 条数和间隔填非法值时**明确报错**，不能悄悄用默认值，
     *      否则用户以为设了 4 小时，实际还是 20 分钟。
     *      ★★★★ 第 116 期：这两个数字框已随用户圈定的「绿色框」删除
     *        （第 10 次获准删控件）⇒ 本条约束**暂时没有界面载体**。参数改由
     *        「创建超话发帖任务」弹窗承载，但执行链路下一期才接。
     *        `Prefs.postPerAccount` / `Prefs.postIntervalMinutes` 的值与
     *        全部读取点一字未动 ⇒ 发帖行为完全不变。
     *   ③ 提供发帖入口 —— 发帖接口本机无法验证，必须让用户当场能试一次。
     *      ★★★★ 第 116 期行为变更：原「立即发一条试试」按钮（`testPostButton`）
     *        改为「**创建任务**」，点击弹出表单而**不再直接发帖**。
     *        ⇒ 全 App 的**直接发帖入口只剩 `postTaskRetryButton`（「重试发帖」）**
     *          一处；且本期弹窗保存后**也不执行**（下一期接）。
     */
    private fun setupPostPanel() {
        val topicsEdit = findViewById<EditText>(R.id.postTopicsEdit)
        // ★★★★ 第 116 期：这里原有两行 `countEdit` / `intervalEdit` 的 findViewById，
        //   随「绿色框」里那两个数字框一起删除（第 10 次获准删控件）。
        // ★★★★ 第 125 期：enabledSwitch 的 findViewById（postEnabledSwitch）
        //   **已删除** —— 该开关（「开启自动发帖」）随用户圈定的绿色框一起删掉
        //   （第 13 次获准删控件）。★ Prefs.postEnabled 的键与全部读取点一字未改，
        //   它现在恒为 false（删除当时实测就是 false）⇒ 旧的定时群发不跑，
        //   发帖一律由「创建任务」的逐任务卡驱动。
        // ★★★ 第 99 期：`postFirstSwitch`（「先发帖再签到」）**已删除** ——
        //   用户 2026-10-11 明确要求「把那个先发帖后签到给删掉」，追问里选了
        //   「删掉，固定先签到后发帖」。删掉之后 `Prefs.postFirst` 恒为 `false`，
        //   而 `AgentService` 里那两处 `if (Prefs.postFirst)` / `if (!Prefs.postFirst)`
        //   **一行未改** ⇒ 行为 = 先签到后发帖，与删除前完全一致。
        //   ★ 控件 id 与它专属的三条字符串已登记进 `_p81_id_string_diff.py` 白名单，
        //     见 `activity_main.xml` 里那段登记注释。

        // ★★ 第 96 期：超话改成**只能填一个**（输入框已改单行，见 activity_main.xml）。
        //   旧数据可能是用户之前填的多行 —— 这里只取第一行并**写回 Prefs**，
        //   否则会出现「界面上看着只有一个、实际后台还在按 postIndex % N 轮流发好几个」
        //   这种界面与行为不一致（用户批准的方案是「只保留第一个，其余自动丢弃」）。
        //   ★ 只做「取第一行」这一步，不改任何解析规则：topicListOf / parseSuperTopicRef
        //     与 AgentService 的发帖循环一行未动。
        //
        // ★★★★ 第 113 期（用户 2026-10-14 原话：「目标超话硬编码（极其重要）」）：
        //   上面那句「取第一行写回」**原地升级**成「写死成 PostTarget 常量」。
        //
        //   ★★ 关键取舍 —— **没有去改 AgentService**：
        //     `AgentService.runPostPhase` 仍照原样读 `Prefs.postTopicsText`；
        //     我们只是**在它原本就有的那个写回位置、那个时机**，把值换成目标超话。
        //     位置没变、时机没变、`Prefs` 键没变、语义（「发帖超话链接列表」）也没变，
        //     只是**值被钉死** ⇒ 发帖链路一行核心代码都没动，
        //     行为却已经是「所有账号的所有帖子都发到这一个超话」。
        //
        //   ★ 输入框已降级为**只读展示卡**（只读属性写在 activity_main.xml 里）：
        //     它现在只负责「给人看」，不再参与任何写盘 ——
        //     所以本页所有原本把 `topicsEdit.text` 写进 Prefs 的地方，全部改写成常量。
        if (Prefs.postTopicsText != PostTarget.TARGET_SUPER_TOPIC_URL) {
            Prefs.postTopicsText = PostTarget.TARGET_SUPER_TOPIC_URL
        }
        topicsEdit.setText(PostTarget.displayName)
        // ★ 第 81 期：正文不再往单个输入框里塞，而是按 --- 拆成一条条铺进语料库
        postBodyList = findViewById(R.id.postBodyList)
        renderPostBodies(Prefs.postContentText)
        // ★★★★ 第 116 期：这里原有两行回填
        //     countEdit.setText(Prefs.postPerAccount.toString())
        //     intervalEdit.setText(Prefs.postIntervalMinutes.toString())
        //   随两个数字框一起删除。
        //   ★ `Prefs.postPerAccount` / `Prefs.postIntervalMinutes` 的值**仍然有效**，
        //     只是界面上不再有它们的显示与编辑入口（下一期由创建任务弹窗接）。
        // ★★★★ 第 125 期：`enabledSwitch.isChecked = Prefs.postEnabled` 与整段
        //   `enabledSwitch.setOnCheckedChangeListener { ... }`（回填 + 开/关处理，
        //   含「开之前先校验超话与正文非空」的那段）**一并删除** ——
        //   开关本身已随绿色框删掉（第 13 次获准删控件）。
        //   ★ 这里**不能只删 findViewById 留监听**：`enabledSwitch` 是 `SwitchCompat`
        //     不可空类型，控件没了就是 null，对 null 赋值/挂监听 = 运行时 NPE，
        //     而编译器与静态闸门都拦不住（同 116 期「早退行绑架整个函数」那类陷阱）。
        //   ★ `Prefs.postEnabled` 保持 `false`；`post_off` / `post_on_summary` /
        //     `dialog_need_config` / `ma_body_1` 这几条字符串**别处仍在用**（不删）。

        // ★★★★ 第 116 期：原来这里有一个 `autoSave`（`View.OnFocusChangeListener`）
        //   整块，以及紧随其后的两行
        //     countEdit.setOnFocusChangeListener(autoSave)
        //     intervalEdit.setOnFocusChangeListener(autoSave)
        //   —— 它**只服务**「每个账号发几条」与「发帖间隔（分钟）」那两个输入框，
        //   而这两个框已随「绿色框」删除（第 10 次获准删控件）⇒ 整块一并删除。
        //   ★ 删掉它**不影响任何其它保存路径**：
        //     · 正文各行有自己的失焦保存（`refreshPostBodyRowState` → `savePostBodies()`）；
        //     · onPause 兜底走 `silentSavePostConfig()`；
        //     · 显式保存按钮在下面（**保留**，见第 86 期说明）。

        // ★ 第 86 期：显式保存按钮。
        //   起因：失焦保存是无声的（只有 toast 一闪），用户不确定改动到底有没有落盘 ——
        //   尤其键盘上点完成键在部分机型不触发失焦，看上去像没保存。
        //   ★ 本按钮不新增任何写入规则：落盘全部复用同一套 persistPostConfig；
        //     原有的失焦保存与 onPause 兜底全部保留，这里只是多一个触发入口。
        // ★★★★ 第 116 期：本按钮**保留** —— 它**不在**用户圈定的「绿色框」内。
        //   但它内部原来对「条数 / 间隔」的取值与两段非法值校验，已随那两个输入框
        //   一起删除；本监听现在只负责把「超话 + 正文」显式落盘一次并给出可见反馈。
        findViewById<Button>(R.id.postSaveButton)?.setOnClickListener {
            persistPostConfig(PostTarget.TARGET_SUPER_TOPIC_URL, collectPostBodies())
            updateStatus()
            // ★ 第 116 期：`post_saved_summary` 的占位符由 3 个缩到 1 个
            //   （两个数字框已删，界面上只剩「超话链接数」一个真实参数）。
            toast(getString(R.string.post_saved_summary, topicListOf(Prefs.postTopicsText).size))
        }
        // ★ 第 81 期：正文各行的失焦保存改由语料库自己挂（见 refreshPostBodyRowState），
        //   这里不再把正文输入框挂到 autoSave 上 —— 否则每行失焦都会弹一次「已保存」的 toast。

        // ★ 第 81 期：正文改成「逐条语料库」—— 「＋ 添加一条」不再是往光标处插一个 `---` 分隔符
        //   （那个符号用户看不见、也删不掉），而是**新开一个输入框**：一条内容一个框，
        //   看得见、改得动、删得掉。
        //   纯界面便利：存储格式仍是 --- 分隔的单字符串，parsePostBodies 的解析与发帖判定一行未动。
        findViewById<Button>(R.id.addPostBodyButton)?.setOnClickListener {
            val list = postBodyList ?: return@setOnClickListener
            list.addView(buildPostBodyRow(""))
            refreshPostBodyRowState()
            // 新加的那一行立刻拿焦点，用户可以直接开始打字
            list.getChildAt(list.childCount - 1)
                ?.findViewById<EditText>(R.id.postContentEdit)
                ?.requestFocus()
        }

        // ★★★★ 第 116 期：原来这里挂着「批量导入」与「清空全部」两个按钮的点击监听
        //   （第 113 期新增）。用户明确选择「**批量导入彻底不要**」⇒ 两个按钮连同
        //   它们的处理函数（`importPostBodies` / `clearPostBodies` /
        //   `showPostBodyImportDialog`）整段删除，**不搬进**「创建任务」弹窗。
        //   ★ 语料库本身的「＋ 添加一条 / 编辑 / 复制 / 上移 / 下移 / 删除」全部保留
        //     （它们不在用户圈定的「绿色框」内）。

        // ★★★★ 第 122 期：逐任务卡列表容器（纯新增，上面那张全局卡一行未动）。
        postTaskList = findViewById(R.id.postTaskList)
        renderPostTaskList()

        // ★★★★ 第 116 期行为变更：原「立即发一条试试」→「创建任务」。
        //   点击弹出 `PostTaskSheet`（近全屏 BottomSheet，13 个字段），
        //   保存后**只落盘**：不调 `startPostRunFromUi()`、不碰 `AgentService`、不写 `Prefs`。
        //   ★ 「保存后立即开始」的编排链路**下一期**接（用户 2026-10-15 拍板：本期分两期做）。
        findViewById<Button>(R.id.testPostButton).setOnClickListener {
            PostTaskSheet.show(this)
        }
    }

    /**
     * ★★★ 第 114 期：从界面发起一轮发帖。
     *
     * ★ 第 114 期时**两个按钮共用这一个函数** ——「立即发一条试试」（testPostButton）
     *   与「重试发帖」（postTaskRetryButton）。
     * ★★★★ 第 116 期：**`testPostButton` 已不再是调用方** —— 它改名「创建任务」后
     *   只弹表单，不再直接发帖。⇒ 本函数**唯一**的调用方是 `postTaskRetryButton`。
     *   ★ 函数体一行未改：落盘的键、Intent 的 action/extra、Toast 全部保持原样，
     *     所以「重试发帖」的行为与第 115 期**完全一致**。
     */
    private fun startPostRunFromUi() {
        val ready = AccountStore.ready()
        if (ready.isEmpty()) {
            toast(getString(R.string.need_account))
            return
        }
        // 先落盘再发：用户往往改了内容就直接点测试，不点保存
        // ★★★ 第 113 期：超话写常量（框里显示的是只读的超话名，不是链接）。
        Prefs.postTopicsText = PostTarget.TARGET_SUPER_TOPIC_URL
        Prefs.postContentText = collectPostBodies()
        val topics = topicListOf(Prefs.postTopicsText)
        if (topics.isEmpty()) {
            toast(getString(R.string.post_topics_missing))
            return
        }
        if (Prefs.postContentText.isBlank()) {
            toast(getString(R.string.post_content_missing))
            return
        }
        Prefs.lastRunAt = System.currentTimeMillis()
        Prefs.lastRunMessage = getString(R.string.ma_topics_1)
        val intent = Intent(this, AgentService::class.java).apply {
            action = AgentService.ACTION_RUN_POST
            putExtra(AgentService.EXTRA_RUN_ALL, true)
        }
        ContextCompat.startForegroundService(this, intent)
        updateStatus()

        val first = ready.first()
        val index = if (first.postDate == LocalScheduler.todayString()) first.postIndex else 0
        val topicName = topics[index % topics.size].display
        // ★★★ 第 99 期（用户原话：「这些发帖之后，出现的文字，把删除，别人是不会看这些东西的，
        //   字太多了」）：这里原来是**整屏对话框** —— 标题「已开始发帖」+ 一整段 161 字的
        //   排查引导（第 96 期截图里那一大坨）。用户批准「改成一行提示条」。
        //   ⇒ 现在只弹一条 Toast，一行说清「谁在往哪发」。
        //   ★ 只换了**呈现方式**：上面的 `Prefs` 落盘与 `startForegroundService`
        //     一行未改，发帖行为完全不变。
        //   ★ 失败原因不会因此丢失 —— 它照旧写进 `Prefs.lastRunMessage`（本页状态区显示），
        //     也照旧进「复制排查信息」。
        //   ★ 标题与正文用字符串拼接而不是合成一条新文案：`dialog_post_started`
        //     这样仍然被引用（否则它会变成孤儿字符串，闸门 2 会报红）。
        toast(
            getString(R.string.dialog_post_started) + "：" +
                getString(R.string.ma_topic_name_1, first.displayName, topicName)
        )
    }

    /**
     * 把发帖面板的当前内容落盘。
     *
     * ★★★★ 第 116 期：本函数只剩「超话 + 正文」两项。
     *   原来还写 `Prefs.postPerAccount` / `Prefs.postIntervalMinutes`，
     *   但那两个输入框已随「绿色框」删除（第 10 次获准删控件）⇒ 界面上不再有
     *   这两个键的**写入口**。
     * ★★ 这两个键**本身与它们的全部读取点一字未动**（`AgentService` /
     *   `AccountStore` / 本文件的 report 与进度口径都还在读）⇒ **发帖行为完全不变**，
     *   只是暂时改不了这两个值 —— 下一期由「创建超话发帖任务」弹窗重新给出写入口。
     * ★★★ 第 116 期：原「非法值（空、超范围）不写、保持原值」这条约束
     *   随两个数字框一起作废 —— 本函数已不再接收任何数字参数。
     */
    private fun persistPostConfig(topics: String, content: String) {
        Prefs.postTopicsText = topics
        Prefs.postContentText = content
    }

    // ==================== ★ 第 81 期：发帖正文「逐条语料库」 ====================
    //
    // 用户的诉求：原来点「＋ 添加一条」只是往光标处插一个 `---` 符号，那个符号
    // 在输入框里既看不出是「一条的分界」、也不好删；他要的是**一条一条加进去**的
    // 语料库 —— 每条内容一个输入框，想发几条就摆几个框。
    //
    // ★ 只改界面，存储与判定一个字都没动：
    //   Prefs.postContentText 仍然是「各行用一行 --- 连接」的单字符串，键名、类型、
    //   写入时机（失焦 / onPause / 点测试 / 开开关）全部照旧；
    //   AgentService.parsePostBodies 的切段正则与发帖判定一行未改。
    //   本区块只做两件事：把那个字符串**铺开**成 N 个输入框，再把 N 个输入框**拼回**那个字符串。

    /** 语料库容器（activity_main.xml 里的 postBodyList），第 1 行是静态的 postContentEdit。 */
    private var postBodyList: LinearLayout? = null

    /**
     * 把存下来的正文拆成一条条。
     *
     * ★★★ 第 113 期：本函数的正则**搬进了 `PrefsContentSource.split`**（contentSources 插槽），
     *   这里只做转发 —— 正则本身**一个字都没改**（`(?m)^\s*-{3,}\s*$`）。
     *   搬家的理由是：原来同一个正则散在两处（本文件 + `AgentService.parsePostBodies`），
     *   改一处忘一处就会出现「界面显示的分段和真正发出去的分段对不上」——
     *   这是本项目公认最难查的一类问题。现在界面侧只剩这一个入口
     *   （`AgentService` 那份按硬规则原样保留，未动）。
     * ★ 这里只用于**界面回显**，不参与任何发帖判定。
     */
    private fun splitPostBodies(raw: String): List<String> = PrefsContentSource.split(raw)

    /** 语料库里每一行的视图（第 1 行是静态的，第 2..N 行是运行时生成的）。 */
    private fun postBodyRows(): List<View> {
        val list = postBodyList ?: return emptyList()
        return (0 until list.childCount).map { list.getChildAt(it) }
    }

    /**
     * 把语料库里每一行的文字拼回「--- 分隔的单字符串」。
     *
     * ★ 空行直接丢掉：用户点了「＋ 添加一条」还没填，不该变成一条空帖子。
     * ★ 容器还没建好时退回原值 —— 绝不能因为界面异常把用户已经存下的正文清空。
     */
    private fun collectPostBodies(): String {
        val list = postBodyList ?: return Prefs.postContentText
        if (list.childCount == 0) return Prefs.postContentText
        return postBodyRows()
            .mapNotNull { it.findViewById<EditText>(R.id.postContentEdit) }
            .map { it.text.toString().trim() }
            .filter { it.isNotBlank() }
            .joinToString("\n---\n")
    }

    /** 按 item_post_body.xml 造一行（第 2..N 行的模板）。 */
    private fun buildPostBodyRow(text: String): View {
        val row = layoutInflater.inflate(R.layout.item_post_body, postBodyList, false)
        row.findViewById<EditText>(R.id.postContentEdit)?.setText(text)
        return row
    }

    /**
     * 用存下来的正文重建整个语料库。
     *
     * ★ 静态的第一行（postContentEdit）**只改内容、绝不重建** —— 它是既有控件，
     *   删掉再生成属于违规改动；所以这里清的是「第 2 行起的动态行」。
     */
    private fun renderPostBodies(raw: String) {
        val list = postBodyList ?: return
        val parts = splitPostBodies(raw)
        list.findViewById<EditText>(R.id.postContentEdit)?.setText(parts.firstOrNull() ?: "")
        while (list.childCount > 1) list.removeViewAt(list.childCount - 1)
        parts.drop(1).forEach { list.addView(buildPostBodyRow(it)) }
        refreshPostBodyRowState()
    }

    /**
     * 重挂每一行的序号提示、删除按钮与失焦保存，并刷新「共 N 条」。
     *
     * ★ 每行都重挂一次 listener 是有意的：动态行是新建的，静态第一行也要跟着刷新
     *   （它可能是唯一一行 —— 这时删除按钮要藏起来，不许把语料库删成 0 条）。
     */
    private fun refreshPostBodyRowState() {
        val rows = postBodyRows()
        rows.forEachIndexed { index, row ->
            val edit = row.findViewById<EditText>(R.id.postContentEdit) ?: return@forEachIndexed
            // 第一行沿用 XML 里的静态提示（post_content_hint），第 2..N 行写「第 N 条内容」
            if (index > 0) edit.setHint(getString(R.string.post_body_item_hint, index + 1))
            edit.setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) savePostBodies()
            }
            val del = row.findViewById<Button>(R.id.postBodyDeleteButton)
            del?.visibility = if (rows.size > 1) View.VISIBLE else View.GONE
            del?.setOnClickListener { removePostBodyRow(row) }

            // ★★★★ 第 113 期：每条文案的操作菜单（编辑 / 复制 / 上移 / 下移）。
            //   ★ 每一行都重挂一次 listener 是**有意的**：动态行是新建的，
            //     静态第一行也要跟着刷新（上移 / 下移的可用状态与它所在的位置有关）。
            row.findViewById<Button>(R.id.postBodyEditButton)?.setOnClickListener {
                row.findViewById<EditText>(R.id.postContentEdit)?.let { focusPostBodyEditor(it) }
            }
            row.findViewById<Button>(R.id.postBodyCopyButton)?.setOnClickListener {
                duplicatePostBodyRow(row)
            }
            // 上移 / 下移：到顶 / 到底就**置灰** —— 比「点了没反应」好懂得多
            row.findViewById<Button>(R.id.postBodyUpButton)?.apply {
                isEnabled = index > 0
                alpha = if (index > 0) 1f else 0.4f
                setOnClickListener { swapPostBodyRows(index, index - 1) }
            }
            row.findViewById<Button>(R.id.postBodyDownButton)?.apply {
                isEnabled = index < rows.size - 1
                alpha = if (index < rows.size - 1) 1f else 0.4f
                setOnClickListener { swapPostBodyRows(index, index + 1) }
            }
        }
        findViewById<TextView>(R.id.postBodyCount)?.text =
            getString(R.string.post_body_count, rows.size)
    }

    /** 让某一行的输入框拿到焦点、光标落到末尾，并尽量弹出软键盘。 */
    private fun focusPostBodyEditor(edit: EditText) {
        edit.requestFocus()
        edit.setSelection(edit.text.length)
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT)
        } catch (_: Throwable) {
            // 弹不出键盘不算错误：焦点与光标已经就位，用户点一下照样能打字
        }
    }

    /**
     * ★★★★ 第 113 期：**交换相邻两行的内容**（上移 / 下移）。
     *
     * ★★ 交换的是**文字**，不是 View —— 移动 View 会触发重新布局、丢掉当前焦点，
     *   而这里只需要「内容换个位置」，交换文本既够用又不会打断用户正在做的事。
     * ★ 行的提示语（第 N 条内容）跟着**位置**走，不跟着内容走 —— 这是对的，
     *   否则「第 3 条内容」会跟着文字跑到第 1 行去，看着像乱了。
     */
    private fun swapPostBodyRows(a: Int, b: Int) {
        val rows = postBodyRows()
        if (a !in rows.indices || b !in rows.indices) return
        val ea = rows[a].findViewById<EditText>(R.id.postContentEdit) ?: return
        val eb = rows[b].findViewById<EditText>(R.id.postContentEdit) ?: return
        val ta = ea.text.toString()
        ea.setText(eb.text.toString())
        eb.setText(ta)
        savePostBodies()
    }

    /**
     * ★★★★ 第 113 期：**复制某一行** —— 在它下面插入一条内容相同的新行。
     *
     * ★ 用 `addView(view, index)` 插到中间，而不是简单地追加到末尾：
     *   用户点的是「这一条」的复制，新行就该出现在这一条旁边。
     */
    private fun duplicatePostBodyRow(row: View) {
        val list = postBodyList ?: return
        val text = row.findViewById<EditText>(R.id.postContentEdit)?.text?.toString().orEmpty()
        val index = postBodyRows().indexOf(row)
        val newRow = buildPostBodyRow(text)
        if (index >= 0 && index + 1 < list.childCount) {
            list.addView(newRow, index + 1)
        } else {
            list.addView(newRow)
        }
        refreshPostBodyRowState()
        savePostBodies()
    }

    // ★★★★ 第 116 期（用户要求，**第 10 次获准删控件**，2026-10-15）：
    //   「批量导入 / 清空全部」两个按钮连同**它们的对话框**一起删除。
    //   用户原话：「把绿色框内的东西删除」；追问里选了「**全删，批量导入彻底不要**」。
    //   ⇒ 只服务这两个按钮的三个函数随之失去全部调用点，一并删除：
    //     · importPostBodies(raw)       —— 唯一调用点是 showPostBodyImportDialog()
    //     · clearPostBodies()           —— 唯一调用点是 postBodyClearAllButton 的监听
    //     · showPostBodyImportDialog()  —— 唯一调用点是 postBodyImportButton 的监听
    //   ★ 语料库的**行内操作全部保留**（复制本行 / 上移 / 下移 / 删除本行 / ＋添加一条），
    //     它们不在用户圈定的绿色框内 ⇒ 这些函数一行未动。
    //   ★ 被删的 6 个 id 与 16 条字符串已逐个登记工作区
    //     `_p81_id_string_diff.py` 的两张白名单，并在 activity_main.xml / strings.xml
    //     的删除处留了原位注释。
    //   ★ `Prefs` 键零增删：被删的这三段代码里没有任何一处「新增的 Prefs 写入」——
    //     它们读写的 postContentText 仍由 savePostBodies()（失焦 / 保存按钮）负责。

    /**
     * 正文失焦落盘。
     *
     * ★ 只写正文，不动超话/条数/间隔 —— 一次失焦只做一件小事，避免互相覆盖。
     * ★ 静默：不弹 toast。每换一个输入框就弹一次「已保存」会变成噪音。
     */
    private fun savePostBodies() {
        val body = collectPostBodies()
        if (body == Prefs.postContentText) return
        Prefs.postContentText = body
    }

    /** 删掉语料库里的某一行；只剩一行时不许删（面板必须始终有地方可填）。 */
    private fun removePostBodyRow(row: View) {
        val list = postBodyList ?: return
        if (list.childCount <= 1) return
        list.removeView(row)
        refreshPostBodyRowState()
        savePostBodies()
    }

    /** 超话名单解析：一行一个链接，解析出超话引用（与 AgentService 的解析保持一致） */
    private fun topicListOf(raw: String): List<WeiboClient.SuperTopicRef> =
        raw.lineSequence().map { it.trim() }
            .filter { it.isNotBlank() }
            .mapNotNull { WeiboClient.parseSuperTopicRef(it) }
            .toList()

    // ★★★★ 第 109 期（用户要求，第 7 次获准删控件）：
    //   **「发帖状态」整块删除**。原 `updatePostStatus()` / `postStatsLines()` 只服务
    //   首页那个 `postStatus` 控件（「今日发帖 X / Y 条」+「上次发帖：…失败…」+
    //   按账号战绩），用户截图圈的就是它 ⇒ 控件连同这两个函数一起下线。
    //
    //   ★ 第 107 期「任务信息卡片」不受影响：状态 / 统计（成功 · 跳过 · 失败 · 已处理）
    //     旧全局状态卡已删除，统计改由逐任务卡实时展示。
    //     与本函数无关。
    //   ★ 随之下线的字符串（已登记闸门 7 白名单）：
    //     `post_status_off` / `post_status_off_hint` / `ma_text_1` / `ma_text_2` /
    //     `ma_text_3` / `ma_text_4` / `post_acct_stats`。
    //   ★ **`ma_jitter_note_38` 必须保留** —— 它印在排查信息报告里（本文件靠后处），
    //     与这一块无关，名字像而已。
    //   ★ 数据层一个都没动：`PostStatsStore` / `AccountStore` / `Prefs` 全键原样，
    //     只是不再有人读出来印在首页。

    // ------------------------------------- 第 107 期：任务信息卡片（只读轮询）

    /**
     * ★★★ 第 113 期：把时间戳印成「yyyy-MM-dd HH:mm:ss」。
     *
     * ★ 为什么不复用 `buildDiagnosticReport()` 里那个 `stamp()`：它是那个函数的
     *   **局部函数**，出了那个函数就看不见了 —— 这里再写一个类级的小工具，
     *   格式串与它**逐字一致**，免得两处显示同一件事却是两种格式。
     * ★ 传 0 / 负数（= 还没跑过）返回空串，调用方据此把那一行整行藏掉。
     */
    private fun formatPostStamp(value: Long): String =
        if (value > 0L) {
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date(value))
        } else {
            ""
        }

    /**
     * ★★★★ 第 126 期（用户拍板）：**把落盘的排队任务续跑起来**。
     *
     * ## 为什么只能在界面这一侧补这一刀
     *
     * 队列里剩下的只可能是「**还没轮到、一次都没开跑**」的任务 ——
     * 开跑前 `poll()` 就已经把它从盘上摘掉了，随后第一件事就是写 `ranAt`。
     * 而这类任务里最常见的是「**立即开始 + 不限时间窗**」：
     * 它既没有 `scheduleStart` 也没有 `limitWindow`，`remountPending` 那三类
     * 一条都不沾 ⇒ **没有任何闹钟会再来叫它**（第 123 期注释明写了
     * 「不自动重挂以免每次开机都意外跑一遍」）。
     *
     * 所以补的时机只有「用户回到前台」这一处：此时他就在看这个界面，
     * 把已准入的任务接着跑完是符合预期的；而纯开机场景仍走
     * [PostTaskScheduler.remountPending]（那里对队列里的任务也会重挂）。
     *
     * ★ 重复调用安全：见 [PostTaskStarter.resumeQueued] 的说明
     *   （同 id 被忽略、不同 id 被 [TaskQueue.offer] 去重）。
     */
    private fun resumeQueuedPostTasks() {
        TaskQueue.init(this)
        if (TaskQueue.size() <= 0) return
        PostTaskStarter.resumeQueued(this)
    }

    private fun renderPostTaskList() {
        if (!::postTaskList.isInitialized) return
        PostTaskStore.init(this)
        // ★★★★ 第 126 期：队列已落盘，渲染前先把盘上那份读回来 ——
        //   否则进程刚重建时 `TaskQueue.contains()` 恒为 false，
        //   排队中的任务会先被画成「待运行」，看起来像任务丢了。
        TaskQueue.init(this)
        val tasks = PostTaskStore.all()
        val ids = tasks.map { it.id }.toSet()

        if (ids != postTaskItemIds) {
            // ---- 结构变了（新建 / 删除任务）：整列表重建 ----
            postTaskList.removeAllViews()
            postTaskItemViews.clear()
            postTaskItemIds = ids
            if (tasks.isEmpty()) {
                val empty = TextView(this)
                empty.text = getString(R.string.pt_item_empty)
                empty.setTextColor(getColor(R.color.text_secondary))
                empty.textSize = 13f
                postTaskList.addView(empty)
                return
            }
            val inflater = LayoutInflater.from(this)
            for (task in tasks) {
                val row = inflater.inflate(R.layout.item_post_task_card, postTaskList, false)
                postTaskItemViews[task.id] = row
                bindPostTaskItemButtons(row, task.id)
                postTaskList.addView(row)
            }
        }

        // ---- 字段刷新：每张卡只改文字，不重建视图 ----
        for (task in tasks) {
            val row = postTaskItemViews[task.id] ?: continue
            updatePostTaskItemRow(row, task)
        }
    }

    /**
     * ★★★★ 第 122 期：给一张逐任务卡绑上五颗按钮 + 验证入口。
     *
     * ★ 全部写操作只发生在**点击那一刻**，且只写本功能自己的数据：
     *   · 开始  重置 `ranAt` / `retryCount` 落盘 + [PostTaskStarter.start]
     *           （不重置会被「已跑不重触」和补跑上限**静默**挡掉）
     *   · 暂停  [TaskQueue.remove] + [PostTaskScheduler.cancel]
     *           （取消排队与补跑闹钟；与补跑闹钟同一 request code，一并清掉）
     *   · 详情  纯界面展开 / 收起，不写任何数据
     *   · 编辑  [PostTaskSheet.show]（编辑模式，见该函数第 122 期注释）
     *   · 删除  确认框 + [PostTaskStore.delete] + cancel + [TaskQueue.remove]
     *   全程不碰 [Prefs]、不碰账号表 ⇒ 不改变四条核心链路的任何决定。
     */
    private fun bindPostTaskItemButtons(row: View, taskId: String) {
        row.findViewById<Button>(R.id.postTaskItemStartButton).setOnClickListener {
            val task = PostTaskStore.get(taskId) ?: return@setOnClickListener
            task.ranAt = null
            task.retryCount = 0
            // ★ 第 123 期：连补跑时刻标记一起清——否则卡片会误显示「等待补跑」，
            //   remountPending 也会把它当补跑时刻重挂。
            task.retryAtMillis = null
            PostTaskStore.save(task)
            if (PostTaskStarter.start(this, taskId)) {
                toast(getString(R.string.pt_item_started_toast))
            } else {
                // ★★★★ 第 133 期：启动被拒时**给出可执行的下一步**。
                //
                //   旧行为：`PostTaskStarter.start` 只弹一句
                //   「没有可参与发帖的账号，任务已保存但未执行」就返回 false，
                //   卡片毫无变化 ⇒ 用户感受是「点了没反应」。
                //   而真实原因是 `AccountStore.postPending`（`WeiboAccount.kt:434`）
                //   的 `!it.needsVerify` 把账号排除掉了 —— 那句话一个字都没提「验证」。
                //
                //   ★ 只在「确实有账号在等验证」时弹（`needsVerifyAccounts()` 是纯读）；
                //     真的没有账号 / 没有文案的情况仍走 `PostTaskStarter` 原来的 toast，
                //     这里不重复弹窗。
                showPostStartBlockedHelp()
            }
        }
        row.findViewById<Button>(R.id.postTaskItemPauseButton).setOnClickListener {
            TaskQueue.remove(taskId)
            PostTaskScheduler.cancel(this, taskId)
            toast(getString(R.string.pt_item_paused_toast))
        }
        row.findViewById<Button>(R.id.postTaskItemDetailButton).setOnClickListener {
            val detail = row.findViewById<TextView>(R.id.postTaskItemDetail)
            val button = it as Button
            val expanded = detail.visibility == View.VISIBLE
            detail.visibility = if (expanded) View.GONE else View.VISIBLE
            button.text = getString(
                if (expanded) R.string.pt_item_detail else R.string.pt_item_detail_collapse
            )
        }
        row.findViewById<Button>(R.id.postTaskItemEditButton).setOnClickListener {
            PostTaskSheet.show(this, taskId)
        }
        row.findViewById<Button>(R.id.postTaskItemDeleteButton).setOnClickListener {
            confirmDeletePostTask(taskId)
        }
        row.findViewById<TextView>(R.id.postTaskItemVerify).setOnClickListener {
            // ★ 拉起验证页 = 与账号页「去验证」**完全同一条路径**
            //   （openLogin(account, verifyMode=true)），不新增任何链路。
            val account = relatedAccountsOf(taskId).firstOrNull { it.needsVerify }
                ?: return@setOnClickListener
            // ★★★★ 第 132 期：**必须传 kind = POST**。
            //   这是本期最关键的漏点：本按钮长在**发帖任务卡**上（`pt_item_verify`
            //   = 「%1$s 需要验证，点我去验证」），以前不传 kind ⇒ 落到默认值
            //   `VERIFY_KIND_CHECKIN` ⇒ 打开花小龙超话去点「签到」——
            //   正是用户 2026-10-18 明令禁止的动作，而且是**用户最容易手动触发**的入口。
            //   传 POST 之后：验证页早退、只提示手动处理，不发任何请求、不点任何按钮。
            openLogin(account, true, YidunAutoSlider.VERIFY_KIND_POST)
        }
    }

    /** 删除任务前的确认框。★ 删除 = 任务 + 排队 + 闹钟一起消失，必须确认。 */
    private fun confirmDeletePostTask(taskId: String) {
        val task = PostTaskStore.get(taskId) ?: return
        val shownName = task.name.ifBlank { getString(R.string.pt_item_name_unnamed) }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.dialog_remove_title, shownName))
            .setMessage(getString(R.string.pt_item_delete_msg))
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .setPositiveButton(getString(R.string.dialog_delete)) { _, _ ->
                PostTaskStore.delete(taskId)
                TaskQueue.remove(taskId)
                PostTaskScheduler.cancel(this, taskId)
                toast(getString(R.string.pt_item_deleted_toast))
                // 结构变了，立刻重建（不等下一拍 0.8 秒）
                renderPostTaskList()
            }
            .show()
    }

    /**
     * 这条任务的参与账号（与 [PostTaskPlan.accounts] 同一口径，但不做 pending 过滤）。
     *
     * ★ 为什么单独写一份而不直接调 `PostTaskPlan.accounts`：那个函数只返回
     *   「今天还没发完的账号」（`AccountStore.postPending`），而验证入口要的是
     *   「参与了这条任务、且正卡在验证上的账号」—— 两者判据不同。
     */
    private fun relatedAccountsOf(taskId: String): List<WeiboAccount> {
        val task = PostTaskStore.get(taskId) ?: return emptyList()
        val all = AccountStore.all()
        return when (task.accountScope) {
            PostAccountScope.MANUAL -> all.filter { it.id in task.accountIds.toSet() }
            else -> all
        }
    }

    /**
     * ★★★★ 第 122 期：刷一张逐任务卡的**字段**（名字 / 来源 / 进度 / 悬浮窗 / 状态 /
     * 验证入口 / 详情区）。
     *
     * ★ 状态**per-task 自算**，不读全局 `Prefs.postLastStatus` —— 全局那个键
     *   会被任何任务写脏（第 121 期起多任务并存），印在单张卡上会张冠李戴：
     *     · 在 [TaskQueue] 里            ⇒ 排队中
     *     · `ranAt != null`             ⇒ 已运行（+ 已补跑 N 次）
     *     · 定时开始未到点              ⇒ 待运行 · 定时开始 HH:mm
     *     · 限了时间窗                   ⇒ 待运行 · 限制时间段 HH:mm ~ HH:mm
     *     · 其余                         ⇒ 待运行
     */
    private fun updatePostTaskItemRow(row: View, task: PostTask) {
        // ---- 标题：固定「超话发帖」（第 124 期） ----
        row.findViewById<TextView>(R.id.postTaskItemName).text =
            getString(R.string.pt_item_title_chaohua)

        // ---- 账号列表：参与账号的用户名（第 124 期） ----
        val accts = relatedAccountsOf(task.id).map { it.displayName }
        row.findViewById<TextView>(R.id.postTaskItemSource).text =
            if (accts.isEmpty()) {
                getString(R.string.pt_item_accounts_none)
            } else {
                getString(R.string.pt_item_accounts, accts.joinToString("、"))
            }

        // ---- 每轮进度 ----
        row.findViewById<TextView>(R.id.postTaskItemProgress).text = getString(
            R.string.pt_item_progress,
            task.perAccountPerRound,
            task.rounds
        )

        // ---- 悬浮窗：任务自己的设置（不是系统权限，全局卡那行才是权限） ----
        val overlayView = row.findViewById<TextView>(R.id.postTaskItemOverlay)
        overlayView.setText(
            if (task.showOverlay) R.string.pt_item_overlay_on else R.string.pt_item_overlay_off
        )
        overlayView.setTextColor(
            getColor(if (task.showOverlay) R.color.text_tertiary else R.color.warning_text)
        )

        // ---- 实时进度：成功 / 跳过 / 失败（第 124 期） ----
        val runProgressView = row.findViewById<TextView>(R.id.postTaskItemRunProgress)
        if (PostTaskRunState.currentTaskId == task.id) {
            runProgressView.text = getString(
                R.string.pt_item_run_progress,
                PostTaskRunState.success.get(),
                PostTaskRunState.skip.get(),
                PostTaskRunState.fail.get()
            )
            runProgressView.visibility = View.VISIBLE
        } else {
            runProgressView.visibility = View.GONE
        }

        // ---- 状态行 ----
        val statusView = row.findViewById<TextView>(R.id.postTaskItemStatus)
        val statusText: String
        val statusColor: Int
        when {
            // ★★★★ 第 126 期（用户拍板）：**正在跑的就是这一条** ⇒ 显示「正在发帖」。
            //   位置刻意排在最前，两个理由：
            //     ① 开跑前已经 `poll()` 出队 ⇒ 与下面 `TaskQueue.contains` 互斥，谁先都不会错；
            //     ② `ranAt` 是**开跑那一刻**就写的（见 executePostTaskOnce ③），
            //        不插在 `ranAt != null` 前面的话，整个发帖过程都会显示
            //        「已运行 · HH:mm」—— 看着像已经跑完了，其实还在发。
            PostTaskRunState.currentTaskId == task.id -> {
                statusText = getString(R.string.pt_item_state_running)
                statusColor = getColor(R.color.brand_accent)
            }
            TaskQueue.contains(task.id) -> {
                statusText = getString(R.string.post_task_status_queued)
                statusColor = getColor(R.color.brand_accent)
            }
            task.ranAt != null -> {
                val ranAt = task.ranAt ?: 0L
                statusText = if (task.retryCount > 0) {
                    getString(R.string.pt_item_state_ran_retry, formatPostStamp(ranAt), task.retryCount)
                } else {
                    getString(R.string.pt_item_state_ran, formatPostStamp(ranAt))
                }
                statusColor = getColor(R.color.state_ok)
            }
            // ★ 第 123 期：正在等补跑（ranAt 已复位、retryAtMillis 有值）——
            //   显示补跑时刻，别再掉进「待运行」。
            task.retryAtMillis != null -> {
                statusText = getString(
                    R.string.pt_item_state_retry_wait,
                    task.retryCount,
                    formatPostStamp(task.retryAtMillis ?: 0L)
                )
                statusColor = getColor(R.color.state_ok)
            }
            task.scheduleStart && task.scheduleAtMillis != null -> {
                statusText = getString(
                    if (task.repeatDaily) R.string.pt_item_state_daily else R.string.pt_item_state_schedule,
                    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                        .format(Date(task.scheduleAtMillis ?: 0L))
                )
                statusColor = getColor(R.color.text_secondary)
            }
            task.limitWindow &&
                task.windowStartMinute != null && task.windowEndMinute != null -> {
                statusText = getString(
                    R.string.pt_item_state_window,
                    minuteOfDayText(task.windowStartMinute ?: 0),
                    minuteOfDayText(task.windowEndMinute ?: 0)
                )
                statusColor = getColor(R.color.text_secondary)
            }
            else -> {
                statusText = getString(R.string.pt_item_state_idle)
                statusColor = getColor(R.color.text_secondary)
            }
        }
        statusView.text = statusText
        statusView.setTextColor(statusColor)

        // ---- 验证入口：参与账号里有人卡在验证上才显示 ----
        val verifyView = row.findViewById<TextView>(R.id.postTaskItemVerify)
        val needVerify = relatedAccountsOf(task.id).firstOrNull { it.needsVerify }
        if (needVerify != null) {
            verifyView.text = getString(R.string.pt_item_verify, needVerify.displayName)
            verifyView.visibility = View.VISIBLE
        } else {
            verifyView.visibility = View.GONE
        }

        // ---- 详情展开区：展开过才拼字（省得每拍拼一串长文本） ----
        val detailView = row.findViewById<TextView>(R.id.postTaskItemDetail)
        if (detailView.visibility == View.VISIBLE) {
            detailView.text = buildPostTaskDetailText(task)
        }
    }

    /** 详情展开区的参数摘要（点「详情」才拼，见 [updatePostTaskItemRow]）。 */
    private fun buildPostTaskDetailText(task: PostTask): String {
        val on = getString(R.string.pt_item_switch_on)
        val off = getString(R.string.pt_item_switch_off)
        val scopeText = when (task.accountScope) {
            PostAccountScope.MANUAL ->
                getString(R.string.pt_item_scope_manual, task.accountIds.size)
            PostAccountScope.ROTATE -> getString(R.string.pt_item_scope_rotate)
            else -> getString(R.string.pt_item_scope_all)
        }
        val sources = PostContentRegistry.all()
            .filter { it.id in task.contentSourceIds }
            .map { it.displayName }
        val at = task.scheduleAtMillis?.let {
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(it))
        } ?: getString(R.string.pt_time_none)
        val windowText =
            if (task.limitWindow && task.windowStartMinute != null && task.windowEndMinute != null) {
                getString(
                    R.string.pt_window_fmt,
                    minuteOfDayText(task.windowStartMinute ?: 0),
                    minuteOfDayText(task.windowEndMinute ?: 0)
                )
            } else {
                getString(R.string.pt_time_none)
            }
        return buildString {
            appendLine(getString(R.string.pt_item_detail_scope, scopeText))
            appendLine(
                getString(
                    R.string.pt_item_detail_source,
                    sources.joinToString("、").ifEmpty { getString(R.string.pt_time_none) }
                )
            )
            appendLine(getString(R.string.pt_item_detail_rounds, task.perAccountPerRound, task.rounds))
            appendLine(getString(R.string.pt_item_detail_wait, task.roundWaitMinutes, task.actionGapSeconds))
            appendLine(getString(R.string.pt_item_detail_cool, task.rateCoolMinutes))
            appendLine(getString(R.string.pt_item_detail_sync, if (task.syncToWeibo) on else off))
            appendLine(getString(R.string.pt_item_detail_schedule, at))
            // ★ 第 123 期：每天重复的口径跟着定时开始行一起展示。
            appendLine(getString(R.string.pt_item_detail_repeat, if (task.repeatDaily) on else off))
            appendLine(getString(R.string.pt_item_detail_window, windowText))
            appendLine(getString(R.string.pt_item_detail_startnow, if (task.startImmediately) on else off))
            append(getString(R.string.pt_item_detail_retry, task.retryCount))
        }
    }

    /** 把「当天第几分钟」写成 `HH:mm`（与 `PostTaskSheet` 里的同名小工具格式一致）。 */
    private fun minuteOfDayText(minute: Int): String =
        String.format(Locale.US, "%02d:%02d", minute / 60, minute % 60)

    /**
     * 任务信息卡片轮询的启停。**幂等**：连点两次切页不会叠出多条 Runnable。
     *
     * ★ 只在发帖页可见时轮询（和 `settingsPageVisible` 同一条纪律）：
     *   用户在别的页 / 在后台时，这一卡看不见，继续读就是白耗电。
     */
    private fun startPostTaskPoll() {
        if (postTaskPolling || !postPageVisible || isFinishing) return
        postTaskPolling = true
        // ★★★★ 第 122 期：切到发帖页的第一帧就把逐任务卡刷出来
        //   （否则要等 0.8 秒后的第一拍 runnable，首屏会白跳一拍）。
        renderPostTaskList()
        handler.postDelayed(postTaskRunnable, postTaskIntervalMs)
    }

    private fun stopPostTaskPoll() {
        handler.removeCallbacks(postTaskRunnable)
        postTaskPolling = false
    }

    /**
     * AgentService 此刻在不在跑。
     *
     * ★ 用 `getRunningServices` 而不是自己维护一个标志位：发帖是点「立即发一条试试」、
     *   到点自动跑、开机重排**三条路**进来的，维护标志必然漏一条；
     *   而服务自己是唯一的真相。同包的服务在任何 API 级别都可见，不依赖权限。
     *
     * ★ 关于那条 deprecation 告警（Android 5.0 起 `getRunningServices` 被标废弃，
     *   官方口径是「只会返回调用方自己的服务」）：这恰恰是我们要的 —— 只关心自己的
     *   AgentService，不需要也不应该看到别人的服务。换成 UsageStatsManager 之类
     *   反而要 `PACKAGE_USAGE_STATS` 这个特殊权限（得把用户送去设置页手动开）。
     *   ⇒ 压掉告警而不是换实现；基线告警数一条不许多。
     */
    @Suppress("DEPRECATION")
    private fun isAgentServiceRunning(): Boolean {
        val manager = getSystemService(ACTIVITY_SERVICE) as? ActivityManager ?: return false
        return try {
            manager.getRunningServices(Int.MAX_VALUE).any {
                it.service.className == AgentService::class.java.name
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun versionLabel(): String = getString(R.string.ma_version_label_1, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE)

    private fun updateStatus() {
        // ★ 2026-09-27：versionText 这个控件从「顶栏」搬到了「设置」页最底部（纯 XML 搬移）。
        //   这里**故意不**把它挪进下面 `if (settingsPageVisible)` 的守卫里，尽管它现在
        //   只可能在设置页被看见。原因是 showPage() 在切页时只刷新
        //   refreshPermissionSummary（第 42 期起只有这一个），**不会**调 updateStatus，
        //   所以一旦加了守卫，用户点开「设置」后会有最多 2 秒看到占位符「版本：—」。
        //   代价对比：无条件赋值 = 每 2 秒多做一次 getString + findViewById，可忽略；
        //   加守卫 = 一个真实可见的闪烁。选前者。
        findViewById<TextView>(R.id.versionText).text = versionLabel()

        // ★ 签到页顶部那行「每天 08:30 ›」和开关，必须每 2 秒跟 Prefs 对齐。
        //   原因：时间可能在别处被改（时间弹窗、诊断恢复等），只靠点击时更新会留下
        //   「显示的和实际登记的不一致」—— 这正是最难排查的一类故障。
        findViewById<TextView>(R.id.scheduleTimeLine).text =
            if (startDateIsFuture()) {
                // ★ 109：开始日期在未来时必须写出来。正常情况（今天/过去）走 else，一个字都不变。
                getString(R.string.checkin_time_line_from, clockText(), Prefs.startDate)
            } else {
                getString(R.string.checkin_time_line, clockText())
            }
        // ★★★★ 第 125 期：原来这里有一行 `refreshScheduleWindowLine()`
        //   （第 120 期加的「时间窗 / 定时开始」入口行文案同步）。控件已删 ⇒ 调用点一并删除。
        syncScheduleSwitch()
        // ★ 权限项数只在设置页可见时才算（见 settingsPageVisible 的注释）
        if (settingsPageVisible) refreshPermissionSummary()

        // 首屏警示横幅：只在「需要用户动手、且不处理就一定不会执行」的状态下出现。
        // 放在标题正下方，不用滚动就能看到 —— 这是这一版最重要的可见性改动。
        val banner = findViewById<TextView>(R.id.warningBanner)
        val bannerText = when {
            // ★ 存储异常排在最前：它是唯一一种会让用户「看到账号莫名消失」的情况，
            //   而且此时签到一定跑不了（没账号可签），优先级高于其它任何提示。
            Prefs.storageError.isNotBlank() ->
                getString(R.string.ma_banner_text_4)
            // ★★★★ 第 125 期：「开启自动发帖」开关已删（第 13 次获准删控件）⇒
            //   横幅**不再提自动发帖**。原来这里是两个分支：
            //     `!scheduleEnabled && !postEnabled` → ma_banner_text_1（两者都未开）
            //     `!scheduleEnabled`                 → ma_banner_text_5（签到未开、发帖仍会执行）
            //   `postEnabled` 现在恒为 false（开关没了，谁也打不开它）⇒ 第一个分支
            //   的条件等价于 `!scheduleEnabled`，第二个分支**永远不可达**。
            //   合并成一个分支，文案只讲签到；`ma_banner_text_5` 一并删除。
            !Prefs.scheduleEnabled ->
                getString(R.string.ma_banner_text_1)
            !LocalScheduler.exactAlarmAllowed(this) ->
                getString(R.string.ma_banner_text_2)
            !getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName) ->
                getString(R.string.ma_banner_text_3)
            else -> ""
        }
        banner.visibility = if (bannerText.isBlank()) View.GONE else View.VISIBLE
        banner.text = bannerText

        val accounts = AccountStore.all()
        val readyCount = accounts.count { it.enabled && it.loggedIn }
        findViewById<TextView>(R.id.weiboStatus).text = when {
            accounts.isEmpty() -> getString(R.string.notif_no_account)
            readyCount == 0 -> getString(R.string.ma_ready_count_1, accounts.size)
            else -> getString(R.string.ma_ready_count_2, accounts.size, readyCount)
        }

        val checkLines = mutableListOf<String>()
        for (account in accounts) {
            if (account.cookie.isBlank()) continue
            val time = if (account.lastCheckAt > 0L) {
                SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(account.lastCheckAt)) + " "
            } else {
                ""
            }
            val expiry = if (account.expiryAt > 0L) {
                getString(R.string.ma_expiry_3, SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(account.expiryAt)))
            } else {
                ""
            }
            checkLines.add(
                account.displayName + "：" + time + account.lastCheckMessage.ifBlank { getString(R.string.ma_expiry_1) } + expiry
            )
        }
        findViewById<TextView>(R.id.loginCheckStatus).text =
            if (checkLines.isEmpty()) getString(R.string.ma_expiry_2) else checkLines.joinToString("\n")

        refreshAccountRows()

        val exactAllowed = LocalScheduler.exactAlarmAllowed(this)
        val power = getSystemService(PowerManager::class.java)
        val batteryAllowed = power.isIgnoringBatteryOptimizations(packageName)

        // 诊断时间统一用「MM-dd HH:mm:ss」，能区分同一分钟内的先后顺序
        val shortTime = SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA)
        // ★ v19.13：状态块拆成「摘要 + 详细」两层。
        //
        //   为什么：这一块会长到十几行（执行链 + 每轮的账号明细），
        //   而每天真正要看的只有三件事 —— 下次什么时候跑、今天签了几个、上次成没成。
        //   其余都是排查用的细节，只在出问题时才需要。
        //
        //   ★★ 硬规则：折叠的只能是「一切正常时的细节」。
        //      凡是「不处理就一定不会执行」的行，一律用 alerts 收集后**提升**到摘要区，
        //      而不是删掉或留在详细里。
        //      （v19.8 的教训：提示藏在页面下方 → 用户连续三轮反馈「到点不执行」，
        //        真正原因只是没点「保存并开启」。）
        val head = StringBuilder()
        val detail = StringBuilder()
        val alerts = mutableListOf<String>()
        // ★ 首屏大字状态：「今天跑了吗」用一句话回答。
        //   纯展示 —— 这两个 View 只被写入、不参与任何判定，改文案不会影响签到结果。
        val headlineView = findViewById<TextView>(R.id.scheduleHeadline)
        val headlineNoteView = findViewById<TextView>(R.id.scheduleHeadlineNote)
        if (Prefs.scheduleEnabled) {
            // ★ 第 41 期：首屏只留「下次什么时候跑」这一句。
            //   「= 设定时间 10-02 08:05 再加 0 分钟随机延迟（防止每天固定时刻发请求，属正常）」
            //   属于解释性文字 —— 只在用户疑惑「为什么显示的时间和设定不一样」时才需要，
            //   折进下面的「查看详情」。纯展示，不参与任何判定。
            head.append(LocalScheduler.formatNextRun(this, withJitterNote = false))
            val jitterNoteText = LocalScheduler.jitterNote(this)
            if (jitterNoteText.isNotBlank()) detail.append(jitterNoteText).append("\n")

            // ★ 分批错峰的进度。
            //   账号多起来之后（10 个以上），一轮只跑 3 个，剩下的 20 分钟后继续。
            //   如果界面只显示「上次结果：成功」，用户会以为今天只签了 3 个号、其余被漏掉了 ——
            //   所以这里必须把「今天已经轮到几个 / 一共几个」直接写出来。
            //   ★ 第 3 期起，这条进度不再塞进摘要正文，而是提到首屏大字里：
            //     headlineView 给结论（今天跑完没），headlineNoteView 给那句补充说明。
            //
            //   ★ 变量名刻意不叫 readyCount：上面第 1031 行已经有一个同名变量，
            //     而且两者**口径不同** ——
            //       上面那个 = accounts.count { enabled && loggedIn }（账号页那句「N 个可签到」）
            //       这一个   = AccountStore.ready().size（还要排除静置期和待验证）
            //     同名会遮住外层的，编译器会报 "Name shadowed" 警告，人也容易看错。
            val signableCount = AccountStore.ready().size
            if (signableCount > 0) {
                val doneToday = AccountStore.doneToday(LocalScheduler.todayString())
                headlineView.text = when {
                    doneToday >= signableCount -> getString(R.string.checkin_headline_done, signableCount)
                    doneToday > 0 -> getString(R.string.checkin_headline_partial, doneToday, signableCount)
                    else -> getString(R.string.checkin_headline_idle)
                }
                headlineNoteView.text =
                    if (doneToday >= signableCount) getString(R.string.ma_done_today_1)
                    else getString(R.string.ma_done_today_2)
                headlineNoteView.visibility = View.VISIBLE
            } else {
                headlineView.text = getString(R.string.checkin_headline_no_account)
                headlineNoteView.visibility = View.GONE
            }

            // ★ 微博要求验证身份 —— 这是**需要用户动手**的状态，必须醒目地说清「去点哪里」。
            //   光显示「需要处理」用户不知道该干什么，只能干等。
            if (Prefs.needsVerify) {
                alerts.add(
                    getString(R.string.ma_done_today_4)
                )
            }

            // ★ 第 41 期：把「被停用的账号」直接说出来。
            //   实测踩过：5 个账号里 4 个被停用，首页只写「✅ 今天全部签完（1 个账号）」，
            //   用户完全看不出「为什么只有 1 个在跑」，只能去「账号」页一个个翻才知道。
            //   ★ 纯展示：读的是 enabled 标志，不参与任何判定（第 41 期真机取证确认，
            //     写入点只有 MainActivity.kt:1675 与 WeiboAccount.kt:232，都在界面上）。
            val disabledAccountCount = AccountStore.all().count { !it.enabled }
            if (disabledAccountCount > 0) {
                alerts.add(getString(R.string.ma_disabled_note_1, disabledAccountCount))
            }

            // ★ 到点了却没执行 —— 必须让用户**看见**。
            //   旧实现遇到这种情况只是悄悄把任务顺延到明天，用户唯一的感受就是
            //   「设了时间却没签」，而且永远不知道是闹钟没响还是被系统拦了。
            //   现在只要超过设定时间 10 分钟还没动静，就直接写在这里。
            val overdueMs = System.currentTimeMillis() - Prefs.nextRunAt
            if (Prefs.nextRunAt > 0L && overdueMs > 10 * 60 * 1000L) {
                alerts.add(
                    getString(R.string.ma_overdue_ms_1, (overdueMs / 60000L))
                )
            }

            // ★ v19.2 的「服务活着 = 不依赖闹钟」是错误结论：Doze 会冻结普通 delay。
            //   心跳只证明协程最近拿到过 CPU；真正到点仍以系统闹钟为主，90 分钟内再加短时唤醒保护。
            val serviceAlive = System.currentTimeMillis() - Prefs.serviceAliveAt < 20 * 60 * 1000L
            // ★ 「服务已停止/被冻结」就是「放后台不执行、打开 App 才执行」的直接证据：
            //   服务被系统冻结时，连维护循环都不会跑，只能等闹钟 —— 而国产 ROM 的省电策略
            //   往往连闹钟一起冻结，于是要等用户打开 App 才一起放行。
            //   光显示「已停止」用户不知道该干什么，所以它必须留在摘要区并带上下一步。
            if (!serviceAlive) {
                alerts.add(
                    getString(R.string.ma_service_alive_11)
                )
            }
            detail.append(getString(R.string.ma_service_alive_1))
            if (serviceAlive) {
                detail.append(getString(R.string.ma_service_alive_2))
            } else if (Prefs.serviceAliveAt > 0L) {
                detail.append(getString(R.string.ma_service_alive_9, SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(Prefs.serviceAliveAt))))
            } else {
                detail.append(getString(R.string.ma_service_alive_3))
            }
            if (Prefs.standbyProtectedUntil > System.currentTimeMillis()) {
                detail.append(getString(R.string.ma_service_alive_10, SimpleDateFormat("HH:mm", Locale.CHINA).format(Date(Prefs.standbyProtectedUntil))))
            }

            // 完整自证链：闹钟触发 → 系统接受启动请求 → Service.onStartCommand 真正执行。
            // 三个时间分开记录，下一次不用再猜是卡在哪一段。
            // ★ 这三行属于「排查用细节」：一切正常时用户不需要看到，折进详细区。
            detail.append(getString(R.string.ma_service_alive_4))
                .append(if (Prefs.lastAlarmAt > 0L) shortTime.format(Date(Prefs.lastAlarmAt)) else getString(R.string.ma_service_alive_5))
            detail.append(getString(R.string.ma_service_alive_6))
                .append(if (Prefs.lastAlarmAcceptedAt > 0L) shortTime.format(Date(Prefs.lastAlarmAcceptedAt)) else getString(R.string.ma_service_alive_7))
            detail.append(getString(R.string.ma_service_alive_8))
                .append(if (Prefs.lastServiceStartAt > 0L) shortTime.format(Date(Prefs.lastServiceStartAt)) else getString(R.string.ma_service_alive_7))
            if (Prefs.pausedUntil > System.currentTimeMillis()) {
                // ★ 暂停的原因不止「风控」一种：验证码、登录失效也会限时暂停。
                //   旧实现一律写「风控暂停中」，用户看到这句就会以为是微博限流，
                //   而那次其实是因为有账号没登录 —— 判断方向完全被带偏。
                // ★★ 第 47 期：改读 displayRunStatus() —— 全自动过完滑块后，
                //   底层那次 USER_REQUIRED 已经被本轮收尾盖掉过一次 VERIFY_OK，
                //   这里按「现在还有没有事要用户做」重新判一次，避免落到
                //   「需要人工处理（验证身份或重新登录）」这种与事实相反的提示上。
                val pauseReason = when (displayRunStatus()) {
                    "USER_REQUIRED" -> getString(R.string.ma_pause_reason_1)
                    "PAUSED" -> getString(R.string.ma_pause_reason_2)
                    // ★ 第 39 期：验证已自动完成（onVerifySuccess 写入 VERIFY_OK）。
                    //   30 分钟暂停窗口可能还没走完，这里得说清「风控已经处理掉了」，
                    //   否则会落到含糊的「暂停中，」上。
                    "VERIFY_OK" -> getString(R.string.ma_pause_reason_1b)
                    else -> getString(R.string.ma_pause_reason_3)
                }
                // 暂停解释了「为什么现在没在签」，属于用户需要知道的事，留在摘要区
                alerts.add(
                    getString(R.string.ma_pause_reason_16, pauseReason, SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(Prefs.pausedUntil)))
                )
            }
            // ★★ 第 47 期：同上，改读 displayRunStatus()。
            head.append(getString(R.string.ma_pause_reason_11, runStatusLabel(displayRunStatus())))
            // ★ 这一段是「上次信息」的完整明细：每个账号一行汇总 + 每个超话的已签/失败。
            //   它是全块最长的部分，也是折叠收益最大的一处。
            if (Prefs.lastRunMessage.isNotBlank()) {
                detail.append(getString(R.string.ma_pause_reason_12, Prefs.lastRunMessage))
            }
        } else {
            // ★ 旧实现这里只写一句「自动签到未开启」，太像普通说明文字，用户会直接跳过，
            //   然后继续反馈「到点不执行」—— 其实功能根本没开，程序压根不会登记任何闹钟。
            //   必须明确写出「当前状态 + 要做什么」，否则这个最廉价的排查点永远被漏掉。
            //   ★ 这一支**不折叠**：它是「不处理就一定不会执行」的典型。
            head.append(getString(R.string.ma_pause_reason_13))
            // 首屏大字也要跟着说清「没开」，否则上面写着「今天还没开始」，
            // 用户会以为只是还没到点 —— 而实际上是根本没开。
            headlineView.text = getString(R.string.checkin_headline_off)
            headlineNoteView.visibility = View.GONE
        }
        detail.append(getString(R.string.ma_pause_reason_4))
            .append(if (exactAllowed) getString(R.string.ma_pause_reason_5) else getString(R.string.ma_pause_reason_6))
        detail.append(getString(R.string.ma_pause_reason_14, alarmModeLabel(Prefs.lastAlarmMode)))
        if (Prefs.lastWatchdogAt > 0L) {
            detail.append(getString(R.string.ma_pause_reason_15, shortTime.format(Date(Prefs.lastWatchdogAt))))
        }
        if (Prefs.lastAlarmError.isNotBlank() && Prefs.lastAlarmMode != "alarm_clock") {
            detail.append("（").append(Prefs.lastAlarmError).append("）")
        }
        detail.append(getString(R.string.ma_pause_reason_7))
            .append(if (batteryAllowed) getString(R.string.ma_pause_reason_8) else getString(R.string.ma_pause_reason_9))
        if (!exactAllowed || !batteryAllowed) {
            alerts.add(getString(R.string.ma_pause_reason_10))
        }

        // 摘要 = 三行状态 + 所有需要用户动手的事（告警统一追加在末尾，最醒目）
        for (alert in alerts) head.append("\n").append(alert)
        findViewById<TextView>(R.id.scheduleStatus).text = head.toString()

        val detailView = findViewById<TextView>(R.id.statusDetail)
        detailView.text = detail.toString()
        detailView.visibility = if (statusExpanded) View.VISIBLE else View.GONE

        val statusToggle = findViewById<TextView>(R.id.statusToggle)
        statusToggle.visibility = if (detail.isEmpty()) View.GONE else View.VISIBLE
        statusToggle.text = getString(if (statusExpanded) R.string.status_hide_detail else R.string.status_show_detail)

        // ★★ 第 109 期：发帖进度那一块（`postStatus`）已按用户要求删除
        //   ⇒ 这里不再有 `updatePostStatus()`。发帖的实时进度改看发帖卡下方
        //   第 107 期「任务信息卡片」（由 `startPostTaskPoll()` 自己轮询）。

        // 区分「正在执行」和「上次执行」：
        // 旧实现整轮都显示上一轮的结果，签到跑起来后界面毫无变化，像是没反应。
        // 这里再加一层时间兜底 —— 万一进程被杀，「正在执行」标记不会永远挂着。
        // ★ 兜底时长要跟单轮最大耗时匹配：每个账号最多 10 分钟（按待签数量动态给），
        //   5 个账号就可能跑很久，所以放宽到 60 分钟，否则跑到一半界面会误判成「已结束」。
        val runningNow = Prefs.running &&
            System.currentTimeMillis() - Prefs.lastRunAt < 60 * 60 * 1000L
        val lastText = when {
            runningNow -> getString(R.string.ma_last_text_1) + Prefs.lastRunMessage.ifBlank { getString(R.string.ma_last_text_2) }
            Prefs.lastRunAt > 0L -> {
                val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date(Prefs.lastRunAt))
                getString(R.string.ma_time_1) + time + "\n" + Prefs.lastRunMessage.ifBlank { getString(R.string.ma_time_2) }
            }
            else -> getString(R.string.settings_log_idle)
        }
        findViewById<TextView>(R.id.logText).text = lastText
    }

    /** 闹钟档位的中文名。首页和诊断报告共用，避免两处文案不一致。 */
    private fun alarmModeLabel(mode: String): String = when (mode) {
        "alarm_clock" -> getString(R.string.ma_alarm_mode_label_1)
        "exact" -> getString(R.string.ma_alarm_mode_label_2)
        "inexact" -> getString(R.string.ma_alarm_mode_label_3)
        "failed" -> getString(R.string.ma_alarm_mode_label_4)
        else -> getString(R.string.ma_alarm_mode_label_5)
    }

    /**
     * 生成一段可以直接粘贴出去的诊断文本。
     *
     * ★ 为什么需要它：用户反馈「还是不行」时，真正决定性的信息是
     *   「闹钟有没有响过」「服务有没有被冻结」「精确闹钟权限有没有给」——
     *   而这些以前只能靠一问一答去凑，一轮就是半天，而且用户看到的内容
     *   和程序实际状态经常对不上（比如没注意到某一行）。
     *   现在点一下按钮就全部整理好并复制到剪贴板，一次问清。
     *
     * ★★★ 第 108 期：报告**大幅精简**。用户反馈「复制出来太长」——
     *   原报告把 20 多项状态 + 滑块日志**全量**（最多 400 条）一起 dump，
     *   一屏都看不完。现在只保留真正决定排查方向的几项：
     *   开关变化时间/原因、唤醒保护时间戳明细、账号序号列表、兼容性跳转、
     *   滑块采样状态、签到原始回包、滑块日志全量 —— 全部砍掉；
     *   滑块日志只留最后 10 条（见本函数末尾）。
     */
    private fun buildDiagnosticReport(): String {
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA)
        fun stamp(value: Long): String = if (value > 0L) formatter.format(Date(value)) else getString(R.string.ma_stamp_1)

        val accounts = AccountStore.all()
        val ready = accounts.count { it.enabled && it.loggedIn }
        val today = LocalScheduler.todayString()
        val doneToday = try {
            AccountStore.doneToday(today)
        } catch (_: Exception) {
            -1
        }
        val power = getSystemService(PowerManager::class.java)
        val batteryAllowed = power.isIgnoringBatteryOptimizations(packageName)

        val report = StringBuilder()
        report.append(getString(R.string.ma_report_1))
        report.append(getString(R.string.ma_report_10, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE))
        report.append(getString(R.string.ma_report_11, formatter.format(Date())))
        report.append(getString(R.string.ma_report_12, Build.MANUFACTURER, ' ', Build.MODEL, Build.VERSION.RELEASE, Build.VERSION.SDK_INT))
        // ★★★ 第 69 期：WebView 版本。
        //
        //   为什么必须有这一行：整个滑块验证链路（检测滑块 → 下载图 → 拖拽）
        //   跑在 WebView 里，`jsDrag` 是**页面内派发 PointerEvent/MouseEvent**。
        //   而 PointerEvent 的支持程度、`evaluateJavascript` 的行为、
        //   甚至 `getBoundingClientRect` 的取值，都随 WebView 内核版本变。
        //   用户报「滑块不动 / 验证页不出来」时，**这是最先要排除的变量** ——
        //   没有它，只能反复问用户「你手机 WebView 什么版本」，一问一答就是半天。
        //
        //   ★ 用 WebView.getCurrentWebViewPackage()：**静态只读 API，API 26+ 可用**
        //     （minSdk=26 正好满足），不创建 WebView 实例、不联网、不碰任何判定。
        report.append(
            getString(
                R.string.ma_report_webview,
                webViewVersion()
            )
        )
        // ★ 存储状态：加密存储失败会静默退到普通存储，表现是「账号莫名其妙没了」。
        //   不写这一行的话，用户只会报「签到不执行」，而真因其实在存储层。
        report.append(getString(R.string.ma_report_2)).append(
            if (Prefs.storageError.isBlank()) {
                getString(R.string.ma_report_3)
            } else {
                getString(R.string.ma_report_15, Prefs.storageError)
            }
        ).append("\n")
        report.append(getString(R.string.ma_report_4))
        report.append(getString(R.string.ma_report_5)).append(if (Prefs.scheduleEnabled) getString(R.string.state_on) else getString(R.string.ma_report_6)).append("\n")
        // ★★★★ 第 119 期（用户批准）：把「开关是谁改的、什么时候改的」补进报告。
        //   起因：报告里反复出现「设定时间已保存、但开关是关的」——从报告上完全看不出是谁关的
        //   （是用户点的？还是程序某条路径？），只能猜，猜错就白改一轮。
        //   `Prefs.scheduleEnabledChangedAt` / `ChangedBy` 从第 100 期起就在写
        //   （`setScheduleEnabled()` 是全工程**唯一**写入点），但**从来没有被读过**，
        //   设计承诺一直没兑现 —— 这一行就是来兑现它的。
        //   ★ 纯只读展示：不参与任何判定、`Prefs` 键零新增。
        //   ★ 原因为空 = 有路径绕过了 `setScheduleEnabled()`（见 Prefs.kt 该字段注释）。
        report.append(
            getString(
                R.string.ma_report_switch_changed,
                stamp(Prefs.scheduleEnabledChangedAt),
                Prefs.scheduleEnabledChangedBy.ifBlank {
                    getString(R.string.ma_report_switch_changed_unknown)
                }
            )
        )
        report.append(getString(R.string.ma_report_14, String.format(Locale.CHINA, "%02d:%02d", Prefs.baseHour, Prefs.baseMinute)))
        // ★ 109：报告必须永远把「开始日期」写全。`ma_report_14` 只有 `%02d:%02d`，
        //   而开始日期是排程的基准日（未来日期会让 `baseRunAt()` 一路等到那天）——
        //   2026-10-03 就是「报告里看不出排程为什么跳到 10-17」。
        report.append(
            getString(
                R.string.ma_report_start_date,
                if (Prefs.startDate.isBlank()) getString(R.string.ma_report_start_date_none)
                else Prefs.startDate
            )
        )
        report.append(getString(R.string.schedule_next_label))
            .append(if (Prefs.nextRunAt > 0L) stamp(Prefs.nextRunAt) else getString(R.string.ma_alarm_mode_label_5)).append("\n")
        // ★ 「设定 18:51，却显示明天 19:05」—— 差的 14 分钟是防固定时刻请求的随机抖动。
        //   不写出来，用户只会以为自己设错了，然后又来反馈一轮。
        val jitterNote = LocalScheduler.jitterNote(this)
        if (jitterNote.isNotBlank()) report.append(jitterNote).append("\n")
        report.append(getString(R.string.ma_jitter_note_1))
            .append(if (LocalScheduler.exactAlarmAllowed(this)) getString(R.string.ma_pause_reason_5) else getString(R.string.ma_jitter_note_2)).append("\n")
        // ★★★ 第 108 期：最近闹钟只留「模式 + 时间 + 错误」三项。
        //   原来这一段还摊开了「启动请求已受理 / 服务最近接令 / 看门狗下次重试 /
        //   服务最近心跳 / 唤醒保护申请 / 保护到 / 唤醒锁错误」共 7 项时间戳，
        //   排查时几乎用不到，全部砍掉。
        report.append(getString(R.string.ma_jitter_note_22, alarmModeLabel(Prefs.lastAlarmMode)))
        report.append(getString(R.string.ma_jitter_note_3)).append(Prefs.lastAlarmError.ifBlank { getString(R.string.ma_jitter_note_4) }).append("\n")
        report.append(getString(R.string.ma_jitter_note_5))
        report.append(getString(R.string.ma_jitter_note_23, stamp(Prefs.lastAlarmAt)))
        report.append(getString(R.string.ma_jitter_note_6)).append(if (batteryAllowed) getString(R.string.ma_pause_reason_8) else getString(R.string.ma_jitter_note_7)).append("\n")
        report.append(getString(R.string.ma_jitter_note_8))
        report.append(getString(R.string.ma_jitter_note_31, accounts.size, ready))
        if (doneToday >= 0) {
            report.append(getString(R.string.ma_jitter_note_32, doneToday, ready))
        }
        report.append(getString(R.string.ma_jitter_note_33, stamp(Prefs.pausedUntil)))
        report.append(getString(R.string.ma_jitter_note_11)).append(if (Prefs.needsVerify) getString(R.string.ma_jitter_note_12) else getString(R.string.ma_jitter_note_13)).append("\n")
        // ★★ 紧挨着「需要人工验证」再放一句「验证页到底出现过没有」。
        //   连着三轮了，用户回传报告时天然只截「自动签到 / 后台执行链 / 账号与结果」这三段，
        //   而第 9 期把这条小结放在了报告最底部（滑块日志上方）—— 位置不对，从来没被贴回来过。
        //   它决定后面所有排查方向（0 次要查闹钟/通知/拉起限制；>0 次才轮到可见性和拖动），
        //   所以必须出现在用户会看的地方。只读，不参与任何判定。
        report.append(getString(R.string.ma_jitter_note_43, SliderTrace.verifySummary()))
        // ★★★ 验证链路能不能「自己弹出来 / 跑通」，取决于这几项权限。
        //   第 11 期实测：用户报告「屏幕根本不亮、什么都不跳出来」，而「验证页累计」是 0 次
        //   —— 说明 showVerifyNotification() 的拉起路径没走通。
        //   这一行把关键权限一次摊开：哪一项是「无」就补哪一项（设置页点「开通向导」即可）。
        //   ★ 第 20 期修正：Period-19 起验证页改走**悬浮窗**承载，不再依赖「全屏通知」
        //     （它是 Android 14+ 单独一项特殊权限，现已从必选项里移除）；
        //     同时补上真正影响全自动跑通的「电池优化 / 精确闹钟」两项。
        report.append(
            getString(
                R.string.ma_jitter_note_44,
                yesNo(notificationsAllowed()),
                yesNo(isIgnoringBatteryOptimizations()),
                yesNo(canScheduleExactAlarms()),
                yesNo(canDrawOverlay()),
                yesNo(isAccessibilityServiceEnabled())
            )
        )
        // ★★★ 第 69 期：设置项自检 —— 必选项完成度 N/3。
        //
        //   ma_jitter_note_44 那一行只有「有/无」，但**没有「应该是什么」**。
        //   向导里必选 3 项（悬浮窗/电池/精确闹钟），用户回传报告时看到
        //   「电池优化=无」，还得自己数这算不算问题。直接写出 N/3，
        //   一眼就知道「能不能全自动跑通」。
        //   ★ 分母与 SetupWizardActivity.REQUIRED_ITEM_COUNT 共用同一个常量，
        //     不会再出现第 41 期那种「已开启 5 / 4 项」的漂移。
        //   ★ 纯只读，不参与任何判定。
        report.append(
            getString(
                R.string.ma_jitter_note_45,
                permissionDoneCount(),
                SetupWizardActivity.REQUIRED_ITEM_COUNT
            )
        )
        report.append(getString(R.string.ma_jitter_note_34, stamp(Prefs.lastRunAt)))
        // ★★ 第 47 期：诊断报告里的「上次结果」与首页用同一个口径（displayRunStatus()），
        //   否则会出现「首页说验证已通过、复制出来的报告说需要处理」这种自相矛盾。
        //   用户 2026-10-02 贴回来的报告就是栽在这一处。
        report.append(getString(R.string.ma_jitter_note_14)).append(displayRunStatus().ifBlank { getString(R.string.ma_jitter_note_4) })
            .append("（").append(runStatusLabel(displayRunStatus())).append("）\n")
        report.append(getString(R.string.ma_jitter_note_15)).append(Prefs.lastRunMessage.ifBlank { getString(R.string.ma_jitter_note_4) }).append("\n")
        // ★ 发帖单独一段：发帖接口是本机无法验证的部分，
        //   这段里的「微博原话」是出问题时唯一的定位依据。
        report.append(getString(R.string.ma_jitter_note_16))
        report.append(getString(R.string.ma_jitter_note_17)).append(if (Prefs.postEnabled) getString(R.string.state_on) else getString(R.string.ma_report_6)).append("\n")
        if (Prefs.postEnabled) {
            report.append(getString(R.string.ma_jitter_note_35, Prefs.postPerAccount, Prefs.postIntervalMinutes))
            report.append(getString(R.string.ma_jitter_note_36, topicListOf(Prefs.postTopicsText).size))
            report.append(getString(R.string.ma_jitter_note_37, Prefs.postContentText.trim().let { raw ->
                if (raw.isBlank()) 0 else raw.split(Regex("(?m)^\\s*-{3,}\\s*$")).count { it.isNotBlank() }
            }))
            report.append(getString(R.string.ma_jitter_note_38, AccountStore.postDoneToday(today), AccountStore.postTargetToday(Prefs.postPerAccount)))
        }
        report.append(getString(R.string.ma_jitter_note_39, stamp(Prefs.postLastRunAt)))
        report.append(getString(R.string.ma_jitter_note_18)).append(Prefs.postLastStatus.ifBlank { getString(R.string.ma_jitter_note_4) }).append("\n")
        report.append(getString(R.string.ma_jitter_note_19)).append(Prefs.postLastMessage.ifBlank { getString(R.string.ma_jitter_note_4) }).append("\n")
        // ★★★ 第 108 期：滑块 / 验证链路的黑匣子，原设计只留**最后 10 条**。
        //   原来这里是 `SliderTrace.dump()` 全量摊开（缓冲上限 400 条），
        //   报告被撑到几百行 —— 用户反馈「太长」。10 条足够看出最近的失败点。
        //   缓冲实现见 SliderTrace.kt（本期未改）。
        // ★★★★ 第 135 期（诊断改进，**纯输出、不改任何行为 / 判定**）：
        //   实践发现，发帖撞 20067 时 `WeiboClient.kt:1626` 写的那行
        //   「[发帖:xxx] 20067 完整回包=...」会被后续大量 trace 推到缓冲深处，
        //   takeLast(10) 永远捞不到 —— 而它正是「定发帖验证页真实 URL」的唯一证据，
        //   捞不到就卡住 135 期。
        //   改为：**无条件捞出所有含「20067 完整回包」的行（位置无关）+ 末 15 条上下文**。
        //   这样即使回包行落在缓冲最旧处，也能在报告里看到，无需重新触发发帖。
        val dumpLines = SliderTrace.dump().lines()
        val pkgLines = dumpLines.filter { it.contains("20067 完整回包") }
        val tail = dumpLines.takeLast(15)
        report.append((pkgLines + tail).distinct().joinToString("\n")).append("\n")
        return report.toString()
    }

    private fun copyToClipboard(text: String) {
        try {
            val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            manager.setPrimaryClip(ClipData.newPlainText(getString(R.string.ma_manager_1), text))
        } catch (_: Exception) {
        }
    }

    /**
     * 把内部状态码翻成中文。
     *
     * ★ 之前这里是直接把 Prefs.lastRunStatus 原样打到界面上，
     *   于是用户会看到「USER_REQUIRED」「PARTIAL」这种词 —— 对自用工具来说毫无意义。
     *   特别是 PARTIAL：它表示「有超话没签完」，绝不能让用户误以为全签上了。
     */
    private fun runStatusLabel(status: String): String {
        return when (status) {
            "" -> getString(R.string.ma_run_status_label_1)
            "SUCCESS" -> getString(R.string.ma_run_status_label_2)
            "PARTIAL" -> getString(R.string.ma_run_status_label_3)
            "PAUSED" -> getString(R.string.ma_run_status_label_4)
            "USER_REQUIRED" -> getString(R.string.ma_run_status_label_5)
            // ★ 第 39 期：全自动过滑块验证成功后由 onVerifySuccess 写入。
            //   原来过验证成功后一个字都不改，于是「上次结果」长期停在 USER_REQUIRED
            //   （需要处理），而实际上风控已经自动处理完了 —— 纯展示口径修正。
            "VERIFY_OK" -> getString(R.string.ma_run_status_label_14)
            // ★ 这个状态码是 v0.19.10 新加的，专门用来区分「有空槽位没登录」和「真的出事了」。
            //
            //   起因是 v0.19.9 的测试报告：账号共 10 个、可签到 5 个，
            //   已登录的 3 个账号全部跑完、今日进度 5/5，
            //   但「上次结果」写的是 USER_REQUIRED（需要处理）——
            //   因为另外 5 个槽位一直没登录，把它们也算进了「需要人工处理」。
            //   结果就是：**功能完全正常，报告却在报警**，用户看到只会以为坏了。
            //
            //   现在未登录槽位单独报，且明确写出「不影响其它账号」。
            "NOT_LOGGED_IN" -> getString(R.string.ma_run_status_label_6)
            // ★ 这是「闹钟响了但系统不让后台启动服务」—— 必须给用户一个可执行的下一步，
            //   旧实现直接把 "BLOCKED" 这个内部状态码打到界面上，用户完全看不懂。
            "BLOCKED" -> getString(R.string.ma_run_status_label_7)
            "ALARM_FAILED" -> getString(R.string.ma_run_status_label_8)
            "FGS_FAILED" -> getString(R.string.ma_run_status_label_9)
            "MAINTENANCE_FAILED" -> getString(R.string.ma_run_status_label_10)
            // ★ 这不是程序出错，而是「服务跑到一半被系统关掉了」。
            //   旧实现把它当普通异常报成「执行出错：Job was cancelled」，
            //   用户看到的是英文报错，还会以为是程序 bug —— 实际要去做后台白名单设置。
            "INTERRUPTED" -> getString(R.string.ma_run_status_label_11)
            "FAILED" -> getString(R.string.ma_run_status_label_12)
            "RETRY" -> getString(R.string.ma_run_status_label_13)
            else -> status
        }
    }

    /**
     * ★★ 第 47 期（纯展示口径修正，2026-10-02 真机实测提出）：
     *   把「上次结果」里那个**已经作废的** `USER_REQUIRED` 纠正成 `VERIFY_OK`。
     *
     * ## 问题（用户 2026-10-02 贴回来的诊断报告）
     * 同一份报告里同时出现
     *   `上次结果：USER_REQUIRED（需要处理（账号未登录，或有账号需要重新授权））`
     *   `[判定] 验证通过，账号进入静置期`
     * —— 风控其实已经被全自动过滑块处理掉了，报告却在报警，用户只会以为白过了。
     *
     * ## 根因
     * `Prefs.lastRunStatus` 这一个键被**两个不同概念**共用：
     *   · `OverlayVerifyHost.onVerifySuccess`（悬浮窗验证成功）写 `VERIFY_OK`；
     *   · `AgentService.executeOnce` 本轮收尾写「本轮整体结果」。
     * 一批有两个以上账号时，收尾那一次一定发生在验证成功**之后**
     * ⇒ 把 `VERIFY_OK` 盖回 `USER_REQUIRED`。
     *
     * ## 为什么不去改写入时机
     * 那属于链路①（自动签到）的行为，且 `Prefs` 全键语义不可动。
     * 所以这里**一个字节都不写**，只在显示前按**当前真实状态**重新问一遍：
     * 「现在还有事要用户做吗？」
     *
     * ## 判定（两条读的都是既有字段，不新增任何状态）
     * · `AccountStore.needsVerifyAccounts()` 非空 ⇒ 还有账号卡在人工验证 ⇒ 保持原样
     * · 任一已启用账号 `!loggedIn` ⇒ 还有账号掉线 ⇒ 保持原样
     * · 两条都不成立 ⇒ 那一轮报的「需要处理」已经作废 ⇒ 显示成 `VERIFY_OK`
     *
     * ★ 只影响文案。`Prefs.lastRunStatus` 全项目**只有本文件在读**
     *   （`updateStatus` 的暂停原因与「上次结果」、`buildDiagnosticReport` 的「上次结果」），
     *   没有任何一处拿它做判定（已逐行核对：`grep -n lastRunStatus` 的全部命中）。
     *   本函数同样不写任何状态，也不参与排程。
     */
    private fun displayRunStatus(): String {
        val raw = Prefs.lastRunStatus
        if (raw != "USER_REQUIRED") return raw
        val stillNeedsUser = AccountStore.needsVerifyAccounts().isNotEmpty() ||
            AccountStore.enabled().any { !it.loggedIn }
        return if (stillNeedsUser) raw else "VERIFY_OK"
    }

    /**
     * 逐个检查所有账号的登录态。
     *
     * ★ 与旧版的区别：某个账号掉线**不再关闭整个自动签到**。
     *   多账号场景下，一个号掉线不该拖累其它号继续签到。
     */
    private fun checkAllLogins() {
        val accounts = AccountStore.all()
        if (accounts.isEmpty()) {
            findViewById<TextView>(R.id.logText).text = getString(R.string.accounts_empty)
            return
        }
        scope.launch {
            findViewById<TextView>(R.id.logText).text =
                getString(R.string.ma_accounts_1, accounts.size)
            val lines = mutableListOf<String>()
            for (account in accounts) {
                val result = withContext(Dispatchers.IO) {
                    try {
                        val config = WeiboClient.fetchConfig(account)
                        when {
                            !config.has("login") -> LoginCheck.UNKNOWN
                            config.optBoolean("login") -> LoginCheck.OK
                            else -> LoginCheck.EXPIRED
                        }
                    } catch (_: Exception) {
                        // 网络异常 / 超时 / 无网，都归为「未知」，不能据此判定掉线
                        LoginCheck.UNKNOWN
                    }
                }
                account.lastCheckAt = System.currentTimeMillis()
                when (result) {
                    LoginCheck.OK -> {
                        account.verified = true
                        account.lastCheckMessage = getString(R.string.ma_config_1)
                    }
                    LoginCheck.EXPIRED -> {
                        account.verified = false
                        account.lastCheckMessage = getString(R.string.ma_config_2)
                    }
                    LoginCheck.UNKNOWN -> {
                        // 旧实现在这里把 scheduleEnabled 置 false 并取消闹钟，
                        // 导致一次网络抖动就会让自动签到永久停摆，且用户毫无感知。
                        account.lastCheckMessage = getString(R.string.ma_config_3)
                    }
                }
                lines.add(account.displayName + "：" + account.lastCheckMessage)
            }
            AccountStore.save()
            findViewById<TextView>(R.id.logText).text = lines.joinToString("\n")
            renderAccounts()
            updateStatus()
        }
    }

    /** 账号列表结构变化（增删/启停/登录返回）时重建所有行 */
    private fun renderAccounts() {
        val container = findViewById<LinearLayout>(R.id.accountList)
        container.removeAllViews()
        rowViews.clear()

        val accounts = AccountStore.all()
        if (accounts.isEmpty()) {
            val empty = TextView(this)
            empty.text = getString(R.string.accounts_empty_hint)
            empty.setTextColor(getColor(R.color.text_secondary))
            empty.textSize = 13f
            container.addView(empty)
            return
        }

        val inflater = LayoutInflater.from(this)
        for (account in accounts) {
            val row = inflater.inflate(R.layout.item_account, container, false)
            rowViews[account.id] = row

            row.findViewById<Button>(R.id.accountLoginButton).setOnClickListener {
                // ★★★★ 第 62 期：待验证的账号点这个按钮走**验证模式** —— 保留登录态、
                //   直接打开微博页面让用户手动过验证码，过了自动清 needsVerify 并进静置期。
                //   在此之前这里永远走登录模式（清 Cookie → 重新扫码），
                //   而用户 2026-10-04 明确要求「不出现重新授权登录类似的」。
                // ★★★★ 第 132 期（用户 2026-10-18 拍板）：**不再猜验证来源，让用户自己选**。
                //   原因：`needsVerify` 只是一个布尔值，代码里分不出这次验证是发帖来的还是签到来的；
                //   猜错就会把「发帖验证」当签到处理 ⇒ 打开超话页点签到 ⇒
                //   正是用户明令禁止的「不要再前往花小龙超话执行操作来触发人工验证」。
                //   ★ 老语义逐字节保留：`accountButtonUseVerifyMode == false` 时，
                //     即使 needsVerify 也走**登录模式**（等价于原来的
                //     `openLogin(account, needsVerify && useVerifyMode)` 里那一段 false 分支）。
                if (account.needsVerify && accountButtonUseVerifyMode) {
                    showVerifyKindChooser(account)
                } else {
                    openLogin(account, false)
                }
            }
            row.findViewById<Button>(R.id.accountToggleButton).setOnClickListener {
                account.enabled = !account.enabled
                AccountStore.save()
                refreshAccountRows()
                updateStatus()
                toast(getString(if (account.enabled) R.string.account_enabled else R.string.account_disabled, account.displayName))
            }
            row.findViewById<Button>(R.id.accountRemoveButton).setOnClickListener {
                confirmRemove(account)
            }
            container.addView(row)
        }
        refreshAccountRows()
    }

    /** 只刷新已有行的文字，不重建视图（每 2 秒调一次，重建会打断滚动和点击） */
    private fun refreshAccountRows() {
        for (account in AccountStore.all()) {
            val row = rowViews[account.id] ?: continue

            row.findViewById<TextView>(R.id.accountName).text = account.displayName

            val state = row.findViewById<TextView>(R.id.accountState)
            when {
                !account.enabled -> {
                    state.text = getString(R.string.account_state_disabled)
                    state.setTextColor(getColor(R.color.text_secondary))
                }
                account.needsVerify -> {
                    state.text = getString(R.string.account_state_verifying)
                    state.setTextColor(getColor(R.color.warning_text))
                }
                account.resting() -> {
                    val hours = ((account.restUntil - System.currentTimeMillis()) / 3600000L).coerceAtLeast(1)
                    state.text = getString(R.string.account_state_resting, hours)
                    state.setTextColor(getColor(R.color.warning_text))
                }
                account.loggedIn -> {
                    state.text = getString(R.string.account_state_on)
                    state.setTextColor(getColor(R.color.state_ok))
                }
                account.cookie.isNotBlank() -> {
                    state.text = getString(R.string.account_state_expired)
                    state.setTextColor(getColor(R.color.warning_text))
                }
                else -> {
                    state.text = getString(R.string.account_state_off)
                    state.setTextColor(getColor(R.color.warning_text))
                }
            }

            val summary = account.lastRunMessage.lineSequence().firstOrNull().orEmpty()
            row.findViewById<TextView>(R.id.accountInfo).text = when {
                summary.isNotBlank() -> summary
                account.cookie.isBlank() -> getString(R.string.account_info_none)
                else -> getString(R.string.ma_summary_1)
            }

            // ★ 第 27 期：风控账号（needsVerify）这个按钮单独给个名字，
            //   让「要干什么」和「点哪里」能对上（上面的 when 里 needsVerify 排在
            //   loggedIn 前面，两边顺序一致）。
            // ★★★★ 第 62 期：名字从「重新授权」改成「去验证」，**点下去的行为也跟着改了** ——
            //   现在走验证模式（保留登录态、直接打开微博让用户手动过验证码），
            //   不再清 Cookie 让人重新扫码。见上面点击监听里的 openLogin(account, account.needsVerify)。
            //   用户 2026-10-04 的要求：「不出现重新授权登录类似的」。
            row.findViewById<Button>(R.id.accountLoginButton).text = when {
                account.needsVerify -> getString(R.string.account_reauth)
                account.loggedIn -> getString(R.string.ma_summary_2)
                else -> getString(R.string.account_login)
            }
            row.findViewById<Button>(R.id.accountToggleButton).text =
                if (account.enabled) getString(R.string.account_disable) else getString(R.string.ma_summary_3)
        }
    }

    /**
     * 打开登录 / 验证页。
     *
     * ★★★★ 第 62 期：[verifyMode] 为真 ⇒ 走**验证模式**：保留该账号已有的登录态，
     *   直接打开微博页面让用户手动拖一次滑块；过了会自动清 `needsVerify` 并进静置期，
     *   **不会**让用户重新扫码。为假 ⇒ 原来的登录模式（清 Cookie → 扫码重新登录）。
     *
     * 在此之前账号页只有一个「重新授权」按钮、永远走登录模式 ——
     * 一个「只是需要过验证码」的账号，用户点下去却要重新扫码，代价太重
     * （用户 2026-10-04 反馈）。
     */
    private fun openLogin(
        account: WeiboAccount,
        verifyMode: Boolean = false,
        // ★★★★ 第 132 期：验证来源类型。默认 CHECKIN ⇒ 所有既有调用点
        //   （账号页「去验证」、账号页「重新登录」两处）行为逐字节不变。
        //   只有**发帖任务卡**上的「去验证」（见 renderPostTaskList 里
        //   `postTaskItemVerify` 的点击监听）显式传 POST。
        kind: String = YidunAutoSlider.VERIFY_KIND_CHECKIN
    ) {
        startActivity(
            Intent(this, WeiboLoginActivity::class.java)
                .putExtra(WeiboLoginActivity.EXTRA_ACCOUNT_ID, account.id)
                .putExtra(WeiboLoginActivity.EXTRA_VERIFY_MODE, verifyMode)
                // ★ 第 132 期：把来源类型透传进验证页（默认 CHECKIN，与历史行为一致）。
                //   缺了这一行，发帖任务卡的「去验证」就会落到默认值 ⇒ 打开花小龙超话
                //   点签到 —— 用户 2026-10-18 明令禁止的动作。
                .putExtra(WeiboLoginActivity.EXTRA_VERIFY_KIND, kind)
                .putExtra(
                    WeiboLoginActivity.EXTRA_LAUNCH_SOURCE,
                    if (verifyMode) "账号页-去验证" else "账号页-重新登录"
                )
        )
    }

    /**
     * ★★★★ 第 132 期（用户 2026-10-18 拍板）：让用户**自己选**验证类型。
     *
     * 起因：`needsVerify` 只是一个布尔值，代码分不出这次验证是「签到触发」还是「发帖触发」。
     * 猜错就会把「发帖验证」当签到处理 —— 打开超话页去点「签到」，
     * 而用户 2026-10-18 明令禁止「不要再前往花小龙超话执行操作来触发人工验证」。
     * 所以不猜：给两个入口，各自走各自的路。
     * ★ 为什么不去数据层加「验证来源」标记：那是链路④数据层（`Prefs` / `WeiboAccount`），
     *   属硬禁区；用户明确选择「不猜、不碰数据层」。
     *
     * ★ 签到验证：与第 62 期行为逐字节一致（打开超话页、自动点签到、拖滑块）。
     * ★ 发帖验证：本期自动成功率为 0（用户已接受的阶段性降级）⇒ 验证页只提示手动完成、
     *   不打开任何页面、不发任何请求。
     */
    private fun showVerifyKindChooser(account: WeiboAccount) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.verify_choose_title))
            .setMessage(getString(R.string.verify_choose_msg, account.displayName))
            .setPositiveButton(getString(R.string.verify_choose_checkin)) { _, _ ->
                openLogin(account, true, YidunAutoSlider.VERIFY_KIND_CHECKIN)
            }
            .setNegativeButton(getString(R.string.verify_choose_post)) { _, _ ->
                openLogin(account, true, YidunAutoSlider.VERIFY_KIND_POST)
            }
            .setNeutralButton(getString(R.string.dialog_cancel), null)
            .show()
    }

    private fun confirmRemove(account: WeiboAccount) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.dialog_remove_title, account.displayName))
            .setMessage(getString(R.string.dialog_remove_message))
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .setPositiveButton(getString(R.string.dialog_delete)) { _, _ ->
                AccountStore.remove(account.id)
                renderAccounts()
                updateStatus()
                toast(getString(R.string.account_removed, account.displayName))
            }
            .show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    /** 用户是否已经点过「暂不设置」（本次启动内不再弹） */
    private var setupPromptDismissed = false

    /**
     * 当前显示的是哪一页。
     *
     * ★ 第 43 期：互动页是**独立 Activity**，不占这里的任何一项 ——
     *   点它不切内容区，所以从互动页回来时勾选状态必须回到这一项，
     *   否则会出现「左边勾着互动、右边显示签到」的错位。
     */
    private var currentPageItemId = R.id.nav_checkin

    /**
     * ★ 第 83 期新增：把当前页码存进实例状态，供重建（切主题 / 转屏 / 进程回收后恢复）使用。
     *   ★ 只存页码，不存任何业务状态 —— 它不改变程序做任何判断。
     */
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(STATE_PAGE_ITEM_ID, currentPageItemId)
    }

    /** 设置左侧导航抽屉。[initialPageItemId] = 启动时要显示的页（重建时由 savedInstanceState 带回来）。 */
    private fun setupDrawer(initialPageItemId: Int) {
        val drawer = findViewById<DrawerLayout>(R.id.drawerLayout)
        val navView = findViewById<NavigationView>(R.id.navView)
        navView.setNavigationItemSelectedListener { item ->
            if (item.itemId == R.id.nav_interact) {
                // ★ 第 43 期：互动页单独开一个 Activity，不参与本页的页面切换。
                //   开之前先把勾选状态还原 —— 用户回来时看到的仍然是原来那一页。
                navView.setCheckedItem(currentPageItemId)
                drawer.closeDrawer(Gravity.START)
                startActivity(Intent(this, InteractActivity::class.java))
            } else {
                currentPageItemId = item.itemId
                showPage(item.itemId)
                drawer.closeDrawer(Gravity.START)
            }
            true
        }
        // ★ 第 83 期：默认仍是签到页；只有 Activity 因切换深色模式而重建时，
        //   savedInstanceState 里才带着上一次的页码，此时直接回到那一页。
        navView.setCheckedItem(initialPageItemId)
        currentPageItemId = initialPageItemId
        findViewById<View>(R.id.menuButton).setOnClickListener {
            drawer.openDrawer(Gravity.START)
        }
        showPage(initialPageItemId)
    }

    /** 按左侧菜单切换页面 */
    private fun showPage(itemId: Int) {
        findViewById<View>(R.id.pageCheckin).visibility = if (itemId == R.id.nav_checkin) View.VISIBLE else View.GONE
        findViewById<View>(R.id.pagePost).visibility = if (itemId == R.id.nav_post) View.VISIBLE else View.GONE
        findViewById<View>(R.id.pageAccounts).visibility = if (itemId == R.id.nav_accounts) View.VISIBLE else View.GONE
        findViewById<View>(R.id.pageSettings).visibility = if (itemId == R.id.nav_settings) View.VISIBLE else View.GONE
        settingsPageVisible = itemId == R.id.nav_settings
        // ★★★ 第 107 期：切到发帖页就开轮询，离开就关。
        //   onPause 也会停，但那是「退到后台」；这里是「人还在 App 里，只是不看这一页」——
        //   两种都要停，否则轮询会一直在没人看的那一页上跑。
        postPageVisible = itemId == R.id.nav_post
        if (postPageVisible) {
            startPostTaskPoll()
        } else {
            stopPostTaskPoll()
        }
        if (settingsPageVisible) {
            // ★ 第 42 期：原来这里还刷一行独立的「自动验证：已开启/未开启」。
            //   无障碍已降为可选（兜底），它自己的状态在开通向导里能看到，
            //   设置页不再单独占一行 ⇒ refreshAccessibilityStatus() 一并删除。
            refreshPermissionSummary()
        }
    }

    /** 本次启动内是否已经展示过「设备兼容/白名单」引导 */
    private var compatGuideShown = false

    /**
     * 检查全自动签到的前置设置。第 42 期起只在**必选项**（悬浮窗 / 电池优化 / 精确闹钟）
     * 有缺时提示一次，点「去开启」直接进开通向导，不再逐个弹窗。
     *
     * ★★ 第 42 期（用户批准）：卡点从「无障碍」改成「必选项」。
     *   第 20 期起这里只卡无障碍一项，但第 36/38 期真机证明点签到与拖动都已经
     *   **不经过无障碍服务**（真实触摸 + 页面内 JS），无障碍只剩第三级兜底
     *   ⇒ 继续拿它当卡点，等于用一个「大概率用不到的服务」拦住用户。
     *   现在改为：必选项没开齐才提示 —— 这三项才是真正会让「到点不执行 / 被系统杀后台」的。
     *   ★ 判据取 `permissionDoneCount()`，与设置页那行、向导的进度**同源**，不会再各说各话。
     * ★ 「全屏通知」卡点是 Period-19 废弃的过时逻辑（验证页改走悬浮窗承载），已移除。
     */
    private fun checkAutoVerifySetup() {
        if (setupPromptDismissed) return
        if (permissionDoneCount() < SetupWizardActivity.REQUIRED_ITEM_COUNT) {
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.dialog_setup_title))
                .setMessage(
                    getString(R.string.dialog_setup_msg)
                )
                .setPositiveButton(getString(R.string.dialog_go_enable)) { _, _ ->
                    // ★ 直接拉开通向导，一次把 3 项必选 + 可选都办了，
                    //   不再只跳到某一个设置页让用户再自己找剩下的。
                    startActivity(Intent(this, SetupWizardActivity::class.java))
                }
                .setNegativeButton(getString(R.string.dialog_skip_setup)) { _, _ -> setupPromptDismissed = true }
                .setCancelable(false)
                .show()
        }
    }

    /** 无障碍服务是否已开启 */
    private fun isAccessibilityServiceEnabled(): Boolean {
        return try {
            val expected = ComponentName(this, SliderGestureAccessibilityService::class.java)
            val enabled = Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            enabled.split(':').any { ComponentName.unflattenFromString(it) == expected }
        } catch (_: Throwable) {
            false
        }
    }

    private fun requestExactAlarmPermissionIfNeeded() {
        DeviceCompatibility.openExactAlarmSettings(this)
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        /**
         * 「测试自动签到」的执行延迟。
         *
         * ★ 取 2 分钟：足够用户按 Home 键、息屏、把手机放下，又不用干等太久。
         *   也不宜更短 —— scheduleAt 里有一条「绝不把闹钟登记到过去」的兜底，
         *   1 分钟以内会被抬到 1 分钟，反而不好预期。
         */
        const val TEST_DELAY_MINUTES = 2

        /**
         * ★ 第 83 期：切换深色模式会让 AppCompat **重建** Activity（系统行为，绕不开）。
         *   重建时要靠这个 key 把「刚才在哪一页」带过去，
         *   否则用户在设置页点完开关会被弹回签到页，还得重新点一遍抽屉。
         *   ★ 顺带修好了同一件事的另一面：以前转屏 / 进程被回收后重建，也会掉回签到页。
         */
        const val STATE_PAGE_ITEM_ID = "page_item_id"

        /**
         * ★★★★ 第 62 期：账号页那个按钮，对「验证没过」（needsVerify）的账号
         *   是否走**验证模式** —— 保留登录态、直接打开微博页面让用户手动拖一次滑块。
         *
         * `true`（默认，用户 2026-10-04 选定）⇒ 走验证模式，**不再清 Cookie、不要求重新扫码**。
         * `false` ⇒ 逐字节回到第 27 期的旧行为（清 Cookie → 扫码重新登录）。
         *
         * ★ 这是本轮唯一**没有界面开关**的一键回滚点 —— 改它需要重新出包，
         *   已在 `星签-第62期-*.md` 里写明。
         */
        @Volatile var accountButtonUseVerifyMode = true
    }
}

/** 登录检查结果：必须区分「确实掉线」和「这次没查成」 */
private enum class LoginCheck { OK, EXPIRED, UNKNOWN }
