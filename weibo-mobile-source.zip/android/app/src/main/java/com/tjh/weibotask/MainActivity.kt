package com.tjh.weibotask

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContentView(R.layout.activity_main)

        findViewById<EditText>(R.id.cloudUrlInput).setText(Prefs.cloudUrl)
        val pairButton = findViewById<Button>(R.id.pairButton)
        val loginButton = findViewById<Button>(R.id.weiboLoginButton)
        val startServiceButton = findViewById<Button>(R.id.startServiceButton)
        val stopServiceButton = findViewById<Button>(R.id.stopServiceButton)
        val batteryButton = findViewById<Button>(R.id.batteryButton)
        val runNowButton = findViewById<Button>(R.id.runNowButton)

        requestNotificationPermission()

        pairButton.setOnClickListener {
            val cloudUrl = findViewById<EditText>(R.id.cloudUrlInput).text.toString().trim().trimEnd('/')
            val code = findViewById<EditText>(R.id.pairCodeInput).text.toString().trim()
            if (cloudUrl.isBlank() || code.isBlank()) {
                toast("请填写云端地址和配对码")
                return@setOnClickListener
            }
            scope.launch {
                setLog("正在配对设备……")
                try {
                    val result = withContext(Dispatchers.IO) {
                        CloudClient.pair(cloudUrl, code, Build.MODEL)
                    }
                    Prefs.cloudUrl = cloudUrl
                    Prefs.deviceId = result.deviceId
                    Prefs.deviceToken = result.deviceToken
                    setLog("配对成功：${result.deviceId}")
                    updateStatus()
                } catch (error: Exception) {
                    setLog("配对失败：" + (error.message ?: "未知错误"))
                }
            }
        }

        loginButton.setOnClickListener {
            startActivity(Intent(this, WeiboLoginActivity::class.java))
        }

        startServiceButton.setOnClickListener {
            if (!Prefs.paired) {
                toast("请先配对设备")
                return@setOnClickListener
            }
            val intent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_START
            }
            ContextCompat.startForegroundService(this, intent)
            toast("后台服务已启动")
            updateStatus()
        }

        stopServiceButton.setOnClickListener {
            stopService(Intent(this, AgentService::class.java))
            toast("后台服务已停止")
            updateStatus()
        }

        batteryButton.setOnClickListener {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        runNowButton.setOnClickListener {
            if (!Prefs.weiboLoggedIn) {
                toast("请先扫码登录微博")
                return@setOnClickListener
            }
            scope.launch {
                setLog("开始本机签到……")
                try {
                    val outcome = withContext(Dispatchers.IO) { WeiboClient.runCheckin() }
                    setLog(
                        "状态：${outcome.status}\n风险：${outcome.riskScore}\n结果：${outcome.summary}"
                    )
                } catch (error: Exception) {
                    setLog("签到失败：" + (error.message ?: "未知错误"))
                }
            }
        }

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        Prefs.init(this)
        updateStatus()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun updateStatus() {
        findViewById<TextView>(R.id.deviceStatus).text =
            if (Prefs.paired) "设备已配对：${Prefs.deviceId}" else "设备未配对"
        findViewById<TextView>(R.id.weiboStatus).text =
            if (Prefs.weiboLoggedIn) "微博已登录，可在本机执行签到" else "微博未登录"
        findViewById<TextView>(R.id.serviceStatus).text = "后台服务启动后，每 30 秒等待云端任务"
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    private fun setLog(text: String) {
        findViewById<TextView>(R.id.logText).text = text
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}
