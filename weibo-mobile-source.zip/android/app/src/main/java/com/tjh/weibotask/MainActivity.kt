package com.tjh.weibotask

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.PowerManager
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.DatePicker
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val handler = Handler(Looper.getMainLooper())

    /** 账号 id -> 该行视图。列表结构变化时重建，状态变化时只改文字。 */
    private val rowViews = mutableMapOf<String, View>()

    private val refreshRunnable = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        AccountStore.init(this)
        AccountStore.ensureAtLeastOne()
        setContentView(R.layout.activity_main)

        val datePicker = findViewById<DatePicker>(R.id.datePicker)
        val timePicker = findViewById<TimePicker>(R.id.timePicker)
        timePicker.setIs24HourView(true)

        datePicker.minDate = System.currentTimeMillis() - 1000L
        val startCalendar = Calendar.getInstance()
        if (Prefs.startDate.isNotBlank()) {
            try { startCalendar.time = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).parse(Prefs.startDate) ?: Date() } catch (_: Exception) {}
        }
        datePicker.updateDate(
            startCalendar.get(Calendar.YEAR),
            startCalendar.get(Calendar.MONTH),
            startCalendar.get(Calendar.DAY_OF_MONTH)
        )

        timePicker.hour = Prefs.baseHour
        timePicker.minute = Prefs.baseMinute

        requestNotificationPermission()

        findViewById<Button>(R.id.addAccountButton).setOnClickListener {
            // 先建一个空账号槽位，再带它的 id 去登录页，
            // 登录成功后 Cookie 会精确写回这个槽位，不会覆盖其它账号
            val account = AccountStore.add()
            renderAccounts()
            updateStatus()
            openLogin(account)
        }

        findViewById<Button>(R.id.checkLoginButton).setOnClickListener {
            checkAllLogins()
        }

        // ★ 「去微博完成验证」：微博判定「你最近的行为存在异常」时会拦下所有请求，
        //   这时唯一的出路是**人工**完成一次验证 —— 程序怎么重试都没用。
        //   而验证必须带着**同一个会话**做（换会话等于白做），
        //   所以这里在应用内用 WebView 打开微博，用户验证完 Cookie 会自动存回。
        findViewById<Button>(R.id.verifyButton).setOnClickListener {
            val accounts = AccountStore.all().filter { it.cookie.isNotBlank() }
            if (accounts.isEmpty()) {
                toast("还没有登录任何微博账号")
                return@setOnClickListener
            }
            if (accounts.size == 1) {
                openVerify(accounts[0])
                return@setOnClickListener
            }
            val labels = accounts.map { it.label }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("要验证哪个账号？")
                .setItems(labels) { _, which -> openVerify(accounts[which]) }
                .setNegativeButton("取消", null)
                .show()
        }

        findViewById<Button>(R.id.saveScheduleButton).setOnClickListener {
            Prefs.startDate = String.format(
                Locale.CHINA,
                "%04d-%02d-%02d",
                datePicker.year,
                datePicker.month + 1,
                datePicker.dayOfMonth
            )
            Prefs.skipDate = ""
            Prefs.baseHour = timePicker.hour
            Prefs.baseMinute = timePicker.minute
            Prefs.scheduleEnabled = true
            // 用户手动重新开启时，清掉风控暂停状态，否则会被顺延到暂停结束时间
            Prefs.pausedUntil = 0L
            requestExactAlarmPermissionIfNeeded()
            LocalScheduler.scheduleNext(this)
            val serviceIntent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_START_SCHEDULED
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            updateStatus()

            // ★ 关键提示：如果用户选的时间点**今天已经过了**，程序会把它顺延到明天。
            //   旧实现只 toast 一句「自动签到已开启」，用户会以为今天到点就会跑，
            //   结果等到超时也没动静 —— 这就是「设置时间自动签到过了 30 分钟都没签」的常见来源。
            val picked = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, timePicker.hour)
                set(Calendar.MINUTE, timePicker.minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val todayPassed = !picked.after(Calendar.getInstance())
            val nextText = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(Prefs.nextRunAt))
            toast(
                if (todayPassed) {
                    "已保存。今天 " + String.format(Locale.CHINA, "%02d:%02d", timePicker.hour, timePicker.minute) +
                        " 已经过了，安排在 " + nextText
                } else {
                    "自动签到已开启，下次执行：" + nextText
                }
            )
        }

        findViewById<Button>(R.id.skipTodayButton).setOnClickListener {
            if (!Prefs.scheduleEnabled) {
                toast("请先开启自动签到")
                return@setOnClickListener
            }
            LocalScheduler.skipToday(this)
            val serviceIntent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_START_SCHEDULED
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            updateStatus()
            toast("今天不签到，已安排到下一天")
        }

        findViewById<Button>(R.id.disableScheduleButton).setOnClickListener {
            Prefs.scheduleEnabled = false
            Prefs.pausedUntil = 0L
            LocalScheduler.cancel(this)
            stopService(Intent(this, AgentService::class.java))
            updateStatus()
            toast("自动签到已关闭")
        }

        findViewById<Button>(R.id.compatibilityButton).setOnClickListener {
            DeviceCompatibility.showGuide(this)
        }

        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        findViewById<Button>(R.id.runNowButton).setOnClickListener {
            val ready = AccountStore.ready()
            if (ready.isEmpty()) {
                findViewById<TextView>(R.id.logText).text = "没有可用的微博账号，请先登录"
                toast("请先添加并登录微博账号")
                return@setOnClickListener
            }
            Prefs.lastRunAt = System.currentTimeMillis()
            // ★ 手动点击 = 明确要求「现在就签」，所以带上 EXTRA_RUN_ALL 跳过分批。
            //   自动定时签到才分批错峰（账号多时避免同一 IP 上打出密集请求）。
            Prefs.lastRunMessage =
                "已启动签到任务（共 " + ready.size + " 个账号），正在执行……"
            findViewById<TextView>(R.id.logText).text = Prefs.lastRunMessage
            val intent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_RUN_CHECKIN
                putExtra(AgentService.EXTRA_RUN_ALL, true)
            }
            ContextCompat.startForegroundService(this, intent)
            toast("已开始立即签到")
        }

        renderAccounts()
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        Prefs.init(this)
        AccountStore.init(this)
        if (Prefs.scheduleEnabled) {
            LocalScheduler.ensureScheduled(this)
            val serviceIntent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_START_SCHEDULED
            }
            ContextCompat.startForegroundService(this, serviceIntent)
        }
        // 从登录页返回时账号状态会变，重建一次行视图
        renderAccounts()
        updateStatus()
        // 有账号超过 12 小时没检查过登录态，就顺手查一遍
        val stale = AccountStore.all().any {
            it.cookie.isNotBlank() &&
                System.currentTimeMillis() - it.lastCheckAt > 12L * 60L * 60L * 1000L
        }
        if (stale) checkAllLogins()
        handler.removeCallbacks(refreshRunnable)
        handler.post(refreshRunnable)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshRunnable)
        super.onPause()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun updateStatus() {
        val accounts = AccountStore.all()
        val readyCount = accounts.count { it.enabled && it.loggedIn }
        findViewById<TextView>(R.id.weiboStatus).text = when {
            accounts.isEmpty() -> "还没有添加微博账号"
            readyCount == 0 -> "共 " + accounts.size + " 个账号，暂时没有可签到的（未登录或已停用）"
            else -> "共 " + accounts.size + " 个账号，" + readyCount + " 个可签到"
        }

        val checkLines = mutableListOf<String>()
        for (account in accounts) {
            if (account.cookie.isBlank()) continue
            val time = if (account.lastCheckAt > 0L) {
                SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(account.lastCheckAt)) + " "
            } else {
                ""
            }
            val expiry = if (account.expiryAt > 0L) {
                "（会话到期 " + SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(account.expiryAt)) + "）"
            } else {
                ""
            }
            checkLines.add(
                account.label + "：" + time + account.lastCheckMessage.ifBlank { "尚未检查" } + expiry
            )
        }
        findViewById<TextView>(R.id.loginCheckStatus).text =
            if (checkLines.isEmpty()) "尚未检查登录状态" else checkLines.joinToString("\n")

        refreshAccountRows()

        val exactAllowed = LocalScheduler.exactAlarmAllowed(this)
        val power = getSystemService(PowerManager::class.java)
        val batteryAllowed = power.isIgnoringBatteryOptimizations(packageName)

        val scheduleText = StringBuilder()
        if (Prefs.scheduleEnabled) {
            scheduleText.append(LocalScheduler.formatNextRun(this))

            // ★ 分批错峰的进度。
            //   账号多起来之后（10 个以上），一轮只跑 3 个，剩下的 20 分钟后继续。
            //   如果界面只显示「上次结果：成功」，用户会以为今天只签了 3 个号、其余被漏掉了 ——
            //   所以这里必须把「今天已经轮到几个 / 一共几个」直接写出来。
            val readyCount = AccountStore.ready().size
            if (readyCount > 0) {
                val doneToday = AccountStore.doneToday(LocalScheduler.todayString())
                scheduleText.append("\n今日进度：").append(doneToday).append(" / ").append(readyCount).append(" 个账号")
                scheduleText.append(
                    if (doneToday >= readyCount) "（今天已全部轮到）"
                    else "（分批错峰执行中，剩下的会自动继续）"
                )
            }

            // ★ 微博要求验证身份 —— 这是**需要用户动手**的状态，必须醒目地说清「去点哪里」。
            //   光显示「需要处理」用户不知道该干什么，只能干等。
            if (Prefs.needsVerify) {
                scheduleText.append("\n⚠ 微博提示「你最近的行为存在异常」，需要验证身份。")
                    .append("请点上方「去微博完成验证」，在页面里验证通过后返回，")
                    .append("本应用会自动继续签到。")
            }

            // ★ 到点了却没执行 —— 必须让用户**看见**。
            //   旧实现遇到这种情况只是悄悄把任务顺延到明天，用户唯一的感受就是
            //   「设了时间却没签」，而且永远不知道是闹钟没响还是被系统拦了。
            //   现在只要超过设定时间 10 分钟还没动静，就直接写在这里。
            val overdueMs = System.currentTimeMillis() - Prefs.nextRunAt
            if (Prefs.nextRunAt > 0L && overdueMs > 10 * 60 * 1000L) {
                scheduleText.append("\n⚠ 已超过设定时间 ").append(overdueMs / 60000L)
                    .append(" 分钟仍未执行，请点下方「全安卓后台兼容设置」把本应用加入白名单")
            }

            // ★ 后台服务心跳 —— 「到点会不会执行」的分水岭。
            //   服务活着：维护循环自己会发现到点并执行，**完全不依赖闹钟**；
            //   服务死了：只能靠闹钟，而闹钟在国产 ROM 的省电策略下很容易被丢弃。
            //   这一行让用户第一次能直接看出「是服务死了，还是闹钟没响」。
            val serviceAlive = System.currentTimeMillis() - Prefs.serviceAliveAt < 20 * 60 * 1000L
            scheduleText.append("\n后台服务：")
            if (serviceAlive) {
                scheduleText.append("运行中（到点会自动执行，不依赖闹钟）")
            } else if (Prefs.serviceAliveAt > 0L) {
                scheduleText.append("已停止（最近心跳 ")
                    .append(SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(Prefs.serviceAliveAt)))
                    .append("）—— 请点下方「全安卓后台兼容设置」")
            } else {
                scheduleText.append("未启动 —— 请点下方「全安卓后台兼容设置」")
            }

            // ★ 闹钟心跳：这是区分「闹钟没响」和「闹钟响了但服务起不来」的唯一依据。
            //   如果这一行的时间停在很久以前，说明系统根本没把闹钟送到本应用 ——
            //   那再怎么调代码都没用，只能去做后台白名单设置。
            if (Prefs.lastAlarmAt > 0L) {
                scheduleText.append("\n闹钟最近触发：")
                    .append(SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(Prefs.lastAlarmAt)))
            } else {
                scheduleText.append("\n闹钟最近触发：尚未触发过")
            }
            if (Prefs.pausedUntil > System.currentTimeMillis()) {
                // ★ 暂停的原因不止「风控」一种：验证码、登录失效也会限时暂停。
                //   旧实现一律写「风控暂停中」，用户看到这句就会以为是微博限流，
                //   而那次其实是因为有账号没登录 —— 判断方向完全被带偏。
                val pauseReason = when (Prefs.lastRunStatus) {
                    "USER_REQUIRED" -> "需要人工处理（验证身份或重新登录），暂停中，"
                    "PAUSED" -> "风控暂停中，"
                    else -> "暂停中，"
                }
                scheduleText.append("\n状态：").append(pauseReason)
                    .append(SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(Prefs.pausedUntil)))
                    .append(" 后自动重试")
            }
            scheduleText.append("\n上次结果：").append(runStatusLabel(Prefs.lastRunStatus))
            if (Prefs.lastRunMessage.isNotBlank()) {
                scheduleText.append("\n上次信息：").append(Prefs.lastRunMessage)
            }
        } else {
            scheduleText.append("自动签到未开启")
        }
        scheduleText.append("\n精确闹钟：")
            .append(if (exactAllowed) "已允许" else "未允许（定时会被系统延迟甚至拦截）")
        scheduleText.append("\n电池优化：")
            .append(if (batteryAllowed) "已关闭" else "未关闭（后台可能被冻结）")
        if (!exactAllowed || !batteryAllowed) {
            scheduleText.append("\n⚠ 请点下方「全安卓后台兼容设置」完成配置，否则定时任务可能不执行")
        }
        findViewById<TextView>(R.id.scheduleStatus).text = scheduleText.toString()

        // 区分「正在执行」和「上次执行」：
        // 旧实现整轮都显示上一轮的结果，签到跑起来后界面毫无变化，像是没反应。
        // 这里再加一层时间兜底 —— 万一进程被杀，「正在执行」标记不会永远挂着。
        // ★ 兜底时长要跟单轮最大耗时匹配：每个账号最多 10 分钟（按待签数量动态给），
        //   5 个账号就可能跑很久，所以放宽到 60 分钟，否则跑到一半界面会误判成「已结束」。
        val runningNow = Prefs.running &&
            System.currentTimeMillis() - Prefs.lastRunAt < 60 * 60 * 1000L
        val lastText = when {
            runningNow -> "正在执行…\n" + Prefs.lastRunMessage.ifBlank { "正在执行微博签到" }
            Prefs.lastRunAt > 0L -> {
                val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date(Prefs.lastRunAt))
                "上次执行：" + time + "\n" + Prefs.lastRunMessage.ifBlank { "无结果" }
            }
            else -> "等待操作"
        }
        findViewById<TextView>(R.id.logText).text = lastText
    }

    /**
     * 把内部状态码翻成中文。
     *
     * ★ 之前这里是直接把 Prefs.lastRunStatus 原样打到界面上，
     *   于是用户会看到「USER_REQUIRED」「PARTIAL」这种词 —— 对自用工具来说毫无意义。
     *   特别是 PARTIAL：它表示「有超话没签完」，绝不能让用户误以为全签上了。
     */
    private fun runStatusLabel(status: String): String {
        return when (status) {
            "" -> "暂无"
            "SUCCESS" -> "成功"
            "PARTIAL" -> "部分完成（有超话没签完，会自动补签）"
            "PAUSED" -> "被风控暂停，稍后自动重试"
            "USER_REQUIRED" -> "需要处理（账号未登录，或需要点「去微博完成验证」）"
            // ★ 这是「闹钟响了但系统不让后台启动服务」—— 必须给用户一个可执行的下一步，
            //   旧实现直接把 "BLOCKED" 这个内部状态码打到界面上，用户完全看不懂。
            "BLOCKED" -> "被系统拦截（后台启动被拒绝，请允许自启动并关闭电池优化）"
            "FAILED" -> "执行出错"
            "RETRY" -> "网络异常，稍后重试"
            else -> status
        }
    }

    /**
     * 逐个检查所有账号的登录态。
     *
     * ★ 与旧版的区别：某个账号掉线**不再关闭整个自动签到**。
     *   多账号场景下，一个号掉线不该拖累其它号继续签到。
     */
    private fun checkAllLogins() {
        val accounts = AccountStore.all()
        if (accounts.isEmpty()) {
            findViewById<TextView>(R.id.logText).text = "还没有添加微博账号"
            return
        }
        scope.launch {
            findViewById<TextView>(R.id.logText).text =
                "正在检查 " + accounts.size + " 个账号的登录状态……"
            val lines = mutableListOf<String>()
            for (account in accounts) {
                val result = withContext(Dispatchers.IO) {
                    try {
                        val config = WeiboClient.fetchConfig(account)
                        when {
                            !config.has("login") -> LoginCheck.UNKNOWN
                            config.optBoolean("login") -> LoginCheck.OK
                            else -> LoginCheck.EXPIRED
                        }
                    } catch (_: Exception) {
                        // 网络异常 / 超时 / 无网，都归为「未知」，不能据此判定掉线
                        LoginCheck.UNKNOWN
                    }
                }
                account.lastCheckAt = System.currentTimeMillis()
                when (result) {
                    LoginCheck.OK -> {
                        account.verified = true
                        account.lastCheckMessage = "登录正常"
                    }
                    LoginCheck.EXPIRED -> {
                        account.verified = false
                        account.lastCheckMessage = "登录已失效，需要重新登录"
                    }
                    LoginCheck.UNKNOWN -> {
                        // 旧实现在这里把 scheduleEnabled 置 false 并取消闹钟，
                        // 导致一次网络抖动就会让自动签到永久停摆，且用户毫无感知。
                        account.lastCheckMessage = "检查未完成（网络异常）"
                    }
                }
                lines.add(account.label + "：" + account.lastCheckMessage)
            }
            AccountStore.save()
            findViewById<TextView>(R.id.logText).text = lines.joinToString("\n")
            renderAccounts()
            updateStatus()
        }
    }

    /** 账号列表结构变化（增删/启停/登录返回）时重建所有行 */
    private fun renderAccounts() {
        val container = findViewById<LinearLayout>(R.id.accountList)
        container.removeAllViews()
        rowViews.clear()

        val accounts = AccountStore.all()
        if (accounts.isEmpty()) {
            val empty = TextView(this)
            empty.text = "还没有账号，点下面「添加微博账号」"
            empty.setTextColor(Color.parseColor("#667085"))
            empty.textSize = 13f
            container.addView(empty)
            return
        }

        val inflater = LayoutInflater.from(this)
        for (account in accounts) {
            val row = inflater.inflate(R.layout.item_account, container, false)
            rowViews[account.id] = row

            row.findViewById<Button>(R.id.accountLoginButton).setOnClickListener {
                openLogin(account)
            }
            row.findViewById<Button>(R.id.accountToggleButton).setOnClickListener {
                account.enabled = !account.enabled
                AccountStore.save()
                refreshAccountRows()
                updateStatus()
                toast(account.label + (if (account.enabled) " 已启用" else " 已停用"))
            }
            row.findViewById<Button>(R.id.accountRemoveButton).setOnClickListener {
                confirmRemove(account)
            }
            container.addView(row)
        }
        refreshAccountRows()
    }

    /** 只刷新已有行的文字，不重建视图（每 2 秒调一次，重建会打断滚动和点击） */
    private fun refreshAccountRows() {
        for (account in AccountStore.all()) {
            val row = rowViews[account.id] ?: continue

            row.findViewById<TextView>(R.id.accountName).text = account.label

            val state = row.findViewById<TextView>(R.id.accountState)
            when {
                !account.enabled -> {
                    state.text = "已停用"
                    state.setTextColor(Color.parseColor("#667085"))
                }
                account.loggedIn -> {
                    state.text = "已登录"
                    state.setTextColor(Color.parseColor("#067647"))
                }
                account.cookie.isNotBlank() -> {
                    state.text = "登录已失效"
                    state.setTextColor(Color.parseColor("#B54708"))
                }
                else -> {
                    state.text = "未登录"
                    state.setTextColor(Color.parseColor("#B54708"))
                }
            }

            val summary = account.lastRunMessage.lineSequence().firstOrNull().orEmpty()
            row.findViewById<TextView>(R.id.accountInfo).text = when {
                summary.isNotBlank() -> summary
                account.cookie.isBlank() -> "尚未登录"
                else -> "尚未签到"
            }

            row.findViewById<Button>(R.id.accountLoginButton).text =
                if (account.loggedIn) "重新登录" else "登录"
            row.findViewById<Button>(R.id.accountToggleButton).text =
                if (account.enabled) "停用" else "启用"
        }
    }

    private fun openLogin(account: WeiboAccount) {
        startActivity(
            Intent(this, WeiboLoginActivity::class.java)
                .putExtra(WeiboLoginActivity.EXTRA_ACCOUNT_ID, account.id)
        )
    }

    /**
     * 打开「微博身份验证」。
     *
     * 与 [openLogin] 的区别：**不清 Cookie**。
     * 微博的「行为异常」验证是按账号 + 会话记的，换一个未登录的会话去验证，
     * 验证的是那个空会话，本应用手里的 Cookie 依然是异常状态 —— 白做一次。
     */
    private fun openVerify(account: WeiboAccount) {
        startActivity(
            Intent(this, WeiboLoginActivity::class.java)
                .putExtra(WeiboLoginActivity.EXTRA_ACCOUNT_ID, account.id)
                .putExtra(WeiboLoginActivity.EXTRA_VERIFY_MODE, true)
        )
        toast("请在页面里完成验证，通过后返回即可")
    }

    private fun confirmRemove(account: WeiboAccount) {
        AlertDialog.Builder(this)
            .setTitle("删除「" + account.label + "」？")
            .setMessage("会同时删除该账号的登录信息，之后需要重新扫码。其它账号不受影响。")
            .setNegativeButton("取消", null)
            .setPositiveButton("删除") { _, _ ->
                AccountStore.remove(account.id)
                renderAccounts()
                updateStatus()
                toast("已删除 " + account.label)
            }
            .show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    private fun requestExactAlarmPermissionIfNeeded() {
        DeviceCompatibility.openExactAlarmSettings(this)
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}

/** 登录检查结果：必须区分「确实掉线」和「这次没查成」 */
private enum class LoginCheck { OK, EXPIRED, UNKNOWN }
