package com.tjh.weibotask

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private val refreshRunnable = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContentView(R.layout.activity_main)

        val timePicker = findViewById<TimePicker>(R.id.timePicker)
        timePicker.setIs24HourView(true)

        timePicker.hour = Prefs.baseHour
        timePicker.minute = Prefs.baseMinute

        requestNotificationPermission()

        findViewById<Button>(R.id.weiboLoginButton).setOnClickListener {
            startActivity(Intent(this, WeiboLoginActivity::class.java))
        }

        findViewById<Button>(R.id.saveScheduleButton).setOnClickListener {
            Prefs.baseHour = timePicker.hour
            Prefs.baseMinute = timePicker.minute
            Prefs.scheduleEnabled = true
            requestExactAlarmPermissionIfNeeded()
            LocalScheduler.scheduleNext(this)
            updateStatus()
            toast("自动签到已开启")
        }

        findViewById<Button>(R.id.disableScheduleButton).setOnClickListener {
            Prefs.scheduleEnabled = false
            LocalScheduler.cancel(this)
            updateStatus()
            toast("自动签到已关闭")
        }

        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        findViewById<Button>(R.id.runNowButton).setOnClickListener {
            if (!Prefs.weiboLoggedIn) {
                findViewById<TextView>(R.id.logText).text = "请先完成微博登录"
                toast("请先扫码登录微博")
                return@setOnClickListener
            }
            Prefs.lastRunAt = System.currentTimeMillis()
            Prefs.lastRunMessage = "已启动签到任务，正在执行……"
            findViewById<TextView>(R.id.logText).text = Prefs.lastRunMessage
            val intent = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_RUN_CHECKIN
            }
            ContextCompat.startForegroundService(this, intent)
            toast("已开始立即签到")
        }

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        Prefs.init(this)
        updateStatus()
        handler.removeCallbacks(refreshRunnable)
        handler.post(refreshRunnable)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshRunnable)
        super.onPause()
    }

    private fun updateStatus() {
        findViewById<TextView>(R.id.weiboStatus).text =
            if (Prefs.weiboLoggedIn) "微博已登录" else "微博未登录，请先扫码"

        val scheduleText = if (Prefs.scheduleEnabled) {
            LocalScheduler.formatNextRun(this) + "\n上次结果：" +
                (Prefs.lastRunStatus.ifBlank { "暂无" })
        } else {
            "自动签到未开启"
        }
        findViewById<TextView>(R.id.scheduleStatus).text = scheduleText

        val lastText = if (Prefs.lastRunAt > 0L) {
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date(Prefs.lastRunAt))
            "上次执行：" + time + "\n" + Prefs.lastRunMessage.ifBlank { "无结果" }
        } else {
            "等待操作"
        }
        findViewById<TextView>(R.id.logText).text = lastText
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    private fun requestExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = getSystemService(AlarmManager::class.java)
            if (!alarmManager.canScheduleExactAlarms()) {
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}
