package com.tjh.weibotask

import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * 微博登录页。
 *
 * ★ 多账号下最容易踩的坑在这里：
 *   WebView 的 Cookie 存储是**整个应用共享**的，不区分账号。
 *   如果不清空就直接打开登录页，第二个账号会看到第一个账号的登录态，
 *   于是「登录」瞬间完成，而保存下来的其实是第一个账号的 Cookie ——
 *   结果是两个槽位装着同一个账号，用户会以为多账号根本没生效。
 *
 *   所以每次进来都先 removeAllCookies，强制重新扫码/输密码。
 */
class WeiboLoginActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var lastSaveAt = 0L

    /** 已经判定登录成功、开始收尾了 —— 之后的页面回调一律忽略，避免重复 finish / 多线程竞争 */
    private var finished = false

    /** 是否验证模式（验证模式验证通过后要进入静置期） */
    private var verifyMode = false

    /** 易盾滑块自动处理 */
    private var autoSlider: YidunAutoSlider? = null

    /** 是否已经看到过验证码页（用于判断验证成功后跳回微博） */
    private var captchaSeen = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        AccountStore.init(this)
        // 接上上次的黑匣子记录：进程重启也能看到上一轮的验证过程
        SliderTrace.init(this)
        setContentView(R.layout.activity_weibo_login)
        webView = findViewById(R.id.webView)

        val accountId = intent.getStringExtra(EXTRA_ACCOUNT_ID).orEmpty()
        val account = AccountStore.find(accountId) ?: AccountStore.ensureAtLeastOne()

        // ★ 两种模式共用这个界面：
        //   登录模式（默认）：清空 Cookie → 打开登录页 → 用户重新登录
        //   验证模式：**保留** Cookie → 直接打开微博 → 用户完成「请先验证身份」
        verifyMode = intent.getBooleanExtra(EXTRA_VERIFY_MODE, false)

        // ★★★ 第 13 期：自动签到那一轮，同一时刻有**三条**拉起路径会同时开火
        //   （全屏通知 / 无障碍 / 悬浮窗）。第 12 期的轨迹里，页面被创建之后
        //   6 毫秒就 onPause、随后被销毁，而窗口焦点一次都没拿到 —— 但当时
        //   **分不清是哪条路把它拉起来的**，也就分不清是不是被重复拉起顶掉的。
        //   记下来源 + 标志位 + 任务号。只留痕，不参与任何判定。
        if (verifyMode) {
            SliderTrace.log(
                "[来源] " + intent.getStringExtra(EXTRA_LAUNCH_SOURCE).orEmpty().ifBlank { "(未标注)" } +
                    " flags=0x" + Integer.toHexString(intent.flags) +
                    " 任务号=" + taskId
            )
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            // 验证模式用电脑版 UA：手机版网页没有签到按钮，触发不了滑块
            userAgentString = if (verifyMode) {
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
            } else {
                "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (verifyMode && url != null) {
                    // ★ 每个跳转都留一条：验证页究竟落在哪个域名，是排查
                    //   「滑块明明拖过去了却不认账」的第一现场 ——
                    //   因为下面的成功判定完全建立在 captchaSeen 上。
                    SliderTrace.log("[页面开始] " + url + "  captchaSeen=" + captchaSeen)
                    if (url.contains("security.weibo.com")) {
                        captchaSeen = true
                        SliderTrace.log("[验证页] 命中 security.weibo.com → captchaSeen=true")
                    } else if (captchaSeen &&
                        (url.startsWith("https://weibo.com") || url.startsWith("https://m.weibo.cn"))
                    ) {
                        // 从验证页跳回微博 = 验证成功，停止加载避免重页面把内核拖崩
                        SliderTrace.log("[验证成功] 已从验证页跳回微博，开始收尾")
                        webView.stopLoading()
                        onVerifySuccess(account)
                        return
                    }
                }
                autoSlider?.onPageStarted()
            }

            // ★ 微博完成验证后会跳转到各种地址（含微博 App 的深链 scheme）。
            //   非 http/https 的跳转 WebView 处理不了、会直接闪退 —— 必须拦下。
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    false
                } else {
                    true
                }
            }

            // ★ 主文档加载失败是「验证页打不开 / 白屏」的直接原因，
            //   而它原来没有任何出口。只记主框架，子资源失败不算数。
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    SliderTrace.log(
                        "[加载失败] code=" + error?.errorCode + " " + error?.description +
                            " " + request.url
                    )
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                Dbg.log("YidunFlow", "onPageFinished: $url")
                SliderTrace.log("[页面完成] " + url)
                autoSlider?.onPageFinished()
                trySaveCookies(account)
            }
        }

        if (verifyMode) {
            // ★ 验证模式**绝不能清 Cookie**。
            //   微博的「行为异常」验证是**按账号 + 会话**记的：换一个未登录的会话去验证，
            //   验证的是那个空会话，本应用手里的 Cookie 依然是「异常」状态 —— 白做。
            //   所以先把这个账号自己的 Cookie 灌进 WebView，让它带着**同一个会话**打开微博。
            injectCookies(account)
            CookieManager.getInstance().flush()

            // ★★★ 「验证页到底有没有真的显示出来」—— 这是手动能成、自动失败的关键分界。
            //   自动签到由闹钟触发，手机多半息屏 / 锁屏，而这个 Activity 在清单里
            //   没有 showWhenLocked / turnScreenOn，于是它可能**被创建了却不可见**。
            //   而 jsDrag 的分步拖动靠页面内 setTimeout，Chromium 对不可见的 WebView
            //   会把 setTimeout 限流到 1 次/秒甚至挂起 —— 分步 pointermove 发不出去，
            //   滑块看起来「没动」，易盾就判失败。
            //   手动「立即签到」时屏幕亮着、App 在前台，所以能成。
            //   不记这一行，这两种情况在报告里完全分不开。
            val env = describeEnvironment()
            SliderTrace.log("[环境] " + env)
            // ★ 除了写进环形缓冲，还累加一个**挤不掉**的计数：
            //   报告里那句「验证页累计 N 次」就是它。这是唯一能区分
            //   「验证页出现过、记录被日志挤掉了」和「验证页压根没出现过」的东西。
            SliderTrace.markVerifySession(env)

            // ★★★ 让本页能在锁屏之上显示、并点亮屏幕 —— 这是「后台自动拉起验证页」
            //   能真正跑通的**必要条件**（用户 2026-09-27 确认：失败那几次手机都是
            //   息屏 + 锁屏；而手动「立即签到」时屏幕亮着、已解锁，一直是好的）。
            //   没有这两项，验证页会被拉起却**显示不出来**，页面内的 setTimeout 被
            //   限流，jsDrag 的分步拖动就发不出去 —— 现象正是「滑块没动」。
            //   ★ 只对验证模式生效：登录模式是用户自己打开的页面，不该抢占锁屏。
            applyVerifyWindowFlags()

            // 易盾滑块自动识别 + 拖动（自用工具）
            autoSlider = YidunAutoSlider(webView) { msg ->
                // ★ 只多记一行：这条回调原本只弹一个 Toast（一两秒就没了），
                //   滑块链路的所有进度和失败点都是从这里丢掉的。
                SliderTrace.log("[滑块] " + msg)
                runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
            }
            autoSlider?.start()

            // 电脑版超话签到页：自动点签到才会触发滑块。
            // 不能写死一个超话 —— 账号没关注它就没有签到按钮；
            // 所以后台取该账号关注的第一超话，用它触发。
            Thread {
                // ★ 第 13 期：这一步是一次**网络往返**（取该账号关注的第一个超话），
                //   而验证页要等它回来才开始加载。记下耗时，才能判断
                //   「页面一直没打开」是网络慢，还是页面根本没活到那一刻。
                val fetchStartedAt = System.currentTimeMillis()
                val url = try {
                    val containerId = kotlinx.coroutines.runBlocking {
                        WeiboClient.fetchFirstTopicContainerId(account)
                    }
                    if (containerId.isNotBlank()) "https://weibo.com/p/" + containerId else VERIFY_CHECKIN_URL
                } catch (_: Exception) {
                    VERIFY_CHECKIN_URL
                }
                SliderTrace.log(
                    "[打开] 取超话用时 " + (System.currentTimeMillis() - fetchStartedAt) + "ms"
                )
                runOnUiThread {
                    if (!finished) {
                        SliderTrace.log("[打开] " + url)
                        webView.loadUrl(url)
                    } else {
                        // ★ 这一行原来完全静默，而它正是
                        //   「验证页被创建了、却一页都没打开」的唯一痕迹。
                        SliderTrace.log("[打开] 跳过：页面已结束（finished=true）")
                    }
                }
            }.start()

            Toast.makeText(
                this,
                getString(R.string.login_verify_hint),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val loginUrl = "https://passport.weibo.com/sso/signin?entry=wapsso&source=wapssowb&url=" +
            java.net.URLEncoder.encode("https://m.weibo.cn/", "UTF-8")

        // 先清空 WebView 里的旧 Cookie，再打开登录页
        val cookieManager = CookieManager.getInstance()
        var opened = false
        val openLoginPage = {
            if (!opened) {
                opened = true
                webView.loadUrl(loginUrl)
            }
        }
        cookieManager.removeAllCookies {
            cookieManager.flush()
            runOnUiThread { openLoginPage() }
        }
        // 兜底：个别机型上 removeAllCookies 的回调不触发，别让页面一直白屏
        webView.postDelayed({ openLoginPage() }, 1200)
    }

    /**
     * 把这个账号已经保存的 Cookie 灌进 WebView 的 CookieManager。
     *
     * WebView 的 Cookie 存储是整个应用共享的、和 Prefs 里存的那份**互不相通**，
     * 所以验证模式下必须显式灌一次，否则 WebView 打开的是一个全新的未登录会话。
     */
    private fun injectCookies(account: WeiboAccount) {
        val manager = CookieManager.getInstance()
        // m.weibo.cn 用手机 cookie
        injectCookieParts(manager, account.cookie, "https://m.weibo.cn", ".weibo.cn")
        // weibo.com 优先用 PC cookie（含 XSRF-TOKEN，电脑版签到/验证需要），没有再用手机 cookie
        val pc = account.pcCookie.ifBlank { account.cookie }
        injectCookieParts(manager, pc, "https://weibo.com", ".weibo.com")
    }

    private fun injectCookieParts(manager: CookieManager, cookieText: String, url: String, domain: String) {
        for (part in cookieText.split(";")) {
            val item = part.trim()
            val index = item.indexOf('=')
            if (index <= 0) continue
            val name = item.substring(0, index).trim()
            val value = item.substring(index + 1).trim()
            if (name.isBlank() || value.isEmpty()) continue
            manager.setCookie(url, "$name=$value; Domain=$domain; Path=/; Secure; SameSite=Lax")
        }
    }

    private fun trySaveCookies(account: WeiboAccount) {
        if (finished) {
            return
        }
        // 每加载一个页面都会回调一次，而验证过程会跳好几个页面。
        // 不节流的话会连开好几个线程去打微博接口，验证期间反而更密。
        val now = System.currentTimeMillis()
        if (now - lastSaveAt < 5000L) {
            return
        }
        lastSaveAt = now

        val cookieText = collectCookieHeader()
        if (!cookieText.contains("SUB=")) {
            return
        }

        val values = parseCookieValues(cookieText)
        for (name in listOf("SUB", "SUBP", "SSOLoginState", "ALF", "SRT", "SRF", "XSRF-TOKEN")) {
            val value = values[name] ?: continue
            CookieManager.getInstance().setCookie(
                "https://m.weibo.cn",
                "$name=$value; Domain=.weibo.cn; Path=/; Secure; SameSite=Lax"
            )
        }
        CookieManager.getInstance().flush()

        // 先写进这个账号的槽位，再验证 —— 验证时用的就是它自己的 Cookie
        account.cookie = cookieText
        account.pcCookie = collectPcCookieHeader()
        account.verified = false
        AccountStore.save()

        Thread {
            var loggedIn = false
            var nickname = ""
            try {
                val config = WeiboClient.fetchConfig(account)
                loggedIn = config.optBoolean("login")
                if (loggedIn) {
                    val user = config.optJSONObject("user")
                    nickname = user?.optString("screen_name").orEmpty()
                        .ifEmpty { user?.optString("name").orEmpty() }
                        .ifEmpty { config.optString("screen_name").orEmpty() }
                    // /api/config 有时不返回 user，用 uid 加 PC 端接口兜底取昵称
                    if (nickname.isBlank()) {
                        val uid = config.optString("uid").orEmpty()
                            .ifEmpty { config.optString("id").orEmpty() }
                            .ifEmpty { user?.optString("id").orEmpty() }
                        nickname = WeiboClient.fetchNickname(account, uid)
                    }
                }
            } catch (_: Exception) {
                loggedIn = false
            }
            AccountStore.save()

            runOnUiThread {
                if (finished || isFinishing || isDestroyed) return@runOnUiThread
                if (verifyMode) {
                    // 验证模式：不要自动关闭页面，让用户完成滑块验证后手动返回。
                    // 否则打开页面 1 秒就被 finish，验证码还没出来就“闪退”。
                    // ★ 这一条决定「后面的验证到底是在有效会话上做的，还是在空会话上白做」。
                    SliderTrace.log("[会话] Cookie 已采集，登录态=" + loggedIn + "（验证模式不自动关页）")
                    // ★★ 第 32 期：修「账号被判未登录」的死锁。
                    //   上面第 313~316 行是**无条件**先写 verified=false，而验证模式在这里直接
                    //   return ⇒ 真实校验结果 loggedIn 只被打印、从不写回账号。
                    //   后果：会话完全有效（loggedIn=true）的账号也会被永久标成「未登录」，
                    //   通知显示「所有账号都未登录」，只能等 12 小时后 checkAllLogins 兜底自救。
                    //   ★ 这里**只做升级、不做降级**：仅在程序自己刚确认会话有效时补写 verified=true。
                    //   needsVerify / restUntil / lastCheckMessage / lastCheckAt 与关页逻辑**一字不动**
                    //   （降级路径已由 WeiboClient.fetchConfig 内部负责）。
                    if (loggedIn) {
                        account.verified = true
                        AccountStore.save()
                    }
                    return@runOnUiThread
                }
                if (loggedIn) {
                    finished = true
                    account.verified = true
                    account.lastCheckAt = System.currentTimeMillis()
                    account.lastCheckMessage = getString(R.string.check_msg_login_ok)
                    // 换账号必须重置风控状态：新账号没被限流，不该继承上一个号的分数
                    account.riskScore = 0
                    account.consecutiveFailures = 0
                    // 登录成功 / 验证通过都清除「待验证」标记
                    account.needsVerify = false
                    // 全局「需要验证」提示跟随：还有别的号待验证就保留，否则清除
                    Prefs.needsVerify = AccountStore.needsVerifyAccounts().isNotEmpty()
                    // ★ 验证模式：刚过完「请先验证身份」，账号还在风控脆弱期，
                    //   设一个静置期，期间不参与任何自动任务，避免再次触发。
                    account.restUntil = if (verifyMode) {
                        System.currentTimeMillis() + Prefs.verifyCooldownHours * 3600_000L
                    } else {
                        0L
                    }
                    // ★ 昵称只当「附加标记」，账号名里的序号**不能**被覆盖掉。
                    //   序号是用户在列表和签到结果里辨认账号的唯一依据；
                    //   微博昵称重复、改名、含特殊字符都会让「哪个账号没签上」变得无法对号。
                    account.nickname = nickname
                    account.label = "账号 " + account.order + " · " + nickname
                    AccountStore.save()
                    if (verifyMode) {
                        Toast.makeText(
                            this,
                            getString(
                                R.string.login_verify_passed_rest,
                                account.displayName,
                                Prefs.verifyCooldownHours
                            ),
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Toast.makeText(
                            this,
                            getString(R.string.login_ok_nickname, nickname),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    finish()
                } else {
                    account.verified = false
                    account.cookie = ""
                    AccountStore.save()
                    Toast.makeText(this, getString(R.string.login_incomplete), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun collectCookieHeader(): String {
        val mobileRaw = CookieManager.getInstance().getCookie("https://m.weibo.cn").orEmpty()
        val mobileValues = parseCookieValues(mobileRaw)
        if (mobileValues.containsKey("SUB")) {
            return mobileValues.entries.joinToString("; ") { "${it.key}=${it.value}" }
        }

        val values = linkedMapOf<String, String>()
        values.putAll(mobileValues)
        for (url in listOf("https://weibo.com", "https://passport.weibo.com")) {
            val raw = CookieManager.getInstance().getCookie(url) ?: continue
            values.putAll(parseCookieValues(raw))
        }
        return values.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    /**
     * 采集 PC 端（weibo.com）cookie，供超话发帖用。
     *
     * ★ 发帖走 weibo.com/p/aj/proxy（PC 代理接口），必须用 .weibo.com 域的
     *   登录 cookie —— m.weibo.cn 那份不通用。登录经过 passport.weibo.com
     *   （它就在 weibo.com 域上），SSO 时会把 PC cookie 也种进 WebView，这里专门取出来。
     */
    private fun collectPcCookieHeader(): String {
        val values = linkedMapOf<String, String>()
        for (url in listOf("https://weibo.com", "https://passport.weibo.com")) {
            val raw = CookieManager.getInstance().getCookie(url).orEmpty()
            values.putAll(parseCookieValues(raw))
        }
        return values.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    private fun parseCookieValues(raw: String): Map<String, String> {
        val values = linkedMapOf<String, String>()
        for (part in raw.split(";")) {
            val item = part.trim()
            val index = item.indexOf('=')
            if (index <= 0) continue
            val name = item.substring(0, index).trim()
            val value = item.substring(index + 1).trim()
            if (value.isNotEmpty()) values[name] = value
        }
        return values
    }

    /**
     * 验证成功后更新账号状态并关闭页面。
     */
    private fun onVerifySuccess(account: WeiboAccount) {
        if (finished) return
        SliderTrace.log("[判定] 验证通过，账号进入静置期")
        finished = true
        // 取消验证全屏通知
        try {
            val nm = getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.cancel(1002)
        } catch (_: Throwable) {
        }
        account.verified = true
        account.needsVerify = false
        account.riskScore = 0
        account.consecutiveFailures = 0
        account.lastCheckAt = System.currentTimeMillis()
        account.lastCheckMessage = getString(R.string.check_msg_verify_ok)
        // 验证完进静置期，避免立刻又触发风控
        // ★★ 第 39 期：与 OverlayVerifyHost.onVerifySuccess **逐行一致**（静置时长可为 0）。
        val cooldownHours = Prefs.verifyCooldownHours
        account.restUntil = System.currentTimeMillis() + cooldownHours * 3600_000L
        // ★★★ 第 39 期：补上报告口径 —— 账号行信息栏读的是 `account.lastRunMessage`，
        //   只写 `lastCheckMessage` 的话，过完验证那一栏还挂着上一次风控的话术。
        //   （两处 onVerifySuccess 是同款缺口，一起补齐，保持两边逐行一致。）
        account.lastRunMessage = if (cooldownHours > 0) {
            getString(R.string.verify_passed_msg_rest, cooldownHours)
        } else {
            getString(R.string.verify_passed_msg_norest)
        }
        Prefs.lastRunStatus = "VERIFY_OK"
        Prefs.needsVerify = AccountStore.needsVerifyAccounts().isNotEmpty()
        AccountStore.save()
        Toast.makeText(
            this,
            getString(R.string.login_verify_passed, account.displayName),
            Toast.LENGTH_LONG
        ).show()
        finish()
    }

    /**
     * 把「这一页到底有没有真的显示出来」记下来。
     *
     * ★ 为什么单独立这几个回调：滑块的分步拖动依赖页面内的 setTimeout，
     *   而 Chromium 对**不可见**的 WebView 会限流甚至挂起定时器。
     *   只要页面没真正可见，拖动就会「发出去了但没动」，现象和「滑块失败」一模一样。
     *   所以必须能区分「页面不可见」和「页面可见但拖动被拒」。
     */
    /**
     * ★★★ 第 13 期：把生命周期补全。
     *
     * 第 12 期交付后拿到的轨迹里出现了这样一个序列：
     *   `[环境]` → `[锁屏] 已开启` → `onResume` → **6 毫秒后 onPause** → 页面被销毁，
     * 而 `窗口焦点=true` **一次都没有出现** —— 说明这个窗口从未真正可见过。
     *
     * 但当时只有 onResume / onPause 两个出口，**分不清**下面三种情况：
     *   ① 被重复拉起顶掉（三条拉起路径同时开火）
     *   ② 锁屏没被真正让开（窗口从未拿到焦点）
     *   ③ 系统把这次启动判为无效
     * 三者的修法完全不同，所以先把出口补齐。
     * **这些回调全部只留痕，不做任何处理。**
     */
    override fun onStart() {
        super.onStart()
        SliderTrace.log("[可见] onStart")
        // ★ 第 16 期：验证页上屏了 —— 「延迟重拉」看到这个就不必再拉。
        if (verifyMode) pageAlive = true
    }

    override fun onStop() {
        super.onStop()
        SliderTrace.log("[可见] onStop")
        // ★ 第 16 期：验证页离开屏幕了。
        if (verifyMode) pageAlive = false
    }

    override fun onResume() {
        super.onResume()
        SliderTrace.log(
            "[可见] onResume 锁屏=" + isKeyguardLockedNow() + " 亮屏=" + isScreenOnNow()
        )
    }

    override fun onPause() {
        // 先记状态再交给 super：super.onPause 之后状态可能已经变了。
        // `正在关闭` / `已销毁` 是区分「自己被 finish 掉」和「被别的页面盖住」的关键。
        SliderTrace.log(
            "[可见] onPause 正在关闭=" + isFinishing + " 已销毁=" + isDestroyed +
                " 锁屏=" + isKeyguardLockedNow() + " 安全锁=" + isKeyguardSecureNow() +
                " 亮屏=" + isScreenOnNow()
        )
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        SliderTrace.log("[可见] 窗口焦点=" + hasFocus + " 锁屏=" + isKeyguardLockedNow())
    }

    /**
     * ★ 第 13 期新增：同一个实例被**第二次**拉起时，intent 会送到这里。
     *
     * 原来没有这个回调，重复拉起是**完全静默**的 —— 而「实例被顶掉」
     * 正是「刚 onResume 就 onPause」的头号嫌疑。
     * 只留痕：**不调用 setIntent**，也不做任何处理（本页在 onCreate 里读一次 intent 就够）。
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        SliderTrace.log(
            "[来源] 同一实例被再次拉起：" +
                intent.getStringExtra(EXTRA_LAUNCH_SOURCE).orEmpty().ifBlank { "(未标注)" } +
                " flags=0x" + Integer.toHexString(intent.flags) +
                " 当前模式=" + verifyMode
        )
        // ★ 第 15 期：清单加了 singleTop 之后，重复拉起走的是 onNewIntent
        //   （**同一个实例**，不再重建），所以这里补一次环境快照 ——
        //   否则「这一次被拉起时锁屏是什么状态」又变成盲区。
        //   ★ 刻意**不**调 markVerifySession()：那是「验证页被创建了多少次」的计数，
        //     而 onNewIntent 恰恰意味着**没有新建页面**；计进去会把那个计数搞成假的，
        //     而那个计数正是判断「页面到底有没有被拉起来」的唯一依据。
        if (verifyMode) {
            SliderTrace.log("[环境] 再次拉起时：" + describeEnvironment())
        }
    }

    /**
     * 让本页能在锁屏之上显示，并点亮屏幕。
     *
     * ★ 为什么必须有：自动签到由闹钟触发，手机几乎一定处于**息屏 + 锁屏**状态。
     *   原来这个 Activity 没有任何 showWhenLocked / turnScreenOn，
     *   于是全屏通知虽然把它拉起来了，它却被锁屏盖住、屏幕也不亮 ——
     *   页面不可见 → Chromium 把页面内的 setTimeout 限流甚至挂起 →
     *   jsDrag 的 24 步分步拖动发不出去 → 滑块「没动」→ 易盾判失败。
     *   手动「立即签到」时屏幕本来就亮着，所以一直是好的。
     *
     * ★ 边界：只设置**窗口显示属性**，不参与任何判定 ——
     *   它不会改变「签不签到」「拖不拖动」「验证成不成功」里的任何一个决定。
     *   手动「立即签到」时这两项是空操作。
     */
    private fun applyVerifyWindowFlags() {
        try {
            val keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            val locked = keyguard.isKeyguardLocked
            val secure = keyguard.isKeyguardSecure

            // ★★★ 第 14 期：`FLAG_DISMISS_KEYGUARD` 必须**无条件**加。
            //
            //   官方对这两个标志的定义，正好解释了第 13 期实测到的「页面只活 18 毫秒」：
            //     · FLAG_SHOW_WHEN_LOCKED（= setShowWhenLocked）只是**临时盖住**锁屏，
            //       「ensure they reappear when the user moves to another UI」——
            //       锁屏**会重新回来**，把验证页顶到后面 ⇒ onPause。
            //     · FLAG_DISMISS_KEYGUARD 则是**真正移除**锁屏，且
            //       「only if it is not a secure lock keyguard」——
            //       非安全锁屏（滑动解锁）移除后「never re-appear」。
            //
            //   实测证据：锁屏全程 locked=true、`窗口焦点` **一次都没拿到**、
            //   onResume 之后 18 毫秒就 onPause —— 正是「只盖住、没移除」的表现。
            //   而本机是**滑动解锁**（截图顶部闭合挂锁、无 PIN 键盘），这条路走得通。
            //
            //   对**安全锁屏**（有 PIN / 图案 / 密码）系统会忽略这个标志，无害。
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            } else {
                // API 26 没有上面两个方法，用等价的窗口标志（已废弃，但对 26 仍有效）
                @Suppress("DEPRECATION")
                window.addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                )
            }

            // ★ 现代 API 的等价手段：非安全锁屏可以直接请求移除，且**不会弹任何界面**。
            //   ★ 只对**非安全**锁屏调用 —— 安全锁屏调用它会弹出 PIN 界面，
            //   反而把验证页盖住；那种情况只能靠上面的 setShowWhenLocked 覆盖。
            if (locked && !secure) {
                keyguard.requestDismissKeyguard(this, null)
            }

            // ★ 顺手防一个真实故障：验证页要可见十几秒（等页面加载 + 多轮滑块），
            //   屏幕中途自动熄灭会让页面再次不可见、setTimeout 被限流。
            //   只影响「屏幕要不要自动熄灭」，不参与任何判定。
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

            SliderTrace.log(
                "[锁屏] 已开启：锁屏上显示 + 点亮屏幕 + 移除非安全锁屏" +
                    "（当时锁屏=" + locked + " 安全锁=" + secure + "）"
            )
        } catch (error: Throwable) {
            SliderTrace.log("[锁屏] 开启失败：" + error.javaClass.simpleName)
        }
    }

    /**
     * 采一次当前环境：亮屏 / 锁屏 / 悬浮窗 / 全屏通知权限。
     *
     * ★ 这四项决定了「后台自动拉起验证页」这条路能不能走通，缺一项都可能让页面
     *   根本显示不出来。全部只读，不改变任何行为。
     */
    private fun describeEnvironment(): String {
        return try {
            val power = getSystemService(Context.POWER_SERVICE) as PowerManager
            val keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val fsOk = if (Build.VERSION.SDK_INT >= 34) nm.canUseFullScreenIntent() else true
            "亮屏=" + power.isInteractive +
                " 锁屏=" + keyguard.isKeyguardLocked +
                // ★ 第 14 期：安全锁（PIN/图案/密码）和非安全锁（滑动）的修法完全不同 ——
                //   前者只能靠 setShowWhenLocked 覆盖，后者可以真正移除。必须能区分。
                " 安全锁=" + keyguard.isKeyguardSecure +
                " 悬浮窗=" + Settings.canDrawOverlays(this) +
                " 全屏通知=" + fsOk
        } catch (_: Throwable) {
            "(读取失败)"
        }
    }

    /** 当前是否锁屏。只读，仅用于留痕。 */
    private fun isKeyguardLockedNow(): Boolean {
        return try {
            (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * 当前锁屏是不是**安全锁**（有 PIN / 图案 / 密码）。
     *
     * ★ 第 14 期：这一项决定「能不能真正把锁屏移除」——
     *   非安全锁（滑动解锁）可以用 FLAG_DISMISS_KEYGUARD / requestDismissKeyguard 移除，
     *   安全锁只能靠 setShowWhenLocked 覆盖。只读，仅用于留痕。
     */
    private fun isKeyguardSecureNow(): Boolean {
        return try {
            (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardSecure
        } catch (_: Throwable) {
            false
        }
    }

    /** 当前屏幕是否亮着。只读，仅用于留痕。 */
    private fun isScreenOnNow(): Boolean {
        return try {
            (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        } catch (_: Throwable) {
            false
        }
    }

    override fun onDestroy() {
        // ★ 第 13 期：这一行是「页面到底活到什么时候」的终点标记。
        //   上一轮报告里那句「自动滑块结束：已尝试 0/8 次」，只能**反推**出
        //   onDestroy 被调用过（stop() 只有这一个调用者）—— 现在直接写出来。
        SliderTrace.log("[可见] onDestroy（本页结束）")
        finished = true
        // ★ 第 16 期：本页结束 ⇒ 验证页肯定不在屏幕上了。
        pageAlive = false
        autoSlider?.stop()
        // ★ 必须先停加载、清空内容，再 destroy —— 否则 WebView 还在加载/跳转时
        //   destroy 会触发 native 崩溃（这是「验证完成跳转时闪退」最常见的根因）。
        try {
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.removeAllViews()
            // 销毁前先从父容器移除，避免“destroy 时仍挂在窗口上”导致渲染进程崩溃
            (webView.parent as? android.view.ViewGroup)?.removeView(webView)
            webView.destroy()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    companion object {
        /** 要登录到哪个账号槽位。不传时退回到第一个账号。 */
        const val EXTRA_ACCOUNT_ID = "account_id"

        /**
         * 验证模式：不清 Cookie，直接带着该账号的会话打开微博，
         * 让用户完成「请先验证身份」。
         */
        const val EXTRA_VERIFY_MODE = "verify_mode"

        /**
         * 谁把本页拉起来的（第 13 期新增）。
         *
         * ★ 自动签到那一轮，全屏通知 / 无障碍 / 悬浮窗**三条路会同时开火**，
         *   而轨迹里分不清是哪一个真正把页面创建出来的。
         *   取值："通知" / "无障碍" / "悬浮窗"。**只用于留痕，不参与任何判定。**
         */
        const val EXTRA_LAUNCH_SOURCE = "launch_source"

        /**
         * ★ 第 16 期：验证页当前是否还活着（onStart 置 true，onStop / onDestroy 置 false）。
         *
         * 只用于判断「延迟重拉」还要不要补那一次 —— 页面已经在屏幕上待着时
         * 就不必再拉。**不参与任何判定。**
         *
         * ★ 为什么用 onStart/onStop 而不是 onResume/onPause：
         *   用户拉一下通知栏只会给 onPause，用 onResume/onPause 会把它误判成
         *   「页面死了」，白白多拉一次。onStart/onStop 才真正对应
         *   「在屏幕上 / 不在屏幕上」。
         */
        @Volatile
        var pageAlive = false

        /**
         * 验证用的超话签到页（电脑版）。
         * 有多个固定超话时，改成第一个要签的即可；签到页会自动点「签到」触发滑块。
         */
        const val VERIFY_CHECKIN_URL = "https://weibo.com/p/100808212349219ac32e9f5c1165965a769d0f"
    }
}
