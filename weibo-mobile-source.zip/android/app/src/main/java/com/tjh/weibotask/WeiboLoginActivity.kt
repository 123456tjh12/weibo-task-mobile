package com.tjh.weibotask

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * 微博登录页。
 *
 * ★ 多账号下最容易踩的坑在这里：
 *   WebView 的 Cookie 存储是**整个应用共享**的，不区分账号。
 *   如果不清空就直接打开登录页，第二个账号会看到第一个账号的登录态，
 *   于是「登录」瞬间完成，而保存下来的其实是第一个账号的 Cookie ——
 *   结果是两个槽位装着同一个账号，用户会以为多账号根本没生效。
 *
 *   所以每次进来都先 removeAllCookies，强制重新扫码/输密码。
 */
class WeiboLoginActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        AccountStore.init(this)
        setContentView(R.layout.activity_weibo_login)
        webView = findViewById(R.id.webView)

        val accountId = intent.getStringExtra(EXTRA_ACCOUNT_ID).orEmpty()
        val account = AccountStore.find(accountId) ?: AccountStore.ensureAtLeastOne()

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                trySaveCookies(account)
            }
        }

        val loginUrl = "https://passport.weibo.com/sso/signin?entry=wapsso&source=wapssowb&url=" +
            java.net.URLEncoder.encode("https://m.weibo.cn/", "UTF-8")

        // 先清空 WebView 里的旧 Cookie，再打开登录页
        val cookieManager = CookieManager.getInstance()
        var opened = false
        val openLoginPage = {
            if (!opened) {
                opened = true
                webView.loadUrl(loginUrl)
            }
        }
        cookieManager.removeAllCookies {
            cookieManager.flush()
            runOnUiThread { openLoginPage() }
        }
        // 兜底：个别机型上 removeAllCookies 的回调不触发，别让页面一直白屏
        webView.postDelayed({ openLoginPage() }, 1200)
    }

    private fun trySaveCookies(account: WeiboAccount) {
        val cookieText = collectCookieHeader()
        if (!cookieText.contains("SUB=")) return

        val values = parseCookieValues(cookieText)
        for (name in listOf("SUB", "SUBP", "SSOLoginState", "ALF", "SRT", "SRF", "XSRF-TOKEN")) {
            val value = values[name] ?: continue
            CookieManager.getInstance().setCookie(
                "https://m.weibo.cn",
                "$name=$value; Domain=.weibo.cn; Path=/; Secure; SameSite=Lax"
            )
        }
        CookieManager.getInstance().flush()

        // 先写进这个账号的槽位，再验证 —— 验证时用的就是它自己的 Cookie
        account.cookie = cookieText
        account.verified = false
        AccountStore.save()

        Thread {
            var loggedIn = false
            var nickname = ""
            try {
                val config = WeiboClient.fetchConfig(account)
                loggedIn = config.optBoolean("login")
                if (loggedIn) {
                    nickname = config.optJSONObject("user")?.optString("screen_name").orEmpty()
                }
            } catch (_: Exception) {
                loggedIn = false
            }
            AccountStore.save()

            runOnUiThread {
                if (loggedIn) {
                    account.verified = true
                    account.lastCheckAt = System.currentTimeMillis()
                    account.lastCheckMessage = "登录成功"
                    // 换账号必须重置风控状态：新账号没被限流，不该继承上一个号的分数
                    account.riskScore = 0
                    account.consecutiveFailures = 0
                    if (nickname.isNotBlank()) account.label = nickname
                    AccountStore.save()
                    Toast.makeText(this, "「" + account.label + "」登录成功", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    account.verified = false
                    account.cookie = ""
                    AccountStore.save()
                    Toast.makeText(this, "登录未完成，请重新扫码或使用短信登录", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun collectCookieHeader(): String {
        val mobileRaw = CookieManager.getInstance().getCookie("https://m.weibo.cn").orEmpty()
        val mobileValues = parseCookieValues(mobileRaw)
        if (mobileValues.containsKey("SUB")) {
            return mobileValues.entries.joinToString("; ") { "${it.key}=${it.value}" }
        }

        val values = linkedMapOf<String, String>()
        values.putAll(mobileValues)
        for (url in listOf("https://weibo.com", "https://passport.weibo.com")) {
            val raw = CookieManager.getInstance().getCookie(url) ?: continue
            values.putAll(parseCookieValues(raw))
        }
        return values.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    private fun parseCookieValues(raw: String): Map<String, String> {
        val values = linkedMapOf<String, String>()
        for (part in raw.split(";")) {
            val item = part.trim()
            val index = item.indexOf('=')
            if (index <= 0) continue
            val name = item.substring(0, index).trim()
            val value = item.substring(index + 1).trim()
            if (value.isNotEmpty()) values[name] = value
        }
        return values
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        /** 要登录到哪个账号槽位。不传时退回到第一个账号。 */
        const val EXTRA_ACCOUNT_ID = "account_id"
    }
}
