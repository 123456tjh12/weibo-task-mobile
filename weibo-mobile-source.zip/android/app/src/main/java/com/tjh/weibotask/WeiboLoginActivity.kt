package com.tjh.weibotask

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * 微博登录页。
 *
 * ★ 多账号下最容易踩的坑在这里：
 *   WebView 的 Cookie 存储是**整个应用共享**的，不区分账号。
 *   如果不清空就直接打开登录页，第二个账号会看到第一个账号的登录态，
 *   于是「登录」瞬间完成，而保存下来的其实是第一个账号的 Cookie ——
 *   结果是两个槽位装着同一个账号，用户会以为多账号根本没生效。
 *
 *   所以每次进来都先 removeAllCookies，强制重新扫码/输密码。
 *
 * ★★★ v0.20.18：本页是「闪退」被报**三次**的地方，这一版按「可观测性优先」重写：
 *   1. **渲染进程被杀 → 原地重载**（不再直接 finish）。
 *      v0.20.17 的处理是「提示一下然后关掉页面」—— 对用户来说**和闪退没有区别**，
 *      等于把崩溃换了个样子，问题照旧。现在改成：摘掉死掉的 WebView、建一个新的、
 *      重新加载刚才那个地址，用户接着验证。
 *   2. **每一步都写 `StepLog`**。因为实测证明崩溃记录抓不到任何异常
 *      （native 崩溃 / 渲染进程被杀都不走 Java 异常），只能靠「最后一步落在哪」定位。
 *   3. 渲染进程崩过一次之后**自动降级为软件渲染** —— WebView 渲染进程崩溃绝大多数
 *      与 GPU 合成有关，软件层能绕开这条路径；验证页是低频操作，慢一点完全可以接受。
 *
 * ★★★ v0.20.19：找到「闪退」的**真凶**了，而且**根本不是崩溃** —— 是这一页自己关的。
 *   用户第三次报「还是闪退」时发来的步骤留痕：
 *
 *       16:25:53  登录判定：loggedIn=true
 *       16:25:54  登录页 onDestroy          ← 页面被自己关掉了
 *
 *   验证模式打开的账号**本来就是已登录的**（它只是被风控拦了签到，登录态是好的），
 *   所以第一次加载完微博首页，`fetchConfig` 立刻返回 `loggedIn=true`，
 *   而下面那支「登录成功」把它当成了「验证通过」→ 直接 `finish()`。
 *   用户看到的是「点进去 → 页面闪一下 → 自己没了」——**在用户眼里这就是闪退**。
 *
 *   ★ 这个判据本身就是错的：`loggedIn` 只说明**登录态还在**，
 *     和「微博要求的验证有没有做完」毫无关系。微博也不会把验证结果告诉第三方。
 *   → 这一版的判据改成**用户在页面上点「我已完成验证」**（见 [confirmVerifyDone]）。
 *     验证模式**不再有任何自动关闭页面的路径**。
 */
class WeiboLoginActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    /** ★ v0.20.18 起改成字段：重建 WebView 时新实例也要用同一个账号 */
    private lateinit var account: WeiboAccount

    private var lastSaveAt = 0L

    /** 已经判定登录成功、开始收尾了 —— 之后的页面回调一律忽略，避免重复 finish / 多线程竞争 */
    private var finished = false

    /** 是否验证模式（验证模式验证通过后要进入静置期） */
    private var verifyMode = false

    /** 最近一次要加载的 http(s) 地址 —— 渲染进程被杀后要靠它原地重载 */
    private var lastUrl = "https://m.weibo.cn/"

    /** 渲染进程被回收后已经重建过几次（防止反复重建变成死循环） */
    private var rendererRetry = 0

    /** 是否已降级为软件渲染（渲染进程崩过一次之后打开） */
    private var softwareLayer = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        AccountStore.init(this)
        // ★ v0.20.17：装上崩溃记录。本页是「闪退」被报上来两次的地方，
        //   崩溃记录装在这里，才能在下次真的崩掉时留下堆栈（见 CrashLog 的注释）。
        CrashLog.install(this)
        setContentView(R.layout.activity_weibo_login)
        StepLog.step(this, "登录页 onCreate")

        webView = findViewById(R.id.webView)

        val accountId = intent.getStringExtra(EXTRA_ACCOUNT_ID).orEmpty()
        account = AccountStore.find(accountId) ?: AccountStore.ensureAtLeastOne()

        // ★ 两种模式共用这个界面：
        //   登录模式（默认）：清空 Cookie → 打开登录页 → 用户重新登录
        //   验证模式：**保留** Cookie → 直接打开微博 → 用户完成「请先验证身份」
        verifyMode = intent.getBooleanExtra(EXTRA_VERIFY_MODE, false)
        StepLog.step(this, "模式=" + (if (verifyMode) "验证" else "登录") + " 账号=" + account.order)

        // ★★ v0.20.19：两种模式的提示语必须分开写。
        //   旧实现两种模式共用同一句「登录成功后会自动返回」——
        //   验证模式**根本不会自动返回**（这一版起更是彻底不自动关页面），
        //   留着那句话用户就会一直干等它自己关掉，而这正是第三次反馈里
        //   「页面闪一下就没了」的另一半误解。
        val hint = findViewById<TextView>(R.id.loginHintText)
        val verifyBar = findViewById<View>(R.id.verifyBar)
        if (verifyMode) {
            hint.text = "这是「完成验证」页：不会清空登录状态，也不会自动关闭。" +
                "请按页面上的提示把微博要求的验证做完。"
            verifyBar.visibility = View.VISIBLE
            findViewById<Button>(R.id.verifyDoneButton).setOnClickListener { confirmVerifyDone() }
        } else {
            hint.text = "请使用微博 App 扫码；登录成功后会自动返回。"
            verifyBar.visibility = View.GONE
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        applyWebSettings(webView)
        attachClient(webView)

        if (verifyMode) {
            // ★ 验证模式**绝不能清 Cookie**。
            //   微博的「行为异常」验证是**按账号 + 会话**记的：换一个未登录的会话去验证，
            //   验证的是那个空会话，本应用手里的 Cookie 依然是「异常」状态 —— 白做。
            //   所以先把这个账号自己的 Cookie 灌进 WebView，让它带着**同一个会话**打开微博。
            injectCookies(account)
            CookieManager.getInstance().flush()
            lastUrl = "https://m.weibo.cn/"
            StepLog.step(this, "验证模式：Cookie 已注入，开始加载微博首页")
            webView.loadUrl(lastUrl)
            Toast.makeText(
                this,
                "请在页面上完成微博要求的验证，做完后点页面下方的「我已完成验证」。",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val loginUrl = "https://passport.weibo.com/sso/signin?entry=wapsso&source=wapssowb&url=" +
            java.net.URLEncoder.encode("https://m.weibo.cn/", "UTF-8")
        lastUrl = loginUrl

        // 先清空 WebView 里的旧 Cookie，再打开登录页
        val cookieManager = CookieManager.getInstance()
        var opened = false
        val openLoginPage = {
            // ★★ v0.20.17：这个闭包有**两个入口**（Cookie 回调 + 1.2 秒兜底），
            //   而用户完全可能在 1.2 秒内就退出本页（登录页白屏时尤其会去点返回）。
            //   WebView 一旦 destroy，再 loadUrl 就是未定义行为 —— 属于「跳转时闪退」
            //   的同一类根因，只是入口不同。这里和 onDestroy 用**同一个** finished 旗标。
            if (!opened && !finished && !isDestroyed) {
                opened = true
                StepLog.step(this, "打开登录页")
                webView.loadUrl(loginUrl)
            }
        }
        cookieManager.removeAllCookies {
            cookieManager.flush()
            runOnUiThread { openLoginPage() }
        }
        // 兜底：个别机型上 removeAllCookies 的回调不触发，别让页面一直白屏
        webView.postDelayed({ openLoginPage() }, 1200)
    }

    /**
     * 把一个 WebView 实例的 settings 配好。
     *
     * ★ 抽成函数是为了「渲染进程被杀后重建」：新实例必须和第一个实例配置一致，
     *   复制粘贴两份配置迟早会漂移（其中一份改了、另一份忘了）。
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun applyWebSettings(view: WebView) {
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
        }
        // ★★ 降级开关：渲染进程崩过一次之后改用软件渲染。
        //   WebView 的渲染进程崩溃绝大多数与 GPU 合成有关，软件层能绕开这条路径。
        //   验证页是低频操作，慢一点完全可以接受 —— 稳定性优先。
        if (softwareLayer) {
            view.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        }
    }

    /** 给一个 WebView 实例挂上回调。同上，抽出来是为了重建时能原样复用。 */
    private fun attachClient(view: WebView) {
        view.webChromeClient = WebChromeClient()
        view.webViewClient = object : WebViewClient() {
            /**
             * ★★★ v0.20.17：这是「人工验证跳转时闪退」**最可能的真凶**。
             *
             * Android 8.0（API 26）起，网页内容跑在**独立的渲染进程**里。
             * 那个进程一旦被杀（内存不足被系统回收，或页面自身把渲染进程搞崩），
             * **默认行为是把整个应用一起杀掉** —— 用户看到的就是「闪退」，而且：
             *   · Java 层没有任何异常（连崩溃记录都抓不到）；
             *   · 设备日志里只有一行 Render process gone，没有我们的堆栈。
             * 微博的验证页 JS 很重，在手机上被系统回收渲染进程是常事 ——
             * 这和「验证跳转时闪退」这个场景高度吻合。
             *
             * ★ 修法：重写并**返回 true**（含义是「我自己处理了，别杀应用」）。
             *   不重写、或返回 false，都会走默认的「杀掉应用」。
             *
             * ★★ v0.20.18 修正：返回 true 之后**不能直接 finish**。
             *   v0.20.17 就是「提示一下然后关掉页面」，而用户第三次报的仍然是「闪退」——
             *   因为「页面自己关掉」和「崩掉」在用户眼里完全一样。
             *   现在的做法是**原地重建 WebView 并重新加载**，让用户能接着验证。
             */
            override fun onRenderProcessGone(w: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                handleRendererGone(w, detail)
                return true
            }

            /**
             * ★★ v0.20.17：旧实现只重写了 String 这个**已废弃**的重载。
             *
             * API 24+ 起框架走的是 WebResourceRequest 重载 —— 子框架导航、
             * 以及**服务端 3xx 重定向**都从它进来。默认实现虽然会把请求转交给
             * String 版，但那条链路在部分 WebView 版本上并不覆盖重定向，
             * 而「验证完成后跳转」恰恰就是重定向。
             * 两个重载都重写，成本为零、覆盖面最广。
             */
            override fun shouldOverrideUrlLoading(w: WebView?, request: WebResourceRequest?): Boolean =
                handleNavigation(request?.url?.toString())

            override fun shouldOverrideUrlLoading(w: WebView?, url: String?): Boolean =
                handleNavigation(url)

            override fun onPageStarted(w: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(w, url, favicon)
                if (url != null) {
                    // ★ 记下地址：渲染进程被杀后要靠它原地重载
                    lastUrl = url
                    StepLog.step(this@WeiboLoginActivity, "开始加载：" + shorten(url))
                }
            }

            override fun onPageFinished(w: WebView?, url: String?) {
                super.onPageFinished(w, url)
                StepLog.step(this@WeiboLoginActivity, "加载完成：" + shorten(url.orEmpty()))
                // ★ 回调里抛出的异常会直接让应用崩溃，而这里做的事（读 Cookie、
                //   起线程、落盘）全都可能失败。整段兜住，绝不让它冒到框架层。
                try {
                    trySaveCookies(account)
                } catch (_: Throwable) {
                }
            }

            override fun onReceivedError(
                w: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(w, request, error)
                // ★ 顺手留痕：白屏类问题以前完全没有线索（用户只会说「打不开」）。
                try {
                    StepLog.step(
                        this@WeiboLoginActivity,
                        "加载出错：" + shorten(request?.url?.toString().orEmpty()) +
                            " / " + error?.description?.toString().orEmpty()
                    )
                } catch (_: Throwable) {
                }
            }
        }
    }

    /** 留痕用的短地址：太长会把日志行撑爆，也不方便肉眼比对。 */
    private fun shorten(url: String): String =
        if (url.length <= 90) url else url.substring(0, 90) + "…"

    /** 留痕用的 scheme（`weibo://` 这类），不记完整 URL。 */
    private fun schemeOf(url: String): String {
        val index = url.indexOf(':')
        return if (index in 1..20) url.substring(0, index) + "://" else "（未知 scheme）"
    }

    /**
     * 验证模式下探到登录状态之后，**只更新提示文字**，绝不关页面。
     *
     * ★★★ 为什么验证模式不能拿探测结果做任何决定（v0.20.19 的真凶）：
     *   验证模式打开的账号**本来就是已登录的** —— 它是被风控拦了签到，登录态没坏。
     *   所以 `loggedIn=true` 只能说明「登录态还在」，**证明不了验证做完了**；
     *   而上一版正是把它当成「验证通过」→ 立刻 `finish()`，
     *   用户看到的就是「点进去、页面闪一下、自己没了」，报上来就是「闪退」。
     *   微博也不会把「验证是否完成」告诉第三方，所以这一页的完成判据只能是
     *   **用户自己点按钮**（见 [confirmVerifyDone]）。
     */
    private fun onVerifyProbe(loggedIn: Boolean) {
        try {
            val hint = findViewById<TextView>(R.id.verifyHintText)
            hint.text = if (loggedIn) {
                "已确认这个账号的登录状态是好的。请把页面上微博要求的验证做完，" +
                    "做完后点下面的按钮。"
            } else {
                "暂时没读到登录状态（多半是页面还没加载完，或网络慢）。" +
                    "把验证做完之后，直接点下面的按钮就行。"
            }
        } catch (_: Throwable) {
        }
    }

    /**
     * 用户在验证页点「我已完成验证」—— **「验证是否完成」的唯一判据**。
     *
     * ★★★ 为什么必须由用户来点（v0.20.19）：
     *   微博不会把「验证是否完成」告诉第三方；而账号被风控时**登录态本来就是好的**，
     *   所以程序**没有任何办法**自己判断验证做完了没有。
     *   前两版硬要自己判断，判出来的结论就是「登录态还在 = 验证通过」——
     *   于是页面刚打开就自己关掉了，这正是用户报的「闪退」。
     *   交给用户点一下，是这一页唯一诚实的做法。
     *
     * ★ 静置期由「账号管理」页的开关决定（v0.20.19 新增，用户要求）：
     *   开着 → 按小时数静置；关掉 → 不静置，账号立刻恢复参与自动签到。
     */
    private fun confirmVerifyDone() {
        if (finished) return
        val cookieText = collectCookieHeader()
        if (!cookieText.contains("SUB=")) {
            // ★ 读不到 SUB 就不许记账：这时候标「已验证」等于把一个没验证的账号
            //   放进签到队列，下一轮必然又撞风控 —— 用户会觉得「验证了也没用」。
            Toast.makeText(
                this,
                "还没读到这个账号的登录状态。请在页面上把验证做完" +
                    "（能看到微博内容就算好了），再点这个按钮。",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        finished = true
        account.cookie = cookieText
        account.pcCookie = collectPcCookieHeader()
        account.verified = true
        account.lastCheckAt = System.currentTimeMillis()
        account.lastCheckMessage = "已人工完成验证"
        // 刚过完风控验证，计数从零开始 —— 之前那些失败是风控造成的，不是账号坏了
        account.riskScore = 0
        account.consecutiveFailures = 0
        // ★★ 静置期只在开关打开时设（用户要求「在静置旁边加一个开关」）。
        //   关掉开关 = 验证完立刻恢复参与任务，适合「验证完就想马上签一次」的场景。
        val resting = Prefs.verifyCooldownEnabled
        account.restUntil = if (resting) {
            System.currentTimeMillis() + Prefs.verifyCooldownHours * 3600_000L
        } else {
            0L
        }
        AccountStore.save()
        StepLog.step(
            this,
            "人工确认验证完成" + (
                if (resting) "，静置 " + Prefs.verifyCooldownHours + " 小时"
                else "，未静置（静置开关已关）"
                )
        )
        Toast.makeText(
            this,
            if (resting) {
                "「" + account.displayName + "」已确认完成验证，静置 " +
                    Prefs.verifyCooldownHours + " 小时（到期自动恢复）"
            } else {
                "「" + account.displayName + "」已确认完成验证，下一轮就会参与签到"
            },
            Toast.LENGTH_LONG
        ).show()
        finish()
    }

    /**
     * 把这个账号已经保存的 Cookie 灌进 WebView 的 CookieManager。
     *
     * WebView 的 Cookie 存储是整个应用共享的、和 Prefs 里存的那份**互不相通**，
     * 所以验证模式下必须显式灌一次，否则 WebView 打开的是一个全新的未登录会话。
     */
    private fun injectCookies(account: WeiboAccount) {
        if (account.cookie.isBlank()) return
        val manager = CookieManager.getInstance()
        for (part in account.cookie.split(";")) {
            val item = part.trim()
            val index = item.indexOf('=')
            if (index <= 0) continue
            val name = item.substring(0, index).trim()
            val value = item.substring(index + 1).trim()
            if (name.isBlank() || value.isEmpty()) continue
            manager.setCookie(
                "https://m.weibo.cn",
                "$name=$value; Domain=.weibo.cn; Path=/; Secure; SameSite=Lax"
            )
            manager.setCookie(
                "https://weibo.com",
                "$name=$value; Domain=.weibo.com; Path=/; Secure; SameSite=Lax"
            )
        }
    }

    private fun trySaveCookies(account: WeiboAccount) {
        if (finished) return
        // 每加载一个页面都会回调一次，而验证过程会跳好几个页面。
        // 不节流的话会连开好几个线程去打微博接口，验证期间反而更密。
        val now = System.currentTimeMillis()
        if (now - lastSaveAt < 5000L) return
        lastSaveAt = now

        val cookieText = collectCookieHeader()
        if (!cookieText.contains("SUB=")) return

        val values = parseCookieValues(cookieText)
        for (name in listOf("SUB", "SUBP", "SSOLoginState", "ALF", "SRT", "SRF", "XSRF-TOKEN")) {
            val value = values[name] ?: continue
            CookieManager.getInstance().setCookie(
                "https://m.weibo.cn",
                "$name=$value; Domain=.weibo.cn; Path=/; Secure; SameSite=Lax"
            )
        }
        CookieManager.getInstance().flush()

        // 先写进这个账号的槽位，再验证 —— 验证时用的就是它自己的 Cookie
        account.cookie = cookieText
        account.pcCookie = collectPcCookieHeader()
        // ★★★ v0.20.19：验证模式下**不许**把 verified 置回 false。
        //   验证模式打开的账号**本来就是已登录的**（它只是被风控拦了签到，登录态是好的）。
        //   置回 false 之后用户若中途退出本页，账号在列表里就变成「登录已失效」——
        //   什么都没坏，界面却在骗人。验证模式的判据是**用户点按钮**
        //   （见 confirmVerifyDone），不在这里。
        if (!verifyMode) {
            account.verified = false
        }
        AccountStore.save()

        Thread {
            var loggedIn = false
            var nickname = ""
            try {
                val config = WeiboClient.fetchConfig(account)
                loggedIn = config.optBoolean("login")
                if (loggedIn) {
                    nickname = config.optJSONObject("user")?.optString("screen_name").orEmpty()
                }
            } catch (_: Throwable) {
                // ★ 用 Throwable 而不是 Exception：只要漏掉一种异常，
                //   它就会从这条后台线程直接冒到框架层 —— 那又是一次「闪退」。
                //   （本页已被「闪退」反馈三次，凡是能崩的地方一律兜住。）
                loggedIn = false
            }
            if (nickname.isNotBlank()) {
                // ★ 昵称只当「附加标记」，账号名里的序号**不能**被覆盖掉。
                //   序号是用户在列表和签到结果里辨认账号的唯一依据；
                //   微博昵称重复、改名、含特殊字符都会让「哪个账号没签上」变得无法对号。
                //
                // ★★ 这里**不许**写 `account.label = ...`（v0.20.13 修，v0.20.16 再修一次）。
                //   v0.20.15 的另一条工作流又把 `label = "账号 " + order + " · " + nickname`
                //   写了回来 —— 上一行注释明明写着「序号不能被覆盖」，代码却在覆盖它，
                //   典型的「注释与实现不一致」。这一行两头都坏：
                //     ① AccountStore.normalizeOrdering() 每次启动都会把 label 重置成「账号 N」，
                //        这行字**活不过一次重启**，用户下次打开又变回「账号 3」——
                //        正是用户报「把账号 1，2，3 换成对应的微博名称」的直接原因；
                //     ② 万一没被重置，displayName 就会拼成「小明（账号 3 · 小明）」。
                //   → 昵称只存进 nickname，显示形式统一由 WeiboAccount 的
                //     title / orderTag / displayName 三个属性算出来，只有一处定义。
                //
                // ★ v0.20.19：改成「探到非空昵称才写」。旧写法无条件赋值，
                //   一旦这一轮探不到昵称就会把已知昵称**抹成空串**，
                //   账号列表里刚显示出来的微博名又会退回「账号 N」。
                account.nickname = nickname
            }
            AccountStore.save()
            StepLog.step(
                this,
                "登录判定：loggedIn=" + loggedIn + " 模式=" + (if (verifyMode) "验证" else "登录")
            )

            runOnUiThread {
                if (finished || isFinishing || isDestroyed) return@runOnUiThread

                // ★★★ v0.20.19：这一支就是「人工验证跳转页闪退」的真凶。
                //
                //   验证模式打开的账号**本来就是已登录的** → 第一次加载完微博首页，
                //   fetchConfig 立刻返回 loggedIn=true → 下面那支「登录成功」
                //   把它当成了「验证通过」，直接 finish()。
                //   用户看到的是「点进去 → 页面闪一下 → 自己没了」，
                //   在用户眼里和闪退**完全一样**（所以他报了三次，而我前两版都在改崩溃）。
                //
                //   ★ 而且这个判据本身就是错的：loggedIn 只说明**登录态还在**，
                //     跟「微博要求的验证有没有做完」毫无关系 ——
                //     账号被风控时登录态本来就是好的。微博也不会把验证结果告诉第三方。
                //   → 验证模式**没有任何自动关闭页面的路径**，这里只更新提示文字；
                //     验证是否完成，由用户在页面上点「我已完成验证」确认。
                if (verifyMode) {
                    onVerifyProbe(loggedIn)
                    return@runOnUiThread
                }

                if (loggedIn) {
                    finished = true
                    account.verified = true
                    account.lastCheckAt = System.currentTimeMillis()
                    account.lastCheckMessage = "登录成功"
                    // 换账号必须重置风控状态：新账号没被限流，不该继承上一个号的分数
                    account.riskScore = 0
                    account.consecutiveFailures = 0
                    // ★ v0.20.19：登录模式**不静置**。
                    //   静置是「验证后风控脆弱期」的专用保护，现在只由
                    //   confirmVerifyDone 在用户确认验证完成时设置。
                    //   这里是一次正常登录，没有风控背景，静置只会白等几小时。
                    account.restUntil = 0L
                    AccountStore.save()
                    Toast.makeText(this, "「" + account.displayName + "」登录成功", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    account.verified = false
                    account.cookie = ""
                    AccountStore.save()
                    Toast.makeText(this, "登录未完成，请重新扫码或使用短信登录", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun collectCookieHeader(): String {
        val mobileRaw = CookieManager.getInstance().getCookie("https://m.weibo.cn").orEmpty()
        val mobileValues = parseCookieValues(mobileRaw)
        if (mobileValues.containsKey("SUB")) {
            return mobileValues.entries.joinToString("; ") { "${it.key}=${it.value}" }
        }

        val values = linkedMapOf<String, String>()
        values.putAll(mobileValues)
        for (url in listOf("https://weibo.com", "https://passport.weibo.com")) {
            val raw = CookieManager.getInstance().getCookie(url) ?: continue
            values.putAll(parseCookieValues(raw))
        }
        return values.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    /**
     * 采集 PC 端（weibo.com）cookie，供超话发帖用。
     *
     * ★ 发帖走 weibo.com/p/aj/proxy（PC 代理接口），必须用 .weibo.com 域的
     *   登录 cookie —— m.weibo.cn 那份不通用。登录经过 passport.weibo.com
     *   （它就在 weibo.com 域上），SSO 时会把 PC cookie 也种进 WebView，这里专门取出来。
     */
    private fun collectPcCookieHeader(): String {
        val values = linkedMapOf<String, String>()
        for (url in listOf("https://weibo.com", "https://passport.weibo.com")) {
            val raw = CookieManager.getInstance().getCookie(url).orEmpty()
            values.putAll(parseCookieValues(raw))
        }
        return values.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    private fun parseCookieValues(raw: String): Map<String, String> {
        val values = linkedMapOf<String, String>()
        for (part in raw.split(";")) {
            val item = part.trim()
            val index = item.indexOf('=')
            if (index <= 0) continue
            val name = item.substring(0, index).trim()
            val value = item.substring(index + 1).trim()
            if (value.isNotEmpty()) values[name] = value
        }
        return values
    }

    /**
     * 非 http/https 的跳转怎么处理。
     *
     * ★ 微博完成验证后会跳到各种深链（`weibo://` / `sinaweibo://` / `intent://` …），
     *   WebView 自己处理不了。
     *
     * ★★ 旧实现直接 `return true` 静默拦掉 —— 这挡住了崩溃，但也可能**挡住验证本身**：
     *   有些验证流程必须靠微博客户端才能走完，静默拦掉会让用户永远卡在这一步。
     *   所以这里改成：**尝试交给系统打开**；没有应用能处理就安静取消。
     *
     * ★ 关键是 try/catch(Throwable)：没有应用能响应时系统抛的是
     *   `ActivityNotFoundException`，不接住就是闪退 ——
     *   这正是「跳转闪退」的另一条常见路径。
     */
    private fun handleNavigation(url: String?): Boolean {
        if (url == null) return false
        if (url.startsWith("http://") || url.startsWith("https://")) {
            // ★ 记下地址：渲染进程被杀后要靠它原地重载
            lastUrl = url
            return false
        }
        try {
            val intent = if (url.startsWith("intent://")) {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            StepLog.step(this, "非 http 跳转，交给系统：" + schemeOf(url))
            startActivity(intent)
        } catch (_: Throwable) {
            // 没有应用能处理这个 scheme：安静取消，绝不能让它抛到框架层
            StepLog.step(this, "非 http 跳转，没有应用能处理：" + schemeOf(url))
        }
        return true
    }

    /**
     * 渲染进程被杀之后的收尾（触发原因见 `onRenderProcessGone` 的注释）。
     *
     * ★ 为什么拆成独立函数、不写在匿名对象里：
     *   匿名 `object : WebViewClient()` 里的 `this` 是 **WebViewClient 不是 Activity**，
     *   直接写 `Toast.makeText(this, …)` 会编译不过（WebViewClient 不是 Context）。
     *   本机没有编译器，这种错只能等 CI 报 —— 拆出来就不给它出错的机会。
     *
     * ★★ v0.20.18：**不再 finish**，改为原地重建 WebView 并重新加载。
     */
    private fun handleRendererGone(view: WebView?, detail: RenderProcessGoneDetail?) {
        // ★ 这一行是排查的关键：didCrash=true 表示渲染进程**自己崩了**，
        //   false 表示是系统因内存压力把它回收了 —— 两种根因的应对完全不同。
        val didCrash = try {
            detail?.didCrash()
        } catch (_: Throwable) {
            null
        }
        StepLog.step(this, "渲染进程结束 didCrash=" + didCrash + " 已重建=" + rendererRetry)

        // ★★ 容器和布局参数必须在「摘出去」之前拿 —— 摘完 parent 就是 null 了。
        val container = try {
            view?.parent as? ViewGroup
        } catch (_: Throwable) {
            null
        }
        val params = view?.layoutParams
        try {
            container?.removeView(view)
        } catch (_: Throwable) {
        }
        // ★★ destroy 放到**下一帧**再执行。
        //   在 onRenderProcessGone 回调里同步 destroy 在部分 WebView 版本上会引发
        //   native 崩溃 —— 那等于把闪退从「渲染进程」搬到「主进程」，越修越糟。
        if (view != null) {
            Handler(mainLooper).post {
                try {
                    view.destroy()
                } catch (_: Throwable) {
                }
            }
        }

        if (rendererRetry >= MAX_RENDERER_RETRY || container == null) {
            // ★ 反复被回收就不再重载了：继续重建只会变成「加载→崩→加载」的死循环，
            //   比直接告诉用户更糟。这里给一句明确的话再退出。
            StepLog.step(this, "渲染进程反复被回收，放弃重载")
            try {
                Toast.makeText(
                    this,
                    "网页组件反复被系统回收（多半是手机内存紧张）。请返回后重试，或先关掉一些后台应用。",
                    Toast.LENGTH_LONG
                ).show()
            } catch (_: Throwable) {
            }
            if (!isFinishing && !isDestroyed) finish()
            return
        }

        rendererRetry++
        // ★★ 崩过一次之后改用软件渲染（见 applyWebSettings 的说明）。
        softwareLayer = true
        try {
            Toast.makeText(this, "页面被系统回收了，已自动重新加载，请继续验证。", Toast.LENGTH_LONG).show()
        } catch (_: Throwable) {
        }
        rebuildWebView(container, params, lastUrl)
    }

    /**
     * 原地重建 WebView 并重新加载刚才那个地址。
     *
     * ★★ 为什么要重建而不是「让原实例继续用」：渲染进程死了之后，
     *   那个 WebView 实例已经不可用了 —— 继续对它调任何方法都可能直接崩。
     *   这是 Android 官方文档明确写的处理方式。
     */
    private fun rebuildWebView(container: ViewGroup, params: ViewGroup.LayoutParams?, url: String) {
        try {
            val fresh = WebView(this)
            applyWebSettings(fresh)
            attachClient(fresh)
            container.addView(
                fresh,
                params ?: ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            webView = fresh
            StepLog.step(this, "已重建 WebView，重新加载：" + shorten(url))
            fresh.loadUrl(url)
        } catch (e: Throwable) {
            StepLog.step(this, "重建 WebView 失败：" + e.javaClass.simpleName)
            if (!isFinishing && !isDestroyed) finish()
        }
    }

    override fun onDestroy() {
        finished = true
        StepLog.step(this, "登录页 onDestroy")
        // ★★ v0.20.17：重写收尾顺序。原来那版（另一条工作流）虽然也 try/catch 了，
        //   但顺序和动作都有问题：
        //
        //   ① 先 `loadUrl("about:blank")` —— 在 Activity 正在销毁时**发起一次导航**，
        //      本身就是「跳转过程中闪退」的经典触发点；而且它引发的 native 崩溃
        //      是 catch(Exception) 接不住的。
        //   ② 没有先把 WebView 从视图树里摘下来 —— destroy 之后父容器仍可能
        //      去测量/绘制它，属于未定义行为。
        //   ③ 没有断开我们自己的回调 —— destroy 过程中的回调会跑进 trySaveCookies。
        //
        //   现在的顺序：摘出视图树 → 断开回调 → stopLoading → destroy。
        //   ★ 不再调用 loadUrl("about:blank")：断开回调之后，它的唯一作用
        //     （阻止旧页面的回调进来）已经没有了，留着只剩风险。
        try {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.webChromeClient = null
            webView.webViewClient = WebViewClient()
            webView.stopLoading()
            webView.removeAllViews()
            webView.destroy()
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }

    companion object {
        /** 要登录到哪个账号槽位。不传时退回到第一个账号。 */
        const val EXTRA_ACCOUNT_ID = "account_id"

        /**
         * 验证模式：不清 Cookie，直接带着该账号的会话打开微博，
         * 让用户完成「请先验证身份」。
         */
        const val EXTRA_VERIFY_MODE = "verify_mode"

        /**
         * 渲染进程最多重建几次。
         *
         * ★ 上限必须有：渲染进程如果是因为「页面本身就把它搞崩」而死的，
         *   重建之后加载同一个页面还会再崩 —— 没有上限就是死循环，
         *   用户看到的是「一直在转圈加载」，比直接报错更难懂。
         */
        private const val MAX_RENDERER_RETRY = 2
    }
}
