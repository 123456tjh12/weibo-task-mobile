package com.tjh.weibotask

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * 微博登录页。
 *
 * ★ 多账号下最容易踩的坑在这里：
 *   WebView 的 Cookie 存储是**整个应用共享**的，不区分账号。
 *   如果不清空就直接打开登录页，第二个账号会看到第一个账号的登录态，
 *   于是「登录」瞬间完成，而保存下来的其实是第一个账号的 Cookie ——
 *   结果是两个槽位装着同一个账号，用户会以为多账号根本没生效。
 *
 *   所以每次进来都先 removeAllCookies，强制重新扫码/输密码。
 */
class WeiboLoginActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var lastSaveAt = 0L

    /** 已经判定登录成功、开始收尾了 —— 之后的页面回调一律忽略，避免重复 finish / 多线程竞争 */
    private var finished = false

    /** 是否验证模式（验证模式验证通过后要进入静置期） */
    private var verifyMode = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        AccountStore.init(this)
        // ★ v0.20.17：装上崩溃记录。本页是「闪退」被报上来两次的地方，
        //   崩溃记录装在这里，才能在下次真的崩掉时留下堆栈（见 CrashLog 的注释）。
        CrashLog.install(this)
        setContentView(R.layout.activity_weibo_login)
        webView = findViewById(R.id.webView)

        val accountId = intent.getStringExtra(EXTRA_ACCOUNT_ID).orEmpty()
        val account = AccountStore.find(accountId) ?: AccountStore.ensureAtLeastOne()

        // ★ 两种模式共用这个界面：
        //   登录模式（默认）：清空 Cookie → 打开登录页 → 用户重新登录
        //   验证模式：**保留** Cookie → 直接打开微博 → 用户完成「请先验证身份」
        verifyMode = intent.getBooleanExtra(EXTRA_VERIFY_MODE, false)

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            /**
             * ★★★ v0.20.17：这是「人工验证跳转时闪退」**最可能的真凶**。
             *
             * Android 8.0（API 26）起，网页内容跑在**独立的渲染进程**里。
             * 那个进程一旦被杀（内存不足被系统回收，或页面自身把渲染进程搞崩），
             * **默认行为是把整个应用一起杀掉** —— 用户看到的就是「闪退」，而且：
             *   · Java 层没有任何异常（连崩溃记录都抓不到）；
             *   · 设备日志里只有一行 Render process gone，没有我们的堆栈。
             * 微博的验证页 JS 很重，在手机上被系统回收渲染进程是常事 ——
             * 这和「验证跳转时闪退」这个场景高度吻合。
             *
             * ★ 修法：重写并**返回 true**（含义是「我自己处理了，别杀应用」）。
             *   不重写、或返回 false，都会走默认的「杀掉应用」。
             *
             * ★ 返回 true 之后必须自己收拾干净：这个 WebView 实例已经不可用，
             *   继续用它必崩。所以这里把它摘出视图树并销毁，然后结束当前页 ——
             *   本页的使命就是「完成一次登录/验证」，让用户回去重试一次最稳妥。
             */
            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                handleRendererGone(view)
                return true
            }

            /**
             * ★★ v0.20.17：旧实现只重写了 String 这个**已废弃**的重载。
             *
             * API 24+ 起框架走的是 WebResourceRequest 重载 —— 子框架导航、
             * 以及**服务端 3xx 重定向**都从它进来。默认实现虽然会把请求转交给
             * String 版，但那条链路在部分 WebView 版本上并不覆盖重定向，
             * 而「验证完成后跳转」恰恰就是重定向。
             * 两个重载都重写，成本为零、覆盖面最广。
             */
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
                handleNavigation(request?.url?.toString())

            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean =
                handleNavigation(url)

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // ★ 回调里抛出的异常会直接让应用崩溃，而这里做的事（读 Cookie、
                //   起线程、落盘）全都可能失败。整段兜住，绝不让它冒到框架层。
                try {
                    trySaveCookies(account)
                } catch (_: Throwable) {
                }
            }
        }

        if (verifyMode) {
            // ★ 验证模式**绝不能清 Cookie**。
            //   微博的「行为异常」验证是**按账号 + 会话**记的：换一个未登录的会话去验证，
            //   验证的是那个空会话，本应用手里的 Cookie 依然是「异常」状态 —— 白做。
            //   所以先把这个账号自己的 Cookie 灌进 WebView，让它带着**同一个会话**打开微博。
            injectCookies(account)
            CookieManager.getInstance().flush()
            webView.loadUrl("https://m.weibo.cn/")
            Toast.makeText(
                this,
                "请在页面里完成验证。验证通过后返回，本应用会自动保存新的登录状态。",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val loginUrl = "https://passport.weibo.com/sso/signin?entry=wapsso&source=wapssowb&url=" +
            java.net.URLEncoder.encode("https://m.weibo.cn/", "UTF-8")

        // 先清空 WebView 里的旧 Cookie，再打开登录页
        val cookieManager = CookieManager.getInstance()
        var opened = false
        val openLoginPage = {
            // ★★ v0.20.17：这个闭包有**两个入口**（Cookie 回调 + 1.2 秒兜底），
            //   而用户完全可能在 1.2 秒内就退出本页（登录页白屏时尤其会去点返回）。
            //   WebView 一旦 destroy，再 loadUrl 就是未定义行为 —— 属于「跳转时闪退」
            //   的同一类根因，只是入口不同。这里和 onDestroy 用**同一个** finished 旗标。
            if (!opened && !finished && !isDestroyed) {
                opened = true
                webView.loadUrl(loginUrl)
            }
        }
        cookieManager.removeAllCookies {
            cookieManager.flush()
            runOnUiThread { openLoginPage() }
        }
        // 兜底：个别机型上 removeAllCookies 的回调不触发，别让页面一直白屏
        webView.postDelayed({ openLoginPage() }, 1200)
    }

    /**
     * 把这个账号已经保存的 Cookie 灌进 WebView 的 CookieManager。
     *
     * WebView 的 Cookie 存储是整个应用共享的、和 Prefs 里存的那份**互不相通**，
     * 所以验证模式下必须显式灌一次，否则 WebView 打开的是一个全新的未登录会话。
     */
    private fun injectCookies(account: WeiboAccount) {
        if (account.cookie.isBlank()) return
        val manager = CookieManager.getInstance()
        for (part in account.cookie.split(";")) {
            val item = part.trim()
            val index = item.indexOf('=')
            if (index <= 0) continue
            val name = item.substring(0, index).trim()
            val value = item.substring(index + 1).trim()
            if (name.isBlank() || value.isEmpty()) continue
            manager.setCookie(
                "https://m.weibo.cn",
                "$name=$value; Domain=.weibo.cn; Path=/; Secure; SameSite=Lax"
            )
            manager.setCookie(
                "https://weibo.com",
                "$name=$value; Domain=.weibo.com; Path=/; Secure; SameSite=Lax"
            )
        }
    }

    private fun trySaveCookies(account: WeiboAccount) {
        if (finished) return
        // 每加载一个页面都会回调一次，而验证过程会跳好几个页面。
        // 不节流的话会连开好几个线程去打微博接口，验证期间反而更密。
        val now = System.currentTimeMillis()
        if (now - lastSaveAt < 5000L) return
        lastSaveAt = now

        val cookieText = collectCookieHeader()
        if (!cookieText.contains("SUB=")) return

        val values = parseCookieValues(cookieText)
        for (name in listOf("SUB", "SUBP", "SSOLoginState", "ALF", "SRT", "SRF", "XSRF-TOKEN")) {
            val value = values[name] ?: continue
            CookieManager.getInstance().setCookie(
                "https://m.weibo.cn",
                "$name=$value; Domain=.weibo.cn; Path=/; Secure; SameSite=Lax"
            )
        }
        CookieManager.getInstance().flush()

        // 先写进这个账号的槽位，再验证 —— 验证时用的就是它自己的 Cookie
        account.cookie = cookieText
        account.pcCookie = collectPcCookieHeader()
        account.verified = false
        AccountStore.save()

        Thread {
            var loggedIn = false
            var nickname = ""
            try {
                val config = WeiboClient.fetchConfig(account)
                loggedIn = config.optBoolean("login")
                if (loggedIn) {
                    nickname = config.optJSONObject("user")?.optString("screen_name").orEmpty()
                }
            } catch (_: Exception) {
                loggedIn = false
            }
            AccountStore.save()

            runOnUiThread {
                if (finished || isFinishing || isDestroyed) return@runOnUiThread
                if (loggedIn) {
                    finished = true
                    account.verified = true
                    account.lastCheckAt = System.currentTimeMillis()
                    account.lastCheckMessage = "登录成功"
                    // 换账号必须重置风控状态：新账号没被限流，不该继承上一个号的分数
                    account.riskScore = 0
                    account.consecutiveFailures = 0
                    // ★ 验证模式：刚过完「请先验证身份」，账号还在风控脆弱期，
                    //   设一个静置期，期间不参与任何自动任务，避免再次触发。
                    account.restUntil = if (verifyMode) {
                        System.currentTimeMillis() + Prefs.verifyCooldownHours * 3600_000L
                    } else {
                        0L
                    }
                    // ★ 昵称只当「附加标记」，账号名里的序号**不能**被覆盖掉。
                    //   序号是用户在列表和签到结果里辨认账号的唯一依据；
                    //   微博昵称重复、改名、含特殊字符都会让「哪个账号没签上」变得无法对号。
                    //
                    // ★★ 这里**不许**再写 `account.label = ...`（v0.20.13 修，v0.20.16 再修一次）。
                    //   v0.20.15 的另一条工作流又把 `label = "账号 " + order + " · " + nickname`
                    //   写了回来 —— 上一行注释明明写着「序号不能被覆盖」，代码却在覆盖它，
                    //   典型的「注释与实现不一致」。这一行两头都坏：
                    //     ① AccountStore.normalizeOrdering() 每次启动都会把 label 重置成「账号 N」，
                    //        这行字**活不过一次重启**，用户下次打开又变回「账号 3」——
                    //        正是用户报「把账号 1，2，3 换成对应的微博名称」的直接原因；
                    //     ② 万一没被重置，displayName 就会拼成「小明（账号 3 · 小明）」。
                    //   → 昵称只存进 nickname，显示形式统一由 WeiboAccount 的
                    //     title / orderTag / displayName 三个属性算出来，只有一处定义。
                    account.nickname = nickname
                    AccountStore.save()
                    if (verifyMode) {
                        Toast.makeText(
                            this,
                            "「" + account.displayName + "」验证通过，已静置 " +
                                Prefs.verifyCooldownHours + " 小时（到期自动恢复）",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Toast.makeText(this, "「" + account.displayName + "」登录成功", Toast.LENGTH_SHORT).show()
                    }
                    finish()
                } else {
                    account.verified = false
                    account.cookie = ""
                    AccountStore.save()
                    Toast.makeText(this, "登录未完成，请重新扫码或使用短信登录", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun collectCookieHeader(): String {
        val mobileRaw = CookieManager.getInstance().getCookie("https://m.weibo.cn").orEmpty()
        val mobileValues = parseCookieValues(mobileRaw)
        if (mobileValues.containsKey("SUB")) {
            return mobileValues.entries.joinToString("; ") { "${it.key}=${it.value}" }
        }

        val values = linkedMapOf<String, String>()
        values.putAll(mobileValues)
        for (url in listOf("https://weibo.com", "https://passport.weibo.com")) {
            val raw = CookieManager.getInstance().getCookie(url) ?: continue
            values.putAll(parseCookieValues(raw))
        }
        return values.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    /**
     * 采集 PC 端（weibo.com）cookie，供超话发帖用。
     *
     * ★ 发帖走 weibo.com/p/aj/proxy（PC 代理接口），必须用 .weibo.com 域的
     *   登录 cookie —— m.weibo.cn 那份不通用。登录经过 passport.weibo.com
     *   （它就在 weibo.com 域上），SSO 时会把 PC cookie 也种进 WebView，这里专门取出来。
     */
    private fun collectPcCookieHeader(): String {
        val values = linkedMapOf<String, String>()
        for (url in listOf("https://weibo.com", "https://passport.weibo.com")) {
            val raw = CookieManager.getInstance().getCookie(url).orEmpty()
            values.putAll(parseCookieValues(raw))
        }
        return values.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    private fun parseCookieValues(raw: String): Map<String, String> {
        val values = linkedMapOf<String, String>()
        for (part in raw.split(";")) {
            val item = part.trim()
            val index = item.indexOf('=')
            if (index <= 0) continue
            val name = item.substring(0, index).trim()
            val value = item.substring(index + 1).trim()
            if (value.isNotEmpty()) values[name] = value
        }
        return values
    }

    /**
     * 非 http/https 的跳转怎么处理。
     *
     * ★ 微博完成验证后会跳到各种深链（`weibo://` / `sinaweibo://` / `intent://` …），
     *   WebView 自己处理不了。
     *
     * ★★ 旧实现直接 `return true` 静默拦掉 —— 这挡住了崩溃，但也可能**挡住验证本身**：
     *   有些验证流程必须靠微博客户端才能走完，静默拦掉会让用户永远卡在这一步。
     *   所以这里改成：**尝试交给系统打开**；没有应用能处理就安静取消。
     *
     * ★ 关键是 try/catch(Throwable)：没有应用能响应时系统抛的是
     *   `ActivityNotFoundException`，不接住就是闪退 ——
     *   这正是「跳转闪退」的另一条常见路径。
     */
    private fun handleNavigation(url: String?): Boolean {
        if (url == null) return false
        if (url.startsWith("http://") || url.startsWith("https://")) return false
        try {
            val intent = if (url.startsWith("intent://")) {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (_: Throwable) {
            // 没有应用能处理这个 scheme：安静取消，绝不能让它抛到框架层
        }
        return true
    }

    /**
     * 渲染进程被杀之后的收尾（触发原因见 WebViewClient.onRenderProcessGone 的注释）。
     *
     * ★ 为什么拆成独立函数、不写在匿名对象里：
     *   匿名 `object : WebViewClient()` 里的 `this` 是 **WebViewClient 不是 Activity**，
     *   直接写 `Toast.makeText(this, …)` 会编译不过（WebViewClient 不是 Context）。
     *   本机没有编译器，这种错只能等 CI 报 —— 拆出来就不给它出错的机会。
     */
    private fun handleRendererGone(view: WebView?) {
        try {
            Toast.makeText(
                this,
                "网页组件被系统回收了（多半是内存不足）。返回后重试一次即可。",
                Toast.LENGTH_LONG
            ).show()
        } catch (_: Throwable) {
        }
        try {
            (view?.parent as? ViewGroup)?.removeView(view)
            view?.destroy()
        } catch (_: Throwable) {
        }
        try {
            if (!isFinishing && !isDestroyed) finish()
        } catch (_: Throwable) {
        }
    }

    override fun onDestroy() {
        finished = true
        // ★★ v0.20.17：重写收尾顺序。原来那版（另一条工作流）虽然也 try/catch 了，
        //   但顺序和动作都有问题：
        //
        //   ① 先 `loadUrl("about:blank")` —— 在 Activity 正在销毁时**发起一次导航**，
        //      本身就是「跳转过程中闪退」的经典触发点；而且它引发的 native 崩溃
        //      是 catch(Exception) 接不住的。
        //   ② 没有先把 WebView 从视图树里摘下来 —— destroy 之后父容器仍可能
        //      去测量/绘制它，属于未定义行为。
        //   ③ 没有断开我们自己的回调 —— destroy 过程中的回调会跑进 trySaveCookies。
        //
        //   现在的顺序：摘出视图树 → 断开回调 → stopLoading → destroy。
        //   ★ 不再调用 loadUrl("about:blank")：断开回调之后，它的唯一作用
        //     （阻止旧页面的回调进来）已经没有了，留着只剩风险。
        try {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.webChromeClient = null
            webView.webViewClient = WebViewClient()
            webView.stopLoading()
            webView.removeAllViews()
            webView.destroy()
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }

    companion object {
        /** 要登录到哪个账号槽位。不传时退回到第一个账号。 */
        const val EXTRA_ACCOUNT_ID = "account_id"

        /**
         * 验证模式：不清 Cookie，直接带着该账号的会话打开微博，
         * 让用户完成「请先验证身份」。
         */
        const val EXTRA_VERIFY_MODE = "verify_mode"
    }
}
