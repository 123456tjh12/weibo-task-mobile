package com.tjh.weibotask

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * 互动任务的唯一数据源。
 *
 * ★★ 为什么**不能**直接塞进 [AccountStore]：
 *   `AccountStore.save()` 是**整表覆盖**（把内存里那份账号列表整个序列化写回去）。
 *   互动任务如果和账号存在同一个对象里，那么「加一个互动任务」这个动作
 *   就会顺带把账号表重写一遍 —— 而账号表里躺着 `restUntil` / `needsVerify` /
 *   `lastRunDate` / `lastRunAt` 这四个**签到链路正在用的判定字段**。
 *   一旦那次重写的时机和签到链路撞上（签到执行中把账号标成「今日已完成」，
 *   这边同时把内存里的旧快照写回去），账号的当日状态就会被回滚 ——
 *   表现就是「明明签过了，第二天又签一遍」或者「明明没签，今天被跳过」。
 *
 *   ⇒ 所以这里**另开一个私有文件**，和 `slider_trace` 同一个思路：
 *     互动功能的数据全部自包含，删掉它不影响四条核心链路。
 *
 * ★ 边界：不读不写 [Prefs]、不读不写 [AccountStore]、不调 `AccountStore.save()`。
 */
object InteractTaskStore {

    private const val STORE_NAME = "interact_tasks"
    private const val KEY_TASKS = "tasks"

    /**
     * ★★★ 第 84 期：超Like 一键编排的配比存这个键。
     *
     * ★ 为什么放在**同一个私有文件**里而不是新开一个：它和任务一样，
     *   是这个互动模块自己的数据，生命周期、清理方式、与账号数据的隔离边界
     *   都完全一样。多开一个 `SharedPreferences` 只会多一处要记得初始化。
     * ★ 它是一个**单对象**（不是数组）：界面上只有一套编排设置。
     */
    private const val KEY_PLAN = "superlike_plan"

    /**
     * ★★★★ 第 102 期：**今天**「一键跑超Like」的累计成果存这个键。
     *
     * ## 为什么从「最近一次」改成「今天累计」
     *
     * 第 99 期存的是**最近一次**结果，于是用户遇到一个看着像故障的现象：
     * 跑过一趟（首评 4 / 4、转发 2 / 2）之后**再跑一趟**，那一行变成
     * 「首评 0 / 4 · 转发 0 / 2」—— 明明该做的都做完了，却像什么都没做。
     *
     * ★ 那个 0 本身**不是故障**：候选池只收「回包明确说 0 条评论」的帖子，
     *   转发还会剔掉「最近已经转过」的帖子（见 [SuperLikeRunner]）——
     *   这是两道**故意设的安全闸**，防的就是重复评论 / 重复转发。
     * ★ 真正的毛病在**显示**：第 99 期是「后一次覆盖前一次」，
     *   于是一趟空跑就能把已经达成的成绩冲掉。
     *
     * ⇒ 第 102 期改成**按「超话 + 账号」当天累加**：
     *   跑第二趟 0 条也不会把 4 / 4 冲掉，跨天自动归零。
     *   用户原话：「你可以显示该微博首评四条，转发两条已经完成了」。
     *
     * ★ 存储形状：`{"date":"2026-10-11","items":{"<超话id>|<账号label>":{…5 个数字…}}}`
     *   —— 整张表共用一个 `date`，跨天一次性作废
     *   （比逐条带日期简单，也不会漏清某一条）。
     * ★ 和 [KEY_PLAN] 放同一个私有文件的理由完全一样（见上）。
     */
    private const val KEY_TODAY_DONE = "superlike_today_done"

    private val tasks = mutableListOf<InteractTask>()

    /** ★ 第 84 期：超Like 编排的配比。`null` = 还没存过（用官方默认配比）。 */
    private var plan: SuperLikePlan? = null

    /** ★ 第 102 期：今天累计成果所在的那一天（`yyyy-MM-dd`）。空 = 还没记过。 */
    private var todayDoneDate = ""

    /** ★ 第 102 期：今天累计成果。键 = `<超话id>|<账号label>`，值 = 那 5 个数字。 */
    private var todayDoneItems: JSONObject? = null

    private var store: SharedPreferences? = null
    private var loaded = false

    /** 读盘。**必须在用之前调用一次**；同一进程内重复调用无副作用。 */
    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        val sp = try {
            context.applicationContext.getSharedPreferences(STORE_NAME, Context.MODE_PRIVATE)
        } catch (_: Throwable) {
            null
        }
        store = sp
        tasks.clear()
        try {
            val raw = sp?.getString(KEY_TASKS, "").orEmpty()
            if (raw.isNotBlank()) {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    tasks.add(InteractTask.fromJson(item))
                }
            }
        } catch (_: Throwable) {
            // 解析失败当成空列表：一份坏数据不该让互动页打不开。
            tasks.clear()
        }
        // ★ 第 84 期：超Like 配比。同样**读坏了就回到默认**，绝不因为一份坏数据
        //   让整页打不开 —— 它只是一个「上次填的值」。
        plan = try {
            val raw = sp?.getString(KEY_PLAN, "").orEmpty()
            if (raw.isBlank()) null else SuperLikePlan.fromJson(JSONObject(raw))
        } catch (_: Throwable) {
            null
        }
        // ★ 第 102 期：今天的累计成果。同一条纪律 —— **读坏了就当没跑过**，
        //   绝不因为一行提示的数据坏掉让整页打不开。
        //   ★ 跨天自动作废：只认「今天」那一份，旧的连读都不读（也就自然归零）。
        todayDoneDate = ""
        todayDoneItems = null
        try {
            val raw = sp?.getString(KEY_TODAY_DONE, "").orEmpty()
            if (raw.isNotBlank()) {
                val root = JSONObject(raw)
                val date = root.optString("date")
                if (date == todayKey()) {
                    todayDoneDate = date
                    todayDoneItems = root.optJSONObject("items") ?: JSONObject()
                }
            }
        } catch (_: Throwable) {
            todayDoneDate = ""
            todayDoneItems = null
        }
        loaded = true
    }

    @Synchronized
    fun all(): List<InteractTask> = tasks.toList()

    @Synchronized
    fun enabledCount(): Int = tasks.count { it.enabled }

    @Synchronized
    fun find(id: String): InteractTask? = tasks.firstOrNull { it.id == id }

    @Synchronized
    fun add(task: InteractTask) {
        tasks.add(task)
        save()
    }

    @Synchronized
    fun remove(id: String) {
        tasks.removeAll { it.id == id }
        save()
    }

    /** 就地改完字段后调用，把改动落盘。 */
    @Synchronized
    fun update(task: InteractTask) {
        val index = tasks.indexOfFirst { it.id == task.id }
        if (index < 0) return
        tasks[index] = task
        save()
    }

    /**
     * ★★★★ 第 56 期：真发过一次之后，把「上次执行」记到任务上。
     *
     * ## 为什么需要它
     *
     * [InteractTask] 从第 43 期起就有 `lastRunAt` / `lastResult` 两个字段，
     * 但它们**从来没人写过** —— 任务行上永远显示不出「上次执行」。
     * 用户点完「立即发送」只看到一次弹窗，回头再看任务，什么都没留下。
     * 这和「一眼看懂」是矛盾的：**这次到底发了没有、发成功没有，应该留在任务上**。
     *
     * ## 为什么用 `copy()` 换一个新实例，而不是就地改字段
     *
     * 1. **界面手上那个旧引用不会被偷偷改掉。** 就地改字段的话，
     *    界面上已经画好的那一行和内存里的是同一个对象，改一半就会画出半新半旧的状态；
     *    换成新实例后，界面必须**重新读一次**才会看到新值（`refreshTasks()` 本来就会重读）。
     * 2. **写的是互动任务自己的字段。** 这里的 `lastRunAt` 是 [InteractTask] 的，
     *    存在 `interact_tasks.xml` 里；和 [WeiboAccount] 上那个
     *    `lastRunAt`（第 41 期的跨天复活判据、签到链路在用）**是两个东西**，
     *    同名不同物。本文件对账号数据**一个字都不写**。
     *
     * @param id 任务 id；找不到就静默返回（任务可能已被删掉）
     * @param result 结果原文（成功是「已发出：评论 id=…」，失败是失败原因）
     * @param at 发生时刻，默认现在
     */
    @Synchronized
    fun markRun(id: String, result: String, at: Long = System.currentTimeMillis()) {
        val index = tasks.indexOfFirst { it.id == id }
        if (index < 0) return
        tasks[index] = tasks[index].copy(lastRunAt = at, lastResult = result)
        save()
    }

    private fun save() {
        val sp = store ?: return
        try {
            val array = JSONArray()
            for (task in tasks) array.put(task.toJson())
            sp.edit().putString(KEY_TASKS, array.toString()).apply()
        } catch (_: Throwable) {
            // 写盘失败静默。
        }
    }

    // ------------------------------------------------------------ 第 84 期：超Like 配比

    /**
     * ★★★ 第 84 期：超Like 编排的配比。
     *
     * ★ 没存过时返回**官方默认**（首评 4 + 转发 2，见 [SuperLikePlan]），
     *   而不是空对象 —— 用户第一次打开就该看到一个能直接点的计划。
     * ★ 返回的是**内存里那一份的副本语义**：调用方拿去改不会污染存储，
     *   要落盘必须显式调 [savePlan]。
     */
    @Synchronized
    fun plan(): SuperLikePlan = plan ?: SuperLikePlan()

    /**
     * ★★★ 第 84 期：把超Like 配比落盘。
     *
     * ★ 只写**这个模块自己的** `interact_tasks.xml` —— 不碰 [Prefs]、
     *   不碰 [AccountStore]、不调 `AccountStore.save()`（见文件头那段说明）。
     */
    @Synchronized
    fun savePlan(value: SuperLikePlan) {
        plan = value
        val sp = store ?: return
        try {
            sp.edit().putString(KEY_PLAN, value.toJson().toString()).apply()
        } catch (_: Throwable) {
            // 写盘失败静默：界面这一趟照常能跑，只是下次打开要重填。
        }
    }

    // ------------------------------------------------ 第 102 期：今天累计成果

    /**
     * ★★★★ 第 102 期：把这一趟的成果**累加**进「今天」。
     *
     * ★ **只记真跑**（[SuperLikeRunner.Outcome.at] > 0）——
     *   没账号 / 没 Cookie / 准备失败都是 `at = 0`，那些一个内容都没发出去，
     *   记进来只会把已经达成的成绩冲淡。试跑连 Outcome 都不产生。
     * ★ **累加而不是覆盖** —— 这正是本期要修的毛病（见 [KEY_TODAY_DONE]）。
     * ★ 累加值**不超过目标**（显示 `4 / 4` 而不是 `6 / 4`）：
     *   用户要看的是「今天做完了没有」，不是数学总和。
     * ★ 跨天自动重置。
     *
     * ★ 只写这个模块自己的 `interact_tasks.xml` —— 不碰 [Prefs]、不碰 [AccountStore]。
     *
     * @param topicId 超话 id（[InteractTarget.topicId] 归一化后的）；空串 = 不按超话分
     * @param label   账号键（`WeiboAccount.label`）；空串 = 不按账号分
     * @param value   这一趟真跑的结果
     */
    @Synchronized
    fun addTodayDone(topicId: String, label: String, value: SuperLikeRunner.Outcome) {
        if (value.at <= 0L) return
        resetTodayIfNeeded()
        val items = todayDoneItems ?: return
        val key = topicId + "|" + label
        // ★ 复用 [SuperLikeRunner.Outcome.fromJson]（`optInt` / `optLong` 兜底，
        //   缺字段不会抛）—— 不再手抄一遍字段名。
        val prev = try {
            items.optJSONObject(key)?.let { SuperLikeRunner.Outcome.fromJson(it) }
        } catch (_: Throwable) {
            null
        }
        val firstTarget = maxOf(prev?.firstTarget ?: 0, value.firstTarget)
        val repostTarget = maxOf(prev?.repostTarget ?: 0, value.repostTarget)
        val firstSum = (prev?.firstOk ?: 0) + value.firstOk
        val repostSum = (prev?.repostOk ?: 0) + value.repostOk
        // ★★★★ 第 140 期：失败数同样**累加**，但**不夹上限** ——
        //   「失败」不是「差几条达成」，今天试错几次就是几次，夹了就等于骗用户。
        val firstFailSum = (prev?.firstFail ?: 0) + value.firstFail
        val repostFailSum = (prev?.repostFail ?: 0) + value.repostFail
        val merged = SuperLikeRunner.Outcome(
            firstOk = if (firstTarget > 0) minOf(firstSum, firstTarget) else firstSum,
            firstTarget = firstTarget,
            repostOk = if (repostTarget > 0) minOf(repostSum, repostTarget) else repostSum,
            repostTarget = repostTarget,
            firstFail = firstFailSum,
            repostFail = repostFailSum,
            at = maxOf(prev?.at ?: 0L, value.at)
        )
        try {
            items.put(key, merged.toJson())
        } catch (_: Throwable) {
            return
        }
        saveTodayDone()
    }

    /**
     * ★★★★ 第 102 期：读「今天」的累计成果。
     *
     * ★ `topicId` 空 ⇒ **不按超话筛**（合计所有超话）；`label` 空 ⇒ **不按账号筛**
     *   （合计所有账号）。两个都空 = 今天所有超话所有账号的总和。
     * ★ 返回 `null` = 今天还没跑过（或记录已跨天作废）⇒ 界面显示引导语。
     * ★ 分母（目标）按参与的记录**相加** ⇒ 「所有账号轮流」时自然变成
     *   `8 / 8` 这种口径（每个账号各 4 条）。
     */
    @Synchronized
    fun todayDone(topicId: String, label: String): SuperLikeRunner.Outcome? {
        resetTodayIfNeeded()
        val items = todayDoneItems ?: return null
        var first = 0
        var firstTarget = 0
        var repost = 0
        var repostTarget = 0
        // ★★★★ 第 140 期：失败数也汇总（界面 per-account 行的「失败 N」读这里）。
        var firstFail = 0
        var repostFail = 0
        var at = 0L
        var found = false
        val keys = items.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            if (topicId.isNotBlank() && key.substringBefore('|') != topicId) continue
            if (label.isNotBlank() && key.substringAfter('|', "") != label) continue
            val item = try {
                items.optJSONObject(key)?.let { SuperLikeRunner.Outcome.fromJson(it) }
            } catch (_: Throwable) {
                null
            } ?: continue
            found = true
            first += item.firstOk
            firstTarget += item.firstTarget
            repost += item.repostOk
            repostTarget += item.repostTarget
            firstFail += item.firstFail
            repostFail += item.repostFail
            at = maxOf(at, item.at)
        }
        if (!found) return null
        return SuperLikeRunner.Outcome(first, firstTarget, repost, repostTarget, firstFail, repostFail, at)
    }

    /**
     * ★★★★ 第 103 期：按**账号**列出今天的成果（互动页要「每个账号一行」）。
     *
     * ## 为什么加它
     *
     * 用户原话：「**一键超like你要在下面显示哪些账号完成了首评，转发几条**……
     * 让客户更加直观的看到」。第 102 期那行是**把所有账号加在一起**的一个总数，
     * 看不出「谁做完了、谁还差几条」。
     *
     * ## 与 [todayDone] 的唯一区别
     *
     * [todayDone] 把命中的记录**相加**；本函数**每个账号单独返回一条**，不相加。
     * 键的形状是 `<超话id>|<账号label>`（见 [addTodayDone]），
     * 所以 `|` 后面那一段**直接就是账号名**（`WeiboAccount.label`），不用再查账号表。
     *
     * ★ 排序按账号名升序：同一份数据每次渲染顺序一致，界面不会自己跳。
     * ★ `topicId` 空 ⇒ **不按超话筛**（列出今天所有超话下的所有账号）。
     * ★ 返回空列表 = 今天还没跑过（或记录已跨天作废）⇒ 界面显示引导语。
     * ★ 只读这个模块自己的 `interact_tasks.xml` —— 不碰 [Prefs]、不碰 [AccountStore]。
     */
    @Synchronized
    fun todayDoneByAccount(topicId: String): List<Pair<String, SuperLikeRunner.Outcome>> {
        resetTodayIfNeeded()
        val items = todayDoneItems ?: return emptyList()
        val result = mutableListOf<Pair<String, SuperLikeRunner.Outcome>>()
        val keys = items.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            if (topicId.isNotBlank() && key.substringBefore('|') != topicId) continue
            val label = key.substringAfter('|', "")
            val item = try {
                items.optJSONObject(key)?.let { SuperLikeRunner.Outcome.fromJson(it) }
            } catch (_: Throwable) {
                null
            } ?: continue
            result.add(label to item)
        }
        result.sortBy { it.first }
        return result
    }

    /**
     * ★ 第 102 期：跨天了就把今天的账清空（**惰性**，不需要任何定时器）。
     *
     * ★ 判据是**日期串相等**，不是「过了多少小时」——
     *   用户要的是「每天重置」，按自然日算最不容易误解。
     */
    private fun resetTodayIfNeeded() {
        val today = todayKey()
        if (todayDoneDate == today && todayDoneItems != null) return
        todayDoneDate = today
        todayDoneItems = JSONObject()
    }

    /** ★ 第 102 期：把今天的账落盘（照 [savePlan] 的套路，同一个私有文件）。 */
    private fun saveTodayDone() {
        val sp = store ?: return
        try {
            val root = JSONObject()
                .put("date", todayDoneDate)
                .put("items", todayDoneItems ?: JSONObject())
            sp.edit().putString(KEY_TODAY_DONE, root.toString()).apply()
        } catch (_: Throwable) {
            // 写盘失败静默：这一趟的结果界面上照常看得到，只是下次打开要重跑。
        }
    }

    /**
     * ★ 第 102 期：今天的日期串（`yyyy-MM-dd`，本地时区）。
     *
     * ★ 刻意**在本文件内自造**、不去依赖 [LocalScheduler]：
     *   本文件的头号纪律是「互动数据完全自包含，删掉它不影响四条核心链路」，
     *   为一个日期串把互动模块挂到调度器上不值得。
     * ★ 这个串只和它自己比较（今天 vs 存下来的那天）⇒ 格式怎么定都自洽。
     */
    private fun todayKey(): String =
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
            .format(java.util.Date())
}
