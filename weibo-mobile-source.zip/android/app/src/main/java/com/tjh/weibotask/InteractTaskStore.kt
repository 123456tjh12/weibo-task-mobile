package com.tjh.weibotask

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/**
 * 互动任务的唯一数据源。
 *
 * ★★ 为什么**不能**直接塞进 [AccountStore]：
 *   `AccountStore.save()` 是**整表覆盖**（把内存里那份账号列表整个序列化写回去）。
 *   互动任务如果和账号存在同一个对象里，那么「加一个互动任务」这个动作
 *   就会顺带把账号表重写一遍 —— 而账号表里躺着 `restUntil` / `needsVerify` /
 *   `lastRunDate` / `lastRunAt` 这四个**签到链路正在用的判定字段**。
 *   一旦那次重写的时机和签到链路撞上（签到执行中把账号标成「今日已完成」，
 *   这边同时把内存里的旧快照写回去），账号的当日状态就会被回滚 ——
 *   表现就是「明明签过了，第二天又签一遍」或者「明明没签，今天被跳过」。
 *
 *   ⇒ 所以这里**另开一个私有文件**，和 `slider_trace` 同一个思路：
 *     互动功能的数据全部自包含，删掉它不影响四条核心链路。
 *
 * ★ 边界：不读不写 [Prefs]、不读不写 [AccountStore]、不调 `AccountStore.save()`。
 */
object InteractTaskStore {

    private const val STORE_NAME = "interact_tasks"
    private const val KEY_TASKS = "tasks"

    private val tasks = mutableListOf<InteractTask>()
    private var store: SharedPreferences? = null
    private var loaded = false

    /** 读盘。**必须在用之前调用一次**；同一进程内重复调用无副作用。 */
    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        val sp = try {
            context.applicationContext.getSharedPreferences(STORE_NAME, Context.MODE_PRIVATE)
        } catch (_: Throwable) {
            null
        }
        store = sp
        tasks.clear()
        try {
            val raw = sp?.getString(KEY_TASKS, "").orEmpty()
            if (raw.isNotBlank()) {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    tasks.add(InteractTask.fromJson(item))
                }
            }
        } catch (_: Throwable) {
            // 解析失败当成空列表：一份坏数据不该让互动页打不开。
            tasks.clear()
        }
        loaded = true
    }

    @Synchronized
    fun all(): List<InteractTask> = tasks.toList()

    @Synchronized
    fun enabledCount(): Int = tasks.count { it.enabled }

    @Synchronized
    fun find(id: String): InteractTask? = tasks.firstOrNull { it.id == id }

    @Synchronized
    fun add(task: InteractTask) {
        tasks.add(task)
        save()
    }

    @Synchronized
    fun remove(id: String) {
        tasks.removeAll { it.id == id }
        save()
    }

    /** 就地改完字段后调用，把改动落盘。 */
    @Synchronized
    fun update(task: InteractTask) {
        val index = tasks.indexOfFirst { it.id == task.id }
        if (index < 0) return
        tasks[index] = task
        save()
    }

    /**
     * ★★★★ 第 56 期：真发过一次之后，把「上次执行」记到任务上。
     *
     * ## 为什么需要它
     *
     * [InteractTask] 从第 43 期起就有 `lastRunAt` / `lastResult` 两个字段，
     * 但它们**从来没人写过** —— 任务行上永远显示不出「上次执行」。
     * 用户点完「立即发送」只看到一次弹窗，回头再看任务，什么都没留下。
     * 这和「一眼看懂」是矛盾的：**这次到底发了没有、发成功没有，应该留在任务上**。
     *
     * ## 为什么用 `copy()` 换一个新实例，而不是就地改字段
     *
     * 1. **界面手上那个旧引用不会被偷偷改掉。** 就地改字段的话，
     *    界面上已经画好的那一行和内存里的是同一个对象，改一半就会画出半新半旧的状态；
     *    换成新实例后，界面必须**重新读一次**才会看到新值（`refreshTasks()` 本来就会重读）。
     * 2. **写的是互动任务自己的字段。** 这里的 `lastRunAt` 是 [InteractTask] 的，
     *    存在 `interact_tasks.xml` 里；和 [WeiboAccount] 上那个
     *    `lastRunAt`（第 41 期的跨天复活判据、签到链路在用）**是两个东西**，
     *    同名不同物。本文件对账号数据**一个字都不写**。
     *
     * @param id 任务 id；找不到就静默返回（任务可能已被删掉）
     * @param result 结果原文（成功是「已发出：评论 id=…」，失败是失败原因）
     * @param at 发生时刻，默认现在
     */
    @Synchronized
    fun markRun(id: String, result: String, at: Long = System.currentTimeMillis()) {
        val index = tasks.indexOfFirst { it.id == id }
        if (index < 0) return
        tasks[index] = tasks[index].copy(lastRunAt = at, lastResult = result)
        save()
    }

    private fun save() {
        val sp = store ?: return
        try {
            val array = JSONArray()
            for (task in tasks) array.put(task.toJson())
            sp.edit().putString(KEY_TASKS, array.toString()).apply()
        } catch (_: Throwable) {
            // 写盘失败静默。
        }
    }
}
