package com.tjh.weibotask

import org.json.JSONObject
import java.util.UUID

/**
 * 互动动作的三种类型。
 *
 * ★ 这套词是从两个竞品里对齐出来的（它们叫法不一样，指的是同一件事）：
 *   - **评论** = 饭援的「评论」/ 豆星人的「评论任务」→ 在一条微博下发一条新评论
 *   - **互评** = 饭援的「楼评」/ 豆星人的「盖楼」→ 回复别人已有的评论（回某层楼）
 *   - **楼赞** = 饭援的「楼赞」/ 豆星人的「内赞」→ 给某层楼点赞
 *
 * ★ 为什么把「叫什么」也塞进枚举里：界面上的动作选择、任务行上的标签、
 *   干跑日志里的说法必须**同源**，否则改一次文案就要改三个地方，迟早不一致。
 */
enum class InteractAction(val labelRes: Int, val hintRes: Int) {
    COMMENT(R.string.interact_action_comment, R.string.interact_hint_comment),
    REPLY(R.string.interact_action_reply, R.string.interact_hint_reply),
    LIKE(R.string.interact_action_like, R.string.interact_hint_like);

    companion object {
        /** 老数据里没有这个字段时的兜底。 */
        fun fromName(value: String): InteractAction =
            entries.firstOrNull { it.name == value } ?: COMMENT
    }
}

/**
 * 一个互动任务：对「哪条微博」做「哪种动作」，用「哪个账号」和「哪组语料」。
 *
 * ★ 设计上刻意保持**扁平**：一个任务就是一个目标 + 一个动作。
 *   竞品那种「任务家族」把目标、语料、频率拆成三层配置，配置项一多，
 *   用户就不知道自己到底会让账号干什么了 —— 而这个功能的代价是账号本身。
 *
 * ★ 字段全部是本功能自己的，**没有一个字段是 [WeiboAccount] 上的**。
 *   这是「加它不影响其他功能」的物理保证：账号的状态机（restUntil /
 *   needsVerify / lastRunAt / lastRunDate）在这里**根本没有对应的写入口**。
 */
data class InteractTask(
    var id: String = UUID.randomUUID().toString(),
    var action: InteractAction = InteractAction.COMMENT,
    /** 目标：微博链接或纯数字 ID（mid）。楼评 / 楼赞时同一栏填楼层标识。 */
    var target: String = "",
    /** 备注，只有用户自己看得到（例如「给账号 1 用」）。 */
    var note: String = "",
    /** 指定账号（按 [WeiboAccount.label]，如「账号 1」）；空串 = 所有可用账号轮流。 */
    var accountLabel: String = "",
    /** 语料分组 id；空串 = 用第一个分组。 */
    var groupId: String = "",
    var enabled: Boolean = true,
    var createdAt: Long = System.currentTimeMillis(),
    var lastRunAt: Long = 0L,
    var lastResult: String = ""
) {

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("action", action.name)
        .put("target", target)
        .put("note", note)
        .put("accountLabel", accountLabel)
        .put("groupId", groupId)
        .put("enabled", enabled)
        .put("createdAt", createdAt)
        .put("lastRunAt", lastRunAt)
        .put("lastResult", lastResult)

    companion object {
        fun fromJson(source: JSONObject): InteractTask = InteractTask(
            id = source.optString("id").ifBlank { UUID.randomUUID().toString() },
            action = InteractAction.fromName(source.optString("action")),
            target = source.optString("target"),
            note = source.optString("note"),
            accountLabel = source.optString("accountLabel"),
            groupId = source.optString("groupId"),
            // 默认启用：老数据没有这个字段时不能让任务静默变成「停用」
            enabled = source.optBoolean("enabled", true),
            createdAt = source.optLong("createdAt"),
            lastRunAt = source.optLong("lastRunAt"),
            lastResult = source.optString("lastResult")
        )
    }
}
