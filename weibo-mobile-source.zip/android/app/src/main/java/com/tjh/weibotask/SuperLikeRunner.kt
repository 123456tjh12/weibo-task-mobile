package com.tjh.weibotask

import android.content.Context
import org.json.JSONObject
import kotlin.random.Random

/**
 * ★★★★ 第 84 期：**超Like 一键编排**的执行器。
 *
 * ## 它做什么（规格来自竞品，逐条对齐）
 *
 * 微博官方「超Like」= **超话签到 ×1 + 首评 ×4 + 转发 ×2**。
 * 签到不在这里（原因见 [SuperLikePlan]），本文件只做后两件：
 *
 *   ① **捞帖**：把超话的帖子列表整页取回来（只读）；
 *   ② **筛首评候选**：只留 `comments_count == 0` 的帖子；
 *   ③ **首评 ×N**：对候选帖发一条评论 → **读回来核对 `floor_number == 1`**；
 *   ④ **转发 ×M**：跳过最近已经转过的帖子，再发转发。
 *
 * ## 「首评」为什么要核对 —— 这是竞品最值钱的一条
 *
 * 竞品界面上的文案把这件事说透了：
 *   · 「暂未找到新的 0 评论帖子」
 *   · 「刚刚被抢首评，未计数，继续找帖」
 *   · 「已核对到上次评论但不是首评」
 *   · 「已核对到上次首评成功（floor_number=1）」
 * ⇒ 它把「抢到第 1 楼」当成**必须核对的事实**，不是「发出去就算」。
 *   星签照做：评论发出后**再读一次评论列表**，看自己那条的楼层号。
 *
 * ## 三种核对结果怎么算（**计数规则**）
 *
 * | 核对结果 | 判据 | 是否计入 |
 * |---|---|---|
 * | 抢到了 | 自己那条 `floor_number == 1` | ✅ 计入 |
 * | 被抢先 | 自己那条 `floor_number > 1` | ❌ **不计入**，继续找下一条帖子 |
 * | 回包没给楼层号 | 列表里**一条**都没有 `floor_number` 字段 | ✅ 计入（判据降级，整趟只提示一次） |
 * | 列表里还没有自己那条 | 列表有评论，但找不到 `uid == 自己` | ✅ 计入（刚发出，还没进列表） |
 * | **列表整个没读到** | `listComments` 返回空 | ✅ 计入（这是「读不到」，不是「没抢到」） |
 *
 * ★ 为什么后两种也计入：`postComment` 回的是 `ok:1` + 新评论 id，
 *   说明**评论确实创建了**。不计入的话循环会继续去评下一条帖子，
 *   结果就是「为了凑数多评了好几条」—— 那比少算一条糟得多。
 * ★ 为什么「被抢先」不计入：那一条**不是首评**，官方不认，计进去等于骗用户。
 *
 * ## 硬边界
 *
 * ★ 不碰 [Prefs]、不写 [AccountStore]、不走 [WeiboClient]。
 * ★ 写请求只走 [InteractProbe] 里**已经真机验证过**的那两个函数
 *   （[InteractProbe.postComment] / [InteractProbe.postRepost]），本文件不自己拼请求。
 * ★ **尝试次数有上限**（[MAX_FIRST_ATTEMPTS]）：最多对 **10 条**帖子发评论（第 100 期起；
 *   第 99 期及以前是「首评条数 × 2」）。
 *   没有这个上限的话，「一直被抢先」会把整个超话的帖子全评一遍。
 * ★ 每条写请求之间有 1.5~4 秒停顿（见 [pause]）。
 * ★ 会阻塞（每个动作一或多次网络往返），调用方**必须**放后台线程。
 */
object SuperLikeRunner {

    /** 两条写请求之间的停顿下限（毫秒）。 */
    private const val PAUSE_MIN_MS = 1500L

    /** 两条写请求之间的停顿上限（毫秒）。 */
    private const val PAUSE_MAX_MS = 4000L

    /**
     * ★★★ 第 105 期：有 [Monitor] 时，停顿被切成多大一片（毫秒）。
     *
     * 为什么切：没有监控口时一次 `Thread.sleep` 睡完就行；有了监控口，
     * 就必须在「暂停」和「停止」按下的**最多 200ms 内**反应过来 ——
     * 一次睡 4 秒的话，用户点了停止还要等 4 秒才有动静。
     */
    private const val PAUSE_SLICE_MS = 200L

    /** 读自己时间线时最多看多少条。 */
    private const val TIMELINE_LIMIT = 20

    /**
     * ★★★★ 第 100 期：首评的**尝试次数上限（绝对条数）**。
     *
     * ## 为什么从「倍数」改成「绝对条数」
     *
     * 第 99 期及以前这里是 `ATTEMPT_FACTOR = 2`，即最多试 `首评条数 × 2` 条帖子
     * （要 4 条 ⇒ 最多试 8 条）。用户第 100 期的原话是
     * 「首评确认零条，你不能 100% 抢到就继续重试啊」⇒ 上限放宽成**绝对 10 条**：
     * 只要超话里有足够多「还没人评论」的帖子，就一直换下一条继续抢，
     * 直到抢够目标条数、或把候选试完、或试满 10 条为止。
     *
     * ## 上限为什么还必须有
     *
     * 首评的判据是「抢到第 1 楼」，而被抢先随时会发生。**完全没有上限**的话，
     * 一个全被抢的超话会让我们把整页帖子评一遍 —— 那是几十条评论，
     * 代价全落在账号上，而且正是最容易招风控的形态。
     * 10 与 [SuperLikePlan.MAX_FIRST] 同值 ⇒「一次点击最多 10 条首评」这条边界不变。
     */
    private const val MAX_FIRST_ATTEMPTS = 10

    /**
     * ★★★★ 第 87 期：**命中就立刻停手**的「账号级」错误码。
     *
     * ## 起因（2026-10-09 真机日志）
     *
     * 账号「伟大族丝」转发第 2 条时，微博回 `20016 / 操作频繁，请您稍后再试`。
     * 这是**账号级**限流 —— 换哪条帖子结果都一样。但当时的代码把它当成
     * 「这条帖子不行」，`continue` 去换下一条 ⇒ 对剩余 **13 条**帖子各打了一次，
     * 19 秒内共 14 个写请求。**在已经被限流的情况下继续加压，只会让风控更重。**
     *
     * ## 判据只认结构，不认文案
     *
     * 用 [InteractProbe.SendOutcome.errno]（微博原样给的错误码），
     * **绝不**去 `detail` 里搜「操作频繁」这种词 —— 那是「认文案」，
     * 第 20 条纪律明令禁止（文案会改、会翻译、会加装饰，判据一认它就随时失效）。
     *
     * ## 表里只放**实测或已确证**的账号级码，不猜
     *
     *   · `20016` —— 操作频繁（2026-10-09 真机实测）
     *   · `100006` —— 请求非法 / 缺 st / 未登录（第 84 / 85 期已确证是**最外层通用拒绝**）
     *   · [InteractProbe.ERRNO_NO_ST] —— 连一次性票据都没取到，请求根本没发出去
     *
     * ★ **目标级**的错误码**故意不在这里**。例如 `20130 暂无查看权限`
     *   （这条微博不让评）—— 那种「换下一条」是**对的**，必须继续换。
     *   把目标级也塞进来，会让一次偶发的单帖失败白白终止整趟编排。
     */
    private val STOP_ERRNOS = setOf(
        "20016",
        "100006",
        InteractProbe.ERRNO_NO_ST
    )

    /**
     * ★★★ 第 105 期：**运行态观察口** —— 给界面的「然屯速递」那一条卡用。
     *
     * ## 为什么要有它
     *
     * 第 105 期用户要的是「跑的时候能看见跑到哪了，还能中途暂停 / 停止」。
     * 但 [run] 只会阻塞几分钟然后返回一个 [Outcome] —— 中间发生了什么，
     * 界面一概不知道，更别说插手。
     *
     * ## 三条硬边界（改了任何一条都会让编排变味）
     *
     * 1. **纯可选**：所有方法都有默认空实现，`monitor == null` 时
     *    [run] 的行为与第 104 期**逐字节等价**（原有调用方什么都不用改）。
     * 2. **判据只认结构**：数字全部来自 [run] 自己的计数（`firstOk` / `repostOk`），
     *    界面**不许**回头去解析 [Outcome.text]（第 20 条纪律）。
     * 3. **暂停只发生在两条写请求之间**：[pause] 本来就要停 1.5~4 秒，
     *    暂停门就挂在那儿 —— 绝不会把一次「已发出、还没核对」的评论打断在半空。
     *
     * ## 线程
     *
     * 所有回调都在 [run] 所在的线程（调用方开的后台线程）上被调用 ⇒
     * 回调里**只做轻量的事**（翻牌子、改界面要自己 `runOnUiThread`）。
     * [awaitResume] 允许阻塞，这是唯一被允许「慢」的方法。
     */
    interface Monitor {

        /** 已经开始跑（连目标数一起给，界面要把分母先画出来）。 */
        fun onStart(firstTarget: Int, repostTarget: Int) {}

        /** 有数字变化就报一次（首评 / 转发各 +1 的那一刻）。 */
        fun onProgress(firstOk: Int, firstTarget: Int, repostOk: Int, repostTarget: Int) {}

        /** 一条给人看的进度文本，例如「正在提交第 2 / 4 条首评」。 */
        fun onMessage(text: String) {}

        /** 用户点了「停止」⇒ 返回 true 就尽快收手（当前这条做完为止）。 */
        fun shouldStop(): Boolean = false

        /**
         * 用户点了「暂停」⇒ 这个方法要**阻塞**到用户按「继续」为止。
         *
         * @return true = 别等了，直接收手（用户在暂停期间点了停止）。
         */
        fun awaitResume(): Boolean = false
    }

    /** 首评核对的结果。 */
    private enum class FirstVerdict {
        /** 自己那条是第 1 楼 —— 真首评。 */
        FIRST,
        /** 自己那条不是第 1 楼 —— 被抢先了。 */
        LOST,
        /** 列表里一条都没有楼层号字段 —— 判据降级。 */
        NO_FLOOR,
        /** 列表里有评论，但还没有自己那条 —— 刚发出，还没进列表。 */
        NOT_LISTED,
        /** **评论列表整个没读到**（空回包 / 解析失败）—— 与 NOT_LISTED 不同，是读的问题。 */
        NO_READ
    }

    /** 一次核对的结果：判定 + 楼层号（-1 = 不知道）。 */
    private class FirstCheck(val verdict: FirstVerdict, val floor: Int)

    /** 「前期准备」的结果。 */
    private class Prepared(
        val posts: List<InteractProbe.LatestPost>,
        val zeroComment: List<InteractProbe.LatestPost>,
        /** `null` = **读不到**时间线（UNKNOWN），不是「没转过」。 */
        val repostedMids: Set<String>?
    )

    /**
     * ★★★ 第 99 期：一次「一键跑超Like」的**结果**（数字 + 整段文字）。
     *
     * ## 为什么要这个类
     *
     * 用户要求「跑完在按钮下面一眼看到首评 / 转发各成了几条」。
     * 原来 [run] 只返回一段**给人看的文字**，界面想拿数字就只能去解析那几行 ——
     * 那正是第 20 条纪律禁止的「判据认文案」（文案会改、会翻译，一改就失效）。
     * ⇒ 把数字**结构化**带出来，文字照旧原样保留（第 84 期起逐字未变）。
     *
     * ## 目标数为什么要一起带
     *
     * 界面要印成「首评 3 / 4 条」——分母就是**这一次的计划**
     * （[SuperLikePlan.firstComments] / [SuperLikePlan.reposts]），
     * 不带上就得让界面再算一遍，多一处可能算错的地方。
     *
     * ## 落盘
     *
     * [toJson] **只写数字**：整段文字只是这一次的日志摘要（本来也已经逐行进了互动日志），
     * 存下来只会让盘里的东西越滚越大。所以 [fromJson] 读回来的 [text] 恒为空串。
     */
    class Outcome(
        /** 这次真跑**确认成**的首评条数。 */
        val firstOk: Int,
        /** 这一次计划要的首评条数（分母）。 */
        val firstTarget: Int,
        /** 这次真跑**成功**的转发条数。 */
        val repostOk: Int,
        /** 这一次计划要的转发条数（分母）。 */
        val repostTarget: Int,
        /** 完成时间（毫秒）。0 = 不知道（例如从盘里读回来的旧记录）。 */
        val at: Long = 0L,
        /** 给人看的整段结果文字。落盘时**不存**。 */
        val text: String = "",
        /**
         * ★★ 第 100 期：**需要单独弹一个短提示**的行（空 = 一切正常，不用打扰用户）。
         *
         * ## 为什么要它
         *
         * 用户要求「**我不要这个编排结果，直接告诉我答案，首评了几条，转发了几条**」
         * ⇒ 界面不再弹那个多行对话框，只在「一键跑超Like」下面那行显示数字。
         * 但有些情况**用户必须知道**，否则他永远不明白为什么是 0 条：
         * 没有评语可发 / 没账号 / 读不出超话 / 被微博限流 / 账号到上限。
         *
         * ## 为什么是 `List<String>` 而不是 `Boolean`
         *
         * 弹出去的那句话必须是**已经取好的人类文案**，不能让界面再去猜原因。
         * ★ 判据仍然是**结构**（只在明确的分支里 `add`），
         *   **不是**回头去解析 [text]（第 20 条纪律）。
         * ★ 与 [text] 一样**不落盘** —— [toJson] 只写数字。
         */
        val alerts: List<String> = emptyList()
    ) {

        /** 只把数字落盘。 */
        fun toJson(): JSONObject = JSONObject()
            .put("firstOk", firstOk)
            .put("firstTarget", firstTarget)
            .put("repostOk", repostOk)
            .put("repostTarget", repostTarget)
            .put("at", at)

        companion object {

            /**
             * 从盘里读回。
             *
             * ★ 用 `optInt` / `optLong` 而不是 `getInt`：老版本存下的记录可能缺字段，
             *   缺一个字段就抛异常会让整页打不开 —— 一个「上次跑成几条」不值得。
             */
            fun fromJson(o: JSONObject): Outcome = Outcome(
                firstOk = o.optInt("firstOk", 0),
                firstTarget = o.optInt("firstTarget", 0),
                repostOk = o.optInt("repostOk", 0),
                repostTarget = o.optInt("repostTarget", 0),
                at = o.optLong("at", 0L)
            )
        }
    }

    // ---------------------------------------------------------------- 只读试跑

    /**
     * **只读试跑**：把捞帖、筛 0 评论、读时间线这三步全走一遍，**一个写请求都不发**。
     *
     * ★ 为什么要它：这三步都是**只读 GET**，不消耗任何额度、不产生任何内容。
     *   用户可以先看清「这个超话现在有几条 0 评论的帖子」「我最近转过哪几条」，
     *   再决定要不要真跑 —— 和 [InteractRunner.rehearse] 是同一个思路。
     * ★ 会阻塞，必须在后台线程调用。
     */
    fun rehearse(context: Context, plan: SuperLikePlan, account: WeiboAccount?): String {
        val lines = mutableListOf<String>()
        lines.add(
            context.getString(
                R.string.interact_superlike_plan, plan.firstComments, plan.reposts
            )
        )
        lines.add(context.getString(R.string.interact_superlike_scope))

        if (account == null) {
            lines.add(context.getString(R.string.interact_superlike_no_account))
            return finish("[超Like·试跑]", lines)
        }
        if (account.cookie.isBlank()) {
            lines.add(context.getString(R.string.interact_rehearse_no_cookie))
            return finish("[超Like·试跑]", lines)
        }

        if (prepare(context, plan, account, lines) == null) return finish("[超Like·试跑]", lines)
        lines.add(context.getString(R.string.interact_superlike_rehearse_done))
        return finish("[超Like·试跑]", lines)
    }

    // ---------------------------------------------------------------- 真跑

    /**
     * **一键跑超Like**：首评 ×N + 转发 ×M。
     *
     * ★★ 第 100 期：**没有总开关了**。原来开头有一道「真发开关关着就一个写请求都不发」，
     *   那个开关已按用户要求删除 ⇒ 点下去就是真的发。想只看不发请用 [rehearse]。
     * ★ 会阻塞（可能几十秒到一两分钟），必须在后台线程调用。
     *
     * ★★★ 第 99 期：返回 [Outcome]（数字 + 文字），不再是裸的 String ——
     *   界面要拿「首评 3 / 4 条」这样的数字，**不许**去解析那段文字（第 20 条纪律）。
     *   没有真跑成的分支（没账号 / 没 Cookie / 准备失败）数字一律为 0，
     *   但**目标数照样带上**（界面那行提示要说清「0 / 4」而不是「0 / 0」）。
     */
    fun run(
        context: Context,
        plan: SuperLikePlan,
        account: WeiboAccount?,
        /**
         * ★★★ 第 105 期：运行态观察口（界面的「然屯速递」）。`null` = 老用法，
         *    行为与第 104 期完全一致。
         */
        monitor: Monitor? = null
    ): Outcome {
        val lines = mutableListOf<String>()
        // ★★ 第 100 期：需要**单独弹一个短提示**的行（判据是结构，不是解析 lines）。
        val alerts = mutableListOf<String>()
        lines.add(
            context.getString(
                R.string.interact_superlike_plan, plan.firstComments, plan.reposts
            )
        )

        if (account == null) {
            val text = context.getString(R.string.interact_superlike_no_account)
            lines.add(text)
            alerts.add(text)
            return Outcome(
                0, plan.firstComments, 0, plan.reposts,
                text = finish("[超Like]", lines), alerts = alerts
            )
        }
        if (account.cookie.isBlank()) {
            val text = context.getString(R.string.interact_rehearse_no_cookie)
            lines.add(text)
            alerts.add(text)
            return Outcome(
                0, plan.firstComments, 0, plan.reposts,
                text = finish("[超Like]", lines), alerts = alerts
            )
        }

        // ★★★ 第 105 期：准备阶段是纯只读（捞帖 / 筛 0 评论 / 读时间线），
        //   但它要打好几个网络往返 ⇒ 先把这句话告诉界面，别让用户以为卡住了。
        monitor?.onMessage(context.getString(R.string.interact_superlike_live_preparing))
        val prepared = prepare(context, plan, account, lines)
        if (prepared == null) {
            // ★ `prepare` 只在「超话 ID 读不出来」时返回 null（它自己已经往 lines 里写了原因）。
            val text = context.getString(R.string.interact_superlike_bad_topic)
            alerts.add(text)
            return Outcome(
                0, plan.firstComments, 0, plan.reposts,
                text = finish("[超Like]", lines), alerts = alerts
            )
        }
        val label = account.label
        val shown = account.displayName
        // ★ 只取一次 uid：ownUid 每次都发一次 GET，循环里绝不能重复调。
        val ownUid = InteractProbe.ownUid(account)
        // ★★★ 第 105 期：真的要开始写请求了 —— 把目标数交给界面画分母。
        monitor?.onStart(plan.firstComments, plan.reposts)
        // 用户在中途点了「停止」⇒ 记下来，收尾时在结果里写一行（不然后面看不懂为什么少了）。
        var aborted = false

        // ---------------------------------------------------------- ① 首评
        var firstOk = 0
        var index = 0
        // ★★★ 第 100 期：上限从「首评条数 × 2」改成**绝对条数**（[MAX_FIRST_ATTEMPTS]）。
        //   用户要求「抢不到就继续重试」⇒ 只要候选够，就一直换下一条接着抢。
        val cap = minOf(prepared.zeroComment.size, MAX_FIRST_ATTEMPTS)
        val usedForFirst = mutableSetOf<String>()
        var resting = false
        // ★ 第 87 期：命中账号级错误码后置 true ⇒ **后面每一步都不做了**（含转发那一段）。
        var stopped = false
        // ★ 判据降级是**整趟只报一次**的事：每条都印一遍会把结果刷屏，
        //   而它其实是同一件事（这个接口就是不给楼层号）。
        var degradedShown = false

        while (firstOk < plan.firstComments && index < cap) {
            if (isResting(context, label, shown, lines, alerts)) {
                resting = true
                break
            }
            // ★★★ 第 105 期：用户点了「停止」⇒ 立刻收手（不领新的一条）。
            if (monitor?.shouldStop() == true) {
                aborted = true
                break
            }
            val post = prepared.zeroComment[index]
            index++
            val content = pickContent(plan)
            if (content.isNullOrBlank()) {
                // ★★ 第 100 期：这里**不是**「抢不到」，而是「没有评语可发」。
                //   以前这句混在别的行里，用户看到「首评确认 0 条」会以为是没抢过别人。
                //   现在这句话本身就是「怎么做」（见 [interact_superlike_no_content]），
                //   并且会**单独弹出来** —— 否则用户永远不知道为什么是 0 条。
                val text = context.getString(R.string.interact_superlike_no_content)
                lines.add(text)
                alerts.add(text)
                break
            }
            // ★★★ 第 105 期：这一步真的要发评论了 —— 先把「第几条 / 共几条」告诉界面。
            monitor?.onMessage(
                context.getString(
                    R.string.interact_superlike_live_first, firstOk + 1, plan.firstComments
                )
            )
            val outcome = InteractProbe.postComment(context, account, post.mid, content)
            if (!outcome.ok) {
                // ★★ 第 100 期：用户可见那一行**不带微博原话**（只说「没发出去、换下一条」）；
                //   微博原话走**互动日志**，出问题时照旧查得到（第 100 期文案纪律）。
                lines.add(context.getString(R.string.interact_superlike_first_fail, index))
                InteractTrace.log(
                    "[超Like·明细] 首评第 " + index + " 条没发出去：mid=" + post.mid +
                        " —— " + outcome.detail
                )
                // ★ 第 87 期：失败也要节流。原来 pause() 只挂在成功分支后面，
                //   失败走 continue 等于**零间隔**连打（2026-10-09 实测 1 秒 3 个写请求）。
                pause(monitor)
                if (isAccountLevel(outcome.errno)) {
                    val text = context.getString(R.string.interact_superlike_stop)
                    lines.add(text)
                    alerts.add(text)
                    stopped = true
                    break
                }
                continue
            }
            val check = verifyFirst(context, account, post.mid, ownUid)
            when (check.verdict) {
                FirstVerdict.FIRST -> {
                    firstOk++
                    usedForFirst.add(post.mid)
                    RateGuard.markRun(label)
                    lines.add(context.getString(R.string.interact_superlike_first_ok, firstOk))
                    InteractTrace.log(
                        "[超Like·明细] 首评第 " + firstOk + " 条抢到：mid=" + post.mid + " floor=1"
                    )
                }
                FirstVerdict.NO_FLOOR -> {
                    firstOk++
                    usedForFirst.add(post.mid)
                    RateGuard.markRun(label)
                    lines.add(context.getString(R.string.interact_superlike_first_soft, firstOk))
                    InteractTrace.log(
                        "[超Like·明细] 首评第 " + firstOk + " 条：mid=" + post.mid + " 回包无楼层号"
                    )
                    if (!degradedShown) {
                        degradedShown = true
                        lines.add(context.getString(R.string.interact_superlike_degraded))
                    }
                }
                FirstVerdict.NO_READ -> {
                    firstOk++
                    usedForFirst.add(post.mid)
                    RateGuard.markRun(label)
                    lines.add(context.getString(R.string.interact_superlike_no_read))
                    InteractTrace.log(
                        "[超Like·明细] 首评第 " + firstOk + " 条：mid=" + post.mid + " 评论列表没读到"
                    )
                }
                FirstVerdict.NOT_LISTED -> {
                    firstOk++
                    usedForFirst.add(post.mid)
                    RateGuard.markRun(label)
                    lines.add(context.getString(R.string.interact_superlike_first_unsure, firstOk))
                    InteractTrace.log(
                        "[超Like·明细] 首评第 " + firstOk + " 条：mid=" + post.mid + " 还没进列表"
                    )
                }
                FirstVerdict.LOST -> {
                    lines.add(
                        context.getString(R.string.interact_superlike_first_lost, firstOk + 1)
                    )
                    InteractTrace.log(
                        "[超Like·明细] 首评第 " + (firstOk + 1) + " 条被抢先：mid=" + post.mid +
                            " floor=" + check.floor
                    )
                }
            }
            // ★★★ 第 105 期：这一趟的首评数字有变化就报给界面（判据是结构：计数器本身）。
            monitor?.onProgress(
                firstOk, plan.firstComments, 0, plan.reposts
            )
            pause(monitor)
        }

        // ★★★ 第 105 期：首评这一段收工 —— 告诉界面一声，别让它停在最后一条「正在提交」上。
        monitor?.onMessage(context.getString(R.string.interact_superlike_live_first_done))

        // ---------------------------------------------------------- ② 转发
        var repostOk = 0
        // ★ 第 87 期：`!stopped` —— 首评阶段已经撞上账号级限制时，转发这一步整个不做。
        // ★★★ 第 105 期：`!aborted` —— 首评阶段用户就点了「停止」时，转发这一步也不做。
        if (plan.reposts > 0 && !resting && !stopped && !aborted) {
            val reposted = prepared.repostedMids
            if (reposted == null) {
                // ★ 读不到时间线 = UNKNOWN ⇒ 整步跳过。
                //   宁可这次不转，也不重复转发同一条内容（竞品的原则）。
                lines.add(context.getString(R.string.interact_superlike_repost_blocked))
            } else {
                val skipped = prepared.posts.filter { it.mid in reposted }
                if (skipped.isNotEmpty()) {
                    lines.add(
                        context.getString(R.string.interact_superlike_repost_skipped, skipped.size)
                    )
                    // ★ 逐条明细只进**互动日志**：对话框里给一行汇总就够，
                    //   具体是哪些 mid 属于排查信息（结果那一屏不该被十几行 mid 占满）。
                    for (post in skipped) {
                        InteractTrace.log(
                            "[超Like] " + context.getString(
                                R.string.interact_superlike_repost_skip, post.mid
                            )
                        )
                    }
                }
                val fresh = prepared.posts.filter { it.mid !in reposted }
                // 优先挑「本批次没用来做首评」的帖子；不够再放宽。
                val preferred = fresh.filter { it.mid !in usedForFirst }
                val pool = if (preferred.size >= plan.reposts) preferred else fresh
                for (post in pool) {
                    if (repostOk >= plan.reposts) break
                    if (isResting(context, label, shown, lines, alerts)) break
                    // ★★★ 第 105 期：用户点了「停止」⇒ 转发这一步也收手。
                    if (monitor?.shouldStop() == true) {
                        aborted = true
                        break
                    }
                    // ★★★ 第 105 期：真的要发转发了 —— 先把「第几条 / 共几条」告诉界面。
                    monitor?.onMessage(
                        context.getString(
                            R.string.interact_superlike_live_repost,
                            repostOk + 1,
                            plan.reposts
                        )
                    )
                    val content = pickContent(plan).orEmpty()
                    val outcome = InteractProbe.postRepost(context, account, post.mid, content)
                    if (!outcome.ok) {
                        // ★★ 第 100 期：同首评 —— 用户可见那一行不带微博原话，原话进互动日志。
                        lines.add(
                            context.getString(R.string.interact_superlike_repost_fail, repostOk + 1)
                        )
                        InteractTrace.log(
                            "[超Like·明细] 转发第 " + (repostOk + 1) + " 条没发出去：mid=" +
                                post.mid + " —— " + outcome.detail
                        )
                        // ★ 第 87 期：失败也要节流（见首评那处的同一条注释）。
                        pause(monitor)
                        if (isAccountLevel(outcome.errno)) {
                            // ★★ 第 100 期：账号级停手也要单独提示（同首评那处）。
                            val stopText = context.getString(R.string.interact_superlike_stop)
                            lines.add(stopText)
                            alerts.add(stopText)
                            break
                        }
                        continue
                    }
                    repostOk++
                    RateGuard.markRun(label)
                    lines.add(context.getString(R.string.interact_superlike_repost_ok, repostOk))
                    InteractTrace.log(
                        "[超Like·明细] 转发第 " + repostOk + " 条已发出：mid=" + post.mid
                    )
                    // ★★★ 第 105 期：转发数字有变化就报给界面。
                    monitor?.onProgress(firstOk, plan.firstComments, repostOk, plan.reposts)
                    pause(monitor)
                }
            }
        }

        // ★★★ 第 105 期：用户中途收手 ⇒ 在结果里写一行，不然「为什么只有 2 条」没人解释。
        if (aborted) {
            lines.add(context.getString(R.string.interact_superlike_live_stopped))
        }
        lines.add(context.getString(R.string.interact_superlike_done, firstOk, repostOk))
        // ★ 第 99 期：把数字结构化带出去（界面那行提示要用）。
        return Outcome(
            firstOk = firstOk,
            firstTarget = plan.firstComments,
            repostOk = repostOk,
            repostTarget = plan.reposts,
            at = System.currentTimeMillis(),
            text = finish("[超Like]", lines)
        )
    }

    // ---------------------------------------------------------------- 内部

    /**
     * 捞帖 → 筛 0 评论 → 读时间线。三步**全是只读 GET**。
     *
     * ★ 返回 `null` = 前置条件不成立（超话 ID 读不出来），调用方**必须原样返回**，
     *   不许往下走 —— 后面每一步都是写请求。
     */
    private fun prepare(
        context: Context,
        plan: SuperLikePlan,
        account: WeiboAccount,
        lines: MutableList<String>
    ): Prepared? {
        val containerId = InteractTarget.topicId(plan.topic)
        if (containerId.isBlank()) {
            lines.add(context.getString(R.string.interact_superlike_bad_topic))
            return null
        }

        val posts = InteractProbe.topicPosts(account, containerId)
        lines.add(context.getString(R.string.interact_superlike_posts, posts.size))

        // ★★★ 只认「回包明确说 0 条评论」的帖子。
        //    `commentsCount == -1`（回包没给）**绝不当候选** —— 见 LatestPost.commentsCount。
        //    写成 `<= 0` 就会去评一条「不知道有没有人评过」的帖子，
        //    那条评论大概率不是首评，白占一次额度。
        val zero = posts.filter { it.commentsCount == 0 }
        if (zero.isEmpty()) {
            lines.add(context.getString(R.string.interact_superlike_no_candidate))
        } else {
            lines.add(context.getString(R.string.interact_superlike_candidates, zero.size))
        }

        val timeline = InteractProbe.ownTimeline(account, TIMELINE_LIMIT)
        val reposted = timeline
            ?.mapNotNull { it.repostedMid.takeIf { mid -> mid.isNotBlank() } }
            ?.toSet()
        if (timeline == null) {
            lines.add(context.getString(R.string.interact_superlike_timeline_fail))
        } else {
            lines.add(
                context.getString(
                    R.string.interact_superlike_timeline, timeline.size, reposted?.size ?: 0
                )
            )
        }

        return Prepared(posts, zero, reposted)
    }

    /**
     * 评论发出后**读回来核对楼层**。
     *
     * ★ 只用 GET（[InteractProbe.listComments]）⇒ 这一步本身不产生任何内容。
     * ★ 判据优先级：先找「自己那条」，再看它有没有楼层号；
     *   一条都没有楼层号 ⇒ 判据降级（[FirstVerdict.NO_FLOOR]），而不是当「没抢到」。
     */
    private fun verifyFirst(
        context: Context,
        account: WeiboAccount,
        mid: String,
        ownUid: String
    ): FirstCheck {
        if (ownUid.isBlank()) return FirstCheck(FirstVerdict.NOT_LISTED, -1)
        // ★ 第 91 期：把 ownUid 传给只读诊断（用来在日志里标出「哪条是自己」）。
        //   只影响日志，**不影响下面的任何判断** —— 返回值与第 90 期逐字节相同。
        val comments = InteractProbe.listComments(context, account, mid, ownUid)
        // ★ 列表**一条都没读到** ⇒ 这是「读不到」，与「列表里有评论但没有我那条」是两件事。
        //   分开报是为了真机排查：前者指向接口 / 解析，后者指向「刚发出还没进列表」。
        if (comments.isEmpty()) return FirstCheck(FirstVerdict.NO_READ, -1)
        val mine = comments.firstOrNull { it.uid == ownUid }
            ?: return FirstCheck(FirstVerdict.NOT_LISTED, -1)
        if (mine.floorNumber < 0) {
            val anyFloor = comments.any { it.floorNumber >= 0 }
            return FirstCheck(
                if (anyFloor) FirstVerdict.NOT_LISTED else FirstVerdict.NO_FLOOR, -1
            )
        }
        return FirstCheck(
            if (mine.floorNumber == 1) FirstVerdict.FIRST else FirstVerdict.LOST,
            mine.floorNumber
        )
    }

    /**
     * 查这个账号是不是已经到每小时上限了。到了就往结果里写一行并返回 true。
     *
     * ★★ 第 100 期：多收一个 [alerts]。
     *   「到每小时上限」是**用户必须知道**的情况 —— 不然他看到 0 条会以为是抢不过别人。
     *   所以这一行除了进结果正文，还要进 [Outcome.alerts]，由界面单独提示。
     */
    private fun isResting(
        context: Context,
        label: String,
        shown: String,
        lines: MutableList<String>,
        alerts: MutableList<String>
    ): Boolean {
        val verdict = RateGuard.verdict(label)
        if (verdict.state != GuardState.RESTING) return false
        val text = context.getString(
            R.string.interact_superlike_resting, shown, InteractFormat.until(verdict.until)
        )
        lines.add(text)
        alerts.add(text)
        return true
    }

    /**
     * ★ 第 87 期：这个失败是不是「**账号级**」的（换目标也没用 ⇒ 应当立刻停手）？
     *
     * ★ 只看结构 [InteractProbe.SendOutcome.errno]，不看文案。
     * ★ `errno` 为空串（网络失败 / 非 JSON / 解析失败）时返回 `false` ——
     *   **判不出类型就不擅自停手**，按「目标级」继续换下一条。
     *   宁可多试一条，也不要因为一次网络抖动把整趟编排误判成「被限流」。
     */
    private fun isAccountLevel(errno: String): Boolean =
        errno.isNotBlank() && errno in STOP_ERRNOS

    /** 取一条语料。与 [InteractRunner] 同一套规则（分组空 = 用第一个分组）。 */
    private fun pickContent(plan: SuperLikePlan): String? =
        if (plan.groupId.isBlank()) CommentLib.pickFirst() else CommentLib.pick(plan.groupId)

    /**
     * 两条写请求之间停一下。
     *
     * ★ 为什么要有：连续写请求是**最容易触发风控**的形态。
     *   停顿本身不保证不被拦，但「一秒发 6 条」和「十几秒发 6 条」
     *   在服务端看是两种完全不同的东西。
     * ★ 用**随机**而不是固定值：固定间隔的请求序列本身就是个指纹。
     * ★★★ 第 105 期：有 [monitor] 时把这一次停顿切成 [PAUSE_SLICE_MS] 的小片，
     *   好让「暂停」和「停止」最多 200ms 内生效；`monitor == null` 时
     *   仍然是**一整段** `Thread.sleep`（与第 104 期逐字节等价）。
     */
    private fun pause(monitor: Monitor? = null) {
        val total = PAUSE_MIN_MS + Random.nextLong(PAUSE_MAX_MS - PAUSE_MIN_MS)
        if (monitor == null) {
            sleepQuietly(total)
            return
        }
        var waited = 0L
        while (waited < total) {
            // 停止优先于继续：暂停期间点了停止，这里直接返回、不再等。
            if (monitor.shouldStop()) return
            // 用户按了「暂停」⇒ 阻塞到「继续」为止；期间点了停止则返回 true。
            if (monitor.awaitResume()) return
            sleepQuietly(minOf(PAUSE_SLICE_MS, total - waited))
            waited += PAUSE_SLICE_MS
        }
    }

    /** 睡一会儿；被中断就把中断标记还回去（绝不吞掉中断）。 */
    private fun sleepQuietly(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    /** 把每一行都写进互动日志，再拼成给弹窗看的文本。 */
    private fun finish(tag: String, lines: List<String>): String {
        for (line in lines) InteractTrace.log(tag + " " + line)
        return lines.joinToString("\n")
    }
}
