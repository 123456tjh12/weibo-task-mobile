package com.tjh.weibotask

import android.content.Context
import kotlin.random.Random

/**
 * ★★★★ 第 84 期：**超Like 一键编排**的执行器。
 *
 * ## 它做什么（规格来自竞品，逐条对齐）
 *
 * 微博官方「超Like」= **超话签到 ×1 + 首评 ×4 + 转发 ×2**。
 * 签到不在这里（原因见 [SuperLikePlan]），本文件只做后两件：
 *
 *   ① **捞帖**：把超话的帖子列表整页取回来（只读）；
 *   ② **筛首评候选**：只留 `comments_count == 0` 的帖子；
 *   ③ **首评 ×N**：对候选帖发一条评论 → **读回来核对 `floor_number == 1`**；
 *   ④ **转发 ×M**：跳过最近已经转过的帖子，再发转发。
 *
 * ## 「首评」为什么要核对 —— 这是竞品最值钱的一条
 *
 * 竞品界面上的文案把这件事说透了：
 *   · 「暂未找到新的 0 评论帖子」
 *   · 「刚刚被抢首评，未计数，继续找帖」
 *   · 「已核对到上次评论但不是首评」
 *   · 「已核对到上次首评成功（floor_number=1）」
 * ⇒ 它把「抢到第 1 楼」当成**必须核对的事实**，不是「发出去就算」。
 *   星签照做：评论发出后**再读一次评论列表**，看自己那条的楼层号。
 *
 * ## 三种核对结果怎么算（**计数规则**）
 *
 * | 核对结果 | 判据 | 是否计入 |
 * |---|---|---|
 * | 抢到了 | 自己那条 `floor_number == 1` | ✅ 计入 |
 * | 被抢先 | 自己那条 `floor_number > 1` | ❌ **不计入**，继续找下一条帖子 |
 * | 回包没给楼层号 | 列表里**一条**都没有 `floor_number` 字段 | ✅ 计入（判据降级，整趟只提示一次） |
 * | 列表里还没有自己那条 | 列表有评论，但找不到 `uid == 自己` | ✅ 计入（刚发出，还没进列表） |
 * | **列表整个没读到** | `listComments` 返回空 | ✅ 计入（这是「读不到」，不是「没抢到」） |
 *
 * ★ 为什么后两种也计入：`postComment` 回的是 `ok:1` + 新评论 id，
 *   说明**评论确实创建了**。不计入的话循环会继续去评下一条帖子，
 *   结果就是「为了凑数多评了好几条」—— 那比少算一条糟得多。
 * ★ 为什么「被抢先」不计入：那一条**不是首评**，官方不认，计进去等于骗用户。
 *
 * ## 硬边界
 *
 * ★ 不碰 [Prefs]、不写 [AccountStore]、不走 [WeiboClient]。
 * ★ 写请求只走 [InteractProbe] 里**已经真机验证过**的那两个函数
 *   （[InteractProbe.postComment] / [InteractProbe.postRepost]），本文件不自己拼请求。
 * ★ **尝试次数有上限**（[ATTEMPT_FACTOR]）：最多对 `首评条数 × 2` 条帖子发评论。
 *   没有这个上限的话，「一直被抢先」会把整个超话的帖子全评一遍。
 * ★ 每条写请求之间有 1.5~4 秒停顿（见 [pause]）。
 * ★ 会阻塞（每个动作一或多次网络往返），调用方**必须**放后台线程。
 */
object SuperLikeRunner {

    /** 两条写请求之间的停顿下限（毫秒）。 */
    private const val PAUSE_MIN_MS = 1500L

    /** 两条写请求之间的停顿上限（毫秒）。 */
    private const val PAUSE_MAX_MS = 4000L

    /** 读自己时间线时最多看多少条。 */
    private const val TIMELINE_LIMIT = 20

    /**
     * 首评的**尝试次数上限倍数**。
     *
     * ★ 为什么要上限：首评的判据是「抢到第 1 楼」，而被抢先随时会发生。
     *   如果只按「成功条数」循环，一个全被抢的超话会让我们把整页帖子评一遍 ——
     *   那是几十条评论，代价全落在账号上。
     * ⇒ 最多试 `首评条数 × 2` 次（要 4 条最多试 8 条帖子）。
     */
    private const val ATTEMPT_FACTOR = 2

    /**
     * ★★★★ 第 87 期：**命中就立刻停手**的「账号级」错误码。
     *
     * ## 起因（2026-10-09 真机日志）
     *
     * 账号「伟大族丝」转发第 2 条时，微博回 `20016 / 操作频繁，请您稍后再试`。
     * 这是**账号级**限流 —— 换哪条帖子结果都一样。但当时的代码把它当成
     * 「这条帖子不行」，`continue` 去换下一条 ⇒ 对剩余 **13 条**帖子各打了一次，
     * 19 秒内共 14 个写请求。**在已经被限流的情况下继续加压，只会让风控更重。**
     *
     * ## 判据只认结构，不认文案
     *
     * 用 [InteractProbe.SendOutcome.errno]（微博原样给的错误码），
     * **绝不**去 `detail` 里搜「操作频繁」这种词 —— 那是「认文案」，
     * 第 20 条纪律明令禁止（文案会改、会翻译、会加装饰，判据一认它就随时失效）。
     *
     * ## 表里只放**实测或已确证**的账号级码，不猜
     *
     *   · `20016` —— 操作频繁（2026-10-09 真机实测）
     *   · `100006` —— 请求非法 / 缺 st / 未登录（第 84 / 85 期已确证是**最外层通用拒绝**）
     *   · [InteractProbe.ERRNO_NO_ST] —— 连一次性票据都没取到，请求根本没发出去
     *
     * ★ **目标级**的错误码**故意不在这里**。例如 `20130 暂无查看权限`
     *   （这条微博不让评）—— 那种「换下一条」是**对的**，必须继续换。
     *   把目标级也塞进来，会让一次偶发的单帖失败白白终止整趟编排。
     */
    private val STOP_ERRNOS = setOf(
        "20016",
        "100006",
        InteractProbe.ERRNO_NO_ST
    )

    /** 首评核对的结果。 */
    private enum class FirstVerdict {
        /** 自己那条是第 1 楼 —— 真首评。 */
        FIRST,
        /** 自己那条不是第 1 楼 —— 被抢先了。 */
        LOST,
        /** 列表里一条都没有楼层号字段 —— 判据降级。 */
        NO_FLOOR,
        /** 列表里有评论，但还没有自己那条 —— 刚发出，还没进列表。 */
        NOT_LISTED,
        /** **评论列表整个没读到**（空回包 / 解析失败）—— 与 NOT_LISTED 不同，是读的问题。 */
        NO_READ
    }

    /** 一次核对的结果：判定 + 楼层号（-1 = 不知道）。 */
    private class FirstCheck(val verdict: FirstVerdict, val floor: Int)

    /** 「前期准备」的结果。 */
    private class Prepared(
        val posts: List<InteractProbe.LatestPost>,
        val zeroComment: List<InteractProbe.LatestPost>,
        /** `null` = **读不到**时间线（UNKNOWN），不是「没转过」。 */
        val repostedMids: Set<String>?
    )

    // ---------------------------------------------------------------- 只读试跑

    /**
     * **只读试跑**：把捞帖、筛 0 评论、读时间线这三步全走一遍，**一个写请求都不发**。
     *
     * ★ 为什么要它：这三步都是**只读 GET**，不消耗任何额度、不产生任何内容。
     *   用户可以先看清「这个超话现在有几条 0 评论的帖子」「我最近转过哪几条」，
     *   再决定要不要真跑 —— 和 [InteractRunner.rehearse] 是同一个思路。
     * ★ 会阻塞，必须在后台线程调用。
     */
    fun rehearse(context: Context, plan: SuperLikePlan, account: WeiboAccount?): String {
        val lines = mutableListOf<String>()
        lines.add(
            context.getString(
                R.string.interact_superlike_plan, plan.firstComments, plan.reposts
            )
        )
        lines.add(context.getString(R.string.interact_superlike_scope))

        if (account == null) {
            lines.add(context.getString(R.string.interact_superlike_no_account))
            return finish("[超Like·试跑]", lines)
        }
        if (account.cookie.isBlank()) {
            lines.add(context.getString(R.string.interact_rehearse_no_cookie))
            return finish("[超Like·试跑]", lines)
        }

        if (prepare(context, plan, account, lines) == null) return finish("[超Like·试跑]", lines)
        lines.add(context.getString(R.string.interact_superlike_rehearse_done))
        return finish("[超Like·试跑]", lines)
    }

    // ---------------------------------------------------------------- 真跑

    /**
     * **一键跑超Like**：首评 ×N + 转发 ×M。
     *
     * ★ 受 [InteractRunner.sendEnabled] 总开关约束 —— 开关关着时**一个写请求都不发**，
     *   但会**明确说**「开关还关着」，绝不静默什么都不做。
     * ★ 会阻塞（可能几十秒到一两分钟），必须在后台线程调用。
     */
    fun run(context: Context, plan: SuperLikePlan, account: WeiboAccount?): String {
        val lines = mutableListOf<String>()
        lines.add(
            context.getString(
                R.string.interact_superlike_plan, plan.firstComments, plan.reposts
            )
        )

        if (!InteractRunner.sendEnabled) {
            lines.add(context.getString(R.string.interact_superlike_switch_off))
            return finish("[超Like]", lines)
        }
        if (account == null) {
            lines.add(context.getString(R.string.interact_superlike_no_account))
            return finish("[超Like]", lines)
        }
        if (account.cookie.isBlank()) {
            lines.add(context.getString(R.string.interact_rehearse_no_cookie))
            return finish("[超Like]", lines)
        }

        val prepared = prepare(context, plan, account, lines) ?: return finish("[超Like]", lines)
        val label = account.label
        val shown = account.displayName
        // ★ 只取一次 uid：ownUid 每次都发一次 GET，循环里绝不能重复调。
        val ownUid = InteractProbe.ownUid(account)

        // ---------------------------------------------------------- ① 首评
        var firstOk = 0
        var index = 0
        val cap = minOf(plan.firstComments * ATTEMPT_FACTOR, prepared.zeroComment.size)
        val usedForFirst = mutableSetOf<String>()
        var resting = false
        // ★ 第 87 期：命中账号级错误码后置 true ⇒ **后面每一步都不做了**（含转发那一段）。
        var stopped = false
        // ★ 判据降级是**整趟只报一次**的事：每条都印一遍会把结果刷屏，
        //   而它其实是同一件事（这个接口就是不给楼层号）。
        var degradedShown = false

        while (firstOk < plan.firstComments && index < cap) {
            if (isResting(context, label, shown, lines)) {
                resting = true
                break
            }
            val post = prepared.zeroComment[index]
            index++
            val content = pickContent(plan)
            if (content.isNullOrBlank()) {
                lines.add(context.getString(R.string.interact_superlike_no_content))
                break
            }
            val outcome = InteractProbe.postComment(context, account, post.mid, content)
            if (!outcome.ok) {
                lines.add(
                    context.getString(
                        R.string.interact_superlike_first_fail, index, outcome.detail
                    )
                )
                // ★ 第 87 期：失败也要节流。原来 pause() 只挂在成功分支后面，
                //   失败走 continue 等于**零间隔**连打（2026-10-09 实测 1 秒 3 个写请求）。
                pause()
                if (isAccountLevel(outcome.errno)) {
                    lines.add(context.getString(R.string.interact_superlike_stop))
                    stopped = true
                    break
                }
                continue
            }
            val check = verifyFirst(context, account, post.mid, ownUid)
            when (check.verdict) {
                FirstVerdict.FIRST -> {
                    firstOk++
                    usedForFirst.add(post.mid)
                    RateGuard.markRun(label)
                    lines.add(
                        context.getString(
                            R.string.interact_superlike_first_ok, firstOk, post.mid
                        )
                    )
                }
                FirstVerdict.NO_FLOOR -> {
                    firstOk++
                    usedForFirst.add(post.mid)
                    RateGuard.markRun(label)
                    lines.add(context.getString(R.string.interact_superlike_first_soft, firstOk))
                    if (!degradedShown) {
                        degradedShown = true
                        lines.add(context.getString(R.string.interact_superlike_degraded))
                    }
                }
                FirstVerdict.NO_READ -> {
                    firstOk++
                    usedForFirst.add(post.mid)
                    RateGuard.markRun(label)
                    lines.add(context.getString(R.string.interact_superlike_no_read, post.mid))
                }
                FirstVerdict.NOT_LISTED -> {
                    firstOk++
                    usedForFirst.add(post.mid)
                    RateGuard.markRun(label)
                    lines.add(context.getString(R.string.interact_superlike_first_unsure, firstOk))
                }
                FirstVerdict.LOST -> {
                    lines.add(
                        context.getString(
                            R.string.interact_superlike_first_lost, firstOk + 1, check.floor
                        )
                    )
                }
            }
            pause()
        }

        // ---------------------------------------------------------- ② 转发
        var repostOk = 0
        // ★ 第 87 期：`!stopped` —— 首评阶段已经撞上账号级限制时，转发这一步整个不做。
        if (plan.reposts > 0 && !resting && !stopped) {
            val reposted = prepared.repostedMids
            if (reposted == null) {
                // ★ 读不到时间线 = UNKNOWN ⇒ 整步跳过。
                //   宁可这次不转，也不重复转发同一条内容（竞品的原则）。
                lines.add(context.getString(R.string.interact_superlike_repost_blocked))
            } else {
                val skipped = prepared.posts.filter { it.mid in reposted }
                if (skipped.isNotEmpty()) {
                    lines.add(
                        context.getString(R.string.interact_superlike_repost_skipped, skipped.size)
                    )
                    // ★ 逐条明细只进**互动日志**：对话框里给一行汇总就够，
                    //   具体是哪些 mid 属于排查信息（结果那一屏不该被十几行 mid 占满）。
                    for (post in skipped) {
                        InteractTrace.log(
                            "[超Like] " + context.getString(
                                R.string.interact_superlike_repost_skip, post.mid
                            )
                        )
                    }
                }
                val fresh = prepared.posts.filter { it.mid !in reposted }
                // 优先挑「本批次没用来做首评」的帖子；不够再放宽。
                val preferred = fresh.filter { it.mid !in usedForFirst }
                val pool = if (preferred.size >= plan.reposts) preferred else fresh
                for (post in pool) {
                    if (repostOk >= plan.reposts) break
                    if (isResting(context, label, shown, lines)) break
                    val content = pickContent(plan).orEmpty()
                    val outcome = InteractProbe.postRepost(context, account, post.mid, content)
                    if (!outcome.ok) {
                        lines.add(
                            context.getString(
                                R.string.interact_superlike_repost_fail,
                                repostOk + 1,
                                outcome.detail
                            )
                        )
                        // ★ 第 87 期：失败也要节流（见首评那处的同一条注释）。
                        pause()
                        if (isAccountLevel(outcome.errno)) {
                            lines.add(context.getString(R.string.interact_superlike_stop))
                            break
                        }
                        continue
                    }
                    repostOk++
                    RateGuard.markRun(label)
                    lines.add(
                        context.getString(
                            R.string.interact_superlike_repost_ok, repostOk, post.mid
                        )
                    )
                    pause()
                }
            }
        }

        lines.add(context.getString(R.string.interact_superlike_done, firstOk, repostOk))
        return finish("[超Like]", lines)
    }

    // ---------------------------------------------------------------- 内部

    /**
     * 捞帖 → 筛 0 评论 → 读时间线。三步**全是只读 GET**。
     *
     * ★ 返回 `null` = 前置条件不成立（超话 ID 读不出来），调用方**必须原样返回**，
     *   不许往下走 —— 后面每一步都是写请求。
     */
    private fun prepare(
        context: Context,
        plan: SuperLikePlan,
        account: WeiboAccount,
        lines: MutableList<String>
    ): Prepared? {
        val containerId = InteractTarget.topicId(plan.topic)
        if (containerId.isBlank()) {
            lines.add(context.getString(R.string.interact_superlike_bad_topic))
            return null
        }

        val posts = InteractProbe.topicPosts(account, containerId)
        lines.add(context.getString(R.string.interact_superlike_posts, posts.size))

        // ★★★ 只认「回包明确说 0 条评论」的帖子。
        //    `commentsCount == -1`（回包没给）**绝不当候选** —— 见 LatestPost.commentsCount。
        //    写成 `<= 0` 就会去评一条「不知道有没有人评过」的帖子，
        //    那条评论大概率不是首评，白占一次额度。
        val zero = posts.filter { it.commentsCount == 0 }
        if (zero.isEmpty()) {
            lines.add(context.getString(R.string.interact_superlike_no_candidate))
        } else {
            lines.add(context.getString(R.string.interact_superlike_candidates, zero.size))
        }

        val timeline = InteractProbe.ownTimeline(account, TIMELINE_LIMIT)
        val reposted = timeline
            ?.mapNotNull { it.repostedMid.takeIf { mid -> mid.isNotBlank() } }
            ?.toSet()
        if (timeline == null) {
            lines.add(context.getString(R.string.interact_superlike_timeline_fail))
        } else {
            lines.add(
                context.getString(
                    R.string.interact_superlike_timeline, timeline.size, reposted?.size ?: 0
                )
            )
        }

        return Prepared(posts, zero, reposted)
    }

    /**
     * 评论发出后**读回来核对楼层**。
     *
     * ★ 只用 GET（[InteractProbe.listComments]）⇒ 这一步本身不产生任何内容。
     * ★ 判据优先级：先找「自己那条」，再看它有没有楼层号；
     *   一条都没有楼层号 ⇒ 判据降级（[FirstVerdict.NO_FLOOR]），而不是当「没抢到」。
     */
    private fun verifyFirst(
        context: Context,
        account: WeiboAccount,
        mid: String,
        ownUid: String
    ): FirstCheck {
        if (ownUid.isBlank()) return FirstCheck(FirstVerdict.NOT_LISTED, -1)
        val comments = InteractProbe.listComments(context, account, mid)
        // ★ 列表**一条都没读到** ⇒ 这是「读不到」，与「列表里有评论但没有我那条」是两件事。
        //   分开报是为了真机排查：前者指向接口 / 解析，后者指向「刚发出还没进列表」。
        if (comments.isEmpty()) return FirstCheck(FirstVerdict.NO_READ, -1)
        val mine = comments.firstOrNull { it.uid == ownUid }
            ?: return FirstCheck(FirstVerdict.NOT_LISTED, -1)
        if (mine.floorNumber < 0) {
            val anyFloor = comments.any { it.floorNumber >= 0 }
            return FirstCheck(
                if (anyFloor) FirstVerdict.NOT_LISTED else FirstVerdict.NO_FLOOR, -1
            )
        }
        return FirstCheck(
            if (mine.floorNumber == 1) FirstVerdict.FIRST else FirstVerdict.LOST,
            mine.floorNumber
        )
    }

    /** 查这个账号是不是已经到每小时上限了。到了就往结果里写一行并返回 true。 */
    private fun isResting(
        context: Context,
        label: String,
        shown: String,
        lines: MutableList<String>
    ): Boolean {
        val verdict = RateGuard.verdict(label)
        if (verdict.state != GuardState.RESTING) return false
        lines.add(
            context.getString(
                R.string.interact_superlike_resting, shown, InteractFormat.until(verdict.until)
            )
        )
        return true
    }

    /**
     * ★ 第 87 期：这个失败是不是「**账号级**」的（换目标也没用 ⇒ 应当立刻停手）？
     *
     * ★ 只看结构 [InteractProbe.SendOutcome.errno]，不看文案。
     * ★ `errno` 为空串（网络失败 / 非 JSON / 解析失败）时返回 `false` ——
     *   **判不出类型就不擅自停手**，按「目标级」继续换下一条。
     *   宁可多试一条，也不要因为一次网络抖动把整趟编排误判成「被限流」。
     */
    private fun isAccountLevel(errno: String): Boolean =
        errno.isNotBlank() && errno in STOP_ERRNOS

    /** 取一条语料。与 [InteractRunner] 同一套规则（分组空 = 用第一个分组）。 */
    private fun pickContent(plan: SuperLikePlan): String? =
        if (plan.groupId.isBlank()) CommentLib.pickFirst() else CommentLib.pick(plan.groupId)

    /**
     * 两条写请求之间停一下。
     *
     * ★ 为什么要有：连续写请求是**最容易触发风控**的形态。
     *   停顿本身不保证不被拦，但「一秒发 6 条」和「十几秒发 6 条」
     *   在服务端看是两种完全不同的东西。
     * ★ 用**随机**而不是固定值：固定间隔的请求序列本身就是个指纹。
     */
    private fun pause() {
        try {
            Thread.sleep(PAUSE_MIN_MS + Random.nextLong(PAUSE_MAX_MS - PAUSE_MIN_MS))
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    /** 把每一行都写进互动日志，再拼成给弹窗看的文本。 */
    private fun finish(tag: String, lines: List<String>): String {
        for (line in lines) InteractTrace.log(tag + " " + line)
        return lines.joinToString("\n")
    }
}
