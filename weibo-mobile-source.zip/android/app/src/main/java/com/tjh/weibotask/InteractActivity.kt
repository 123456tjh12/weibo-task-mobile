package com.tjh.weibotask

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONTokener

/**
 * 互动页（评论 / 互评 / 楼赞）。
 *
 * ★★ 这一页**独立于四条核心链路**，是「加功能不影响老功能」的物理体现：
 *   - 只读写自己的三个私有存储：`interact_tasks` / `interact_lib` / `interact_guard`；
 *   - 对账号只做**只读**（[AccountStore.all]），从不写 `restUntil` / `needsVerify` /
 *     `lastRunAt` / `lastRunDate` 里的任何一个 —— 这四个是签到链路正在用的判定字段；
 *   - 不调 `AccountStore.save()`（它是整表覆盖，会把账号表整个重写一遍）；
 *   - 不碰 `Prefs`、不碰 `WeiboClient`。
 *   把这一页连同它引用的 5 个文件整个删掉，签到 / 发帖 / 验证的行为不会有任何变化。
 *
 * ★ 界面按「用户的操作顺序」从上到下排：
 *   账号保护状态 → 语料库 → 任务列表 → 频率设置 → 互动日志。
 *   用户看一眼就知道「现在账号还能不能动」「要发的话发什么」。
 */
class InteractActivity : AppCompatActivity() {

    // ★★ 第 100 期：`guardText` / `rateLimitEdit` / `rateRestEdit` 已删 ——
    //   「账号保护」整块（第 4 次获准删控件）连同它的 `refreshGuard()` /
    //   `refreshRateFields()` / `saveRate()` 一起移除。后台兜底仍在 `RateGuard` 里。
    private lateinit var libSummary: TextView
    private lateinit var taskSummary: TextView
    private lateinit var taskList: LinearLayout
    private lateinit var traceText: TextView

    /**
     * ★ 第 53 期：发送区与「排查工具」折叠区（「一眼看懂」重排新增的两块）。
     *
     * ★★ 第 100 期：真发开关（`sendSwitch`）已删 —— 第 3 次获准删控件。
     *   连它那行状态文字（`sendState`）也不再需要代码持有：文案固定，
     *   直接写在布局里（`@string/interact_send_state`），省掉一个只写不读的字段。
     */
    private lateinit var toolsWrap: LinearLayout
    private lateinit var toolsToggle: TextView

    /**
     * ★★★ 第 84 期：超Like 一键编排（**默认收起**的折叠卡）。
     *
     * ★ 这三个输入框里装的是**用户正在打的字** ⇒ 只在 `onCreate` 回填一次，
     *   **不进** `refreshAll()`（与频率那两个框同一条纪律）。
     */
    private lateinit var superlikeWrap: LinearLayout
    private lateinit var superlikeToggle: TextView
    private lateinit var superlikeTopicEdit: EditText
    private lateinit var superlikeFirstEdit: EditText
    private lateinit var superlikeRepostEdit: EditText
    private lateinit var superlikeAccountSpinner: Spinner

    /**
     * ★★★ 第 99 期：「一键跑超Like」按钮**下面那一行结果**。
     *
     * ★ 用户要求「跑完一眼看到首评 / 转发各成了几条」。这一行是**纯展示**：
     *   数字来自 [SuperLikeRunner.Outcome]，由 [InteractTaskStore] 落盘，
     *   本页只负责把它印出来（`onResume` 也会重刷，所以跨页面回来还在）。
     */
    private lateinit var superlikeResult: TextView

    /**
     * ★★★ 第 105 期：**一键超Like 运行态界面**（用户 2026-10-12 给的设计稿）。
     *
     * 四块新东西，**一个老控件都没删**（只是主按钮文案改成「开始一键超Like」）：
     *   ① 概览二卡 `superlikeStatFirst` / `superlikeStatRepost` —— 今天累计 X/Y；
     *   ② 任务复选框 `superlikeTaskFirst` / `superlikeTaskRepost` —— 默认全选中；
     *   ③ 暂停 / 停止 `superlikePause` / `superlikeStop` —— 初始 disabled；
     *   ④ 「然屯速递」实时卡：两条进度条 + 两个读数 + 一行动态文本。
     *
     * ★ 全部是**纯展示 + 编排开关**：它们只影响「这一趟超Like 做不做首评 / 转发」，
     *   不碰签到 / 发帖 / 验证 / 数据层四条核心链路（硬规则一）。
     * ★ 概览二卡与下面那一行战绩**同一个数据源**（[InteractTaskStore.todayDone]），
     *   不另起一套统计 —— 两处数字必须永远一致。
     */
    private lateinit var superlikeStatFirst: TextView
    private lateinit var superlikeStatRepost: TextView
    private lateinit var superlikeTaskFirst: CheckBox
    private lateinit var superlikeTaskRepost: CheckBox
    private lateinit var superlikePause: Button
    private lateinit var superlikeStop: Button
    private lateinit var superlikeLiveFirstBar: ProgressBar
    private lateinit var superlikeLiveRepostBar: ProgressBar
    private lateinit var superlikeLiveFirstNum: TextView
    private lateinit var superlikeLiveRepostNum: TextView
    private lateinit var superlikeLiveText: TextView
    private lateinit var superlikeLiveLog: TextView

    /**
     * ★★★ 第 105 期：实时明细的**最近 3 行**（内存里，不落盘）。
     *
     * ★ 为什么只留 3 行：这一行是「刚发生了什么」，不是日志归档 ——
     *   真要翻旧账有下面「排查工具」里的互动日志（[InteractTrace]），
     *   那里一条不少。这里刷屏只会把「然屯速递」那两条进度条挤到看不见。
     */
    private val superlikeLogLines = ArrayDeque<String>()

    /** 上一回报给界面的首评 / 转发数（只报**变化**，同样一条不重复追加）。 */
    private var liveFirstPrev = 0
    private var liveRepostPrev = 0

    /**
     * ★★★ 第 105 期：**这一趟超Like**的暂停 / 停止标志。
     *
     * ★ 为什么单独一个类：跑起来是在后台线程里，界面点在主线程 ——
     *   两个线程要看到同一份状态，`@Volatile` 是底线。
     * ★ 每次点「开始」都新建一个：上一趟的标志留着会让「停止」误伤下一趟。
     */
    private class SuperlikeRunFlags {
        @Volatile
        var paused = false

        @Volatile
        var stopped = false
    }

    /** 当前这一趟的标志；没在跑的时候是 null。 */
    private var superlikeFlags: SuperlikeRunFlags? = null

    /** ★ 第 46 期阶段 1：抓真实请求用的 WebView 容器与实例。没打开时都是 null。 */
    private var webWrap: FrameLayout? = null
    private var webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_interact)

        // ① 三个私有存储 + 账号只读列表。
        //    AccountStore.init 和 MainActivity 启动时调的是同一个函数，
        //    正常路径下这里已经是 no-op（loaded 已置位）。
        InteractTrace.init(this)
        CommentLib.init(this)
        InteractTaskStore.init(this)
        RateGuard.init(this)
        AccountStore.init(this)

        libSummary = findViewById(R.id.interactLibSummary)
        taskSummary = findViewById(R.id.interactTaskSummary)
        taskList = findViewById(R.id.interactTaskList)
        traceText = findViewById(R.id.interactTraceText)
        toolsWrap = findViewById(R.id.interactToolsWrap)
        toolsToggle = findViewById(R.id.interactToolsToggle)

        // ★ 第 84 期：超Like 一键编排（默认收起）
        superlikeWrap = findViewById(R.id.interactSuperlikeWrap)
        superlikeToggle = findViewById(R.id.interactSuperlikeToggle)
        superlikeTopicEdit = findViewById(R.id.interactSuperlikeTopic)
        superlikeFirstEdit = findViewById(R.id.interactSuperlikeFirst)
        superlikeRepostEdit = findViewById(R.id.interactSuperlikeRepost)
        superlikeAccountSpinner = findViewById(R.id.interactSuperlikeAccount)
        // ★ 第 99 期：按钮下面那行结果（纯展示，见字段注释）。
        superlikeResult = findViewById(R.id.interactSuperlikeResult)

        // ★★★ 第 105 期：运行态界面四块（见字段注释）。全部是新增接线。
        superlikeStatFirst = findViewById(R.id.interactSuperlikeStatFirst)
        superlikeStatRepost = findViewById(R.id.interactSuperlikeStatRepost)
        superlikeTaskFirst = findViewById(R.id.interactSuperlikeTaskFirst)
        superlikeTaskRepost = findViewById(R.id.interactSuperlikeTaskRepost)
        superlikePause = findViewById(R.id.interactSuperlikePause)
        superlikeStop = findViewById(R.id.interactSuperlikeStop)
        superlikeLiveFirstBar = findViewById(R.id.interactSuperlikeLiveFirstBar)
        superlikeLiveRepostBar = findViewById(R.id.interactSuperlikeLiveRepostBar)
        superlikeLiveFirstNum = findViewById(R.id.interactSuperlikeLiveFirstNum)
        superlikeLiveRepostNum = findViewById(R.id.interactSuperlikeLiveRepostNum)
        superlikeLiveText = findViewById(R.id.interactSuperlikeLiveText)
        superlikeLiveLog = findViewById(R.id.interactSuperlikeLiveLog)

        findViewById<TextView>(R.id.interactBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.interactLibManage).setOnClickListener { showLibDialog() }
        findViewById<Button>(R.id.interactLibQuickAdd).setOnClickListener { quickAddLine() }
        findViewById<Button>(R.id.interactAddTask).setOnClickListener { showAddTaskDialog() }
        // ★★★ 第 101 期：「试跑一次」（互动任务卡那颗，id `interactDryRun`）已按用户要求删除
        //   ⇒ 这里少一条接线，`runRehearse()` / `doRehearse()` 也一并删了（它们只服务这颗按钮）。
        //   ★ `InteractRunner.rehearse()` 只读能力**原样保留**。
        findViewById<Button>(R.id.interactProbe).setOnClickListener { runProbe() }
        findViewById<Button>(R.id.interactProbePaths).setOnClickListener { runPathProbe() }
        findViewById<Button>(R.id.interactProbeSend).setOnClickListener { runSendProbe() }
        // ★ 第 84 期：转发接口探测。与「探发送」同一套零风险设计（目标是不存在的微博）。
        findViewById<Button>(R.id.interactProbeRepost).setOnClickListener { runRepostProbe() }
        findViewById<Button>(R.id.interactProbeReply).setOnClickListener { runReplyScout() }
        findViewById<Button>(R.id.interactProbeReplyGo).setOnClickListener { runReplyProbe() }
        // ★★ 第 100 期：`interactRateSave` 已删（「账号保护」整块移除）。
        findViewById<Button>(R.id.interactTraceCopy).setOnClickListener { copyTrace() }
        findViewById<Button>(R.id.interactTraceClear).setOnClickListener { clearTrace() }

        // ★ 第 46 期阶段 1：抓一条真实请求（只读）
        webWrap = findViewById(R.id.interactWebWrap)
        findViewById<Button>(R.id.interactWebOpen).setOnClickListener { openWeb() }
        findViewById<Button>(R.id.interactWebCapture).setOnClickListener { captureWeb() }
        findViewById<Button>(R.id.interactWebClose).setOnClickListener { closeWeb() }

        // ★★ 第 100 期：真发开关已删（第 3 次获准删控件）。
        //   原来这里是「开关默认关 + 每次打开 App 都回到关 + 关着就一个写请求都不发」。
        //   用户明确要求删掉它 ⇒ 现在点下去就是真的发出去；「想只看不发」的出口是「试跑」。
        //   连带**两处「真发前再问一次」的确认框也一并删掉**（用户选的「连确认框也去掉」）。
        findViewById<Button>(R.id.interactSend).setOnClickListener { runSend() }
        toolsToggle.setOnClickListener { toggleTools() }

        // ★ 第 84 期：超Like 一键编排的折叠 + 主按钮。
        // ★★★ 第 101 期：「试跑一次」那颗按钮（id `interactSuperlikeRehearse`）已按用户要求
        //   删除 ⇒ 这里少一条接线。`SuperLikeRunner.rehearse()` 只读能力**原样保留**。
        superlikeToggle.setOnClickListener { toggleSuperlike() }
        findViewById<Button>(R.id.interactSuperlikeRun).setOnClickListener { runSuperLike() }

        // ★★ 第 102 期：按钮下面那行改成「**今天累计已完成**」，范围跟着
        //   「超话 + 账号」走 ⇒ 这两处一变就得重刷那一行。
        //   ★ 两个回调都**只读**（[refreshSuperlikeResult] 不写任何输入框、不动下拉选中项）
        //     ⇒ 不会递归触发，也不会把用户正在打的字冲掉。
        superlikeAccountSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    refreshSuperlikeResult()
                }

                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
        superlikeTopicEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) =
                Unit

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) =
                Unit

            override fun afterTextChanged(s: Editable?) {
                refreshSuperlikeResult()
            }
        })

        // ★★★ 第 105 期：两个复选框的文案跟着上面两个条数框实时同步 ——
        //   把「首评条数」从 4 改成 3，复选框当场变成「确认首评 3 条」。
        //   ★ 只改文案，不改任何判断（这一趟做不做某件事只看 isChecked）。
        val syncTaskLabels = {
            val first = superlikeFirstEdit.text.toString().trim().toIntOrNull()
                ?: SuperLikePlan.OFFICIAL_FIRST
            val repost = superlikeRepostEdit.text.toString().trim().toIntOrNull()
                ?: SuperLikePlan.OFFICIAL_REPOST
            superlikeTaskFirst.text = getString(R.string.interact_superlike_task_first, first)
            superlikeTaskRepost.text = getString(R.string.interact_superlike_task_repost, repost)
        }
        val countWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) =
                Unit

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) =
                Unit

            override fun afterTextChanged(s: Editable?) {
                syncTaskLabels()
            }
        }
        superlikeFirstEdit.addTextChangedListener(countWatcher)
        superlikeRepostEdit.addTextChangedListener(countWatcher)
        syncTaskLabels()

        // ★★★ 第 105 期：暂停 / 停止（初始 disabled，跑起来才可用）。
        superlikePause.setOnClickListener { toggleSuperlikePause() }
        superlikeStop.setOnClickListener { stopSuperLike() }

        // ★★ 第 100 期：`refreshRateFields()` 已删（频率设置那两个输入框不在了）。
        loadSuperlike()
        refreshAll()
    }

    override fun onDestroy() {
        // WebView 是重资源，页面销毁时必须主动 destroy，否则会泄漏整个 Activity
        try {
            webView?.destroy()
        } catch (_: Throwable) {
        }
        webView = null
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        // 回到本页时把状态重新读一遍 —— 用户可能在别处改了东西，
        // 也可能在系统里刚把这个账号重新授权过。
        // ★ 刻意**不刷新**频率那两个输入框：那会把用户正在输入的内容冲掉。
        refreshAll()
    }

    // ---------------------------------------------------------------- 刷新

    /** 刷新除频率输入框以外的全部区域。 */
    private fun refreshAll() {
        // ★★ 第 100 期：`refreshGuard()` 已删（「账号保护」整块移除）。
        refreshLib()
        refreshTasks()
        refreshTrace()
        // ★★ 第 100 期：`refreshSendUi()` 已删 —— 真发开关没了，那句提示改成
        //   布局里的静态文案（`@string/interact_send_state`），不需要每次刷新。
        // ★ 第 84 期：只刷超Like 卡里**会变的**那一部分（可用账号）；
        //   三个输入框里的字是用户打的，刷新不许碰。
        refreshSuperlike()
    }

    private fun refreshLib() {
        libSummary.text = if (CommentLib.groupCount() == 0) {
            getString(R.string.interact_lib_empty)
        } else {
            getString(
                R.string.interact_lib_summary,
                CommentLib.groupCount(),
                CommentLib.totalLines(),
                CommentLib.suffixCount()
            )
        }
    }

    private fun refreshTasks() {
        taskList.removeAllViews()
        val tasks = InteractTaskStore.all()
        taskSummary.text = if (tasks.isEmpty()) {
            getString(R.string.interact_task_empty)
        } else {
            getString(R.string.interact_task_summary, tasks.size, InteractTaskStore.enabledCount())
        }
        for (task in tasks) taskList.addView(buildTaskRow(task))
    }

    private fun refreshTrace() {
        val dump = InteractTrace.dump()
        traceText.text = dump.ifBlank { getString(R.string.interact_trace_empty) }
    }

    // ★★ 第 100 期：`refreshRateFields()` 已删 —— 「频率设置」那两个输入框整块移除。

    // ------------------------------------------ 第 53 期：发送 / 排查工具折叠

    /**
     * 展开 / 收起「排查工具」。**默认收起**。
     *
     * ★ 里面一个功能都没删，只是不让它们占据默认那一屏 ——
     *   这就是这一轮「简约但功能不减」的全部做法。
     */
    private fun toggleTools() {
        val show = toolsWrap.visibility != View.VISIBLE
        toolsWrap.visibility = if (show) View.VISIBLE else View.GONE
        toolsToggle.setText(
            if (show) R.string.interact_tools_title_open else R.string.interact_tools_title_closed
        )
    }

    // ---------------------------------------------- 第 84 期：超Like 一键编排

    /**
     * 展开 / 收起「超Like 一键编排」。**默认收起**。
     *
     * ★ 与 [toggleTools] 同一套折叠套路 —— 日常那一屏不该被一整个编排器占满，
     *   但里面的东西**一个都没删**，点开就能用。
     */
    private fun toggleSuperlike() {
        val show = superlikeWrap.visibility != View.VISIBLE
        superlikeWrap.visibility = if (show) View.VISIBLE else View.GONE
        superlikeToggle.setText(
            if (show) R.string.interact_superlike_title_open
            else R.string.interact_superlike_title_closed
        )
    }

    /**
     * 把**存过的**超Like 计划读回界面。★ **只在 onCreate 调一次**。
     *
     * ★ 为什么不像「频率」那样每次 `onResume` 都重读：这三个框里装的是
     *   **用户正在打的字**，刷新会把它们冲掉（频率那两个框正是为此被排除在
     *   [refreshAll] 之外的）。这里同样只回填一次。
     */
    private fun loadSuperlike() {
        val plan = InteractTaskStore.plan()
        superlikeTopicEdit.setText(plan.topic)
        superlikeFirstEdit.setText(plan.firstComments.toString())
        superlikeRepostEdit.setText(plan.reposts.toString())
        fillSuperlikeAccounts()
    }

    /**
     * 刷新超Like 卡里**会变的**那一部分：可用的账号。
     *
     * ★ 刻意**不碰**超话链接 / 首评条数 / 转发条数三个输入框 —— 同上，那是用户的输入。
     * ★ 条目没变就**不重填**：重填会让已经展开的下拉框当场合上，
     *   而 `refreshAll()` 在每次 `onResume` 时都会跑一遍。
     */
    private fun refreshSuperlike() {
        val wanted = accountChoices()
        val adapter = superlikeAccountSpinner.adapter
        val current = (0 until (adapter?.count ?: 0)).map { adapter?.getItem(it) as? String ?: "" }
        if (wanted != current) fillSuperlikeAccounts()
        // ★ 第 99 期：按钮下面那行结果也在这里刷（`refreshAll()` 每次 `onResume` 都会调过来，
        //   所以从别的页面回来，「上次结果」还在）。
        refreshSuperlikeResult()
    }

    /**
     * ★★★★ 第 102 期：刷新「一键跑超Like」按钮下面那一行 —— **今天累计已完成多少**。
     *
     * ## 为什么从「上次结果」改成「今天累计」
     *
     * 用户报「弄过一次超 Like 之后，再跑一次，结果就为零零了」。
     * 那 0 条**不是故障**：候选池只收「回包明确说 0 条评论」的帖子、
     * 转发还会剔掉「最近已经转过」的帖子 —— 这是两道**故意设的安全闸**
     * （防的就是重复评论 / 重复转发，见 [SuperLikeRunner]）。
     * 真正的毛病是第 99 期「后一次覆盖前一次」的显示口径：
     * 一趟空跑就把已经达成的 4 / 4 冲成了 0 / 4。
     *
     * ★ 用户原话：「**你可以显示该微博首评四条，转发两条已经完成了**」。
     *
     * ## 范围跟着界面上的「超话 + 账号」走
     *
     *   · 选了具体账号 ⇒ 只看那个账号；
     *   · 「所有账号轮流」 ⇒ 合计（分母也一起相加）；
     *   · 超话框为空 ⇒ 不按超话筛（合计今天所有超话）。
     *
     * ★ 数字全部来自 [InteractTaskStore.todayDone]（**结构化**的），
     *   这一行**不解析任何文案** —— 第 20 条纪律：判据不许认文案。
     * ★ 没跑过 ⇒ 印一句引导语，而不是留白：留白会让人以为这一行是坏的。
     */
    private fun refreshSuperlikeResult() {
        val topicId = InteractTarget.topicId(superlikeTopicEdit.text.toString().trim())
        val rows = InteractTaskStore.todayDoneByAccount(topicId)
        if (rows.isEmpty()) {
            superlikeResult.text = getString(R.string.interact_superlike_result_idle)
            return
        }
        // ★★★★ 第 103 期（用户批准）：由「一行汇总」改成「**每个账号一行**」。
        //   用户原话：「一键超like你要在下面显示哪些账号完成了首评，转发几条……
        //   让客户更加直观的看到」。第 102 期那行只有一个总数，看不出谁做完了、谁还差几条。
        //   ★ 达成判据仍是**结构**（数字比数字），不是看文案里有没有「已完成」（第 20 条纪律）。
        //   ★ 目标为 0 时判「已达成」，免得显示成永远做不完。
        //   ★ 顺序由 [InteractTaskStore.todayDoneByAccount] 保证（按账号名升序），界面不重排。
        val lines = rows.map { (label, one) ->
            val complete = (one.firstTarget <= 0 || one.firstOk >= one.firstTarget) &&
                (one.repostTarget <= 0 || one.repostOk >= one.repostTarget)
            if (complete) {
                getString(
                    R.string.interact_superlike_acct_done,
                    label, one.firstOk, one.repostOk
                )
            } else {
                getString(
                    R.string.interact_superlike_acct_progress,
                    label, one.firstOk, one.firstTarget, one.repostOk, one.repostTarget
                )
            }
        }
        superlikeResult.text = lines.joinToString("\n")
        // ★★★ 第 105 期：概览二卡与这一行**同源**，一起刷。
        refreshSuperlikeStats()
    }

    // ---------------------------------------------------------------- 第 105 期：运行态

    /**
     * ★★★ 第 105 期：**开始 / 暂停 / 停止** 的按钮可用性。
     *
     * 跑起来时主按钮要点不动（再点一遍就是同时跑两趟），暂停 / 停止才可用；
     * 跑完（或停了）反过来。
     */
    private fun setSuperlikeBusy(busy: Boolean) {
        findViewById<Button>(R.id.interactSuperlikeRun).isEnabled = !busy
        superlikePause.isEnabled = busy
        superlikeStop.isEnabled = busy
        if (!busy) {
            superlikePause.setText(R.string.interact_superlike_pause_btn)
        }
    }

    /**
     * 「然屯速递」切到**运行态**：分母先画出来（0/4、0/2），动态文本复位。
     *
     * @param firstTarget 这一趟的首评目标数（0 = 没勾「确认首评」）。
     * @param repostTarget 这一趟的转发目标数（0 = 没勾「精华转发」）。
     */
    private fun showSuperlikeRunning(firstTarget: Int, repostTarget: Int) {
        updateSuperlikeNumbers(0, firstTarget, 0, repostTarget)
        superlikeLogLines.clear()
        superlikeLiveLog.text = ""
        liveFirstPrev = 0
        liveRepostPrev = 0
        superlikeLiveText.setText(R.string.interact_superlike_live_preparing)
    }

    /**
     * 往「然屯速递」的明细里补一行，只留最近 3 行。
     *
     * ★ 同一个数字**不重复追加**（被抢先、没发出去都不会让计数变化，
     *   那些情况靠动态文本那一行说，明细里只记「真的成了几条」）。
     */
    private fun appendSuperlikeLog(line: String) {
        superlikeLogLines.addLast(line)
        while (superlikeLogLines.size > 3) superlikeLogLines.removeFirst()
        superlikeLiveLog.text = superlikeLogLines.joinToString("\n")
    }

    /**
     * 刷新「然屯速递」的数字与两条进度条，**并顺手刷新顶部概览二卡**。
     *
     * ★ 概览二卡平时读的是「今天累计」（[InteractTaskStore.todayDone]）；
     *   跑起来的这一趟还没落盘，所以这里用**这一趟的实时数字 + 已落盘的累计**
     *   取和 —— 用户看到的永远是「现在已经成了几条」。
     */
    private fun updateSuperlikeNumbers(
        firstOk: Int,
        firstTarget: Int,
        repostOk: Int,
        repostTarget: Int
    ) {
        superlikeLiveFirstNum.text = getString(
            R.string.interact_superlike_live_num_fmt, firstOk, firstTarget
        )
        superlikeLiveRepostNum.text = getString(
            R.string.interact_superlike_live_num_fmt, repostOk, repostTarget
        )
        superlikeLiveFirstBar.progress =
            if (firstTarget <= 0) 0 else firstOk * 100 / firstTarget
        superlikeLiveRepostBar.progress =
            if (repostTarget <= 0) 0 else repostOk * 100 / repostTarget
        val done = InteractTaskStore.todayDone(
            InteractTarget.topicId(superlikeTopicEdit.text.toString().trim()),
            superlikeSelectedLabel()
        )
        val showFirst = (done?.firstOk ?: 0) + firstOk
        val showFirstTarget = (done?.firstTarget ?: 0) + firstTarget
        val showRepost = (done?.repostOk ?: 0) + repostOk
        val showRepostTarget = (done?.repostTarget ?: 0) + repostTarget
        superlikeStatFirst.text = getString(
            R.string.interact_superlike_live_num_fmt, showFirst, showFirstTarget
        )
        superlikeStatRepost.text = getString(
            R.string.interact_superlike_live_num_fmt, showRepost, showRepostTarget
        )
        // 哪边的数字涨了就补一行明细（只报变化）。
        if (firstOk != liveFirstPrev) {
            liveFirstPrev = firstOk
            appendSuperlikeLog(getString(R.string.interact_superlike_log_first, firstOk, firstTarget))
        }
        if (repostOk != liveRepostPrev) {
            liveRepostPrev = repostOk
            appendSuperlikeLog(
                getString(R.string.interact_superlike_log_repost, repostOk, repostTarget)
            )
        }
    }

    /**
     * 顶部概览二卡：**只读「今天累计」**（不在跑的时候用）。
     *
     * ★ 与下面那一行战绩同一个数据源（[InteractTaskStore.todayDone]）——
     *   两处数字必须一致，否则用户一定以为其中一个是坏的。
     */
    private fun refreshSuperlikeStats() {
        val done = InteractTaskStore.todayDone(
            InteractTarget.topicId(superlikeTopicEdit.text.toString().trim()),
            superlikeSelectedLabel()
        )
        superlikeStatFirst.text = getString(
            R.string.interact_superlike_live_num_fmt,
            done?.firstOk ?: 0,
            done?.firstTarget ?: 0
        )
        superlikeStatRepost.text = getString(
            R.string.interact_superlike_live_num_fmt,
            done?.repostOk ?: 0,
            done?.repostTarget ?: 0
        )
    }

    /**
     * 「暂停」按一下暂停、再按一下继续（文案在两者之间切换）。
     *
     * ★ 暂停只发生在 [SuperLikeRunner] 两条写请求之间本来就要停的那 1.5~4 秒里，
     *   所以绝不会把一次「已发出、还没核对」的评论打断在半空。
     */
    private fun toggleSuperlikePause() {
        val flags = superlikeFlags ?: return
        flags.paused = !flags.paused
        superlikePause.setText(
            if (flags.paused) R.string.interact_superlike_resume_btn
            else R.string.interact_superlike_pause_btn
        )
        superlikeLiveText.setText(
            if (flags.paused) R.string.interact_superlike_live_paused
            else R.string.interact_superlike_running
        )
    }

    /**
     * 「停止」—— 后台线程最多再跑完**当前这一个动作**就收手。
     *
     * ★ 只翻一个标志，不杀线程：这一趟的 [InteractTaskStore] 落盘与结果刷新
     *   照常在原线程的收尾里做完（用户要能看到「停之前成了几条」）。
     */
    private fun stopSuperLike() {
        superlikeFlags?.stopped = true
        superlikeLiveText.setText(R.string.interact_superlike_live_stopped)
    }

    /**
     * 填账号下拉，并尽量**保住用户已经选中的那个**。
     *
     * ★ 为什么非要保住：`refreshAll()` 会重填这个下拉（用户可能刚在账号页
     *   加过号、或改过启用状态）。如果每次都跳回第 0 项「所有账号轮流」，
     *   用户刚选好的账号就被**悄悄改掉**了 —— 那正是这个工程反复吃亏的
     *   「静默的不同决定」。找不到原来那个（被删 / 被停用）才回落到第 0 项。
     */
    private fun fillSuperlikeAccounts() {
        val keep = superlikeSelectedLabel()
        val items = accountChoices()
        fillSpinner(superlikeAccountSpinner, items)
        val found = if (keep.isBlank()) -1 else usableAccounts().indexOfFirst { it.label == keep }
        val index = if (found < 0) 0 else found + 1
        superlikeAccountSpinner.setSelection(index.coerceIn(0, (items.size - 1).coerceAtLeast(0)))
    }

    /**
     * 下拉当前选中的**账号键**（`label`）。第 0 项「所有账号轮流」= 空串。
     *
     * ★ 印出来的是昵称、交出去的是 `label` —— 与任务对话框同一条纪律
     *   （见 [accountChoices] 那段说明）：任务与计划都是靠 `label` 匹配回账号的，
     *   存昵称会让匹配失败、静默退化成「第一个账号」。
     */
    private fun superlikeSelectedLabel(): String {
        val position = superlikeAccountSpinner.selectedItemPosition
        if (position <= 0) return ""
        return usableAccounts().getOrNull(position - 1)?.label.orEmpty()
    }

    /** 这个计划要跑在**哪些账号**上（与 [accountsFor] 同一条规则：空 = 全部可用账号）。 */
    private fun superlikeAccounts(plan: SuperLikePlan): List<WeiboAccount> {
        val usable = usableAccounts()
        if (plan.accountLabel.isBlank()) return usable
        return usable.filter { it.label == plan.accountLabel }
    }

    /**
     * 把界面上填的东西读成一个 [SuperLikePlan]。
     *
     * ★ 三条校验都在这里做，任何一条不过就**当场说清**并返回 null ——
     *   绝不让一个半成品计划走到「真发」那一步。
     * ★ 数字用 [SuperLikePlan.clampFirst] / [SuperLikePlan.clampRepost] 夹到 0..10：
     *   这两个数字直接决定一次点击会发多少个写请求，没有上限就是拿账号在赌。
     */
    private fun readSuperlikePlan(): SuperLikePlan? {
        val topic = superlikeTopicEdit.text.toString().trim()
        if (topic.isBlank()) {
            toast(getString(R.string.interact_superlike_need_topic))
            return null
        }
        if (InteractTarget.topicId(topic).isBlank()) {
            toast(getString(R.string.interact_superlike_bad_topic))
            return null
        }
        val first = SuperLikePlan.clampFirst(
            superlikeFirstEdit.text.toString().trim().toIntOrNull() ?: SuperLikePlan.OFFICIAL_FIRST
        )
        val reposts = SuperLikePlan.clampRepost(
            superlikeRepostEdit.text.toString().trim().toIntOrNull() ?: SuperLikePlan.OFFICIAL_REPOST
        )
        // ★★★ 第 105 期：复选框取消哪一项，那一项的条数就按 **0** 跑。
        //   （例：只勾「精华转发」⇒ firstComments = 0，首评那一步整个不做。）
        //   ★ 与「条数框填 0」在 [SuperLikeRunner] 里是同一条路：`firstComments <= 0`
        //     时首评循环一次都不进，转发照常。
        val wantFirst = if (superlikeTaskFirst.isChecked) first else 0
        val wantReposts = if (superlikeTaskRepost.isChecked) reposts else 0
        if (wantFirst + wantReposts == 0) {
            toast(getString(R.string.interact_superlike_nothing))
            return null
        }
        return SuperLikePlan(
            topic = topic,
            firstComments = wantFirst,
            reposts = wantReposts,
            accountLabel = superlikeSelectedLabel(),
            // ★ 语料分组留空 = 用第一个分组（与「试跑 / 发送」同一套取语料规则）。
            groupId = ""
        )
    }

    /**
     * 「一键跑超Like」—— 首评 + 转发。
     *
     * ★★ 第 100 期：**确认框已删**。原来是「真发开关关着就不问、开着才弹一次确认」，
     *   现在开关和确认框一起按用户要求去掉了 ⇒ 点一下就直接跑。
     * ★★★ 第 101 期：**「试跑一次」那颗按钮也已删**（用户要求）⇒ 这张卡上只剩这一颗按钮，
     *   点下去就是真发。`SuperLikeRunner.rehearse()` 的只读能力原样保留，只是没有 UI 入口了。
     */
    private fun runSuperLike() {
        val plan = readSuperlikePlan() ?: return
        launchSuperLike(plan)
    }

    /**
     * 真跑一次超Like 编排。
     *
     * ★ 必须放**后台线程**：一次编排要打十几个网络请求，最长一两分钟，
     *   在 UI 线程发就是 ANR。
     * ★ 一个账号失败**不影响**后面的账号 —— 每个账号单独兜异常。
     * ★ 把这次填的计划**落盘**：下次打开 App 不用重填。
     * ★★★ 第 101 期：`rehearse` 参数已删（「试跑一次」按钮不在了）⇒ 这里只有真跑一条路。
     */
    private fun launchSuperLike(plan: SuperLikePlan) {
        val accounts = superlikeAccounts(plan)
        if (accounts.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.interact_superlike_result_title))
                .setMessage(getString(R.string.interact_superlike_no_account))
                .setPositiveButton(getString(R.string.dialog_ok), null)
                .show()
            return
        }
        InteractTaskStore.savePlan(plan)
        if (accounts.size > 1) {
            toast(getString(R.string.interact_multi_running, accounts.size))
        } else {
            toast(getString(R.string.interact_superlike_running))
        }
        // ★★★ 第 105 期：这一趟的暂停 / 停止标志（每次开始都新建，旧的那一趟作废）。
        val flags = SuperlikeRunFlags()
        superlikeFlags = flags
        val monitor = object : SuperLikeRunner.Monitor {
            override fun onStart(firstTarget: Int, repostTarget: Int) {
                runOnUiThread { showSuperlikeRunning(firstTarget, repostTarget) }
            }

            override fun onProgress(
                firstOk: Int,
                firstTarget: Int,
                repostOk: Int,
                repostTarget: Int
            ) {
                runOnUiThread {
                    updateSuperlikeNumbers(firstOk, firstTarget, repostOk, repostTarget)
                }
            }

            override fun onMessage(text: String) {
                runOnUiThread { superlikeLiveText.text = text }
            }

            override fun shouldStop(): Boolean = flags.stopped

            /**
             * 用户按了「暂停」时阻塞到这里。
             *
             * ★ 200ms 醒一次：既不会空转到烫手，点「继续」后的延迟人也感觉不到。
             * ★ 返回 true = 别等了（用户在暂停期间点了停止，或线程被中断）。
             */
            override fun awaitResume(): Boolean {
                while (flags.paused && !flags.stopped) {
                    try {
                        Thread.sleep(200)
                    } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                        return true
                    }
                }
                return flags.stopped
            }
        }
        runOnUiThread { setSuperlikeBusy(true) }
        Thread {
            // ★★★ 第 99 期：真跑时**顺手把数字收下来**（首评 / 转发各成了几条），
            //   给按钮下面那一行用。数字来自 [SuperLikeRunner.Outcome]，
            //   **不去解析**那段文字（第 20 条纪律）。
            // ★★★ 第 102 期：连**账号**一起配对收下来 —— 今天的累计是
            //   **按「超话 + 账号」分开记**的（用户选的口径），
            //   只留 Outcome 就丢了归属，没法记进正确的格子。
            val outcomes = mutableListOf<Pair<WeiboAccount, SuperLikeRunner.Outcome>>()
            val result = accounts.joinToString("\n\n") { account ->
                try {
                    SuperLikeRunner.run(this, plan, account, monitor)
                        .also { outcomes.add(account to it) }.text
                } catch (error: Throwable) {
                    account.displayName + "：" + getString(
                        R.string.interact_superlike_aborted,
                        error.message ?: error.javaClass.simpleName
                    )
                }
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                // ★ 只记**真的跑完了一趟**的那些（`at > 0` 就是这个意思，
                //   它是**结构**标记，不是看文字）。
                //   没账号 / 没 Cookie / 准备失败都是 `at = 0` —— 那些
                //   一个内容都没发出去，记成「0 / 4 条」会把已经达成的成绩冲淡。
                // ★★★ 第 102 期：**累加进「今天」**，不再覆盖 ——
                //   这正是「再跑一次结果就变 0」的修复点
                //   （见 [InteractTaskStore.KEY_TODAY_DONE]）。
                //   跑第二趟哪怕一条都没成，已经拿到的 4 / 4 也不会被冲掉。
                val topicId = InteractTarget.topicId(plan.topic)
                val real = outcomes.filter { it.second.at > 0L }
                for ((account, outcome) in real) {
                    InteractTaskStore.addTodayDone(topicId, account.label, outcome)
                }
                refreshTrace()
                refreshSuperlikeResult()

                // ★★★ 第 105 期：这一趟收工 —— 按钮恢复、动态文本换成这一趟的汇总。
                //   ★ 进度条用**这一趟**的数字（用户刚看的是它）；概览二卡走今天累计
                //     （[refreshSuperlikeResult] 已经把这一趟落盘了，不能再加一遍）。
                superlikeFlags = null
                setSuperlikeBusy(false)
                val firstOk = real.sumOf { it.second.firstOk }
                val firstTarget = real.sumOf { it.second.firstTarget }
                val repostOk = real.sumOf { it.second.repostOk }
                val repostTarget = real.sumOf { it.second.repostTarget }
                updateSuperlikeNumbers(firstOk, firstTarget, repostOk, repostTarget)
                if (flags.stopped) {
                    superlikeLiveText.setText(R.string.interact_superlike_live_stopped)
                } else if (real.isNotEmpty()) {
                    superlikeLiveText.text = getString(
                        R.string.interact_superlike_live_done,
                        firstOk, firstTarget, repostOk, repostTarget
                    )
                }

                // ★★★ 第 100 期：**不再无脑弹那个多行「编排结果」框**。
                //   用户原话：「我不要这个编排结果，直接告诉我答案，首评了几条，转发了几条」。
                //   所以分两种走：
                //     · 一切正常 → 只 toast 一行数字（答案就在按钮下面那行，这里再报一次）；
                //     · 有事挡住 → 才弹框，**只列那几条「怎么做」**。
                //   ★ 判据是**结构**：`alerts` 由 [SuperLikeRunner] 在明确分支里填，
                //     这里**不解析** [result] 那段文字（第 20 条纪律：判据不许认文案）。
                //   ★★★ 第 101 期：原来的「试跑 → 照旧弹框」那一支已随按钮删除。
                val alerts = real.flatMap { it.second.alerts }.distinct()
                when {
                    alerts.isNotEmpty() -> AlertDialog.Builder(this)
                        .setTitle(getString(R.string.interact_superlike_alert_title))
                        .setMessage(alerts.joinToString("\n\n"))
                        .setPositiveButton(getString(R.string.dialog_ok), null)
                        .show()

                    real.isNotEmpty() -> {
                        // ★ 第 102 期：toast 报的也是**今天累计**（与按钮下面那行同口径）——
                        //   否则第二趟跑出 0 条时，toast 会跟那行显示打架。
                        val done = InteractTaskStore.todayDone(topicId, superlikeSelectedLabel())
                        toast(
                            getString(
                                R.string.interact_superlike_toast,
                                done?.firstOk ?: 0,
                                done?.firstTarget ?: 0,
                                done?.repostOk ?: 0,
                                done?.repostTarget ?: 0
                            )
                        )
                    }

                    // 兜底：一个 Outcome 都没收到（例如每个账号都在网络层抛异常）
                    // ⇒ 把错误串原样给用户看，不然他点了半天没有任何反馈。
                    else -> AlertDialog.Builder(this)
                        .setTitle(getString(R.string.interact_superlike_result_title))
                        .setMessage(result)
                        .setPositiveButton(getString(R.string.dialog_ok), null)
                        .show()
                }
            }
        }.start()
    }

    /**
     * 「立即发送」—— 真的把评语发到微博上。
     *
     * ★ 选任务的方式与「试跑」**完全一致**（只有一个就直接发，多个先让用户挑），
     *   否则用户会分不清「刚才那下是发给谁的」。
     * ★★ 第 100 期：真发开关与「真发前再问一次」的确认框都已删 ⇒ 选完就直接发。
     */
    private fun runSend() {
        val tasks = InteractTaskStore.all()
        if (tasks.isEmpty()) {
            toast(getString(R.string.interact_task_empty))
            return
        }
        if (tasks.size == 1) {
            doSend(tasks[0])
            return
        }
        // ★★ 第 100 期：这个弹窗**只是「选哪一条」**，不是「确不确定发」——
        //   确认框已删。标题因此从「确认发送」改成「发送」。
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.interact_send_card_title))
            .setItems(tasks.map { taskRowText(it) }.toTypedArray()) { _, which ->
                doSend(tasks[which])
            }
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .show()
    }

    /**
     * 真跑一次发送（会阻塞，必须放后台线程 —— 和试跑同理，最长 15 秒 × 两个接口）。
     *
     * ★ 预演与真发只差一件事：真发会**消耗账号额度**并真的写出去，
     *   所以它会记账（`RateGuard.markRun`，在 [InteractRunner.send] 里面）。
     */
    private fun doSend(task: InteractTask) {
        // ★★★★ 第 67 期：任务没指定账号（下拉第 0 项「所有账号轮流」）⇒ **每个可用账号都发一遍**；
        //   指定了账号 ⇒ 只发那一个。分派逻辑在 [accountsFor]。
        val accounts = accountsFor(task)
        if (accounts.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.interact_send_result_title))
                .setMessage(getString(R.string.interact_no_usable_account))
                .setPositiveButton(getString(R.string.dialog_ok), null)
                .show()
            return
        }

        if (accounts.size > 1) {
            toast(getString(R.string.interact_multi_running, accounts.size))
        } else {
            toast(getString(R.string.interact_send_running))
        }
        Thread {
            // ★ 一个账号失败**不影响**后面的账号 —— 每个账号单独兜异常，
            //   否则第一个账号网络抽风就会把剩下几个一起带掉。
            val result = accounts.joinToString("\n\n") { account ->
                try {
                    InteractRunner.send(this, task, account)
                } catch (error: Throwable) {
                    account.displayName + "：" + (error.message ?: error.javaClass.simpleName)
                }
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                refreshAll()
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.interact_send_result_title))
                    .setMessage(result)
                    .setPositiveButton(getString(R.string.dialog_ok), null)
                    .show()
            }
        }.start()
    }

    // ---------------------------------------------------------------- 任务行

    private fun buildTaskRow(task: InteractTask): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ContextCompat.getColor(this@InteractActivity, R.color.row_bg))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        }

        val head = TextView(this).apply {
            text = taskRowText(task)
            textSize = 14f
            setTextColor(
                ContextCompat.getColor(
                    this@InteractActivity,
                    if (task.enabled) R.color.text_primary else R.color.text_secondary
                )
            )
        }
        row.addView(head)

        // ★★★★ 第 56 期：任务行上把「上次执行」说出来。
        //
        // 在这之前 `lastRunAt` / `lastResult` 两个字段**从来没有人写过** ——
        // 用户点完「立即发送」只看到一次弹窗，回头再看任务，什么都没留下；
        // 过两天就完全想不起「这条到底发成功过没有」。这和「一眼看懂」是矛盾的。
        //
        // ★ 只有真跑过（`lastRunAt > 0`）才显示这一行 —— 新建的任务不该假装自己跑过。
        // ★ 结果原文照实显示（成功是「已发出：评论 id=…」，失败是失败原因），
        //   不在这里二次判断「算不算成功」：判据只有一处（`POST` 回包的 ok 字段）。
        if (task.lastRunAt > 0L) {
            row.addView(TextView(this).apply {
                text = getString(
                    R.string.interact_task_last_run,
                    InteractFormat.stamp(task.lastRunAt),
                    task.lastResult.ifBlank { "—" }
                )
                textSize = 12f
                setTextColor(ContextCompat.getColor(this@InteractActivity, R.color.text_secondary))
                setPadding(0, dp(4), 0, 0)
            })
        }

        if (task.note.isNotBlank()) {
            row.addView(TextView(this).apply {
                text = task.note
                textSize = 12f
                setTextColor(ContextCompat.getColor(this@InteractActivity, R.color.text_secondary))
                setPadding(0, dp(4), 0, 0)
            })
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }

        buttons.addView(smallButton(
            if (task.enabled) R.string.interact_task_disable else R.string.interact_task_enable
        ) {
            task.enabled = !task.enabled
            InteractTaskStore.update(task)
            refreshTasks()
        })

        buttons.addView(smallButton(R.string.interact_task_delete) {
            InteractTaskStore.remove(task.id)
            refreshTasks()
            toast(getString(R.string.interact_task_removed))
        })

        row.addView(buttons)
        return row
    }

    private fun smallButton(textRes: Int, onClick: () -> Unit): Button =
        Button(this).apply {
            text = getString(textRes)
            textSize = 13f
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            ).apply { marginEnd = dp(6) }
        }

    // ---------------------------------------------------------------- 语料库

    /**
     * 「快速加一条评语」按钮。
     *
     * ★★★★ 第 58 期修：这条路径原来**固定往第一个分组里加**，而且界面上**一个字都没说**。
     *   用户新建了「分组 2」，点这个按钮加了几条，回头点开「分组 2」—— 空的。
     *   评语没丢，只是进了「分组 1」，而用户拿不到任何线索。
     *   ⇒ 两个改动：
     *     ① 只有一个分组时照旧直接加（不多一次点击），但**标题里写清是哪个分组**；
     *     ② 有多个分组时**先让用户挑**—— 猜用户的意图、然后悄悄写进别的分组，
     *        正是这个工程反复吃过亏的那类「静默的不同决定」。
     *   ★ 第 44 期的教训还留着：绝不能拿「新建分组」这种**按钮文案**当默认分组名。
     */
    private fun quickAddLine() {
        val groups = CommentLib.groups()
        when {
            groups.isEmpty() -> addLineTo(
                CommentLib.addGroup(getString(R.string.interact_lib_default_group)).id
            )

            groups.size == 1 -> addLineTo(groups[0].id)

            else -> AlertDialog.Builder(this)
                .setTitle(getString(R.string.interact_lib_quick_pick_group))
                .setItems(groups.map { it.name }.toTypedArray()) { _, which ->
                    addLineTo(groups[which].id)
                }
                .setNegativeButton(getString(R.string.dialog_cancel), null)
                .show()
        }
    }

    /** 往**指定**分组加评语（标题里带上分组名，免得又不知道加到哪儿去了）。 */
    private fun addLineTo(groupId: String) {
        val group = CommentLib.findGroup(groupId) ?: return
        inputDialog(
            R.string.interact_lib_add,
            R.string.interact_lib_add_hint,
            "",
            // ★ 第 56 期：填的时候就把「低质风险」说出来（只提示，不拦）
            qualityCheck = true,
            titleGroup = group.name
        ) { value ->
            reportImport(CommentLib.addLines(groupId, value))
        }
    }

    /**
     * 把一次导入的结果说清楚。
     *
     * ★ 第 44 期：清理过内容时必须**明说**。静默改掉用户粘进来的字，
     *   哪怕改的是 `[/cp]` 这种机器标记，也会让人以为程序在乱改东西。
     */
    private fun reportImport(result: CommentImport) {
        refreshLib()
        toast(
            if (result.cleaned > 0) {
                getString(R.string.interact_lib_import_cleaned, result.added, result.cleaned)
            } else {
                getString(R.string.interact_lib_import_done, result.added)
            }
        )
    }

    private fun showLibDialog() {
        val groups = CommentLib.groups()
        // 分组名后面挂上条数 —— 用户选分组时最想知道的就是「这组够不够用」。
        val names = groups.map {
            getString(R.string.interact_lib_group_item, it.name, it.lines.size)
        }.toMutableList()
        // ★ 第 57 期：分组行之后是两个**全局**动作。
        //   「追加一个后缀」为什么挪到这里：后缀本来就是**全局**的
        //   （`CommentLib.addSuffix` 加进的是共享后缀表，跟哪个分组无关），
        //   原来塞在某个分组的菜单里，等于让人以为「后缀是这组的」—— 位置本身就错了。
        names.add(getString(R.string.interact_lib_new_group))
        names.add(getString(R.string.interact_lib_suffix_title))

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.interact_lib_manage))
            .setItems(names.toTypedArray()) { _, which ->
                when {
                    which < groups.size -> showGroupActions(groups[which].id)
                    which == groups.size -> inputDialog(
                        R.string.interact_lib_new_group,
                        R.string.interact_lib_group_name_hint,
                        ""
                    ) { value ->
                        CommentLib.addGroup(value)
                        refreshLib()
                    }
                    else -> promptAddSuffix()
                }
            }
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .show()
    }

    /**
     * 追加一个后缀（**全局**，不属于任何分组）。
     *
     * ★ 第 57 期从「分组菜单」挪到「语料库菜单」—— 原来那个位置是错的。
     */
    private fun promptAddSuffix() {
        inputDialog(
            R.string.interact_lib_suffix_title,
            R.string.interact_lib_suffix_hint,
            ""
        ) { value ->
            val added = CommentLib.addSuffix(value)
            refreshLib()
            toast(
                getString(
                    if (added) R.string.interact_lib_suffix_added
                    else R.string.interact_lib_suffix_exists
                )
            )
        }
    }

    /**
     * 一个分组能做的事。
     *
     * ★★★★ 第 57 期精简：原来一张单子 8 项，问题**不是「多」而是「乱」**——
     *   三种不同性质的东西混在一起：
     *     ① 日常用：加评语、随机取一条、低质风险自检
     *     ② 改这个分组的结构：重命名、清空、删除
     *     ③ 跟这个分组**根本没关系**的：追加一个后缀（后缀是全局表，
     *        见 [promptAddSuffix] 的说明，已挪到语料库菜单）
     *   现在 ① 留在这一层、② 收进「分组设置…」、③ 挪走 ⇒ 一张单子只剩 4 项。
     *
     *   ★ 只是**把入口归位，功能一个都没删**：原来能做的现在都还能做。
     *     「批量导入评语」并进「加评语」也是同一个道理 ——
     *     [CommentLib.addLines] 本来就是**按行拆**的，两个入口跑的是同一段代码、
     *     只差一句提示语，摆两个选项纯粹是让人犹豫点哪个。
     *
     * ★★★★ 第 58 期补：加上「看看这组的评语」。
     *   用户反馈「新建分组看不到里面的评语内容」—— 这是个**真的缺口**：
     *   语料库那一层只显示「分组名（N 条）」，而 N 这个数字是**唯一**的证据，
     *   点进来又只有动作、没有内容 ⇒ 用户加了评语却**没有任何地方能看见它**，
     *   只能靠「随机取一条」一条一条抽（抽到重复的还会以为没加进去）。
     *   ⇒ 加一项只读的清单。★ 只读：不改、不删、不排序，看完就关。
     */
    private fun showGroupActions(groupId: String) {
        val group = CommentLib.findGroup(groupId) ?: return
        val actions = listOf(
            getString(R.string.interact_lib_add),
            getString(R.string.interact_lib_view),
            getString(R.string.interact_lib_pick),
            getString(R.string.interact_quality_title),
            getString(R.string.interact_lib_group_settings)
        )

        AlertDialog.Builder(this)
            .setTitle(group.name)
            .setItems(actions.toTypedArray()) { _, which ->
                when (which) {
                    0 -> addLineTo(groupId)

                    1 -> showGroupLines(groupId)

                    2 -> {
                        val picked = CommentLib.pick(groupId)
                        toast(picked ?: getString(R.string.interact_lib_pick_empty))
                    }

                    3 -> showQualityReport(groupId)

                    else -> showGroupSettings(groupId)
                }
            }
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .show()
    }

    /**
     * ★ 第 58 期：把这一组的评语**原样列出来**（只读）。
     *
     * ★ 用 `setMessage` 而不是自己塞 ScrollView：框架的 AlertController
     *   会把 message 放进一个 ScrollView 里，长列表自动可滚。
     *   自己塞一个 ScrollView 反而容易把对话框撑出屏幕（那时它就不滚了）。
     *
     * ★ 编号从 1 开始：用户是拿它跟「我粘了几条」对数的，从 0 开始会让人怀疑少了一条。
     * ★ **不显示**每条的风险标记 —— 那是「低质风险自检」的活，这里只负责「让你看见」。
     *   一个界面只说一件事，才不会又变成一个看不懂的界面。
     */
    private fun showGroupLines(groupId: String) {
        val group = CommentLib.findGroup(groupId) ?: return
        if (group.lines.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.interact_lib_view_title, group.name, 0))
                .setMessage(getString(R.string.interact_lib_view_empty))
                .setPositiveButton(getString(R.string.dialog_ok), null)
                .show()
            return
        }
        val body = group.lines.mapIndexed { index, line ->
            getString(R.string.interact_lib_view_item, index + 1, line.text)
        }.joinToString("\n")
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.interact_lib_view_title, group.name, group.lines.size))
            .setMessage(body)
            .setPositiveButton(getString(R.string.dialog_ok), null)
            .show()
    }

    /**
     * 分组的管理动作（重命名 / 清空 / 删除）单独收一层。
     *
     * ★ 第 57 期：这三个都是**改结构**的动作，跟「加评语」那种日常动作不是一个性质 ——
     *   混在一张单子里既容易误点，也会把日常那几项淹没。
     *   收进来之后，外层那张单子才真的能一眼看完。
     */
    private fun showGroupSettings(groupId: String) {
        val group = CommentLib.findGroup(groupId) ?: return
        val actions = listOf(
            getString(R.string.interact_lib_rename_group),
            getString(R.string.interact_lib_clear),
            getString(R.string.interact_lib_delete_group)
        )

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.interact_lib_group_settings_title, group.name))
            .setItems(actions.toTypedArray()) { _, which ->
                when (which) {
                    0 -> inputDialog(
                        R.string.interact_lib_rename_group,
                        R.string.interact_lib_group_name_hint,
                        group.name
                    ) { value ->
                        CommentLib.renameGroup(groupId, value)
                        refreshLib()
                    }

                    1 -> {
                        CommentLib.clearGroup(groupId)
                        refreshLib()
                        toast(getString(R.string.interact_lib_cleared))
                    }

                    else -> {
                        CommentLib.removeGroup(groupId)
                        refreshLib()
                    }
                }
            }
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .show()
    }

    // ---------------------------------------------------------------- 新建任务

    private fun showAddTaskDialog() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }

        // ★ 用闭包记选中的动作，不给 RadioButton 编 id ——
        //   `checkedRadioButtonId` 只有在 id 来自资源时才有意义，
        //   自造的整数 id 在恢复实例状态那条路上会踩坑。
        var selectedAction = InteractAction.COMMENT
        val actionGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val actionHint = TextView(this).apply {
            text = getString(InteractAction.COMMENT.hintRes)
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@InteractActivity, R.color.text_secondary))
            setPadding(0, dp(4), 0, 0)
        }
        for (action in InteractAction.entries) {
            actionGroup.addView(RadioButton(this).apply {
                text = getString(action.labelRes)
                textSize = 14f
                isChecked = action == InteractAction.COMMENT
                setOnCheckedChangeListener { _, checked ->
                    if (checked) {
                        selectedAction = action
                        actionHint.text = getString(action.hintRes)
                    }
                }
            })
        }
        root.addView(actionGroup)
        root.addView(actionHint)

        root.addView(labelView(R.string.interact_task_target_hint))
        val targetEdit = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            textSize = 14f
        }
        root.addView(targetEdit)

        root.addView(labelView(R.string.interact_task_note_hint))
        val noteEdit = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            textSize = 14f
        }
        root.addView(noteEdit)

        // ★★★★ 第 57 期修：**这两个 Spinner 原来建出来了却没加进对话框** ——
        //     `spinner(...)` 的返回值只是赋给了局部变量，少了两句 `root.addView(...)`。
        //     表现就是：界面上只剩「用哪个账号」「用哪组语料」两行灰字，下面一片空白，
        //     用户根本选不了账号、也选不了语料库。
        //     而下面 `.setPositiveButton` 里**又真的在读** `accountSpinner.selectedItemPosition`
        //     ⇒ 一直在拿一个从未显示过的控件的默认值（第 0 项 = 「所有账号轮流」）。
        //     ★ 这种错**不报编译错**（变量被读了，编译器不会说「没用」），
        //       只有真机点开对话框才看得见。
        root.addView(labelView(R.string.interact_task_account_label))
        val accountSpinner = spinner(accountChoices())
        root.addView(accountSpinner)

        root.addView(labelView(R.string.interact_task_group_label))
        val groupSpinner = spinner(groupChoices())
        root.addView(groupSpinner)

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.interact_add_task))
            .setView(root)
            // ★ 第 57 期：这里原来借通用的 `dialog_ok`（「知道了」）——
            //   可它点下去是**建一个任务**，不是「我读完了」。换个名副其实的按钮名。
            .setPositiveButton(getString(R.string.interact_task_add_ok)) { _, _ ->
                val task = InteractTask(
                    action = selectedAction,
                    target = targetEdit.text.toString().trim(),
                    note = noteEdit.text.toString().trim(),
                    accountLabel = if (accountSpinner.selectedItemPosition <= 0) ""
                    else usableAccounts().getOrNull(accountSpinner.selectedItemPosition - 1)?.label.orEmpty(),
                    groupId = if (groupSpinner.selectedItemPosition <= 0) ""
                    else CommentLib.groups().getOrNull(groupSpinner.selectedItemPosition - 1)?.id.orEmpty()
                )
                InteractTaskStore.add(task)
                refreshTasks()
                toast(getString(R.string.interact_task_added))
            }
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .show()
    }

    private fun labelView(textRes: Int): TextView = TextView(this).apply {
        text = getString(textRes)
        textSize = 12f
        setTextColor(ContextCompat.getColor(this@InteractActivity, R.color.text_secondary))
        setPadding(0, dp(12), 0, dp(2))
    }

    /**
     * 下拉框。
     *
     * ★ 用项目自己的 item_spinner 布局，不用系统框架自带的那个 spinner 条目布局：
     *   框架那套的文字颜色跟着系统主题走，深色模式下可能变成「深底深字」。
     *   ★ 另一个附带原因：`_p2_ui_verify.py` 的布局引用校验**不区分系统资源前缀**
     *     （它就是直接正则扫布局引用的字面写法），用框架布局会被误报成「布局不存在」。
     *     这是那个工具的已知盲区 —— 这里连全名都不写，就是为了不给它制造误报。
     */
    private fun spinner(items: List<String>): Spinner = Spinner(this).apply {
        fillSpinner(this, items)
        // ★ 第 57 期：撑满一行。原来没设 layoutParams，`addView` 会退到
        //   WRAP_CONTENT —— 控件是出现了，但只有「所有账号轮流」那几个字那么宽，
        //   在一堆满宽输入框中间很不起眼，看起来就像「这里什么都没有」。
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    /**
     * 把条目填进一个**已经存在**的下拉框。
     *
     * ★ 抽出来是因为第 84 期的超Like 卡里那个账号下拉是**写在布局里**的
     *   （它需要有个稳定的 id，好在 `onCreate` 里直接 `findViewById`），
     *   走不了 [spinner] 那条「新建一个再 addView」的路。
     * ★ 两处必须用**同一套**条目布局（[R.layout.item_spinner]）——
     *   各写一份迟早会不一致，而这里的不一致在深色模式下就是「一个能看、一个看不见」。
     */
    private fun fillSpinner(view: Spinner, items: List<String>) {
        view.adapter = ArrayAdapter(this, R.layout.item_spinner, items)
            .apply { setDropDownViewResource(R.layout.item_spinner) }
    }

    /**
     * 下拉框里显示的账号名。
     *
     * ★★★★ 第 58 期修：原来显示 [WeiboAccount.label]，而 label 是**内部序号**
     *   （`syncOrderLabels` 统一写成「账号 N」）—— 所以用户看到的是「账号 1 / 账号 2」，
     *   根本认不出哪个是哪个。现在显示 [WeiboAccount.displayName]（有昵称就显示昵称），
     *   与账号页那一行 `accountName` 用的是**同一个字段**，两处终于一致。
     *
     * ★★ 但**只改显示，不改存进去的值**：下面 `.setPositiveButton` 里存的仍是
     *   `usableAccounts()[…].label`。因为任务的 `accountLabel` 是靠
     *   `firstOrNull { it.label == resolveAccount(task) }` 匹配回账号的
     *   （见 [resolveAccount]，排查工具那几处都是这么比的），
     *   存昵称会让匹配失败、静默退化成「第一个账号」—— 那是**行为变化**，不许。
     *   ⇒ 显示昵称、存序号，两边各司其职。
     */
    private fun accountChoices(): List<String> {
        val list = mutableListOf(getString(R.string.interact_task_account_auto))
        list.addAll(usableAccounts().map { it.displayName })
        return list
    }

    private fun groupChoices(): List<String> {
        val list = mutableListOf(getString(R.string.interact_task_group_auto))
        list.addAll(CommentLib.groups().map { it.name })
        return list
    }

    // ---------------------------------------------------------------- 频率 / 日志
    // ★★★ 第 101 期：`runRehearse()` / `doRehearse()` 已随「试跑一次」按钮一并删除
    //   （它们只服务那颗按钮；留着就是 private 未使用函数 —— 真编会多出一条警告）。
    //   ★ `InteractRunner.rehearse()` 的只读能力**原样保留**，以后要恢复只需把按钮加回来。

    /** 任务在一行里怎么念 —— 任务行和「发送」选择框共用同一句话。 */
    private fun taskRowText(task: InteractTask): String = getString(
        R.string.interact_task_row,
        getString(task.action.labelRes),
        task.target.ifBlank { "—" }
    )

    /** 任务指定了账号就用它，否则取第一个可用账号。★ 只给下面那几颗**排查工具**用。 */
    private fun resolveAccount(task: InteractTask): String {
        if (task.accountLabel.isNotBlank()) return task.accountLabel
        return usableAccounts().firstOrNull()?.label.orEmpty()
    }

    /**
     * ★★★★ 第 67 期：这个任务要发给**哪些账号**。
     *
     * - 任务明确选了账号（`accountLabel` 非空）⇒ **只发它**；
     * - 任务选的是「所有账号轮流」（`accountLabel` 为空）⇒ **全部可用账号，逐个执行**。
     *
     * ★ 为什么会有这个函数：在此之前，真发与试跑都是
     *   `usableAccounts().firstOrNull { it.label == resolveAccount(task) } ?: usableAccounts().firstOrNull()`，
     *   而 `accountLabel` 为空时 [resolveAccount] 只返回**第一个**账号 ——
     *   于是下拉里写着「所有账号轮流」，实际只发第一个（名不副实）。
     *
     * ★ 顺带修掉一个隐患：原来那个 `?: usableAccounts().firstOrNull()` 兜底，
     *   会让「指定了一个**已被禁用**的账号」**静默换成第一个账号**（用错账号）。
     *   现在指定了却不可用 ⇒ 返回**空列表** ⇒ 调用方明确报错，绝不静默换人。
     *
     * ★ [resolveAccount] 保留给排查工具（探接口用一个账号就够，不需要轮流）。
     */
    private fun accountsFor(task: InteractTask): List<WeiboAccount> {
        val usable = usableAccounts()
        if (task.accountLabel.isBlank()) return usable
        return usable.filter { it.label == task.accountLabel }
    }

    /**
     * 接口自检（只读）。
     *
     * ★★ 为什么必须放**后台线程**：它要发网络请求（最长 15 秒 × 3 个接口）。
     *   在 UI 线程发就是 ANR，用户会以为 App 卡死了。
     * ★ 回到 UI 时判 `isFinishing`：用户很可能等不及就退出这一页了。
     * ★ 用**第一个任务的目标**去探，和「试跑」用同一套解析规则 ——
     *   两个按钮面对的是同一个对象，结果才对得上。
     */
    private fun runProbe() {
        val task = InteractTaskStore.all().firstOrNull()
        if (task == null) {
            toast(getString(R.string.interact_probe_need_task))
            return
        }
        val account = usableAccounts().firstOrNull { it.label == resolveAccount(task) }
            ?: usableAccounts().firstOrNull()

        toast(getString(R.string.interact_probe_running))
        Thread {
            val result = try {
                InteractProbe.run(this, account, task.target)
            } catch (error: Throwable) {
                error.message ?: error.javaClass.simpleName
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                refreshTrace()
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.interact_probe_title))
                    .setMessage(result)
                    .setPositiveButton(getString(R.string.dialog_ok), null)
                    .show()
            }
        }.start()
    }

    /**
     * ★ 第 46 期「阶段 0.5」：探路径与票据。
     *
     * ★★ 它是**全只读**的（只用 GET）⇒ 比上面那颗发送探测还安全，
     *   所以顺序上也排在它前面：先问清「哪个接口通、st 放哪儿」，
     *   再决定要不要花掉那一次 POST。
     *
     * ★ 依然必须放后台线程：一次要打 7 个 GET。
     */
    private fun runPathProbe() {
        val task = InteractTaskStore.all().firstOrNull()
        if (task == null) {
            toast(getString(R.string.interact_probe_need_task))
            return
        }
        val account = usableAccounts().firstOrNull { it.label == resolveAccount(task) }
            ?: usableAccounts().firstOrNull()

        toast(getString(R.string.interact_probe_running))
        Thread {
            val result = try {
                InteractProbe.probePaths(this, account, task.target)
            } catch (error: Throwable) {
                error.message ?: error.javaClass.simpleName
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                refreshTrace()
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.interact_probe_paths_title))
                    .setMessage(result)
                    .setPositiveButton(getString(R.string.dialog_ok), null)
                    .show()
            }
        }.start()
    }

    /**
     * ★ 第 46 期「阶段 0」：探发送接口。
     *
     * ★★ 它和上面那颗自检按钮**唯一的不同**：自检全程只读，这一颗会发**一个 POST**。
     *   所以设计上做了三重保险（都在 [InteractProbe.probeSend] 里）：
     *     ① POST 前先 GET 确认那条微博**不存在**；
     *     ② ★ 必须是**正面证据**（`errno=20101` 或明说「不存在」）才放行；
     *       拿到别的（含风控报错、解析不出来）一律**不放行**；
     *     ③ 只发一次，**绝不重试**。
     *
     * ★ 依然必须放后台线程：一次探测最长要跑 4 个网络请求。
     */
    private fun runSendProbe() {
        val task = InteractTaskStore.all().firstOrNull()
        if (task == null) {
            toast(getString(R.string.interact_probe_need_task))
            return
        }
        val account = usableAccounts().firstOrNull { it.label == resolveAccount(task) }
            ?: usableAccounts().firstOrNull()

        toast(getString(R.string.interact_probe_running))
        Thread {
            val result = try {
                InteractProbe.probeSend(this, account, task.target)
            } catch (error: Throwable) {
                error.message ?: error.javaClass.simpleName
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                refreshTrace()
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.interact_probe_send_title))
                    .setMessage(result)
                    .setPositiveButton(getString(R.string.dialog_ok), null)
                    .show()
            }
        }.start()
    }

    /**
     * ★★★★ 第 84 期：转发接口探测（**会发一次 POST，零风险**）。
     *
     * ★ 与 [runSendProbe] 同一形状：先确认那条微博**不存在**，再对它试转发一次。
     *   目标不存在 ⇒ 微博那边没有帖子可以转发 ⇒ 不可能产生任何内容。
     * ★ 依然必须放后台线程：一次探测最长要跑 4 个网络请求。
     */
    private fun runRepostProbe() {
        val task = InteractTaskStore.all().firstOrNull()
        if (task == null) {
            toast(getString(R.string.interact_probe_need_task))
            return
        }
        val account = usableAccounts().firstOrNull { it.label == resolveAccount(task) }
            ?: usableAccounts().firstOrNull()

        toast(getString(R.string.interact_probe_running))
        Thread {
            val result = try {
                InteractProbe.probeRepost(this, account, task.target)
            } catch (error: Throwable) {
                error.message ?: error.javaClass.simpleName
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                refreshTrace()
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.interact_probe_repost_title))
                    .setMessage(result)
                    .setPositiveButton(getString(R.string.dialog_ok), null)
                    .show()
            }
        }.start()
    }

    /**
     * ★ 第 64 期：回复 / 点赞 接口侦察（**全只读**）。
     *
     * ★ 为什么单开一颗：第 55 期给「互评 / 楼赞」加了闸（当时只能真发顶层评论），
     *   但要做真还缺两样 —— **父评论 id** 与回复/点赞两个接口的路径参数。
     *   这一颗只用 GET：先拿真实评论列表定死父评论 id，再看候选路径哪个真的存在。
     *
     * ★ 依然必须放后台线程：一次要打 1 个目标解析 + 1 个评论列表 + 4 个候选路径。
     */
    private fun runReplyScout() {
        val task = InteractTaskStore.all().firstOrNull()
        if (task == null) {
            toast(getString(R.string.interact_probe_need_task))
            return
        }
        val account = usableAccounts().firstOrNull { it.label == resolveAccount(task) }
            ?: usableAccounts().firstOrNull()

        toast(getString(R.string.interact_probe_running))
        Thread {
            val result = try {
                InteractProbe.scoutReplyLike(this, account, task.target)
            } catch (error: Throwable) {
                error.message ?: error.javaClass.simpleName
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                refreshTrace()
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.interact_probe_reply_title))
                    .setMessage(result)
                    .setPositiveButton(getString(R.string.dialog_ok), null)
                    .show()
            }
        }.start()
    }

    /**
     * ★ 第 64 期：试发一条测试回复 + 一个赞（**会发 POST**）。
     *
     * ★★ 与上面那颗**唯一的不同**：这一颗真的会发出去。所以闸都在
     *   [InteractProbe.probeReplyLike] 里，四道缺一不可：
     *     ① 目标必须解析成一条**存在**的微博；
     *     ② 评论列表里必须有**本账号自己**的评论 ⇒ 只回自己的楼，绝不碰陌生人；
     *     ③ 候选路径命中即停（第一个 `ok:1` 就收手，绝不连发）；
     *     ④ 绝不重试。
     */
    private fun runReplyProbe() {
        val task = InteractTaskStore.all().firstOrNull()
        if (task == null) {
            toast(getString(R.string.interact_probe_need_task))
            return
        }
        val account = usableAccounts().firstOrNull { it.label == resolveAccount(task) }
            ?: usableAccounts().firstOrNull()

        toast(getString(R.string.interact_probe_running))
        Thread {
            val result = try {
                InteractProbe.probeReplyLike(this, account, task.target)
            } catch (error: Throwable) {
                error.message ?: error.javaClass.simpleName
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                refreshTrace()
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.interact_probe_reply_title))
                    .setMessage(result)
                    .setPositiveButton(getString(R.string.dialog_ok), null)
                    .show()
            }
        }.start()
    }

    // ★★ 第 100 期：`saveRate()` 已删 —— 「账号保护」整块（含「频率设置」）移除。
    //   后台的每小时兜底仍在 `RateGuard` 里，默认值已提到 30 条/小时。

    private fun copyTrace() {
        val dump = InteractTrace.dump()
        if (dump.isBlank()) {
            toast(getString(R.string.interact_trace_empty))
            return
        }
        val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        manager.setPrimaryClip(ClipData.newPlainText("interact-trace", dump))
        toast(getString(R.string.interact_trace_copied))
    }

    private fun clearTrace() {
        InteractTrace.clear()
        refreshTrace()
        toast(getString(R.string.interact_trace_cleared))
    }

    // ---------------------------------------------------------------- 小工具

    /**
     * 可以拿去互动的账号。
     *
     * ★ **只读**：取 [AccountStore] 里已启用的账号标签。
     *   刻意不看 `needsVerify` / `restUntil` —— 那是签到链路的状态，
     *   互动功能不该替签到判断「这个账号今天能不能用」，也不该因为自己
     *   把账号标脏而让签到跳过它。
     */
    private fun usableAccounts(): List<WeiboAccount> = AccountStore.all().filter { it.enabled }

    /**
     * 一个「输入一行字」的对话框。
     *
     * ★ 第 56 期新增 `qualityCheck`（默认关，老调用点一个字都不用改）：
     *   给「加一条评语 / 批量导入」用 —— 打开后会在输入框下面**实时**显示
     *   这条评语的「低质风险」。
     *
     *   为什么放在**填语料的这一刻**：微博会把「话题标签 + 大量表情 + @某人」
     *   这种成套模板判成「疑似低质或无意义」并**折叠**（第 46 期阶段 3 真机实测，
     *   评论真的发出去了、也真的被折叠了）。发送链路没有任何问题，
     *   能拦住这件事的只有**内容本身** —— 而内容是在这里填进去的。
     *
     *   ★★ 它**只提示，不拦**：不阻止保存、不改写用户写的字。
     *      用户的语料是他的，我们只给意见（与 [CommentQuality] 同一条纪律）。
     */
    private fun inputDialog(
        titleRes: Int,
        hintRes: Int,
        initial: String,
        qualityCheck: Boolean = false,
        /**
         * ★ 第 58 期：要写进哪个分组 —— 非空时标题写成「加评语 · 分组名」。
         *   默认空串 ⇒ 老调用点（新建分组 / 重命名 / 加后缀）一个字都不用改。
         */
        titleGroup: String = "",
        onOk: (String) -> Unit
    ) {
        val edit = EditText(this).apply {
            hint = getString(hintRes)
            setText(initial)
            inputType = InputType.TYPE_CLASS_TEXT
            textSize = 14f
        }
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
            addView(edit)
        }

        if (qualityCheck) {
            val qualityView = TextView(this).apply {
                textSize = 12f
                setPadding(0, dp(6), 0, 0)
            }
            holder.addView(qualityView)
            val refreshQuality = {
                // ★ 第 57 期：改用 liveHint —— 它自己分辨「一条」和「一批」。
                //   用户一次粘 20 条时，按行分别判，不会把 20 个话题标签堆成一次误报。
                val hint = CommentQuality.liveHint(this, edit.text.toString())
                qualityView.text = hint.text
                qualityView.setTextColor(
                    ContextCompat.getColor(
                        this,
                        if (hint.ok) R.color.text_secondary else R.color.warning_text
                    )
                )
            }
            // ★ 手写 TextWatcher 而不是 ktx 的 doAfterTextChanged：
            //   本工程没有引 core-ktx 的文本扩展，为一个提示去加依赖不值得。
            edit.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) = refreshQuality()
            })
            // 初值也刷一遍：对话框刚弹出时（尤其是「改一条已有评语」）就该看到结论
            refreshQuality()
        }

        AlertDialog.Builder(this)
            .setTitle(
                if (titleGroup.isBlank()) {
                    getString(titleRes)
                } else {
                    getString(R.string.interact_lib_title_with_group, getString(titleRes), titleGroup)
                }
            )
            .setView(holder)
            .setPositiveButton(getString(R.string.dialog_ok)) { _, _ ->
                onOk(edit.text.toString())
            }
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .show()
    }

    /**
     * ★ 第 56 期：整组「低质风险自检」。
     *
     * 逐条走 [CommentQuality.check]，把**像模板的条数**和**前几条原文**摆出来。
     * ★ 只给结论与原文，**不替用户改**、也**不自动删** —— 删哪条是用户的决定。
     */
    private fun showQualityReport(groupId: String) {
        val report = CommentQuality.checkGroup(this, groupId)
        val body = when {
            report.total == 0 -> getString(R.string.interact_quality_group_empty)
            report.ok -> getString(R.string.interact_quality_group_ok, report.total)
            else -> buildString {
                append(getString(R.string.interact_quality_group_risk, report.total, report.risky))
                append("\n")
                for (sample in report.samples) {
                    append("\n")
                    append(getString(R.string.interact_quality_group_sample, sample.take(QUALITY_SAMPLE_MAX)))
                }
                append("\n\n")
                append(getString(R.string.interact_quality_why))
            }
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.interact_quality_title))
            .setMessage(body)
            .setPositiveButton(getString(R.string.dialog_ok), null)
            .show()
    }

    // ------------------------------------------------- 第 46 期阶段 1：抓真实请求

    /**
     * ★★★ 第 46 期阶段 1：**只读**的网络钩子。
     *
     * ## 为什么需要它
     * 第 46 期卡在一个问题上：**「带登录态调 `/api/comments/create` 就被 100006 拦」**。
     * 已经排除的：`mid` 真假（真 mid 也 403）、`st` 放 query 还是 body、路径对不对
     * （PC 匿名打同一路径回「请先登录」，说明路径是对的）。
     * ⇒ 剩下的可能性只在「**请求到底长什么样**」上：请求头 / 请求体 / 是不是缺某个头。
     * 靠猜没用，只能**看一条页面自己发出的真请求**。
     *
     * ## 与 `OverlayVerifyHost.NET_HOOK_JS` 的关系
     * 那份是为滑块写的：**只记 URL / 状态 / 回包**，且只认
     * `checkin|verify|captcha|yidun|…` 这几个关键词。
     * 这里要的是**方法 + 请求头 + 请求体**（答案就在请求头里），而且要覆盖
     * `m.weibo.cn` 的全部 XHR（不限关键词）。
     * ★ 没有去改 `OverlayVerifyHost`（它在链路执行器清单里，隔离闸门锁着），
     *   而是在互动功能自己的范围内**另写一份** —— 与第 19 期「不去改核心文件、
     *   独立复制一份编排逻辑」是同一个规矩。
     *
     * ## 安全性（三条都是硬要求）
     *   1. **只记不改**：`open/send/setRequestHeader/fetch` 全部**透传**
     *      （`apply` 返回原返回值）；`fetch` 用 `r.clone().text()` 读**副本**，
     *      不消费原响应。不 preventDefault、不改 header、不改 URL、不改返回值。
     *      整段删掉不影响任何功能，也不参与任何判定。
     *   2. **脱敏**：Cookie / st / token / xsrf 这些**只留字段名、不留值** ——
     *      这份日志用户会复制出去贴给别人看（见 [copyTrace]）。
     *   3. **不写任何东西**：不发评论、不 POST、不碰账号与 Prefs。
     */
    /**
     * JS 侧缓冲在 `sessionStorage` 里的键名。写一处，钩子与清空脚本共用。
     *
     * ★ 为什么是 `val` 而不是 `const val`：`const` 只允许在顶层 / object / companion 里，
     *   而这里是普通类的成员。**必须声明在两个 JS 常量之前** —— 它们用 `$NET_KEY`
     *   插值，而类属性的初始化顺序就是声明顺序。
     */
    private val NET_KEY = "__tjhNet_v1"

    /**
     * ★★★ 111：这个名字**绝不从账号 Cookie 里灌进 WebView**（原因见 [openWeb] 里的长注释）。
     *
     * 一句话：账号里存的那份属于**上一次登录**，而服务器会在页面加载时下发当前会话的新值；
     * 按 RFC 6265，同名同 path 的 Cookie「创建更早的排前面」，浏览器取第一个 ⇒
     * 我们灌的旧值会把新值**遮住** ⇒ 写操作（发评论）必然 403 / errno 100006 请求非法。
     * 读操作不做这个校验，所以一直是好的 —— 这就是为什么「能看不能发」。
     */
    private val WEB_XSRF_COOKIE = "XSRF-TOKEN"

    /**
     * 每次「打开 m.weibo.cn」时**先清一次** JS 侧缓冲。
     *
     * ★ 为什么必须清：缓冲现在落在 `sessionStorage`（为了跨页面存活），
     *   不清的话上一轮抓到的请求会混进这一轮的报告里，用户会拿旧数据当新证据 ——
     *   这正是「覆盖安装不清空黑匣子」那个坑的翻版（第 37/38 期栽过两次）。
     * ★ 只在**本次打开的第一页**清一次，之后的导航绝不能清（见 [openWeb]）。
     */
    private val WEB_RESET_JS = """
        (function(){ try { sessionStorage.removeItem('$NET_KEY'); } catch(e){} return 'cleared'; })()
    """

    private val WEB_HOOK_JS = """
        (function(){
          if (window.__tjhNet) return 'exists';
          // ★ 缓冲跨页面存活：微博网页「发完评论」很可能刷新或跳转，
          //   而 window 会被整个换掉 ⇒ 只放内存里会把刚抓到的那一条丢掉，
          //   而丢掉的那一条恰好就是我们唯一要的那条。
          //   sessionStorage 在同一标签页内跨导航保留（domStorageEnabled 已开）。
          window.__tjhNet = [];
          var KEY = '$NET_KEY';
          try {
            var saved = sessionStorage.getItem(KEY);
            if (saved) { var arr = JSON.parse(saved); if (arr && arr.length) window.__tjhNet = arr; }
          } catch(e){}
          function save(){
            try { sessionStorage.setItem(KEY, JSON.stringify(window.__tjhNet)); } catch(e){}
          }
          function push(o){
            try {
              // ★ 每条都带上「当时的页面地址」与来路：浏览器自动加的 Referer / Origin
              //   在请求头里根本看不见，而它们很可能正是 100006 的成因。
              o.p = shortUrl(location.href);
              o.rf = shortUrl(document.referrer);
              if (window.__tjhNet.length > 40) window.__tjhNet.shift();
              window.__tjhNet.push(o);
              save();
            } catch(e){}
          }
          function hide(s){
            s = String(s == null ? '' : s);
            s = s.replace(/(cookie|set-cookie|x-xsrf-token|authorization|passport|token|sig)\s*[:=]\s*[^|&,\s}]+/gi,
              function(m){ var i = m.indexOf(':'); if (i < 0) i = m.indexOf('='); return m.slice(0, i + 1) + '<已隐藏>'; });
            s = s.replace(/([?&](st|access_token|token|sig|gsid)=)[^&\s]+/gi, '$1<已隐藏>');
            return s;
          }
          function shortUrl(u){
            var s = String(u == null ? '' : u);
            var q = s.indexOf('?');
            var p = q >= 0 ? s.slice(0, q) : s;
            p = p.replace(/^https?:\/\//, '');
            return p.length > 56 ? p.slice(-56) : p;
          }
          function hdrText(h){
            if (!h) return '';
            try {
              if (typeof h === 'string') return h;
              if (typeof Headers !== 'undefined' && h instanceof Headers) {
                var out = []; h.forEach(function(v, k){ out.push(k + ': ' + v); }); return out.join(' | ');
              }
              var arr = [];
              for (var k in h) { if (Object.prototype.hasOwnProperty.call(h, k)) arr.push(k + ': ' + String(h[k])); }
              return arr.join(' | ');
            } catch(e) { return String(h); }
          }
          try {
            var oOpen = XMLHttpRequest.prototype.open;
            var oSend = XMLHttpRequest.prototype.send;
            var oSet  = XMLHttpRequest.prototype.setRequestHeader;
            XMLHttpRequest.prototype.open = function(m, u){
              try { this.__m = m; this.__u = u; this.__h = []; } catch(e){}
              return oOpen.apply(this, arguments);
            };
            XMLHttpRequest.prototype.setRequestHeader = function(k, v){
              try { (this.__h || (this.__h = [])).push(k + ': ' + v); } catch(e){}
              return oSet.apply(this, arguments);
            };
            XMLHttpRequest.prototype.send = function(b){
              var self = this;
              try {
                self.addEventListener('load', function(){
                  var rb = ''; try { rb = self.responseText || ''; } catch(e){}
                  push({ m: String(self.__m || 'GET'), u: shortUrl(self.__u),
                         h: hide((self.__h || []).join(' | ')), b: hide(String(b || '')).slice(0, 300),
                         w: (self.withCredentials === true),
                         s: self.status, r: String(rb).replace(/\s+/g, ' ').slice(0, 200) });
                });
              } catch(e){}
              return oSend.apply(this, arguments);
            };
          } catch(e){}
          try {
            var oFetch = window.fetch;
            if (oFetch) {
              window.fetch = function(){
                var u = arguments[0];
                try { u = (typeof u === 'string') ? u : (u && u.url); } catch(e){}
                var init = arguments[1] || {};
                var p = oFetch.apply(this, arguments);
                try {
                  p.then(function(r){
                    try {
                      r.clone().text().then(function(t){
                        push({ m: String(init.method || 'GET'), u: shortUrl(u),
                               h: hide(hdrText(init.headers)), b: hide(String(init.body || '')).slice(0, 300),
                               w: String(init.credentials || ''),
                               s: r.status, r: String(t).replace(/\s+/g, ' ').slice(0, 200) });
                      });
                    } catch(e){}
                  });
                } catch(e){}
                return p;
              };
            }
          } catch(e){}
          return 'installed';
        })()
    """

    /** 把 JS 侧攒下的 `window.__tjhNet` 摊成纯文本（每条 5 行：请求 / 页面 / 头 / 体 / 回）。 */
    private val WEB_DUMP_JS = """
        (function(){
          try {
            var a = window.__tjhNet || [];
            if (!a.length) return 'EMPTY';
            var out = [];
            for (var i = 0; i < a.length; i++) {
              var x = a[i];
              out.push(x.m + ' ' + x.u + ' -> ' + x.s
                + (x.w === true ? '（带 Cookie）' : (x.w ? '（credentials=' + x.w + '）' : '（不带 Cookie）'))
                + '\n  页: ' + (x.p || '(未知)') + (x.rf ? '   来路: ' + x.rf : '')
                + '\n  头: ' + (x.h || '(无)')
                + '\n  体: ' + (x.b || '(空)')
                + '\n  回: ' + (x.r || '(空)'));
            }
            return out.join('\n');
          } catch(e) { return 'ERR ' + e; }
        })()
    """

    /** 打开 `m.weibo.cn`（带账号自己的 Cookie），并装上 [WEB_HOOK_JS]。 */
    private fun openWeb() {
        val account = usableAccounts().firstOrNull()
        if (account == null || account.cookie.isBlank()) {
            toast(getString(R.string.interact_web_no_account))
            return
        }
        val wrap = webWrap ?: return
        // ★ 只记 Cookie 的**字段名个数**，绝不记值 —— 与 InteractProbe 的约定一致
        InteractTrace.log(
            "[抓包] 打开 m.weibo.cn（账号=" + account.label +
                "，Cookie 字段数=" + account.cookie.split(";").size + "）"
        )
        wrap.visibility = View.VISIBLE
        wrap.removeAllViews()
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                /**
                 * ★ 只在**本次打开的第一页**清一次缓冲，之后的导航绝不能清 ——
                 *   清了就等于把用户刚发出去那条评论的请求扔掉，而那正是我们要的。
                 */
                private var firstPage = true

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (firstPage) {
                        firstPage = false
                        view?.evaluateJavascript(WEB_RESET_JS, null)
                    }
                    // 每加载完一页就补一次（页面跳转后 window 会被换掉）
                    view?.evaluateJavascript(WEB_HOOK_JS, null)
                }
            }
        }
        wrap.addView(
            web,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(380))
        )
        webView = web
        // 把账号自己的 Cookie 灌进 WebView 的 cookie jar。
        // ★ 一条一条灌：setCookie 只接受 "name=value" 单条，整串塞进去只认第一个。
        //
        // ★★★ 111 修的 bug：为什么「能看不能发评论」
        //   账号里存的那份 Cookie 是**导入那一刻**的会话快照，里面的 XSRF-TOKEN
        //   属于**上一次登录**（真机实测：我们灌进去的那个对应 09-30 的登录，
        //   而服务器在页面加载时下发的才是当前会话的）。
        //   按 RFC 6265，同名同 path 的 Cookie 按「创建更早的排前面」，浏览器取第一个
        //   ⇒ 我们灌的旧值把服务器刚下发的新值**遮住**了。
        //   读操作不做 CSRF 校验 ⇒ 一直是好的；写操作（发评论）必然
        //   HTTP 403 / errno 100006 请求非法 —— 而且**网页自己的 JS 也发不出去**，
        //   因为它继承的是同一个被污染的 cookie jar。
        //   所以：① 先把 jar 里可能残留的旧值删掉（它是会话 Cookie，会一直留着，
        //          光「不灌」不够）；② 灌的时候跳过这个名字，让服务器自己下发。
        //   ★ 只动这一个名字 —— 库里其余字段要么服务器不另发，要么创建时间比我们早
        //     （按排序规则本来就用服务器那份），所以单变量改这一处即可。
        try {
            val cm = CookieManager.getInstance()
            cm.setAcceptCookie(true)
            cm.setCookie(
                "https://m.weibo.cn",
                WEB_XSRF_COOKIE + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/"
            )
            // ★ 灌失败以前是**静默**的（setCookie 的返回值被直接丢掉）。
            //   改成**灌完回读一次 jar**，把字段名记下来 —— 比返回值更直接：
            //   能一眼看清「到底进去了哪些名字」，也顺便证明 XSRF-TOKEN 确实没被灌。
            //   ★ 只记**字段名**，绝不记值（沿用本文件既有的脱敏约定）。
            val pairs = account.cookie.split(";")
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .filterNot { it.substringBefore("=").trim().equals(WEB_XSRF_COOKIE, ignoreCase = true) }
            pairs.forEach { cm.setCookie("https://m.weibo.cn", it) }
            cm.flush()
            val jarNames = (cm.getCookie("https://m.weibo.cn") ?: "")
                .split(";")
                .map { it.substringBefore("=").trim() }
                .filter { it.isNotBlank() }
            InteractTrace.log(
                "[抓包] WebView Cookie 字段=" + jarNames.size + " 个（已跳过 " +
                    WEB_XSRF_COOKIE + "）：" + jarNames.joinToString("、")
            )
        } catch (_: Throwable) {
        }
        web.loadUrl("https://m.weibo.cn/")
        refreshTrace()
    }

    /** 把 JS 侧抓到的请求读回来，记进 [InteractTrace]。 */
    private fun captureWeb() {
        val web = webView
        if (web == null) {
            toast(getString(R.string.interact_web_not_open))
            return
        }
        web.evaluateJavascript(WEB_DUMP_JS) { raw ->
            val text = unquoteJs(raw)
            when {
                text.isBlank() || text == "EMPTY" ->
                    InteractTrace.log("[抓包] " + getString(R.string.interact_web_empty))
                text.startsWith("ERR") ->
                    InteractTrace.log("[抓包] 读取失败：" + text)
                else -> {
                    InteractTrace.log("[抓包] 抓到的请求：")
                    text.split("\n").forEach { line ->
                        if (line.isNotBlank()) InteractTrace.log("  " + line)
                    }
                }
            }
            refreshTrace()
        }
    }

    /** 收起并销毁网页。 */
    private fun closeWeb() {
        val wrap = webWrap ?: return
        try {
            webView?.stopLoading()
            webView?.destroy()
        } catch (_: Throwable) {
        }
        webView = null
        wrap.removeAllViews()
        wrap.visibility = View.GONE
    }

    /**
     * `evaluateJavascript` 回的是**带引号、带转义**的 JSON 字符串
     * （`"...a\nb..."`），这里还原成普通文本。用 `JSONTokener` 而不是手搓
     * `trim('"')` —— 后者处理不了 `\\n` 这类转义。
     */
    private fun unquoteJs(raw: String?): String {
        val s = (raw ?: "").trim()
        if (s.isBlank() || s == "null") return ""
        return try {
            val v = JSONTokener(s).nextValue()
            if (v is String) v else s
        } catch (_: Throwable) {
            s.trim('"')
        }
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

/**
 * ★ 第 56 期：整组自检里每条示例最多显示多少字。
 *
 * 示例只是为了「一眼认出是哪条」，不是给人读全文的；
 * 一条评语上百字会把对话框撑得没法看。
 */
private const val QUALITY_SAMPLE_MAX = 24
