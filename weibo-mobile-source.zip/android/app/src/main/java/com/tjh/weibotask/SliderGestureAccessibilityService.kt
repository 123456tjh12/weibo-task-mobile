package com.tjh.weibotask

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import kotlin.random.Random

/**
 * 无障碍服务：通过系统手势管线派发「真实触摸」。
 *
 * 与 JS 注入（isTrusted=false）不同，无障碍手势走系统输入管线，
 * 网页看到的是 isTrusted=true 的真实触摸，易盾无法从事件来源上区分。
 *
 * 需要在系统「设置 → 无障碍」里手动开启一次本服务。
 */
class SliderGestureAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: SliderGestureAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    }

    /**
     * 在屏幕指定位置真实点一下（用于点击签到按钮等需要 isTrusted=true 的场景）。
     */
    fun tap(screenX: Float, screenY: Float, onDone: (Boolean) -> Unit) {
        try {
            val path = Path()
            path.moveTo(screenX, screenY)
            val stroke = GestureDescription.StrokeDescription(path, 0, 80)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            // ★ 第 23 期取证：手势有没有被系统接受，是「点签到没反应」最关键的缺失信号。
            //   原来只写进 Dbg.log（默认关闭，交付机看不到），这里改落黑匣子。
            SliderTrace.log("[手势] 派发 tap（屏幕坐标 " + screenX + "," + screenY + "，时长 80ms）")
            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    SliderTrace.log("[手势] tap onCompleted（系统已把这次触摸投出去）")
                    onDone(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    SliderTrace.log("[手势] tap onCancelled（被系统取消，触摸没投出去）")
                    onDone(false)
                }
            }, null)
        } catch (e: Throwable) {
            SliderTrace.log("[手势] tap 抛异常：" + e.message)
            onDone(false)
        }
    }

    /**
     * 拉起验证页。无障碍服务由系统绑定，可以绕过后台启动 Activity 的限制，
     * 作为全屏通知之外更可靠的自动验证入口。
     */
    fun launchVerify(accountId: String) {
        try {
            Dbg.log("AutoVerify", "launchVerify 开始 accountId=" + accountId)
            val intent = Intent(this, WeiboLoginActivity::class.java)
                .putExtra(WeiboLoginActivity.EXTRA_VERIFY_MODE, true)
                .putExtra(WeiboLoginActivity.EXTRA_ACCOUNT_ID, accountId)
                // ★ 第 13 期：标注来源，好在验证页的轨迹里分清是哪条路把它拉起来的。
                .putExtra(WeiboLoginActivity.EXTRA_LAUNCH_SOURCE, "无障碍")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            Dbg.log("AutoVerify", "launchVerify startActivity 成功")
        } catch (e: Throwable) {
            Dbg.log("AutoVerify", "launchVerify 失败 " + e.message)
        }
    }

    override fun onInterrupt() {
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    /**
     * 派发一条人手式水平拖动轨迹。
     *
     * @param screenX    起点 x（屏幕坐标）
     * @param screenY    起点 y（屏幕坐标）
     * @param distance   水平拖动距离（物理像素）
     * @param durationMs 总时长
     */
    fun drag(
        screenX: Float,
        screenY: Float,
        distance: Float,
        durationMs: Int,
        onDone: (Boolean) -> Unit
    ) {
        val path = Path()
        path.moveTo(screenX, screenY)
        val steps = 28
        val rnd = Random(System.nanoTime())
        for (i in 1..steps) {
            val f = i.toFloat() / steps
            val ease = if (f < 0.5f) {
                4f * f * f * f
            } else {
                1f - (-2f * f + 2f).let { it * it * it } / 2f
            }
            val x = screenX + distance * ease + (rnd.nextFloat() * 1.4f - 0.7f)
            val y = screenY + (rnd.nextFloat() * 2.4f - 1.2f)
            path.lineTo(x, y)
        }
        // 终点精确落在目标位置
        path.lineTo(screenX + distance, screenY)

        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.toLong())
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onDone(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                onDone(false)
            }
        }, null)
    }
}
