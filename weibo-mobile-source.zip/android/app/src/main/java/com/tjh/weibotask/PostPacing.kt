package com.tjh.weibotask

import kotlin.random.Random

/**
 * 发帖节奏控制器 —— 把「固定间隔」换成「基础 ± 浮动」的随机间隔。
 *
 * ## 为什么要有这个文件（第 114 期）
 *
 * `AgentService` 里原有**五处**间隔，其中四处早已带 `Random.nextLong` 抖动
 * （账号间 `ACCOUNT_GAP_JITTER_MS`、批次间 `BATCH_GAP_JITTER_MS`、验证重试……），
 * **只有发帖间隔是死板的固定值**：
 *
 * ```kotlin
 * val gap = pauseLeft + Prefs.postIntervalMinutes * 60_000L   // ← 第 114 期前
 * ```
 *
 * 固定节奏是最容易被平台识别的行为特征（每隔整整 20 分钟准点一条）。
 * 本文件把那一处换成随机间隔。
 *
 * ## 设计取舍（按用户 2026-10-14 的决定）
 *
 * · 浮动范围 = **基础 ± 25%**，且**带下限保护**（不低于 [MIN_GAP_MS]）。
 * · 25% 是**内置常量**，不新增输入框 —— 用户依旧只调「发帖间隔（分钟）」这一个基础值。
 * · 严禁固定间隔：随机化是这个文件存在的全部理由。
 *
 * ## 硬规则符合性
 *
 * 本文件**不 import 任何 `android.` 类**（纯 Kotlin 标准库），
 * 与 `SliderMatch.kt`（第 71 期）同一套做法 ⇒ 它自己就是可独立核验的单元，
 * 闸门 8 逐文件 md5 即可确认它没被动过。
 *
 * @author 第 114 期
 */
object PostPacing {

    /**
     * 间隔硬下限：**5 分钟**。
     *
     * ★ 5 不是随手取的 —— 它就是 `Prefs.postIntervalMinutes` 的真实下界：
     *   `MainActivity.kt` 的 `savePostPacing()` 里写着
     *   `if (interval != null && interval >= 5) Prefs.postIntervalMinutes = interval.coerceIn(5, 240)`。
     *   用户能设的最小基础间隔就是 5 分钟；再把 25% 往下浮动（5 × 0.75 = 3.75 分钟）
     *   会被本常量托回 5 分钟 ⇒ 绝不会因为随机化而跌破安全底线。
     */
    const val MIN_GAP_MS: Long = 5 * 60_000L

    /**
     * 基础间隔的最小取值（分钟）。**必须与 `Prefs.postIntervalMinutes` 的下界一致**（见 [MIN_GAP_MS] 的说明）。
     *
     * ★ 这里刻意不写 1：用户根本调不到 1（真实下界是 5），
     *   写小了只会在「用户填了非法值」时给出一个比真实更宽的下探空间。
     */
    const val MIN_BASE_MINUTES: Int = 5

    /** 浮动比例：基础值的 **25%**。 */
    const val JITTER_RATIO: Double = 0.25

    /**
     * 算下一次发帖要等多久（毫秒）。
     *
     * 例：基础 20 分钟 ⇒ jitter = 5 分钟　⇒ 随机落在 **[15, 25]** 分钟。
     * 　　 基础 5 分钟　 ⇒ jitter = 1.25 分钟 ⇒ 理论 [3.75, 6.25]，
     * 　　 但 3.75 分钟那条会被 [MIN_GAP_MS] 托回 5 分钟 ⇒ 实际落在 **[5, 6.25]** 分钟。
     *
     * @param baseMinutes 用户设的「发帖间隔（分钟）」，来自 `Prefs.postIntervalMinutes`
     * @param random 随机源；**参数化是为了可测**（闸门 3 会用固定种子验证边界），
     *               生产环境走默认的 [Random.Default]
     * @return 随机后的间隔毫秒数，**保证 ≥ [MIN_GAP_MS]**
     */
    fun nextGapMs(baseMinutes: Int, random: Random = Random.Default): Long {
        // 基础值本身也要有下限：用户填 0 或负数时不能让间隔退化成 0（那等于不休息）
        val base = baseMinutes.coerceAtLeast(MIN_BASE_MINUTES) * 60_000L
        val jitter = (base * JITTER_RATIO).toLong()
        val low = base - jitter
        val high = base + jitter
        // high <= low 只可能在极端取整时发生；那种情况退回 base，别除零也别抛异常
        val picked = if (high <= low) base else low + random.nextLong(high - low + 1)
        return picked.coerceAtLeast(MIN_GAP_MS)
    }

    /**
     * 「可能的间隔范围」的人话描述，用于日志与界面提示。
     *
     * 例：基础 20 ⇒ "15~25 分钟"；基础 5 ⇒ "5~6 分钟"（下探被下限托住）。
     * **只用于展示，不参与任何判定** —— 判据一律走 [nextGapMs]。
     */
    fun describeRange(baseMinutes: Int): String {
        val base = baseMinutes.coerceAtLeast(MIN_BASE_MINUTES)
        val jitter = base * JITTER_RATIO
        val floorMinutes = (MIN_GAP_MS / 60000L).toInt()
        // 下探按分钟向上取整（展示宁可说大不说小），上探按分钟向下取整
        val lo = Math.ceil(base - jitter).toInt().coerceAtLeast(floorMinutes)
        val hi = Math.floor(base + jitter).toInt()
        return "${lo}~${hi} 分钟"
    }
}
