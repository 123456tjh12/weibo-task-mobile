package com.tjh.weibotask

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * 一个微博账号。
 *
 * ★ 为什么风控状态必须按账号存：
 *   微博的限流是**按账号**算的。A 号被限流不代表 B 号也被限流。
 *   如果几个号共用一份 riskScore / consecutiveFailures，
 *   一个号被风控就会把其它号的计数一起推高，导致全部签不上 ——
 *   这正是 v13「只签到一个」和 v16「签 5 个就停」那类 bug 的同一个根源：
 *   把本不该共享的状态共享了。
 */
class WeiboAccount {
    var id: String = ""
    var label: String = ""
    var cookie: String = ""
    var verified: Boolean = false
    var expiryAt: Long = 0L
    var lastCheckAt: Long = 0L
    var lastCheckMessage: String = ""
    var enabled: Boolean = true

    /** 该账号自己的风控分（0~100），不与其他账号共享 */
    var riskScore: Int = 0

    /** 该账号自己的连续失败计数 */
    var consecutiveFailures: Int = 0

    var lastRunAt: Long = 0L
    var lastRunStatus: String = ""
    var lastRunMessage: String = ""

    /** 是否处于「可以拿去签到」的状态 */
    val loggedIn: Boolean
        get() = verified && cookie.contains("SUB=")

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("label", label)
        .put("cookie", cookie)
        .put("verified", verified)
        .put("expiryAt", expiryAt)
        .put("lastCheckAt", lastCheckAt)
        .put("lastCheckMessage", lastCheckMessage)
        .put("enabled", enabled)
        .put("riskScore", riskScore)
        .put("consecutiveFailures", consecutiveFailures)
        .put("lastRunAt", lastRunAt)
        .put("lastRunStatus", lastRunStatus)
        .put("lastRunMessage", lastRunMessage)

    companion object {
        fun fromJson(source: JSONObject): WeiboAccount {
            val account = WeiboAccount()
            account.id = source.optString("id").ifBlank { UUID.randomUUID().toString() }
            account.label = source.optString("label")
            account.cookie = source.optString("cookie")
            account.verified = source.optBoolean("verified")
            account.expiryAt = source.optLong("expiryAt")
            account.lastCheckAt = source.optLong("lastCheckAt")
            account.lastCheckMessage = source.optString("lastCheckMessage")
            // 默认启用：老数据里没有这个字段时不能让账号变成「停用」而静默不签到
            account.enabled = source.optBoolean("enabled", true)
            account.riskScore = source.optInt("riskScore")
            account.consecutiveFailures = source.optInt("consecutiveFailures")
            account.lastRunAt = source.optLong("lastRunAt")
            account.lastRunStatus = source.optString("lastRunStatus")
            account.lastRunMessage = source.optString("lastRunMessage")
            return account
        }
    }
}

/**
 * 账号列表的唯一数据源。
 *
 * 存在 EncryptedSharedPreferences 里（整个 JSON 串一起加密），
 * 进程内用单例缓存，任何改动都要调 [save] 落盘。
 */
object AccountStore {
    private val accounts = mutableListOf<WeiboAccount>()
    private var loaded = false

    fun init(context: Context) {
        if (loaded) return
        Prefs.init(context)
        load()
        loaded = true
    }

    private fun load() {
        accounts.clear()

        val raw = Prefs.accountsJson
        if (raw.isNotBlank()) {
            try {
                val array = JSONArray(raw)
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    accounts.add(WeiboAccount.fromJson(item))
                }
            } catch (_: Exception) {
                // JSON 损坏时不能直接崩，退回下面的迁移/空列表逻辑
                accounts.clear()
            }
        }

        // ★ 从 v16 及以前升级上来时，老版本只有一份全局 Cookie。
        //   这里做一次性迁移 —— 用户不需要重新登录，超话列表也不会丢。
        if (accounts.isEmpty() && Prefs.cookieHeader.isNotBlank()) {
            val migrated = WeiboAccount()
            migrated.id = "account-1"
            migrated.label = "账号 1"
            migrated.cookie = Prefs.cookieHeader
            migrated.verified = Prefs.weiboVerified
            migrated.expiryAt = Prefs.cookieExpiryAt
            migrated.lastCheckAt = Prefs.lastLoginCheckAt
            migrated.lastCheckMessage = Prefs.lastLoginCheckMessage
            migrated.riskScore = Prefs.riskScore
            migrated.consecutiveFailures = Prefs.consecutiveFailures
            accounts.add(migrated)
            save()
        }
    }

    fun save() {
        val array = JSONArray()
        for (account in accounts) array.put(account.toJson())
        Prefs.accountsJson = array.toString()
    }

    fun all(): List<WeiboAccount> = accounts.toList()

    fun enabled(): List<WeiboAccount> = accounts.filter { it.enabled }

    /** 可以真正拿去签到的账号：已启用且登录态有效 */
    fun ready(): List<WeiboAccount> = accounts.filter { it.enabled && it.loggedIn }

    fun find(id: String): WeiboAccount? = accounts.firstOrNull { it.id == id }

    fun add(): WeiboAccount {
        val account = WeiboAccount()
        account.id = UUID.randomUUID().toString()
        account.label = nextLabel()
        accounts.add(account)
        save()
        return account
    }

    fun remove(id: String) {
        accounts.removeAll { it.id == id }
        save()
    }

    /** 界面要渲染列表时用：一个账号都没有就先建一个空的 */
    fun ensureAtLeastOne(): WeiboAccount {
        if (accounts.isEmpty()) return add()
        return accounts[0]
    }

    private fun nextLabel(): String {
        var index = accounts.size + 1
        while (accounts.any { it.label == "账号 " + index }) index++
        return "账号 " + index
    }
}
