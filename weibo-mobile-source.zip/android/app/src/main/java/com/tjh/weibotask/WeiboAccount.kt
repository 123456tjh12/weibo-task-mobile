package com.tjh.weibotask

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * 一个微博账号。
 *
 * ★ 为什么风控状态必须按账号存：
 *   微博的限流是**按账号**算的。A 号被限流不代表 B 号也被限流。
 *   如果几个号共用一份 riskScore / consecutiveFailures，
 *   一个号被风控就会把其它号的计数一起推高，导致全部签不上 ——
 *   这正是 v13「只签到一个」和 v16「签 5 个就停」那类 bug 的同一个根源：
 *   把本不该共享的状态共享了。
 */
class WeiboAccount {
    var id: String = ""
    var label: String = ""
    var cookie: String = ""
    var verified: Boolean = false
    var expiryAt: Long = 0L
    var lastCheckAt: Long = 0L
    var lastCheckMessage: String = ""
    var enabled: Boolean = true

    /** 该账号自己的风控分（0~100），不与其他账号共享 */
    var riskScore: Int = 0

    /** 该账号自己的连续失败计数 */
    var consecutiveFailures: Int = 0

    var lastRunAt: Long = 0L
    var lastRunStatus: String = ""
    var lastRunMessage: String = ""

    /**
     * 这个账号最近一次被「排进批次」的日期（yyyy-MM-dd）。
     *
     * ★ 账号多起来之后（10 个以上），同一时刻把所有账号都跑一遍，
     *   会在同一个 IP 上形成一次密集请求 —— 这是最容易触发风控的形态。
     *   所以改成**分批错峰**：每轮只跑一小批，跑过的账号记下日期，
     *   下一批 20 分钟后再来，几轮跑完。
     *   这个字段就是「今天轮到过它没有」的依据。
     */
    var lastRunDate: String = ""

    /**
     * 这个账号今天以「超话没签完」（PARTIAL）结束过几次，以及这个计数属于哪一天。
     *
     * ★ 为什么必须限次：
     *   分批之后，「今天还没轮到的账号」优先跑。如果一个账号**永远**签不完
     *   （某个超话链接失效、或微博那边就是不认），不设上限的话它会被
     *   每 20 分钟捞出来重跑一轮，一直到零点 —— 既签不上，又白白往微博送请求，
     *   而用户这次的诉求恰恰是「降低风险」。
     *   所以达到 [MAX_PARTIAL_RETRIES] 次之后当天不再碰它，等第二天。
     */
    var partialRetryDate: String = ""
    var partialRetryCount: Int = 0

    /** 是否处于「可以拿去签到」的状态 */
    val loggedIn: Boolean
        get() = verified && cookie.contains("SUB=")

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("label", label)
        .put("cookie", cookie)
        .put("verified", verified)
        .put("expiryAt", expiryAt)
        .put("lastCheckAt", lastCheckAt)
        .put("lastCheckMessage", lastCheckMessage)
        .put("enabled", enabled)
        .put("riskScore", riskScore)
        .put("consecutiveFailures", consecutiveFailures)
        .put("lastRunAt", lastRunAt)
        .put("lastRunStatus", lastRunStatus)
        .put("lastRunMessage", lastRunMessage)
        .put("lastRunDate", lastRunDate)
        .put("partialRetryDate", partialRetryDate)
        .put("partialRetryCount", partialRetryCount)

    companion object {
        /**
         * 一个账号一天最多可以「以没签完结束」几次。
         *
         * 计数在每次结束时 +1（含第一次正常执行），所以 3 次 = 正常跑 1 次 + 补跑 2 次。
         * 到 3 之后当天不再碰它 —— 再跑也是同样的结果，只是白送请求给微博风控。
         */
        const val MAX_PARTIAL_RETRIES = 3

        fun fromJson(source: JSONObject): WeiboAccount {
            val account = WeiboAccount()
            account.id = source.optString("id").ifBlank { UUID.randomUUID().toString() }
            account.label = source.optString("label")
            account.cookie = source.optString("cookie")
            account.verified = source.optBoolean("verified")
            account.expiryAt = source.optLong("expiryAt")
            account.lastCheckAt = source.optLong("lastCheckAt")
            account.lastCheckMessage = source.optString("lastCheckMessage")
            // 默认启用：老数据里没有这个字段时不能让账号变成「停用」而静默不签到
            account.enabled = source.optBoolean("enabled", true)
            account.riskScore = source.optInt("riskScore")
            account.consecutiveFailures = source.optInt("consecutiveFailures")
            account.lastRunAt = source.optLong("lastRunAt")
            account.lastRunStatus = source.optString("lastRunStatus")
            account.lastRunMessage = source.optString("lastRunMessage")
            // 老数据没有这个字段 → 空串，等于「今天还没轮到」，会被排进第一批
            account.lastRunDate = source.optString("lastRunDate")
            account.partialRetryDate = source.optString("partialRetryDate")
            account.partialRetryCount = source.optInt("partialRetryCount")
            return account
        }
    }
}

/**
 * 账号列表的唯一数据源。
 *
 * 存在 EncryptedSharedPreferences 里（整个 JSON 串一起加密），
 * 进程内用单例缓存，任何改动都要调 [save] 落盘。
 */
object AccountStore {
    private val accounts = mutableListOf<WeiboAccount>()
    private var loaded = false

    fun init(context: Context) {
        if (loaded) return
        Prefs.init(context)
        load()
        loaded = true
    }

    private fun load() {
        accounts.clear()

        val raw = Prefs.accountsJson
        if (raw.isNotBlank()) {
            try {
                val array = JSONArray(raw)
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    accounts.add(WeiboAccount.fromJson(item))
                }
            } catch (_: Exception) {
                // JSON 损坏时不能直接崩，退回下面的迁移/空列表逻辑
                accounts.clear()
            }
        }

        // ★ 从 v16 及以前升级上来时，老版本只有一份全局 Cookie。
        //   这里做一次性迁移 —— 用户不需要重新登录，超话列表也不会丢。
        if (accounts.isEmpty() && Prefs.cookieHeader.isNotBlank()) {
            val migrated = WeiboAccount()
            migrated.id = "account-1"
            migrated.label = "账号 1"
            migrated.cookie = Prefs.cookieHeader
            migrated.verified = Prefs.weiboVerified
            migrated.expiryAt = Prefs.cookieExpiryAt
            migrated.lastCheckAt = Prefs.lastLoginCheckAt
            migrated.lastCheckMessage = Prefs.lastLoginCheckMessage
            migrated.riskScore = Prefs.riskScore
            migrated.consecutiveFailures = Prefs.consecutiveFailures
            accounts.add(migrated)
            save()
        }
    }

    fun save() {
        val array = JSONArray()
        for (account in accounts) array.put(account.toJson())
        Prefs.accountsJson = array.toString()
    }

    fun all(): List<WeiboAccount> = accounts.toList()

    fun enabled(): List<WeiboAccount> = accounts.filter { it.enabled }

    /** 可以真正拿去签到的账号：已启用且登录态有效 */
    fun ready(): List<WeiboAccount> = accounts.filter { it.enabled && it.loggedIn }

    /**
     * 今天还没轮到过的可签到账号（分批错峰用）。
     *
     * 保持列表顺序，这样批次是稳定的：第 1 批永远是账号 1~3，
     * 用户能预期「先签哪几个」。
     */
    fun notRunToday(today: String): List<WeiboAccount> =
        accounts.filter { it.enabled && it.loggedIn && it.lastRunDate != today }

    /** 今天已经轮到过的可签到账号数（首页用来显示进度） */
    fun doneToday(today: String): Int =
        accounts.count { it.enabled && it.loggedIn && it.lastRunDate == today }

    /**
     * 今天还需要「补跑」的账号：上一轮结束时还有超话没签完（PARTIAL），且补跑次数没用完。
     *
     * ★ 为什么单独拎出来：
     *   分批之后，「今天还没轮到的账号」优先跑。如果某个账号上一轮没签完，
     *   它会被记进 `lastRunDate`，于是**永远排在后面**，当天再也不会被选中 ——
     *   界面上写着「会自动补签」，实际却没人管它。这个方法就是补上这一环。
     */
    fun partialPending(today: String): List<WeiboAccount> =
        accounts.filter {
            it.enabled && it.loggedIn &&
                it.lastRunStatus == "PARTIAL" &&
                it.partialRetryDate == today &&
                it.partialRetryCount < WeiboAccount.MAX_PARTIAL_RETRIES
        }

    fun find(id: String): WeiboAccount? = accounts.firstOrNull { it.id == id }

    fun add(): WeiboAccount {
        val account = WeiboAccount()
        account.id = UUID.randomUUID().toString()
        account.label = nextLabel()
        accounts.add(account)
        save()
        return account
    }

    fun remove(id: String) {
        accounts.removeAll { it.id == id }
        save()
    }

    /** 界面要渲染列表时用：一个账号都没有就先建一个空的 */
    fun ensureAtLeastOne(): WeiboAccount {
        if (accounts.isEmpty()) return add()
        return accounts[0]
    }

    private fun nextLabel(): String {
        var index = accounts.size + 1
        while (accounts.any { it.label == "账号 " + index }) index++
        return "账号 " + index
    }
}
