package com.tjh.weibotask

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import kotlinx.coroutines.runBlocking
import java.util.ArrayDeque

/**
 * ★★★ 第 19 期：把验证链路搬进悬浮窗（核心改动，已按用户批准）。
 *
 * ## 为什么要搬
 *
 * 自动过易盾滑块的前提是「有一个被系统判定为可见的 WebView」——因为 `jsDrag` 的分步
 * 拖动靠页面内 `setTimeout`，Chromium 对不可见页面会把定时器限流到 1 次/秒甚至挂起。
 *
 * 而 `WeiboLoginActivity`（验证模式）在安全锁屏下会被 ActivityTaskManager 挂
 * 「睡眠令牌」（`wm_pause_activity … sleep`，第 17 期根因），页面创建几毫秒就被暂停，
 * 焦点一次都拿不到 —— 四期（第 7/14/15/16）全死在这。
 *
 * 悬浮窗（WindowManager）**不参与** ActivityTaskManager 的睡眠判定。第 18 期实验已证：
 * 锁屏 + 熄屏下，悬浮窗里的 WebView 定时器 40/40 满速、`visibilityState=visible`、
 * `innerWidth=360` ⇒ 隐形方案可行。
 *
 * ## 它做了什么 / 没做什么
 *
 * - **只换容器**：把验证页 WebView 从 `WeiboLoginActivity` 换成
 *   `TYPE_APPLICATION_OVERLAY` 悬浮窗（窗口标志同第 18 期探针：
 *   `SHOW_WHEN_LOCKED|TURN_SCREEN_ON|KEEP_SCREEN_ON|NOT_FOCUSABLE`，
 *   `alpha=0.01f`——隐形但真实渲染）。
 *   ★ 第 21 期修正：挂载后**前 30 秒可触摸**（不再全程 `NOT_TOUCHABLE`）。
 *   根因：无障碍 `dispatchGesture()` 走系统输入管线，**只投给「可触摸」窗口**；
 *   原来全程 `NOT_TOUCHABLE` ⇒ 「点签到」的手势点在空气上 ⇒ 微博不弹验证码
 *   （真机报告：`bg=0 jigsaw=0 slider=0`，`已尝试 0/8 次`）。
 *   30 秒后自动收回 `NOT_TOUCHABLE`（签到约挂载后 2~3 秒即点完，
 *   之后的滑块拖动是 JS 注入、不需要触摸）。
 * - **判定逻辑逐字节不动**：滑块检测 / 拖动全部来自 `YidunAutoSlider`（本文件零改动，
 *   直接 `new` 出来复用）。本文件只复制了「承载 + Cookie 注入 / 采集 / 验证成功记账」
 *   这段编排逻辑（与 `WeiboLoginActivity` 验证模式逐行一致），因为核心文件一行都不许动，
 *   所以这里独立复制一份，而不是去改 `WeiboLoginActivity`。
 * - `WeiboLoginActivity` 保持原样，作为「用户清醒时手动点通知打开验证页」的兜底。
 *
 * ## 队列
 *
 * 一次可能多个账号待验证，悬浮窗一次只能挂一个 WebView，所以这里用一个队列顺序处理。
 */
object OverlayVerifyHost {

    /** 单个账号验证的安全超时：超过就收摊，避免隐形 WebView 卡死。 */
    private const val SAFETY_TIMEOUT_MS = 120_000L

    /**
     * ★★★ 第 39 期开关：「滑块这一轮失败后，重新挂一次再试」的最大轮数。
     *
     * - `0` ⇒ **完全不重挂**，行为与第 38 期逐字节相同（一键回退就是把它置 0）。
     * - `2`（本轮默认，用户 2026-10-01 选定）⇒ 一个账号最多 **3 个滑块会话**
     *   （首轮 + 2 次重挂）。
     *
     * ## 为什么只做「重新挂一次再试」，而不是改拖动算法
     *
     * 第 38 期真机结论：`jsDrag` 是唯一能驱动滑块的方式，单次拖动命中率大约 **1/3**，
     * 而一轮已经有 8 次机会（`YidunAutoSlider.maxAttempts`）。
     * 一轮 8 次全失败时，最省事、最不碰核心逻辑的办法就是**换一个全新的会话再来一轮** ——
     * 而不是去改识别/轨迹（那属于核心链路）。
     *
     * ## 风险与边界（必须知道）
     *
     * · 每多一轮 = 多一次「打开超话页 + 拉验证码」的请求 ⇒ 风控升级风险上升，
     *   所以**必须有上限**，且默认只给 2 轮。
     * · 重挂前先把 `captchaSeen` 复位 —— 否则重新打开 `weibo.com/p/...` 会被
     *   `onPageStarted` 的成功判定**立刻**当成「验证通过」（假成功）。
     * · 判定与拖动**一行未动**：这里只决定「要不要再来一轮」，不决定「这一轮算不算过」。
     */
    @Volatile
    var maxSliderRearms = 2

    /**
     * ★★★ 第 61 期（用户批准，属链路③「重挂」动作层）：重挂时是否**换一个超话**再试。
     *
     * - `true`（本轮默认）＝ 重挂前重新挑一个「今天还没签」的超话（**排除刚点不动的那个**），
     *   打开它再试一轮。
     * - `false` ＝ 逐字节恢复第 60 期行为（重挂复用 `currentCheckinUrl`，死磕同一个超话）。
     *
     * ## 为什么必须改
     *
     * 第 49 期把「优先挑今天还没签的超话」只加在**首轮**上；重挂复用的是同一个
     * `currentCheckinUrl` ⇒ 2 轮重挂全砸在同一个超话上。真机 10-04 实证：
     *
     * ```
     * 09:46:53  [手势] 按钮 … 文本=签到          ← 首轮：点了，签到请求发出去了，但没弹验证码
     * 09:47:22  [滑块] 30 秒内没等到验证码…
     * 09:47:39  [手势] 按钮 … 文本=已签到        ← 重挂 1：同一个超话，点不动
     * 09:48:27  [手势] 按钮 … 文本=已签到        ← 重挂 2：同一个超话，点不动
     * 09:49:12  [重挂] 已重挂 2/2 轮仍未过，停手，交给用户手动处理
     * ```
     *
     * 而 09:50:49 同一账号重新起一次会话、重开**同一个**超话，验证码就出来了、验证通过。
     * ⇒ 「三轮全废在同一个超话上」是这次账号卡死（今日进度 4/5）的关键一环。
     *
     * ## 一个字没动什么
     *
     * · 只决定**重挂时打开哪个地址**；重挂轮数上限、15 秒间隔、`captchaSeen` 复位、
     *   安全超时公式**全部未动**。
     * · 滑块的识别 / 缺口计算 / 拖动轨迹 / **成功判定**一律未动。
     * · 数据层未动：`excludeContainerId` 是 `WeiboClient.fetchFirstTopicContainerId` 的
     *   一个**默认参数**，没有任何东西写进 `WeiboAccount` / `Prefs`。
     * · 取不到新超话（网络异常 / 只关注了一个超话）⇒ 回退到 `currentCheckinUrl`，
     *   即第 60 期行为。
     *
     * ## 一键回滚
     *
     * 置 `false` ⇒ 逐字节回到第 60 期的重挂逻辑。
     */
    @Volatile
    var rearmSwitchTopic = true

    /**
     * ★ 第 39 期：一轮失败到重挂之间的等待。
     *
     * 让易盾侧那一次会话先凉下来，也避免连续请求显得像脚本。
     */
    private const val REARM_DELAY_MS = 15_000L

    /**
     * ★ 第 39 期：每一轮重挂给滑块留的时间预算。
     *
     * 第 38 期真机：一轮完整跑完（含 3 次拖动 + 收尾）约 14 秒；
     * 给 45 秒足够覆盖慢网与「8 次机会用满」的最坏情况。
     */
    private const val REARM_SESSION_BUDGET_MS = 45_000L

    /**
     * ★ 第 21 期：挂载后保持「可触摸」的时长。
     *
     * 无障碍「点签到」的手势走系统输入管线，只投给可触摸窗口；实测签到约在
     * 挂载后 2~3 秒被点击，给 30 秒足够覆盖慢网。之后收回 NOT_TOUCHABLE，
     * 用户就不会再被这个隐形窗口挡到（之后的滑块拖动是 JS 注入，不需要触摸）。
     */
    private const val TOUCH_WINDOW_MS = 30_000L

    /**
     * ★★ 第 37 期：悬浮窗是否还占用「系统触摸面」（默认 **false = 不占用**）。
     *
     * ## 为什么改
     *
     * 第 21~36 期这个悬浮窗挂载后**前 30 秒是「全屏 + 可触摸 + 可聚焦」**，
     * 而它 `alpha = 0.01f` **肉眼完全看不见** ⇒ 这 30 秒里**用户手指的触摸全部被它吃掉**，
     * 下面的页面（包括验证页）对用户来说「点了没反应」。
     * 第 36 期真机报告里用户的原话就是：**「手工验证的时候，手机触摸没有反应」**。
     *
     * ## 为什么现在可以不占用了
     *
     * 当初之所以要可触摸，是因为「点签到」走的是**无障碍 `dispatchGesture()`**——
     * 那条路经过系统输入分发，**只投给可触摸窗口**（第 21 期）。
     *
     * 第 36 期起「点签到」改成 `webView.dispatchTouchEvent()` 注入真实 `MotionEvent`，
     * 第 37 期起「拖滑块」也改走同一条路 ——
     * 两者都**直接在 View 上派发、完全不经过系统窗口分发** ⇒
     * 窗口可不可触摸对它们**没有任何影响**，于是没有理由再占着系统触摸面。
     *
     * ## 想恢复旧行为
     *
     * 置为 `true` 即逐字节回到第 36 期（挂载后前 30 秒可触摸 + 可聚焦，30 秒后收回）。
     * ★ 只有**无障碍 tap 兜底**那条路需要窗口可触摸 ——
     *   即 `YidunAutoSlider.useTrustedTouchForCheckin = false` 时才需要把这里也置 `true`。
     */
    @Volatile
    var keepWindowTouchable = false

    /**
     * ★★★ 第 38 期开关：「从验证页跳走」时，把**超话域**也算作「验证通过」。
     *
     * ## 问题
     *
     * `onPageStarted` 原来的成功判定只认
     * `https://weibo.com` / `https://m.weibo.cn` 两个前缀，
     * 而**实测验证页跳回的是 `https://huati.weibo.cn/super/browser/close`（超话域）**
     * ⇒ **永远匹配不上** ⇒ 从不打印 `[判定] 验证通过`
     * ⇒ `needsVerify` 不清、`restUntil`（静置期）不设
     * ⇒ **下个定时点又去签、又撞风控**。
     * ★ 这正是「风控变频繁」的真正原因 —— 不是账号有问题，是**我们没认出成功**。
     *
     * ## 为什么可以认为「跳走 = 通过」
     *
     * 1. 易盾失败时**不会自动关页**，它会把滑块留在原地让你重试
     *    （真机 22:00 那 4 次被拒，每次都是**换一张新图继续**，页面没走）。
     * 2. 落地的是**超话域**（就是我们出发的地方），不是错误页。
     * 3. 独立佐证：第 36 期 22:00 那次（`jsDrag`）落地后，
     *    账号当天**确实签上了**（`今日进度 1/1`，用户确认没有手动签）。
     *
     * ## 判定规则
     *
     * `captchaSeen == true`（真的进过验证页）**且**新地址命中 `.weibo.cn`
     * ⇒ 判为验证通过。`security.weibo.com` 本身不含 `.weibo.cn`，不会被误判。
     *
     * ★ 置 `false` 即回到第 37 期（只认 `weibo.com` / `m.weibo.cn`）。
     * ★ 只改「认不认这一条落地」；滑块识别 / 缺口计算 / 拖动轨迹 / 数据层一字未动。
     */
    @Volatile
    var useLandingAsSuccess = true

    // ★★ 第 22~23 期诊断探针（只读，不改任何判定；验证完可整段删除）。
    //   目的：判定「点签到没出验证码」到底卡在哪 ——
    //   ① 手势根本没落到页面上（全 0）；② 落到了但页面把 click 抑制了（touchstart>0 而 click=0）；
    //   ③ 页面收到了点击但没弹验证码（click>0）。
    //   顺带读：是否聚焦（focus）、可见性（vis）、缩放（dpr/clientW）、按钮文本与位置（btn）、
    //   按钮中心点下面到底是哪个元素（pt = elementFromPoint）、验证码 DOM。

    /**
     * 在页面里装「触摸/鼠标事件捕获」监听，**分开统计 7 种事件**。
     * ★ 第 23 期升级：只数 click 分不清「没送到」和「送到了但被 preventDefault 吃掉」，
     *   所以 touchstart / pointerdown / mousedown / click 各数各的。
     * 只累加计数，不 preventDefault、不 stopPropagation。
     */
    private val CLICK_LISTENER_JS = """
        (function(){
          if (window.__tjhProbe) return 'exists';
          // ★ 第 36 期：加 it / sy 两个累计量 —— 分别是 `e.isTrusted === true` 与合成事件的条数。
          window.__tjhProbe = { ev:{}, last:'', it:0, sy:0 };
          var types = ['touchstart','touchend','touchmove','pointerdown','pointerup','mousedown','mouseup','click'];
          for (var i=0;i<types.length;i++){
            (function(t){
              document.addEventListener(t, function(e){
                try {
                  window.__tjhProbe.ev[t] = (window.__tjhProbe.ev[t]||0)+1;
                  // ★★ 第 36 期：数「可信事件」——这是判断 `webView.dispatchTouchEvent()`
                  //   到底有没有产生 trusted 事件的**唯一直接读数**。
                  //   合成事件（dispatchEvent）恒为 false；真实触摸走 WebView 输入管线则为 true。
                  if (e.isTrusted) { window.__tjhProbe.it = (window.__tjhProbe.it||0)+1; }
                  else { window.__tjhProbe.sy = (window.__tjhProbe.sy||0)+1; }
                  if (t === 'click') {
                    window.__tjhProbe.last = (e.target && (e.target.textContent||'')).trim().slice(0,16);
                  }
                } catch(err){}
              }, true);
            })(types[i]);
          }
          return 'installed';
        })()
    """

    /**
     * ★★★ 第 36 期：纯读钩子 —— 记录**页面自己发出的**请求与**回包原文**。
     *
     * 为什么需要它：第 35 期已经证明「点击 → 页面发签到请求 → 200」，
     * 但**看不到回包内容**。而微博风控的两样关键信息都在回包体里：
     *   · `msg`   —— 话术（例如「你最近的行为存在异常，请先验证身份后再进行操作。」）
     *   · `scheme` —— **它给的验证地址**（本工程的 HTTP 签到路径就把它整条丢掉了）
     * 拿到回包，才能判断「页面处理器到底拿到了什么、它想让我们去哪」。
     *
     * ★ 纯读，行为零变化：
     *   · `XMLHttpRequest.prototype.open/send` 只是**透传**（`apply` 返回原返回值）；
     *   · 只对 URL 命中 `checkin|verify|captcha|yidun|necapcha|sign|proxy|aj/` 的请求挂 `load` 监听；
     *   · `fetch` 用 `r.clone().text()` 读副本，**不消费原响应**；
     *   · 不 preventDefault、不改 header、不改 URL、不改返回值、不参与任何判定。
     *   整段删掉不影响任何功能。
     *
     * ★ 只在 URL 命中时才记，最多留 40 条，每条回包截 400 字符 —— 防报告爆量。
     */
    private val NET_HOOK_JS = """
        (function(){
          if (window.__tjhNet) return 'exists';
          window.__tjhNet = [];
          function push(u, s, b) {
            try {
              if (window.__tjhNet.length > 40) window.__tjhNet.shift();
              window.__tjhNet.push({
                u: String(u||'').split('?')[0].slice(-44),
                s: s,
                b: String(b||'').replace(/\s+/g,' ').slice(0, 400)
              });
            } catch(e) {}
          }
          var KEY = /checkin|verify|captcha|yidun|necapcha|sign|proxy|aj\//;
          try {
            var oOpen = XMLHttpRequest.prototype.open;
            var oSend = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.open = function(m, u) {
              try { this.__tjhUrl = u; } catch(e) {}
              return oOpen.apply(this, arguments);
            };
            XMLHttpRequest.prototype.send = function() {
              var self = this;
              try {
                if (KEY.test(String(self.__tjhUrl||''))) {
                  self.addEventListener('load', function(){
                    var body = '';
                    try { body = self.responseText || ''; } catch(e) {}
                    push(self.__tjhUrl, self.status, body);
                  });
                }
              } catch(e) {}
              return oSend.apply(this, arguments);
            };
          } catch(e) {}
          try {
            var oFetch = window.fetch;
            if (oFetch) {
              window.fetch = function() {
                var u = arguments[0];
                try { u = (typeof u === 'string') ? u : (u && u.url); } catch(e) {}
                var p = oFetch.apply(this, arguments);
                try {
                  if (KEY.test(String(u||''))) {
                    p.then(function(r){
                      try { r.clone().text().then(function(t){ push(u, r.status, t); }); } catch(e) {}
                    });
                  }
                } catch(e) {}
                return p;
              };
            }
          } catch(e) {}
          return 'installed';
        })()
    """

    /**
     * ★★ 第 37 期：读「离开验证页之后的落地页」信息。
     *
     * 真机实测：验证页 `security.weibo.com/captcha/geetest` 之后会跳到
     * `https://huati.weibo.cn/super/browser/close`（**超话域**），
     * 而 `onPageStarted` 里的成功判定只认 `https://weibo.com` / `https://m.weibo.cn`
     * ⇒ 匹配不上 ⇒ 报告里没有 `[判定] 验证通过`。
     * 但那个落地页究竟是「**验证通过后跳回**」还是「**拖 4 次都没过、放弃**」，
     * 当前证据**分不出来**（4 次拖动全被拒，形状上像放弃）。
     *
     * 这里只把落地页的可见信息记下来：标题 / 正文文本长度 / 有没有「签到」字样的按钮。
     * `bodyLen` 很小 ⇒ 大概率是个空壳回调页；出现「已签到」⇒ 说明真的过了。
     * ★ **纯读**：只读 DOM 拼字符串，不改页面、不发请求、不参与任何判定。整段删掉无影响。
     */
    private val LANDING_JS = """
        (function(){
          var t = '', n = -1, btn = '';
          try { t = document.title || ''; } catch(e) {}
          try {
            n = (document.body && document.body.textContent)
                ? document.body.textContent.trim().length : -1;
          } catch(e) {}
          try {
            var all = document.querySelectorAll('a,button,div,span,i');
            for (var i = 0; i < all.length && i < 2000; i++) {
              var x = (all[i].textContent || '').trim();
              if (x.length <= 20 && x.indexOf('签到') >= 0 && all[i].offsetParent !== null) {
                btn = x; break;
              }
            }
          } catch(e) {}
          return 'title=' + t + ' btn=' + (btn || '(无)') + ' bodyLen=' + n;
        })()
    """

    /** 一次性读出「聚焦 / 可见 / 缩放 / 七种事件计数 / 签到按钮与它中心点的元素 / 验证码 DOM」。 */
    private val PROBE_JS = """
        (function(){
          var p = window.__tjhProbe || { ev:{}, last:'(no-listen)' };
          var ev = p.ev || {};
          var found = '', pt = '';
          var all = document.querySelectorAll('a,button,div,span,i,[class*="check"],[class*="sign"],[class*="btn"],[class*="Button"]');
          for (var i=0;i<all.length;i++){
            var t = (all[i].textContent || '').trim();
            var r = all[i].getBoundingClientRect();
            if (t.indexOf('签到') >= 0 && all[i].offsetParent !== null && r.width > 0 && r.width < 300) {
              found = t + '@' + Math.round(r.left) + ',' + Math.round(r.top) +
                      ' w' + Math.round(r.width) + ' h' + Math.round(r.height);
              var cx = Math.round(r.left + r.width/2), cy = Math.round(r.top + r.height/2);
              var e = document.elementFromPoint(cx, cy);
              pt = cx + ',' + cy + '>' + (e ? (e.tagName + '.' + String(e.className||'').slice(0,24)) : 'null');
              break;
            }
          }
          // ★★ 第 35 期新增 ua= ：navigator.userActivation 的 isActive / hasBeenActive。
          //   这是「页面有没有见过一次真实用户手势」的唯一客观读数 ——
          //   合成事件（dispatchEvent）**不会**设置 user activation，真手指/真实触摸会。
          //   `00` = 从来没被激活过（页面若按 userActivation 分支，就必然拒绝我们）；
          //   `11` = 曾经被激活过。比 isTrusted 更贴近「页面凭什么拒绝」这件事。
          var ua = window.navigator.userActivation
                 ? ((navigator.userActivation.isActive ? 1 : 0) + '' +
                    (navigator.userActivation.hasBeenActive ? 1 : 0))
                 : 'n/a';
          // ★★ 第 36 期新增 it= ：click 监听里 trusted / 合成 的累计条数。
          //   若 trusted 分量从 0 变正 ⇒ `webView.dispatchTouchEvent()` 确实产生了可信事件。
          var tr = (p.it||0) + '/' + (p.sy||0);
          // ★★ 第 36 期新增 cap= ：验证码类元素总数 / 其中 src 命中的 iframe 数。
          //   第 35 期只查 `.yidun_bg-img` / `.yidun_jigsaw` 两个**具体选择器** ——
          //   若易盾换了类名、或把验证码塞进 iframe，那两处永远是 0，
          //   而实际上「验证码已经存在、只是不可见」。这一项就是用来排除这种情形的。
          var cap = 0, capIf = 0;
          try {
            cap = document.querySelectorAll(
              '[class*="captcha"],[class*="nc_"],[class*="yidun"],[id*="captcha"],[id*="yidun"]'
            ).length;
            var fr = document.querySelectorAll('iframe');
            for (var q=0;q<fr.length;q++){
              var s = String(fr[q].src||'');
              if (s.indexOf('captcha')>=0 || s.indexOf('yidun')>=0 ||
                  s.indexOf('verify')>=0 || s.indexOf('security')>=0) capIf++;
            }
          } catch(e) {}
          return 'focus=' + document.hasFocus() + ' vis=' + document.visibilityState +
                 ' inner=' + window.innerWidth + 'x' + window.innerHeight +
                 ' ua=' + ua + ' it=' + tr + ' cap=' + cap + '/' + capIf +
                 ' | ev=' + (ev.touchstart||0) + ',' + (ev.touchend||0) + ',' +
                 (ev.pointerdown||0) + ',' + (ev.pointerup||0) + ',' +
                 (ev.mousedown||0) + ',' + (ev.mouseup||0) + ',' + (ev.click||0) +
                 ' last=' + p.last +
                 ' | btn=' + found + ' pt=' + pt +
                 ' bg=' + (document.querySelector('.yidun_bg-img') ? 1 : 0) +
                 ' jig=' + (document.querySelector('.yidun_jigsaw') ? 1 : 0);
        })()
    """

    /**
     * ★ 第 35 期：探针的**短版**。
     *
     * 原来探针每 3 秒一条、一轮 12 条、每条约 250 字符 —— 单这一项就占了整份报告一半以上，
     * 用户反馈「文字太多，微信发不出去」。现在改成：
     *   · 第 1 次打**完整版**（`PROBE_JS`，含 `btn=`/`pt=` 这类只用来做基线、之后不会变的信息）；
     *   · 之后只打这个短版，并且**只在内容真的变了时才留痕**（见 `startProbe`）。
     * 于是「什么时候变了、变成了什么」照样一眼看得见，没变的就不再重复。
     *
     * ★ 短版保留的都是**会变**的项：可见性、`ua=`、trusted/合成计数、7 种事件计数、验证码 DOM。
     * ★ 第 36 期：为容纳新增的 `it=` / `cap=`，把 7 个事件计数压成 `ev=ts,te,pd,pu,md,mu,cl` 一行，
     *   并**去掉短版里的 `last=`**（点击目标文案在完整版里已经打过，且只在点击那一刻才有意义）。
     *   净体量与第 35 期基本持平。
     */
    private val PROBE_JS_SHORT = """
        (function(){
          var p = window.__tjhProbe || { ev:{}, last:'(no-listen)' };
          var ev = p.ev || {};
          var ua = window.navigator.userActivation
                 ? ((navigator.userActivation.isActive ? 1 : 0) + '' +
                    (navigator.userActivation.hasBeenActive ? 1 : 0))
                 : 'n/a';
          var cap = 0;
          try {
            cap = document.querySelectorAll(
              '[class*="captcha"],[class*="nc_"],[class*="yidun"],[id*="captcha"],[id*="yidun"]'
            ).length;
          } catch(e) {}
          return 'vis=' + document.visibilityState + ' ua=' + ua +
                 ' it=' + (p.it||0) + '/' + (p.sy||0) + ' cap=' + cap +
                 ' | ev=' + (ev.touchstart||0) + ',' + (ev.touchend||0) + ',' +
                 (ev.pointerdown||0) + ',' + (ev.pointerup||0) + ',' +
                 (ev.mousedown||0) + ',' + (ev.mouseup||0) + ',' + (ev.click||0) +
                 ' | bg=' + (document.querySelector('.yidun_bg-img') ? 1 : 0) +
                 ' jig=' + (document.querySelector('.yidun_jigsaw') ? 1 : 0);
        })()
    """

    /** 验证用的超话签到页（电脑版），与 WeiboLoginActivity 一致。 */
    private const val VERIFY_CHECKIN_URL = "https://weibo.com/p/100808212349219ac32e9f5c1165965a769d0f"

    @Volatile
    private var running = false

    private val queue = ArrayDeque<WeiboAccount>()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var appContext: Context? = null
    private var windowManager: WindowManager? = null
    private var webView: WebView? = null
    private var autoSlider: YidunAutoSlider? = null
    private var safetyTask: Runnable? = null
    private var touchDisarmTask: Runnable? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    // ★ 第 22 期诊断探针（只读，验证完可整段删除）
    private var probeTask: Runnable? = null
    private var probeTicks = 0
    private var probeInstalled = false
    // ★ 第 35 期：探针「只在变化时留痕」用的上一行内容（见 startProbe 的说明）。
    // ★ 第 93 期：改存**去重 key**（不是原文）—— 见 `startProbe()` 里的说明。
    private var lastProbeKey: String? = null
    // ★ 第 35 期：`[页面完成]` 去重用的上一个 URL —— 同一页会连着回调 2~3 次，
    //   原来就留 2~3 条一模一样的行，纯占地方。
    private var lastPageFinishedUrl: String? = null
    // ★ 第 37 期：`[落地]` 去重用的上一个 URL（同一页同样会连着回调）。
    private var lastLandingUrl: String? = null
    // ★ 第 39 期：本账号已经重挂过几轮；`rearmTask` 是待执行的重挂任务（收摊时要撤掉）；
    //   `currentCheckinUrl` 是「重挂时重新打开哪个地址」——就是首轮打开的那个超话页。
    private var rearmCount = 0
    private var rearmTask: Runnable? = null
    private var currentCheckinUrl: String? = null
    // ★ 第 61 期：首轮打开的那个超话的纯 100808… id —— 重挂换超话时要把它**排除**掉。
    //   与 `currentCheckinUrl` 同生同灭（同一处赋值、同一处清空）。
    private var currentContainerId: String = ""

    // —— 与 WeiboLoginActivity 验证模式一致的字段 ——
    private var finished = false
    private var captchaSeen = false
    private var lastSaveAt = 0L

    fun isActive(): Boolean = running

    /**
     * 入队一个待验证账号。悬浮窗权限缺失时直接报错收摊；否则排进队列，
     * 当前没在跑就立刻开始处理下一个。
     */
    fun start(context: Context, account: WeiboAccount) {
        if (!Settings.canDrawOverlays(context)) {
            SliderTrace.log("[悬浮窗验证] 失败：没有悬浮窗权限（SYSTEM_ALERT_WINDOW）")
            return
        }
        appContext = context.applicationContext
        val size: Int
        synchronized(queue) {
            queue.addLast(account)
            size = queue.size
        }
        SliderTrace.log("[悬浮窗验证] 入队：" + account.displayName + "（队列=" + size + "）")
        if (!running) mainHandler.post { processNext() }
    }

    private fun processNext() {
        if (running) return
        val acc = synchronized(queue) { queue.pollFirst() } ?: return
        finished = false
        captchaSeen = false
        lastSaveAt = 0L
        probeInstalled = false
        // ★ 第 39 期：重挂计数按账号清零（一个账号最多 maxSliderRearms 轮）。
        rearmCount = 0
        running = true
        try {
            arm(acc)
        } catch (error: Throwable) {
            SliderTrace.log("[悬浮窗验证] 挂载失败：" + error.javaClass.simpleName + " " + error.message)
            running = false
            if (synchronized(queue) { queue.isNotEmpty() }) mainHandler.post { processNext() }
        }
    }

    private fun arm(account: WeiboAccount) {
        val ctx = appContext ?: return
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val w = ctx.resources.displayMetrics.widthPixels
        val h = ctx.resources.displayMetrics.heightPixels

        val params = WindowManager.LayoutParams().apply {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            width = w
            height = h
            format = PixelFormat.TRANSLUCENT
            // ★ 第 21 期：挂载初期**可触摸**（不设 FLAG_NOT_TOUCHABLE），
            //   让无障碍「点签到」的手势能真正落到 WebView 上。
            // ★ 第 23 期：同时**去掉 FLAG_NOT_FOCUSABLE**，让窗口能拿焦点。
            //   第 22 期探针实测 `focus=false`（页面始终没焦点）——这是与「前台 Activity 能点中」
            //   唯一的窗口级差异；而 focus=false 时页面可能收不到/不处理输入。
            //   30 秒后由 touchDisarmTask 一并收回「可触摸 + 可聚焦」。
            // ★ 第 21 期：挂载初期**可触摸**（不设 FLAG_NOT_TOUCHABLE），
            //   让无障碍「点签到」的手势能真正落到 WebView 上。
            // ★ 第 23 期：同时**去掉 FLAG_NOT_FOCUSABLE**，让窗口能拿焦点。
            //   第 22 期探针实测 `focus=false`（页面始终没焦点）——这是与「前台 Activity 能点中」
            //   唯一的窗口级差异；而 focus=false 时页面可能收不到/不处理输入。
            //   30 秒后由 touchDisarmTask 一并收回「可触摸 + 可聚焦」。
            // ★★ 第 37 期：上面这套（第 21/23 期的「占住系统触摸面」）**默认不再启用** ——
            //   见 keepWindowTouchable 的说明：点击与拖动都改走 `webView.dispatchTouchEvent()`，
            //   不再经过系统窗口分发，所以没有理由再让这个隐形窗口吃掉用户的手指触摸。
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            // ★★ 窗口级（不是 Activity 级）的「锁屏上显示」+「点亮屏幕」——
            //   正是 Activity 那条路上被睡眠令牌忽略掉的。
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                flags = flags or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            }
            // ★★ 第 37 期：默认**不占用系统触摸面** —— 手指触摸直接透给下面的页面。
            if (!keepWindowTouchable) {
                flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            }
            // ★ 几乎全透明：隐形，但窗口真实存在、surface 真的会渲染。
            alpha = 0.01f
        }

        val web = WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            // 验证模式用电脑版 UA：手机版网页没有签到按钮，触发不了滑块
            settings.userAgentString =
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
        }
        webView = web

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (url != null) {
                    // ★ 每个跳转都留一条：验证页究竟落在哪个域名，是排查
                    //   「滑块明明拖过去了却不认账」的第一现场。
                    SliderTrace.log("[页面开始] " + url + "  captchaSeen=" + captchaSeen)
                    if (url.contains("security.weibo.com")) {
                        captchaSeen = true
                        SliderTrace.log("[验证页] 命中 security.weibo.com → captchaSeen=true")
                    } else if (captchaSeen &&
                        (
                            url.startsWith("https://weibo.com") ||
                                url.startsWith("https://m.weibo.cn") ||
                                // ★★★ 第 38 期：实测落地是 `https://huati.weibo.cn/super/browser/close`
                                //   （超话域），原来这里只认上面两个前缀 ⇒ 永远匹配不上
                                //   ⇒ 从不打印 `[判定] 验证通过` ⇒ `restUntil` 不设 ⇒ 反复撞风控。
                                //   详见 useLandingAsSuccess 的说明。
                                (useLandingAsSuccess && url.contains(".weibo.cn"))
                            )
                    ) {
                        // 从验证页跳回微博 = 验证成功，停止加载避免重页面把内核拖崩
                        SliderTrace.log("[验证成功] 已从验证页跳回微博，开始收尾（url=" + url + "）")
                        web.stopLoading()
                        onVerifySuccess(account)
                        return
                    }
                }
                autoSlider?.onPageStarted()
            }

            // ★ 非 http/https 的跳转 WebView 处理不了、会直接闪退 —— 必须拦下。
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    false
                } else {
                    true
                }
            }

            // ★★★ 第 70 期新增：滑块样本采集（纯旁观，行为零变化）。
            //
            //   为什么必须挂在**这里**：`YidunAutoSlider.downloadImage()` 走的是
            //   `HttpURLConnection`，**不经过 WebView 的资源加载** ⇒ JS 钩子（NET_HOOK_JS）
            //   完全看不到这两张图（它只 hook 页面自己发的 XHR/fetch）。能拿到原始字节的
            //   位置只有这一个；而且这里是**响应原文**，避开了 `bitmapToMat` 前
            //   `inPreferredConfig = ARGB_8888` 的颜色空间转换 —— 样本必须与 OpenCV
            //   看到的逐字节一致，否则「复刻 vs OpenCV 逐像素对齐」的比对结论无效。
            //
            //   ★ 一律 `return null` ⇒ WebView 照常自己发请求、自己加载。
            //     本分支只旁观字节流：不改 URL、不改 header、不改响应、不注入任何东西、
            //     不参与任何判定。[SliderSampler.enabled] 默认 false ⇒ 连日志都没有。
            //   ★ 只取 body：`WebResourceResponse` 的流只能读一次，读走了不还给 WebView 会白屏 ——
            //     所以这里读的是 `request` 侧拿不到、只能靠 `openConnection` 再取一次；
            //     但那会产生**第二次网络请求**。因此这里改为**只记 URL 清单**，
            //     真正的字节由 YidunAutoSlider 侧顺手落盘（见 SolveOnce 前的 capture）。
            //     这样零额外请求、零风险。
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): android.webkit.WebResourceResponse? {
                try {
                    val u = request?.url?.toString()
                    if (u != null && u.contains("necaptcha")) {
                        SliderSampler.noteUrl(u)
                    }
                } catch (_: Throwable) {
                }
                // ★ 返回 null：完全交给 WebView 自己处理，行为与第 69 期逐字节相同。
                return null
            }

            // ★ 主文档加载失败是「验证页打不开 / 白屏」的直接原因。只记主框架。
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    SliderTrace.log(
                        "[加载失败] code=" + error?.errorCode + " " + error?.description +
                            " " + request.url
                    )
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // ★ 第 35 期：同一页会连着回调 2~3 次，只保留「与上一条不同」的那次。
                if (url != lastPageFinishedUrl) {
                    lastPageFinishedUrl = url
                    SliderTrace.log("[页面完成] " + url)
                }
                autoSlider?.onPageFinished()
                trySaveCookies(account)
                // ★★ 第 36 期：纯读探针（点击监听 + 网络钩子 + 周期探针）。
                //   ★★★ 第 37 期改成**每一页都装**：原来只在第一页装一次（`probeInstalled` 置 true
                //   后不再装），而「点签到」后 **0.687 秒**就跳到了验证页
                //   ⇒ 新 document 里 `window.__tjhProbe` / `window.__tjhNet` 都是空的，
                //   报告里 `it=` / `ev=` / `net=` 全是 0 / `(无)` —— 看着像功能失效，其实是压根没装。
                //   ★ 两个脚本自身幂等（都以 `if (window.__tjhXxx) return 'exists'` 开头），重复装安全。
                if (view != null) {
                    try {
                        view.evaluateJavascript(CLICK_LISTENER_JS, null)
                        // ★ 第 36 期：纯读网络钩子 —— 记录页面自己发出的 checkin/verify 类请求
                        //   与**回包原文**（风控话术 + `scheme` 验证地址都在回包体里）。
                        view.evaluateJavascript(NET_HOOK_JS, null)
                    } catch (_: Throwable) {
                    }
                    if (!probeInstalled) {
                        probeInstalled = true
                        startProbe(view)
                    }
                    // ★★ 第 37 期：离开验证页后的「落地页」信息（纯读，去重）。
                    //   用来判定 `https://huati.weibo.cn/super/browser/close` 到底是
                    //   「验证通过后跳回」还是「拖 4 次都没过、放弃」——当前证据分不出来。
                    if (captchaSeen && url != null && !url.contains("security.weibo.com") &&
                        url != lastLandingUrl
                    ) {
                        lastLandingUrl = url
                        SliderTrace.log("[落地] " + url)
                        try {
                            view.evaluateJavascript(LANDING_JS) { v ->
                                SliderTrace.log("[落地] 页面=" + (v?.trim('"') ?: "null"))
                            }
                        } catch (_: Throwable) {
                        }
                    }
                }
            }
        }
        // ★★★ 第 36 期纯读诊断：把默认的 `WebChromeClient()` 换成「只加日志、返回值与默认完全一致」
        //   的匿名子类。三处都只记一行、行为零变化：
        //
        //   ① `onCreateWindow` —— 页面想开新窗口。
        //      微博风控回包里带 `scheme`（验证地址）+ `button`（按钮文案），
        //      页面很可能就是靠 `window.open(scheme)` 打开验证页的；而 **没有 user activation
        //      时 Chromium 会直接拦掉 window.open**（第 35 期实测 `ua=00`）。
        //      `isUserGesture` 这个参数正好回答「页面自己认为这是一次用户手势吗」。
        //      默认实现返回 false（不创建窗口）—— 这里也返回 false，行为不变。
        //
        //   ② `onJsAlert` —— 默认实现**什么都不显示**（这里只记日志，仍返回 false）。
        //   ③ `onJsConfirm` / `onJsPrompt` —— 默认实现**直接返回 false**，
        //      也就是**等于用户点了「取消」**。若页面是用 confirm() 问「需要验证身份，是否前往？」，
        //      那它永远收到「取消」，于是什么都不做 —— 这正是「处理器跑了却零反应」的一种解释。
        //      这里返回值与默认一致（false），只多一行日志。
        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                SliderTrace.log(
                    "[弹窗] 页面尝试打开新窗口 isDialog=" + isDialog +
                        " isUserGesture=" + isUserGesture + "（本工程不创建窗口，行为不变）"
                )
                return false
            }

            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                SliderTrace.log("[JS对话框] alert: " + message)
                return false
            }

            override fun onJsConfirm(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                SliderTrace.log("[JS对话框] confirm: " + message + "（默认返回 false = 取消）")
                return false
            }

            override fun onJsPrompt(
                view: WebView?,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: android.webkit.JsPromptResult?
            ): Boolean {
                SliderTrace.log("[JS对话框] prompt: " + message)
                return false
            }
        }

        // ★ 验证模式**绝不能清 Cookie**：要带着同一个会话打开微博。
        injectCookies(account)
        CookieManager.getInstance().flush()

        val env = describeEnvironment(ctx)
        SliderTrace.log("[环境] " + env)
        // ★ 累加一个挤不掉的计数：报告里那句「验证页累计 N 次」。
        SliderTrace.markVerifySession(env)
        SliderTrace.log(
            "[锁屏] 已开启：悬浮窗 锁屏上显示 + 点亮屏幕" +
                "（标志=SHOW_WHEN_LOCKED|TURN_SCREEN_ON|KEEP_SCREEN_ON|NOT_TOUCH_MODAL" +
                if (keepWindowTouchable) {
                    "；前 30 秒可触摸+可聚焦，30 秒后加回 NOT_TOUCHABLE|NOT_FOCUSABLE）"
                } else {
                    "|NOT_TOUCHABLE|NOT_FOCUSABLE —— ★ 第 37 期起默认不占系统触摸面，手指触摸直接透给下面的页面）"
                }
        )

        // 易盾滑块自动识别 + 拖动（复用同一个 YidunAutoSlider，逐字节不变）
        autoSlider = YidunAutoSlider(web) { msg ->
            SliderTrace.log("[滑块] " + msg)
            try {
                Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
            } catch (_: Throwable) {
            }
        }
        // ★★★ 第 39 期：挂上「这一轮失败」的回调 —— 失败后隔 15 秒重新打开签到页再试一轮。
        //   ★ `WeiboLoginActivity` 那条兜底路径**不挂**这个回调（保持 null）⇒ 行为不变。
        //   ★ 只挂回调，滑块的识别 / 轨迹 / 成功判定一行未动。
        autoSlider?.onGaveUp = { scheduleRearm(account) }
        autoSlider?.start()

        wm.addView(web, params)
        layoutParams = params
        // ★★ 第 24 期取证：触摸到底有没有到达「我们这个窗口」。
        //   第 23 期已证：`[手势] tap onCompleted`（系统确实把触摸投出去了），
        //   但页面七种事件 `ts/pd/md/click` **全为 0** —— 触摸没进页面。
        //   这个监听挂在 WebView 上：
        //     · 它响了 ⇒ 触摸到了我们的窗口，问题在 Chromium/页面那一层；
        //     · 它不响 ⇒ 触摸被系统投给了**别的窗口**（安全锁屏下输入不给非 Activity 悬浮窗）。
        //   返回 false = 不消费，WebView 自己的 onTouchEvent 照常执行，行为不变。
        web.setOnTouchListener { _, e ->
            try {
                SliderTrace.log(
                    "[触摸] 窗口收到 action=" + e.action + " @(" + e.x + "," + e.y + ")"
                )
            } catch (_: Throwable) {
            }
            false
        }
        // ★ 第 23 期：窗口已可聚焦，主动请求一次视图焦点，让 document.hasFocus() 有机会变 true。
        try {
            web.isFocusable = true
            web.isFocusableInTouchMode = true
            web.requestFocus()
        } catch (_: Throwable) {
        }

        // ★ 第 21/23 期：30 秒后收回「可触摸 + 可聚焦」。
        //   签到早在挂载后 2~3 秒就点完，之后的滑块拖动是 JS 注入、不需要触摸；
        //   收回后用户就不会再被这个隐形窗口挡到、也不会被它抢焦点。
        //   ★★ 第 37 期：只有在 keepWindowTouchable = true 时才需要这套收尾 ——
        //     默认（false）挂载时就已经是 NOT_TOUCHABLE|NOT_FOCUSABLE，没有东西要收回。
        if (keepWindowTouchable) {
            val disarm = Runnable {
                if (!running) return@Runnable
                val p = layoutParams ?: return@Runnable
                // ★ 同时去掉 TURN_SCREEN_ON：否则 updateViewLayout 重新应用标志会再点亮一次屏幕
                //   （用户实测「每个账号亮了两次屏」）。
                @Suppress("DEPRECATION")
                val turnOnFlag = WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                p.flags = (p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) and turnOnFlag.inv()
                try {
                    windowManager?.updateViewLayout(web, p)
                    SliderTrace.log("[悬浮窗验证] 已收回触摸与焦点（30 秒点击窗口结束，恢复不接收触摸、不抢焦点）")
                } catch (_: Throwable) {
                }
            }
            touchDisarmTask = disarm
            mainHandler.postDelayed(disarm, TOUCH_WINDOW_MS)
        }

        SliderTrace.log(
            "[悬浮窗验证] 已挂载：宽=" + w + " 高=" + h + " alpha=0.01" +
                // ★★ 第 38 期：这句原来一直写着「前 30 秒可触摸+可聚焦以点击签到」，
                //   但第 37 期起默认已经挂 NOT_TOUCHABLE|NOT_FOCUSABLE 了 ——
                //   文案与事实相反会误导以后读日志的人，按开关分支出真实状态。
                if (keepWindowTouchable) {
                    "（隐形，前 30 秒可触摸+可聚焦以点击签到；账号=" + account.displayName + "）"
                } else {
                    "（隐形，不占系统触摸面，手指触摸直接透给下面的页面；账号=" + account.displayName + "）"
                }
        )

        // 电脑版超话签到页：自动点签到才会触发滑块。
        // 不能写死一个超话 —— 取该账号关注的第一超话，用它触发。
        Thread {
            val fetchStartedAt = System.currentTimeMillis()
            // ★ 第 61 期：把 containerId 与 url 一起算出来 —— 重挂换超话时要排除这一个。
            //   ★ 语义与第 60 期逐字相同：取不到（异常或空串）⇒ 回退 VERIFY_CHECKIN_URL。
            val containerId = try {
                runBlocking {
                    WeiboClient.fetchFirstTopicContainerId(account)
                }
            } catch (_: Exception) {
                ""
            }
            val url = if (containerId.isNotBlank()) "https://weibo.com/p/" + containerId else VERIFY_CHECKIN_URL
            SliderTrace.log("[打开] 取超话用时 " + (System.currentTimeMillis() - fetchStartedAt) + "ms")
            mainHandler.post {
                if (!finished) {
                    // ★ 第 39 期：记住这个地址 —— 滑块失败重挂时就是重新打开它。
                    currentCheckinUrl = url
                    // ★ 第 61 期：同时记住它的 containerId —— 重挂换超话时把它排除掉。
                    currentContainerId = containerId
                    SliderTrace.log("[打开] " + url)
                    web.loadUrl(url)
                } else {
                    SliderTrace.log("[打开] 跳过：页面已结束（finished=true）")
                }
            }
        }.start()

        // 安全超时：滑块最多 ~1 分钟会自行停手，这里兜底收摊。
        // ★ 第 39 期：把「重挂占用的时间」算进去，否则第 2 轮还没跑完就被这里收摊了。
        val task = Runnable { if (running) finishCurrent() }
        safetyTask = task
        mainHandler.postDelayed(task, safetyTimeoutMs())
    }

    /**
     * ★ 第 39 期：把「重挂轮数」折算进安全超时。
     *
     * 原来固定 120 秒 —— 加了重挂之后，一个账号最多跑 `1 + maxSliderRearms` 个会话，
     * 每个会话的等待 + 预算都要预留，否则第 2/3 轮会被安全超时直接掐掉，
     * 表现成「重挂没生效」。
     *
     * ★ `maxSliderRearms = 0` 时结果**恰好等于 120 秒**（= 第 38 期原值）。
     */
    private fun safetyTimeoutMs(): Long =
        SAFETY_TIMEOUT_MS + maxSliderRearms.coerceAtLeast(0) * (REARM_DELAY_MS + REARM_SESSION_BUDGET_MS)

    /**
     * ★★★ 第 39 期：滑块这一轮用尽机会后，隔 [REARM_DELAY_MS] 重新打开签到页再试一轮。
     *
     * 触发点是 `YidunAutoSlider.onGaveUp`（见那边的说明），覆盖三种失败收尾：
     * 用满 8 次机会 / 验证图连续 12 次未刷新 / 30 秒没等到验证码。
     *
     * ## 三道闸门（缺一不可）
     *
     * 1. `finished || !running` ⇒ 什么都不做。
     *    ★★★ **最关键的一道**：「30 秒没等到验证码」**同时也是验证成功的形状**
     *    （验证码消失 → 页面跳走 → `onVerifySuccess` → `finishCurrent()`），
     *    不查这两项就会在**成功之后**再挂一次，白白多打一轮请求。
     * 2. `rearmCount >= maxSliderRearms` ⇒ 到上限就停手，留痕交给用户手动处理。
     * 3. `webView` / `currentCheckinUrl` 为空 ⇒ 环境已经不在，直接放弃。
     *
     * ## ★★★ 第 61 期：重挂时**换一个超话**（见 [rearmSwitchTopic]）
     *
     * 原来重挂复用 `currentCheckinUrl` —— 2 轮全砸在同一个超话上。真机 10-04 实证：
     * 首轮点得动但没弹验证码，两轮重挂那个按钮已变「已签到」⇒ 点不动 ⇒ 三轮全废 ⇒
     * 账号卡在 `needsVerify` 里一整天（今日进度 4/5）。
     * 现在重挂前先在**后台线程**重新挑一个「今天还没签」的超话（排除刚点不动的那个），
     * 取不到就回退原地址。重挂轮数 / 间隔 / 安全超时公式一律未动。
     *
     * ## 重挂前必须做的一件事
     *
     * **把 `captchaSeen` 复位成 `false`**。`onPageStarted` 的成功判定是
     * 「`captchaSeen == true` 且新地址命中 `.weibo.cn`」，而重挂打开的正是
     * `https://weibo.com/p/...`（同样属于 `.weibo.cn`）⇒ 不复位就会被**立刻**
     * 判成「验证成功」，那是个**假成功**（会把账号错误地推进静置期）。
     * 顺带把 `[页面完成]` / `[落地]` 两个去重游标一起清掉，让新会话的日志完整。
     */
    private fun scheduleRearm(account: WeiboAccount) {
        val budget = maxSliderRearms
        if (budget <= 0) return
        val task = Runnable {
            rearmTask = null
            if (finished || !running) return@Runnable
            if (rearmCount >= budget) {
                SliderTrace.log(
                    "[重挂] 已重挂 " + rearmCount + "/" + budget + " 轮仍未过，停手，交给用户手动处理"
                )
                return@Runnable
            }
            val web = webView ?: return@Runnable
            val fallbackUrl = currentCheckinUrl ?: return@Runnable
            rearmCount++
            val round = rearmCount
            // ★ 第 61 期：本轮要排除掉的超话 = 首轮打开的那个（换超话就是为了不重复点它）。
            val excludeId = currentContainerId
            SliderTrace.log(
                "[重挂] 第 " + round + "/" + budget + " 轮：重新打开签到页再试一次滑块（账号=" +
                    account.displayName + "）"
            )

            /**
             * 真正开一轮：复位游标 → 重启滑块 → 打开目标页。
             *
             * ★★★ 三处复位**必须**留着：否则重新打开 `weibo.com` 会被 `onPageStarted`
             *   立刻判成「验证成功」（假成功）。
             * ★ 第 61 期：把这三行连同 `restart()`/`loadUrl()` 一起收进这个闭包 ——
             *   这样「换超话」那条路（先在后台线程取列表）也保证**复位与开页在同一主线程回合**，
             *   与第 60 期的时序逐字相同。
             */
            val begin = { target: String, newContainerId: String ->
                captchaSeen = false
                lastPageFinishedUrl = null
                lastLandingUrl = null
                currentCheckinUrl = target
                if (newContainerId.isNotBlank()) currentContainerId = newContainerId
                autoSlider?.restart()
                try {
                    web.loadUrl(target)
                } catch (_: Throwable) {
                }
            }

            if (rearmSwitchTopic && excludeId.isNotBlank()) {
                // ★★★ 第 61 期：换一个「今天还没签」的超话再试，不再死磕刚点不动的那个。
                //   取列表是网络动作 ⇒ 必须放后台线程（这个 Runnable 跑在主线程上）。
                //   取不到 / 取回来还是同一个 ⇒ 回退第 60 期行为（重开原地址）。
                Thread {
                    val startedAt = System.currentTimeMillis()
                    val nextId = try {
                        runBlocking {
                            WeiboClient.fetchFirstTopicContainerId(account, excludeId)
                        }
                    } catch (_: Exception) {
                        ""
                    }
                    val switched = nextId.isNotBlank() && nextId != excludeId
                    val target = if (switched) "https://weibo.com/p/" + nextId else fallbackUrl
                    SliderTrace.log(
                        "[重挂] 第 " + round + " 轮换超话用时 " + (System.currentTimeMillis() - startedAt) +
                            "ms → " + (if (switched) target else "没换到新超话，沿用 " + target)
                    )
                    mainHandler.post {
                        if (finished || !running) return@post
                        begin(target, if (switched) nextId else "")
                    }
                }.start()
            } else {
                begin(fallbackUrl, "")
            }
        }
        rearmTask = task
        mainHandler.postDelayed(task, REARM_DELAY_MS)
    }

    /**
     * 验证成功后更新账号状态并收摊。与 WeiboLoginActivity.onVerifySuccess 逐行一致。
     */
    private fun onVerifySuccess(account: WeiboAccount) {
        if (finished) return
        SliderTrace.log("[判定] 验证通过，账号进入静置期")
        finished = true
        // 取消验证全屏通知
        try {
            val nm = appContext?.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
            nm?.cancel(1002)
        } catch (_: Throwable) {
        }
        account.verified = true
        account.needsVerify = false
        account.riskScore = 0
        account.consecutiveFailures = 0
        account.lastCheckAt = System.currentTimeMillis()
        account.lastCheckMessage = "验证通过"
        // 验证完进静置期，避免立刻又触发风控
        // ★★ 第 39 期：静置时长可以是 0（= 验证后完全不静置，下个定时点自动补签）。
        //   `resting()` 的判定与下面这个算式**一行未动**，只是把用户可填范围放宽到 0~72。
        val cooldownHours = Prefs.verifyCooldownHours
        account.restUntil = System.currentTimeMillis() + cooldownHours * 3600_000L
        // ★★★ 第 39 期：**补上报告口径**（原来这里是缺口，用户 2026-10-01 真机实测到）。
        //   账号行信息栏读的是 `account.lastRunMessage`（MainActivity.kt:1725），
        //   而这里原来只写 `lastCheckMessage` ⇒ 明明 14:43:09 已经验证通过，
        //   那一栏还挂着上一次风控留下的「需要人工处理：微博要求验证身份」。
        //   ★ 两个字段都是**纯展示**：`account.lastRunMessage` 全工程只有
        //     MainActivity.kt:1725 读；`Prefs.lastRunStatus` 只有 MainActivity 的
        //     1304 / 1314 / 1513 / 1514 读。不参与任何判定。
        //   ★ 不动 `Prefs.lastRunMessage`：那是**多账号汇总**（每个账号一行），
        //     用单个账号的一句话覆盖它会丢信息。
        //   ★ 不动 `Prefs.pausedUntil`：它**参与判定**（AgentService 靠它决定本轮跑不跑），
        //     清掉它会立刻放行下一轮 ⇒ 真的会改行为，不在本次范围内。
        val passedMsg = if (cooldownHours > 0) {
            appContext?.getString(R.string.verify_passed_msg_rest, cooldownHours)
        } else {
            appContext?.getString(R.string.verify_passed_msg_norest)
        }
        passedMsg?.let { account.lastRunMessage = it }
        Prefs.lastRunStatus = "VERIFY_OK"
        Prefs.needsVerify = AccountStore.needsVerifyAccounts().isNotEmpty()
        AccountStore.save()
        try {
            Toast.makeText(appContext, "验证通过：" + account.displayName, Toast.LENGTH_LONG).show()
        } catch (_: Throwable) {
        }
        finishCurrent()
    }

    /**
     * 采集 Cookie 并落盘账号状态。与 WeiboLoginActivity.trySaveCookies 逐行一致
     * （仅把 runOnUiThread 换成主线程 Handler，因为这里没有 Activity）。
     */
    private fun trySaveCookies(account: WeiboAccount) {
        if (finished) {
            return
        }
        // 每加载一个页面都会回调一次，而验证过程会跳好几个页面。节流。
        val now = System.currentTimeMillis()
        if (now - lastSaveAt < 5000L) {
            return
        }
        lastSaveAt = now

        val cookieText = collectCookieHeader()
        if (!cookieText.contains("SUB=")) {
            return
        }

        val values = parseCookieValues(cookieText)
        for (name in listOf("SUB", "SUBP", "SSOLoginState", "ALF", "SRT", "SRF", "XSRF-TOKEN")) {
            val value = values[name] ?: continue
            CookieManager.getInstance().setCookie(
                "https://m.weibo.cn",
                "$name=$value; Domain=.weibo.cn; Path=/; Secure; SameSite=Lax"
            )
        }
        CookieManager.getInstance().flush()

        // 先写进这个账号的槽位，再验证 —— 验证时用的就是它自己的 Cookie
        account.cookie = cookieText
        account.pcCookie = collectPcCookieHeader()
        account.verified = false
        AccountStore.save()

        Thread {
            var loggedIn = false
            try {
                val config = WeiboClient.fetchConfig(account)
                loggedIn = config.optBoolean("login")
            } catch (_: Exception) {
                loggedIn = false
            }
            AccountStore.save()

            mainHandler.post {
                if (finished) return@post
                // 验证模式：不要自动关闭页面（这里没有页可关），只记会话状态。
                SliderTrace.log("[会话] Cookie 已采集，登录态=" + loggedIn + "（验证模式不自动关页）")
                // ★★ 第 32 期：与 WeiboLoginActivity.trySaveCookies 同款修复（注释见那边）。
                //   上面第 483~486 行无条件写了 verified=false，而这里原先只记日志、不写回账号
                //   ⇒ 会话有效的账号会被永久标成「未登录」。只做升级、不做降级。
                if (loggedIn) {
                    account.verified = true
                    AccountStore.save()
                }
            }
        }.start()
    }

    private fun collectCookieHeader(): String {
        val mobileRaw = CookieManager.getInstance().getCookie("https://m.weibo.cn").orEmpty()
        val mobileValues = parseCookieValues(mobileRaw)
        if (mobileValues.containsKey("SUB")) {
            return mobileValues.entries.joinToString("; ") { "${it.key}=${it.value}" }
        }

        val values = linkedMapOf<String, String>()
        values.putAll(mobileValues)
        for (url in listOf("https://weibo.com", "https://passport.weibo.com")) {
            val raw = CookieManager.getInstance().getCookie(url) ?: continue
            values.putAll(parseCookieValues(raw))
        }
        return values.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    private fun collectPcCookieHeader(): String {
        val values = linkedMapOf<String, String>()
        for (url in listOf("https://weibo.com", "https://passport.weibo.com")) {
            val raw = CookieManager.getInstance().getCookie(url).orEmpty()
            values.putAll(parseCookieValues(raw))
        }
        return values.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    private fun parseCookieValues(raw: String): Map<String, String> {
        val values = linkedMapOf<String, String>()
        for (part in raw.split(";")) {
            val item = part.trim()
            val index = item.indexOf('=')
            if (index <= 0) continue
            val name = item.substring(0, index).trim()
            val value = item.substring(index + 1).trim()
            if (value.isNotEmpty()) values[name] = value
        }
        return values
    }

    /**
     * 把这个账号已经保存的 Cookie 灌进 WebView 的 CookieManager。
     * WebView 的 Cookie 存储是整个应用共享的、和 Prefs 里存的那份互不相通，
     * 所以验证模式下必须显式灌一次，否则 WebView 打开的是一个全新的未登录会话。
     */
    private fun injectCookies(account: WeiboAccount) {
        val manager = CookieManager.getInstance()
        injectCookieParts(manager, account.cookie, "https://m.weibo.cn", ".weibo.cn")
        // weibo.com 优先用 PC cookie（含 XSRF-TOKEN，电脑版签到/验证需要），没有再用手机 cookie
        val pc = account.pcCookie.ifBlank { account.cookie }
        injectCookieParts(manager, pc, "https://weibo.com", ".weibo.com")
    }

    private fun injectCookieParts(manager: CookieManager, cookieText: String, url: String, domain: String) {
        for (part in cookieText.split(";")) {
            val item = part.trim()
            val index = item.indexOf('=')
            if (index <= 0) continue
            val name = item.substring(0, index).trim()
            val value = item.substring(index + 1).trim()
            if (name.isBlank() || value.isEmpty()) continue
            manager.setCookie(url, "$name=$value; Domain=$domain; Path=/; Secure; SameSite=Lax")
        }
    }

    /** 采一次当前环境：亮屏 / 锁屏 / 悬浮窗 / 全屏通知权限。全部只读，不改变任何行为。 */
    private fun describeEnvironment(ctx: Context): String {
        return try {
            val power = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            val keyguard = ctx.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            val fsOk = if (Build.VERSION.SDK_INT >= 34) nm.canUseFullScreenIntent() else true
            "亮屏=" + power.isInteractive +
                " 锁屏=" + keyguard.isKeyguardLocked +
                " 安全锁=" + keyguard.isKeyguardSecure +
                " 悬浮窗=" + Settings.canDrawOverlays(ctx) +
                " 全屏通知=" + fsOk
        } catch (_: Throwable) {
            "(读取失败)"
        }
    }

    /**
     * ★ 第 22 期诊断：周期性把页面现场打进黑匣子。只读，不改任何判定。
     *   每 3 秒读一次，共 14 次（约 42 秒），覆盖「点签到 → 等验证码」整段。
     * ★ 第 24 期补充：同时带上「窗口焦点」与「亮屏/锁屏」——点签到那一刻屏幕到底亮没亮、
     *   我们的窗口到底有没有拿到焦点，光看挂载时那一条 [环境] 不够。
     */
    private fun startProbe(web: WebView) {
        probeTicks = 0
        lastProbeKey = null
        val task = object : Runnable {
            override fun run() {
                if (!running || probeTicks >= 14) return
                probeTicks++
                try {
                    // ★ 第 35 期：环境只留「亮屏/锁屏」两项。安全锁 / 悬浮窗 / 全屏通知
                    //   在 [环境] 那行已经打过、且全程没变过，每行重复一遍纯属浪费篇幅。
                    val env = appContext?.let { ctx ->
                        val power = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                        val keyguard = ctx.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
                        "亮屏=" + power.isInteractive + " 锁屏=" + keyguard.isKeyguardLocked
                    } ?: ""
                    val winFocus = try {
                        web.hasWindowFocus()
                    } catch (_: Throwable) {
                        false
                    }
                    // ★ 第 35 期：第 1 次打完整版（基线：按钮位置、中心点元素），之后只打短版。
                    val js = if (probeTicks == 1) PROBE_JS else PROBE_JS_SHORT
                    web.evaluateJavascript(js) { v ->
                        val line = (v?.trim('"') ?: "null")
                        val full = "[探针] " + line + " | winFocus=" + winFocus + " " + env
                        // ★★ 第 35 期：**只在内容真的变了时才留痕**。
                        //   原来每 3 秒一条、一轮 12 条、每条 250 字符，占整份报告一半以上，
                        //   用户反馈「文字太多，微信发不出去」。去重后通常只剩 2~3 条，
                        //   而「什么时候变了、变成了什么」照样一眼看得见。
                        //
                        // ★★★ 第 93 期：第 35 期这道去重**实际失效了** ——
                        //   `ev=`（7 种事件计数）与 `it=/sy=`（可信 / 合成事件累计）**每拖动一次必然递增**，
                        //   于是「刚拖动过」这件事被重复记成十几条，一轮又能刷出十几行。
                        //   而这件事 `[拖动]` 行已经写过一次，属**无意义的变化**。
                        //   ⇒ 比对用的 key 里把这两个读数抹平（`ev=*` / `it=*`），
                        //     但**日志正文仍原样保留它们**，基线值照样看得见。
                        //   ⇒ 现在只有 vis / ua / cap / bg / jig / winFocus / 亮屏 / 锁屏 真的变了才新增行。
                        val key = full
                            .replace(Regex("""ev=[\d,]+"""), "ev=*")
                            .replace(Regex("""it=\d+/\d+"""), "it=*")
                        if (key != lastProbeKey) {
                            lastProbeKey = key
                            SliderTrace.log(full)
                        }
                    }
                } catch (_: Throwable) {
                }
                mainHandler.postDelayed(this, 3000)
            }
        }
        probeTask = task
        mainHandler.postDelayed(task, 500)
    }

    /** 收摊：停滑块、拆窗口、销毁 WebView，然后继续队列里的下一个账号。 */
    private fun finishCurrent() {
        safetyTask?.let { mainHandler.removeCallbacks(it) }
        safetyTask = null
        touchDisarmTask?.let { mainHandler.removeCallbacks(it) }
        touchDisarmTask = null
        probeTask?.let { mainHandler.removeCallbacks(it) }
        probeTask = null
        // ★ 第 39 期：撤掉还没执行的重挂任务，否则收摊后它还会去动一个已销毁的 WebView。
        //   （`scheduleRearm` 里另有 `finished || !running` 兜底，这里是双保险。）
        rearmTask?.let { mainHandler.removeCallbacks(it) }
        rearmTask = null
        currentCheckinUrl = null
        // ★ 第 61 期：与 currentCheckinUrl 同生同灭（下一个账号从零开始挑超话）。
        currentContainerId = ""
        layoutParams = null
        autoSlider?.stop()
        try {
            webView?.let { windowManager?.removeView(it) }
        } catch (_: Throwable) {
        }
        try {
            webView?.destroy()
        } catch (_: Throwable) {
        }
        webView = null
        windowManager = null
        autoSlider = null
        running = false
        if (synchronized(queue) { queue.isNotEmpty() }) mainHandler.post { processNext() }
    }
}
