package com.tjh.weibotask

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

object LocalScheduler {
    private const val REQUEST_CODE = 2001
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA)

    fun todayString(): String = dateFormat.format(Date())

    fun scheduleNext(context: Context) {
        Prefs.init(context)
        val now = Calendar.getInstance()
        val start = parseDate(Prefs.startDate.ifBlank { todayString() })
        val runAt = Calendar.getInstance().apply {
            time = start.time
            set(Calendar.HOUR_OF_DAY, Prefs.baseHour)
            set(Calendar.MINUTE, Prefs.baseMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (!after(now)) add(Calendar.DAY_OF_YEAR, 1)
            add(Calendar.MINUTE, Random.nextInt(0, 31))
        }

        if (Prefs.skipDate == todayString() && sameDay(runAt, now)) {
            runAt.add(Calendar.DAY_OF_YEAR, 1)
        }
        scheduleAt(context, runAt.timeInMillis)
    }

    fun ensureScheduled(context: Context) {
        Prefs.init(context)
        if (!Prefs.scheduleEnabled) return
        val existing = Prefs.nextRunAt
        if (existing > System.currentTimeMillis()) {
            scheduleAt(context, existing)
        } else {
            scheduleNext(context)
        }
    }

    fun skipToday(context: Context) {
        Prefs.init(context)
        Prefs.skipDate = todayString()
        cancel(context)
        if (Prefs.scheduleEnabled) scheduleNext(context)
    }

    fun cancel(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent(context))
        Prefs.nextRunAt = 0L
    }

    fun exactAlarmAllowed(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return alarmManager.canScheduleExactAlarms()
    }

    fun formatNextRun(context: Context): String {
        Prefs.init(context)
        if (!Prefs.scheduleEnabled || Prefs.nextRunAt <= 0L) return "自动签到未开启"
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA)
        return "下次自动执行：" + formatter.format(Date(Prefs.nextRunAt))
    }

    private fun scheduleAt(context: Context, triggerAt: Long) {
        Prefs.nextRunAt = triggerAt
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = pendingIntent(context)
        if (exactAlarmAllowed(context)) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        }
    }

    private fun parseDate(value: String): Calendar {
        val calendar = Calendar.getInstance()
        try {
            calendar.time = dateFormat.parse(value) ?: Date()
        } catch (_: Exception) {
            calendar.time = Date()
        }
        return calendar
    }

    private fun sameDay(left: Calendar, right: Calendar): Boolean {
        return left.get(Calendar.YEAR) == right.get(Calendar.YEAR) &&
            left.get(Calendar.DAY_OF_YEAR) == right.get(Calendar.DAY_OF_YEAR)
    }

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, CheckinAlarmReceiver::class.java)
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
