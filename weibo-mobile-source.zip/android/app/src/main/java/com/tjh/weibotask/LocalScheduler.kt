package com.tjh.weibotask

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

object LocalScheduler {
    private const val REQUEST_CODE = 2001

    fun scheduleNext(context: Context) {
        Prefs.init(context)
        val now = Calendar.getInstance()
        val runAt = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, Prefs.baseHour)
            set(Calendar.MINUTE, Prefs.baseMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (!after(now)) add(Calendar.DAY_OF_YEAR, 1)
            add(Calendar.MINUTE, Random.nextInt(0, 31))
        }
        scheduleAt(context, runAt.timeInMillis)
    }

    fun ensureScheduled(context: Context) {
        Prefs.init(context)
        if (!Prefs.scheduleEnabled) return
        val existing = Prefs.nextRunAt
        if (existing > System.currentTimeMillis()) {
            scheduleAt(context, existing)
        } else {
            scheduleNext(context)
        }
    }

    fun cancel(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent(context))
        Prefs.nextRunAt = 0L
    }

    fun exactAlarmAllowed(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return alarmManager.canScheduleExactAlarms()
    }

    fun formatNextRun(context: Context): String {
        Prefs.init(context)
        if (!Prefs.scheduleEnabled || Prefs.nextRunAt <= 0L) return "自动签到未开启"
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA)
        return "下次自动执行：" + formatter.format(Date(Prefs.nextRunAt))
    }

    private fun scheduleAt(context: Context, triggerAt: Long) {
        Prefs.nextRunAt = triggerAt
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = pendingIntent(context)
        if (exactAlarmAllowed(context)) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        }
    }

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, CheckinAlarmReceiver::class.java)
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
