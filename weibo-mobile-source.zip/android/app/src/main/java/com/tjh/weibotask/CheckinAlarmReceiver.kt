package com.tjh.weibotask

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import androidx.core.content.ContextCompat

class CheckinAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            Prefs.init(context)
        } catch (_: Exception) {
            // 加密存储损坏（EncryptedSharedPreferences 已知会抛 AEADBadTagException）
            // 时不能让 receiver 崩掉，否则后面什么都做不了
            return
        }
        if (!Prefs.scheduleEnabled) return

        // ★ 心跳：记下「闹钟真的响过」。
        //   用户报「到点没执行」时，这是唯一能区分两种原因的东西 ——
        //   闹钟没响（被系统省电策略丢弃）vs 闹钟响了但后台启动服务被拒。
        //   没有它，两种情况在界面上长得一模一样，只能靠猜。
        try {
            Prefs.lastAlarmAt = System.currentTimeMillis()
        } catch (_: Exception) {
        }

        // ★ 旧代码在服务启动前就 scheduleNext()，把 nextRunAt 直接推到明天。
        //   只要本次服务没真正起来，维护循环就会误以为今天已经没事了；
        //   唯一能发现漏跑的入口只剩 MainActivity.onResume，所以表现成「打开 App 才执行」。
        //
        //   现在先排一个 15 分钟后的**看门狗重试**：
        //   - 服务正常执行后，executeOnce 会用下一批/明天的计划覆盖它；
        //   - 服务被系统拦截或冷启动崩掉，它会再次唤醒，而不是把今天这一轮丢掉。
        try {
            LocalScheduler.scheduleRetry(context)
        } catch (_: Exception) {
        }

        // 广播到服务 onStartCommand 之间也可能再次休眠；用带超时的短锁只桥接冷启动，
        // 不长期持有，不需要手工释放（90 秒后系统自动释放）。
        try {
            val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            bridgeWakeLock = power.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "WeiboTask::AlarmBridgeWakeLock"
            ).apply {
                setReferenceCounted(false)
                acquire(90_000L)
            }
        } catch (_: Exception) {
        }

        val serviceIntent = Intent(context, AgentService::class.java).apply {
            // 启动维护模式即可：服务起来后，维护循环会按 nextRunAt 在正确时间触发签到，
            // 这样分批间隔（20~25 分钟）不会被看门狗多次唤醒打乱。
            // 维护循环本身靠 90 分钟窗口内的短时唤醒锁保证在 Doze 下也能到点执行。
            action = AgentService.ACTION_START_SCHEDULED
        }
        try {
            ContextCompat.startForegroundService(context, serviceIntent)
            // 这只证明系统接受了启动请求；AgentService.onStartCommand 另记 lastServiceStartAt，
            // 两个时间能区分「请求被接受」和「服务真的启动」。
            Prefs.lastAlarmAcceptedAt = System.currentTimeMillis()
        } catch (error: Exception) {
            Prefs.lastRunStatus = "BLOCKED"
            Prefs.lastRunMessage = "系统阻止了后台执行（" + error.javaClass.simpleName +
                "）。15 分钟后会重试；请允许「闹钟和提醒」并关闭电池优化。"
            Prefs.lastAlarmError = "start_service:" + error.javaClass.simpleName
        }
    }

    companion object {
        // 保持强引用直到 90 秒超时；否则局部 WakeLock 可能在服务冷启动前被回收。
        private var bridgeWakeLock: PowerManager.WakeLock? = null
    }
}
