package com.tjh.weibotask

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class CheckinAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Prefs.init(context)
        if (!Prefs.scheduleEnabled) return
        val serviceIntent = Intent(context, AgentService::class.java).apply {
            action = AgentService.ACTION_RUN_CHECKIN
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
