package com.tjh.weibotask

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

/**
 * 星签的进程入口（在 AndroidManifest 的 application 节点上用 android:name 挂载）。
 *
 * ★★ 第 83 期：界面外观固定为「默认浅色，可在设置页手动切深色」。
 *
 * ★ 为什么这件事必须放在 Application，而不是 MainActivity.onCreate：
 *   深色 / 浅色是**进程级**的静态设置（AppCompatDelegate.setDefaultNightMode）。
 *   放进 MainActivity 只能覆盖「从桌面图标点进来」这一条路，而本应用至少还有两条
 *   **绕过 MainActivity** 直接把界面拉起来的路径：
 *     ① 闹钟到点 → CheckinAlarmReceiver → AgentService 起前台服务（进程起来了，但一个 Activity 都没有）；
 *     ② 进程被 ROM 回收后，用户从最近任务回到互动页 → 系统**直接重建** InteractActivity。
 *   放在 Application.onCreate 才能保证：只要进程起来，外观就已经定好，
 *   与用户从哪个入口进来无关。
 *
 * ★ 为什么读的是 UiTheme 而不是 Prefs：
 *   Prefs 是数据层（账号 / Cookie / 登录态 / 签到与发帖状态），属硬规则一保护的范围；
 *   界面偏好是纯显示层的东西。两者混在一个文件里，以后动主题就有碰数据层的风险。
 *   所以单独一份只存这一个开关的偏好文件。
 *
 * ★ 判据自检（这个改动会不会让程序做出不同的决定）：不会。
 *   它只决定像素用哪套颜色，不参与签到 / 发帖 / 验证 / 账号里的任何一个判断，
 *   也不读写 Prefs 的任何一个键。
 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(UiTheme.mode(this))
    }
}

/**
 * 界面偏好 —— 目前只有「深色模式」一个开关。
 *
 * ★ 存储与 Prefs 完全分开：文件名 ui_theme，里面只放一个布尔值。
 *   它不是账号 / Cookie / 登录态 / 签到状态的一部分，改它不影响任何链路。
 *
 * ★ 默认值 false = 浅色。这一条就是「所有手机看到的都是浅色」的实现：
 *   不跟随系统；用户没主动开过深色，就永远是浅色。
 */
object UiTheme {
    private const val STORE = "ui_theme"
    private const val KEY_DARK = "dark"

    /** 用户是否手动开了深色模式（默认 false = 浅色）。 */
    fun isDark(ctx: Context): Boolean =
        ctx.getSharedPreferences(STORE, Context.MODE_PRIVATE).getBoolean(KEY_DARK, false)

    /** 换算成 AppCompatDelegate 需要的模式常量。 */
    fun mode(ctx: Context): Int =
        if (isDark(ctx)) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO

    /** 写入用户的选择（apply 异步落盘，不阻塞界面）。 */
    fun setDark(ctx: Context, dark: Boolean) {
        ctx.getSharedPreferences(STORE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_DARK, dark).apply()
    }
}
