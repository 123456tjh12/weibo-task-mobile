package com.tjh.weibotask

/**
 * ★★★★ 第 126 期（用户 2026-10-17 拍板）：**「哪些账号此刻正被签到 / 发帖链路占用」的登记表**。
 *
 * ## 为什么需要它
 *
 * 用户问：「发帖、签到、一键超Like 不可以同时进行吗？」
 *
 * 查源码的结论是**分两种**：
 *
 * - **签到 vs 发帖**：两者都住在 [AgentService] 里，共用同一个 `running` 布尔锁
 *   （见 `requestRun` / `requestPostTask`）⇒ **本来就不能同时**，后到的发帖会进
 *   [TaskQueue] 排队。这是第 121 期「排队替代丢弃」的设计，本期**不动**。
 * - **一键超Like vs 签到/发帖**：超Like 跑在**独立前台服务** [SuperLikeService] 里，
 *   有自己的 `running`，和 [AgentService] 之间**没有任何互斥** ⇒ 两条链路可以
 *   同时对**同一个账号**打请求。
 *
 * 最后这一条才是真风险：微博的风控是按账号算的，同一账号在同一秒被两条链路
 * 各打一串写请求，比「两个账号各打一串」危险得多 —— 而超Like 发的正是首评 / 转发
 * 这类**写请求**。
 *
 * ## 本对象的职责边界（硬纪律）
 *
 * - **只记录、不决策**：[AgentService] 里的签到 / 发帖循环只是把自己的批次**登记**
 *   进来，**一行判定都没改** —— 它们照旧跑自己的账号，不会因为这里有什么而跳过谁。
 * - **决策在超Like 那一侧**：`SuperLikeService.runOrchestration` 逐个账号开跑前问一句
 *   [isBusy]，命中就**跳过该账号**并记一行日志。这属于「互动模块内的任务编排」，
 *   是用户已批准的可改范围。
 * - **纯内存、不落盘**：进程活着才有意义 —— 进程死了，[AgentService] 那两条链路
 *   也一起死了，登记表自然该是空的。不碰 [Prefs]、不碰任何 Store。
 * - 全部方法 `synchronized`：主线程（服务 onStartCommand）与协程 / 工作线程都会碰。
 *
 * ★ 为什么按**批次**登记而不是「逐个账号进出」：
 *   逐个进出要在签到 / 发帖的 `for (account in batch)` 循环**内部**插桩 ——
 *   那是在核心链路①的执行体里加代码，风险明显更高。按批次登记只需要在
 *   「批次算出来」和「finally」两个位置各一行，核心循环一个字节都不用碰，
 *   代价是「整批账号在整趟执行期间都算忙」—— 对「同一账号不同时跑两条链路」
 *   这个目标来说，偏保守但完全够用。
 */
object AccountBusy {

    /** 此刻正被签到 / 发帖链路占用的账号 id。 */
    private val busy = java.util.Collections.synchronizedSet(LinkedHashSet<String>())

    /** 登记一批账号（批次算出来后调用一次）。空 id 直接忽略。 */
    fun enter(accounts: Collection<WeiboAccount>) {
        for (account in accounts) {
            val id = account.id
            if (id.isNotBlank()) busy.add(id)
        }
    }

    /** 释放一批账号（**必须**放在 `finally` 里，异常路径也要放掉）。 */
    fun release(accounts: Collection<WeiboAccount>) {
        for (account in accounts) {
            busy.remove(account.id)
        }
    }

    /** 这个账号此刻是否正被签到 / 发帖链路占用。 */
    fun isBusy(accountId: String): Boolean = busy.contains(accountId)

    /** 此刻忙着的账号有几个（诊断 / 日志用）。 */
    fun size(): Int = busy.size

    /** 全清（只用于「服务被重建」这类明确的复位点）。 */
    fun clear() {
        busy.clear()
    }
}
