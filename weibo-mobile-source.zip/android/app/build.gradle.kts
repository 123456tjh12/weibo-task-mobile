plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// 固定签名：让每次构建出来的包都用同一把钥匙。
//
// 背景：CI 运行器是一次性的，Gradle 每次都会重新生成 ~/.android/debug.keystore，
// 于是每个包的签名都不一样，装新版必须先卸载旧版（微博登录态也会一起丢）。
// 只要在 CI 里注入 KEYSTORE_* 环境变量，下面就会自动启用固定签名，
// 之后就能直接覆盖安装，不再需要卸载。
//
// 未配置这些环境变量时，一切照旧（走默认 debug 签名），不会影响现有构建。
val keystorePath = System.getenv("KEYSTORE_PATH").orEmpty()
val hasFixedKeystore = keystorePath.isNotBlank() && file(keystorePath).exists()

android {
    namespace = "com.tjh.weibotask"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tjh.weibotask"
        minSdk = 26
        targetSdk = 34
        // ★ 第 6 期（滑块黑匣子）起版本号开始逐期递增。
        //   第 2~5 期（按钮精简 / 文案抽干 / 首屏重排 / 深色模式）全都压在 0.20.20 / 61 上，
        //   结果是装完包**分不清拿到的是哪一版** —— 而诊断报告里第一行就打印版本号，
        //   靠它才能把「用户贴回来的报告」和「我改的代码」对上。
        //   规则：只要这一期会产生新的安装包，就必须 +1。
        //   62 / 0.20.21 = 滑块黑匣子（SliderTrace）
        //   63 / 0.20.22 = 可见性埋点 + 验证页锁屏显示与点亮屏幕
        //   64 / 0.20.23 = 黑匣子落盘（进程被杀也能接上上次记录）
        //   65 / 0.20.24 = 验证页累计计数（挤不掉的「到底出现过没有」）
        //   66 / 0.20.25 = 把「验证页是否出现过」搬进「账号与结果」段（用户会看的那一段）
        //   67 / 0.20.26 = ★ 修根因：全屏通知权限（跳错设置页 + 检查函数是死代码）
        //   68 / 0.20.27 = ★★ 真根因：验证通知挂在 IMPORTANCE_LOW 渠道上 → 改用独立高优先级渠道
        //   75 / 0.20.34 = ★ 落地：验证链路正式搬进悬浮窗（OverlayVerifyHost + AgentService 路由）
        //   76 / 0.20.35 = ★ 开通向导：新增 SetupWizardActivity（4 必选+通知可选，实时刷新），
        //                   砍掉 Period-19 遗留的「全屏通知」过时卡点，补齐电池优化 / 精确闹钟
        //   77 / 0.20.36 = ★ 修悬浮窗验证点不到签到：悬浮窗挂载后前 30 秒可触摸
        //                   （无障碍 dispatchGesture 只投给可触摸窗口；原来全程 NOT_TOUCHABLE ⇒ 点在空气上）
        //   78 / 0.20.37 = 诊断：容器加只读探针（focus/vis/clicks/btn/captcha DOM 打进黑匣子）；
        //                   并修「收回触摸时重放 TURN_SCREEN_ON 导致亮两次屏」
        //   79 / 0.20.38 = 探针升级（分开统计 touchstart/pointer*/mouse*/click 七种事件 + 缩放/坐标换算）
        //                   + 手势结果取证（onCompleted/onCancelled 落黑匣子）
        //                   + 悬浮窗前 30 秒**可聚焦**（去 FLAG_NOT_FOCUSABLE）修 focus=false
        //   80 / 0.20.39 = 触摸落点取证：悬浮窗挂 WebView 触摸监听（触摸到底有没有到我们窗口）
        //                   + 探针每轮带 winFocus 与 亮屏/锁屏
        //   81 / 0.20.40 = 第 27 期「风控账号一键重新授权」引导：
        //                   账号页按钮在 needsVerify 时显示「重新授权」；首页提示 /
        //                   验证通知 / 运行状态标签全部改成「动手做什么」的说法。
        //                   ★ 纯文案 + 按钮文字，代码路径一个字未动。
        //   82 / 0.20.41 = 第 32 期「修账号被判未登录的死锁」：
        //                   WeiboLoginActivity / OverlayVerifyHost 的 trySaveCookies 原先
        //                   无条件先写 verified=false，验证模式下又直接 return ⇒ 会话有效的
        //                   账号被永久标成「未登录」。改为**只升级不降级**（loggedIn 时补写
        //                   verified=true）。needsVerify / restUntil / 关页逻辑一字未动。
        //   83 / 0.20.42 = 第 33 期 P1 实验「点签到改用页面内 JS 点击」：
        //                   YidunAutoSlider 加开关 useJsClickForCheckin（默认 true），
        //                   「点签到」改走 element.dispatchEvent 合成点击，不经系统触摸分发。
        //                   ★ 只换「点」这个动作，滑块/拖动/判定/数据层一字未动；
        //                     翻回 false 即逐字节回到第 32 期。
        //   84 / 0.20.43 = 第 34 期「P2-A：点签到补 touch 事件 + 加纯读页面反应快照」：
        //                   YidunAutoSlider.clickCheckinButton 的合成序列补上
        //                   touchstart/touchend（第 33 期实测 ts=0 te=0，是唯一确凿的
        //                   事件类型缺口），顺序照真机点一下的顺序；
        //                   并新增 dumpPageReaction()：纯读 performance 资源条目 +
        //                   页面可见提示文案 + 标题/URL/按钮文案，用来分清
        //                   「处理器没跑」与「处理器跑了但微博不出滑块」。
        //                   ★ 只改「点」这一个动作 + 纯读日志，滑块/拖动/判定/数据层一字未动。
        //   85 / 0.20.44 = 第 35 期「补齐合成事件属性 + 定性 req= + 日志瘦身」：
        //                   ① YidunAutoSlider.clickCheckinButton 的 fire() 按真机属性补齐：
        //                      buttons（按下 1 / 抬起 0）、pointerType='touch'、isPrimary=true、
        //                      pointerId、pressure、composed、detail、screenX/Y。
        //                      原来 pointerdown 实际带着 buttons=0 / pointerType='' /
        //                      isPrimary=false —— 页面或风控看任一项就能把这串当噪声丢掉。
        //                   ② dumpPageReaction() 每条资源挂 t=startTime / d=duration /
        //                      s=responseStatus，并附 now=performance.now()；
        //                      点击返回值带 @performance.now() ⇒ 才能定死「这条请求是
        //                      点击触发的还是页面加载时就发的」（第 34 期就是缺它才白跑一轮）。
        //                      过滤词补 yidun/verify/slide（易盾脚本名里没有 captcha/sign，原来漏掉）。
        //                   ③ 日志瘦身（用户要求「微信发不出去」）：OverlayVerifyHost 探针
        //                      第 1 次打完整版、之后只在**内容变化时**打短版；[页面完成] 去重；
        //                      探针环境只留 亮屏/锁屏；dumpPageReaction 去掉 title=/url=。
        //                      新增探针项 ua=navigator.userActivation（判断页面有没有见过真实手势）。
        //                   ★ ① 属链路③「怎么点」，与第 34 期 P2-A 同类；
        //                     翻 useJsClickForCheckin=false 即逐字节回到第 32 期行为。
        //                     ②③ 纯读日志，不参与任何判定。
        //   86 / 0.20.45 = 第 36 期「点签到改真实触摸（trusted）+ 纯读诊断」：
        //                   依据 = 第 35 期真机定性「点击确实触发了签到请求（page/checkin 比点击
        //                          只晚 4ms、服务端 200）⇒ 瓶颈在签到 POST 之后」，且探针读到
        //                          ua=00（页面从没见过真实手势）。
        //                   ① 【链路③「怎么点」，需批准】YidunAutoSlider 新增
        //                      useTrustedTouchForCheckin（默认 true）：用
        //                      webView.dispatchTouchEvent() 注入一对真实 MotionEvent
        //                      （DOWN + 70ms + UP，SOURCE_TOUCHSCREEN，WebView 本地像素，
        //                      **不加** getLocationOnScreen）。走 WebView 自己的输入管线 ⇒
        //                      isTrusted=true 且**真正产生 user activation**，
        //                      一条改动同时覆盖三种解释：window.open 被无手势拦截 /
        //                      confirm() 默认返回 false 被吞 / 处理器自查 userActivation。
        //                      ★ 翻 useTrustedTouchForCheckin=false 即逐字节回到第 35 期。
        //                   ② 【纯读】OverlayVerifyHost 新增 NET_HOOK_JS：透传式包住
        //                      XHR.open/send 与 fetch，只对 URL 命中 checkin|verify|captcha|
        //                      yidun|necapcha|sign|proxy|aj/ 的请求挂 load 监听，记录回包原文
        //                      （风控话术 + scheme 验证地址都在回包体里）。不改返回值/不消费响应。
        //                   ③ 【纯读】OverlayVerifyHost 的 WebChromeClient 由默认实现换成
        //                      只加日志、返回值与默认**完全一致**的匿名子类：
        //                      onCreateWindow（带 isUserGesture）/ onJsAlert / onJsConfirm /
        //                      onJsPrompt。用来判定「页面是不是想弹窗或弹提示、被我们吞掉了」。
        //                   ④ 【纯读】探针新增 it=trusted/合成 计数（验证真实触摸是否 trusted）、
        //                      cap=验证码类元素总数/命中 iframe 数（排除「验证码存在但不可见」）；
        //                      7 个事件计数压成 ev= 一行以腾出体量。
        //                   ⑤ 【纯读】dumpPageReaction() 新增 net= 字段（读上面钩子的回包）；
        //                      去掉 5 秒那次重复快照（第 35 期实测与 1.5 秒那次完全相同）。
        //                   ★ 除 ① 外全部是纯读日志，不参与任何判定；
        //                     滑块识别 / 缺口计算 / 拖动轨迹 / 成功判定 / 数据层一字未动。
        //   87 / 0.20.46 = 第 37 期「拖动改真实触摸（trusted）+ 不再占系统触摸面 + 探针每页重装」：
        //                   依据 = 第 36 期真机（22:00 那次）——
        //                          ① 换成真实触摸点签到后，点击后 0.687 秒页面就跳到了
        //                             https://security.weibo.com/captcha/geetest，
        //                             探针 bg=1 jig=1（**滑块第一次出现**）
        //                             ⇒ 「页面按『有没有真实手势』分支」被证实；
        //                          ② 但拖动这一环还是合成事件，拖了 4 次都没过
        //                             （缺口 139.1/166.8/17.6/243.1、可信度 0.93~0.94）；
        //                          ③ 用户报「手工验证的时候，手机触摸没有反应」。
        //                   ① 【链路③「怎么拖」，需批准】YidunAutoSlider 新增
        //                      useTrustedTouchForDrag（默认 true）：改用 dispatchTrack()
        //                      注入真实触摸序列（ACTION_DOWN + 24×ACTION_MOVE + ACTION_UP，
        //                      SOURCE_TOUCHSCREEN）。★ 它本来就是项目里写好的死代码，
        //                      且 scheduleDrag 里 startX/startY/dist 本来就按 WebView 本地像素算
        //                      ⇒ 只是「把现成的东西接上」，轨迹算法一字未改。
        //                      ★ 翻 useTrustedTouchForDrag=false 即逐字节回到第 36 期。
        //                   ② 【窗口类，第7/14/15期先例】OverlayVerifyHost 新增
        //                      keepWindowTouchable（默认 false）：悬浮窗**不再占用系统触摸面**
        //                      （挂载即 NOT_TOUCHABLE|NOT_FOCUSABLE，不再有「前 30 秒可触摸」）。
        //                      根因：点击与拖动都改走 webView.dispatchTouchEvent（不经过系统窗口分发）
        //                      ⇒ 没有理由再让这个 alpha=0.01 的隐形全屏窗口吃掉用户的手指触摸。
        //                      ★ 置 true 即回到第 36 期（只有无障碍 tap 兜底才需要它）。
        //                   ③ 【纯读】探针/钩子改成**每一页都装**（原来只在第一页装，而点击后
        //                      0.687 秒就跳走 ⇒ 验证页上 it=/ev=/net= 全是 0，看着像功能失效）。
        //                   ④ 【纯读】新增 LANDING_JS + [落地] 日志：记录离开验证页后的落地页
        //                      （标题/正文长度/有没有「签到」按钮），用来定性
        //                      https://huati.weibo.cn/super/browser/close 是「过了」还是「放弃」。
        //                   ★ 除 ①②外全部是纯读；滑块识别 / 缺口计算 / 成功判定 / 数据层一字未动。
        //
        //  0.20.47 / 88 —— 第 38 期：回退「拖动改真实触摸」+ 让「验证成功」被认出来
        //                  依据 = 第 37 期真机（2026-09-30 23:30 那次）——
        //                          ① 真实触摸拖动**投递成功但滑块一动不动**：
        //                             24 步 ACTION_MOVE 全投递、`[拖动] P3 … 步数=24`，
        //                             但探针前后都是 `bg=1 jig=1 cap=93`；
        //                             `ev=1,1,1,0,0,0,0`（**`pointerup` 恒为 0**）+ `it=22/0`
        //                             ⇒ 触摸事件到了、Chromium 侧的 pointermove/pointerup 没生成
        //                             ⇒ 易盾滑块走 pointer ⇒ 没被驱动；
        //                          ② 对照组：第 36 期 22:00 用的 `jsDrag` 4 次拖动
        //                             缺口 x 每次都变（139.1→166.8→17.6→243.1）
        //                             ⇒ **`jsDrag` 才是能驱动滑块的那一个**；
        //                          ③ `sameBgPolls` **无上限** ⇒ 拖完不换图死转 180 次（约 108 秒）、
        //                             `attempts` 不增 ⇒ 8 次机会只用 1 次；
        //                          ④ 3 个账号卡在「需要人工验证」（今日进度 2/5）。
        //                  ① 【链路③「怎么拖」，已批准】YidunAutoSlider 的
        //                     useTrustedTouchForDrag 默认改回 **false** ⇒ 回到 jsDrag。
        //                     ★ 开关保留，方便以后换思路再试。
        //                  ② 【链路③循环控制，已批准】YidunAutoSlider 新增 sameBgLimit=12：
        //                     同一张验证图连续 12 次（约 8 秒）不刷新 ⇒ 判「这次拖动没起作用」，
        //                     打一条明确日志后**结束本轮**，不再空转 108 秒。
        //                     ★ 取值依据：第 36 期「拖成功后页面跳走」只用了 1 次同图轮询。
        //                  ③ 【链路③成功判定，已批准】OverlayVerifyHost 新增
        //                     useLandingAsSuccess（默认 true）：`captchaSeen` 且新地址命中 `.weibo.cn`
        //                     ⇒ 判验证通过。实测落地是 https://huati.weibo.cn/super/browser/close，
        //                     而原判定只认 weibo.com / m.weibo.cn ⇒ 永远匹配不上
        //                     ⇒ 从不打印 [判定] 验证通过 ⇒ needsVerify 不清、restUntil 不设
        //                     ⇒ **下个定时点又去签、又撞风控**（这才是「风控变频繁」的真因）。
        //                     ★ 依据：易盾失败时不会自动关页（会把滑块留在原地重试）；
        //                       落地是超话域（出发地）而非错误页；且 22:00 那次落地后账号确实签上了。
        //                     ★ 置 false 即回到第 37 期。
        //                  ④ 【纯读】YidunAutoSlider 新增 captchaEverSeen + 一条日志，把
        //                     「验证码消失」与「压根没出验证码」分开（原来混在同一分支）；
        //                     `30 秒内没等到验证码` 那条补上「曾出现过 / 已拖动几次」。
        //                  ⑤ 【文案】修 `[悬浮窗验证] 已挂载` 的过时文案（第 37 期改了标志却漏改这句，
        //                     它还写着「前 30 秒可触摸+可聚焦」）；修 YidunAutoSlider 类头
        //                     与代码相反的四行（旧版写着「拖动用原生 MotionEvent…不是 JS dispatchEvent」
        //                     「最多 3 次」）。
        //                  ★ 保留第 37 期的 keepWindowTouchable=false —— 真机已证实生效
        //                    （`[锁屏] …NOT_TOUCHABLE|NOT_FOCUSABLE`），且与拖动无关。
        // ★ 第 40 期：SliderTrace.CAP 80 → 400（纯日志，不改任何判定）
        //             + Dbg.enabled false → true（白名单内的日志开关）。
        //             目的：下一次真机撞风控时，证据不再被 80 条环形缓冲挤掉。
        // ★ 第 41 期：①【判定·用户已批准】AgentService.executeOnce 开头新增「跨天给一次
        //               重试机会」—— 修「撞风控后 account.needsVerify 永不自清 ⇒ 被
        //               notRunToday()/partialPending() 永久排除 ⇒ 只能手动重新授权」的死锁。
        //               判据用已有的 account.lastRunAt（不新增字段），当天行为一字不变。
        //             ②【纯展示】AgentService 签到成功时 Prefs.needsVerify 由「一刀切 false」
        //               改为按账号重算（与另外两处口径一致）。
        //             ③【纯展示】首页新增「另有 N 个账号已停用」提示；
        //               「随机延迟」说明从首屏折进「查看详情」。
        //             ④【文案】账号行结果句瘦身；4 处「一键开启（4 步）」改成界面上真实
        //               存在的按钮名「开通向导」；删 3 个没人引用的孤儿字符串。
        //             ★ 四条核心链路的判定，除 ① 之外一行未动（① 已单独取证并写入报告）。
        // ★ 第 42 期（2026-10-01，用户诉求：「有可能我换了手机，所以这些功能我希望做的是
        //            全安卓手机适用，而且开通向导，这个设置能不能更方便简洁一点，
        //            把不需要的设置删除」）—— 全部是【界面 / 文案 / 跳转】：
        //             ①【界面】无障碍由「必选」降为「可选（兜底）」，向导必选 4 → 3 项。
        //               依据：第 36 期起点签到走 webView.dispatchTouchEvent() 真实触摸、
        //               第 38 期起拖动改回页面内 JS ⇒ 无障碍只剩「两者都失败」时的第三级
        //               兜底（YidunAutoSlider.kt:596），第 36/38 期真机黑匣子从没走到过。
        //               新增常量 SetupWizardActivity.REQUIRED_ITEM_COUNT = 3，设置页与向导共用。
        //             ②【界面·修 bug】根治「已开启 5 / 4 项」：settings_perm_summary 原来
        //               分母写死 4，而向导把可选的通知也数进分子。现在分子分母都只数必选。
        //             ③【界面】设置页把「已开启 N / 3 项」文字 + 独立的「开通向导」按钮
        //               合并成**一行可点的状态行**（点它进向导）；删掉独立的
        //               「自动验证：已开启/未开启」一行（无障碍已降级，状态在向导里看）。
        //             ④【界面·换手机关键】把「各品牌后台设置教程」入口补进向导底部 ——
        //               第 20 期把向导搬出旧对话框时漏掉了它，导致这份教程只在首次打开
        //               自动签到开关时弹一次、之后再也找不到（各家 ROM 的「自启动 / 后台
        //               运行」程序检测不到，只能靠它）。
        //             ⑤【清理】删除第 20 期起就没人调用的旧对话框 showPermissionWizard()
        //               及其 5 个孤儿辅助函数（openAccessibilitySettings /
        //               openNotificationSettings / openOverlaySettings /
        //               openFullScreenIntentSettings / canUseFullScreenIntent）、
        //               refreshAccessibilityStatus()，以及随之变成孤儿的 11 个字符串。
        //             ⑥【文案】向导条目去掉 ①②③④⑤ 编号（与「未开启排前」的排序打架，
        //               会出现 ① ② ④ ⑤ 这种看着像坏了的序号）；进度文案改成
        //               「还差 N 项必选就能全自动跑通」；checkAutoVerifySetup 的卡点
        //               从「无障碍」改成「必选项没开齐」，文案随之重写。
        //             ★ 四条核心链路的判定、数据读写时机**一行未动**（只换入口 / 文案 / 哪几项算必选）。
        // ★ 第 43 期（2026-10-01，用户诉求：「把三个 APP 关于评论的功能的优点
        //            全部融合到我这个 APP 上」，并在确认隔离设计后开工）——
        //            第一批只做**离线可验证的地基**，不发任何网络请求：
        //             ①【新增·独立】互动页 InteractActivity（左侧抽屉新增「互动」一项）。
        //               评论 / 互评（回复楼层）/ 楼赞 三种动作，任务模型扁平：
        //               一个任务 = 一个目标 + 一个动作 + 一个账号 + 一组语料。
        //             ②【新增·独立】五个自包含文件，全部使用**自己的私有存储**：
        //               InteractTrace（interact_trace）互动黑匣子
        //               CommentLib（interact_lib）评语库：分组 / 批量导入 / 随机后缀
        //               InteractTask + InteractTaskStore（interact_tasks）任务
        //               RateGuard（interact_guard）账号级频率保护
        //               InteractRunner 干跑执行器
        //             ③【抄豆星人】频率保护：同一账号每小时达到上限（默认 5 条）
        //               就自动休息（默认 60 分钟）。★ 这是三个竞品里唯一必须抄的设计 ——
        //               星签的账号是拿来签到的，互动刷狠了赔掉的是**当天的签到**。
        //             ④【干跑】「试跑一次」只做检查（账号能不能动 / 语料有没有 /
        //               目标填没填），**不产生任何网络请求、不消耗额度**。
        //               真实的发送动作要等真机抓包定死接口（Cookie 在 App 私有加密
        //               存储里，PC 读不出来，猜参数只会拿用户账号试错）。
        //             ★★★ 隔离保证（用户两次追问「不会影响我其他功能吧」）：
        //               ① 四个核心文件 Prefs / WeiboAccount / WeiboClient /
        //                  YidunSliderSolver **逐字节未动**；
        //               ② 八个链路执行器（AgentService / LocalScheduler /
        //                  CheckinAlarmReceiver / BootReceiver / OverlayVerifyHost /
        //                  YidunAutoSlider / WeiboLoginActivity /
        //                  SliderGestureAccessibilityService）**逐字节未动**；
        //               ③ 互动代码里**没有**对 needsVerify / restUntil / lastRunAt /
        //                  lastRunDate / Prefs.* / AccountStore.save() / WeiboClient.*
        //                  的任何一处写入 —— 由新增的 _audit_interact_isolation.py
        //                  静态断言看守，不通过就不出包；
        //               ④ 对账号只读（AccountStore.all()），不替签到判断
        //                  「这个账号今天能不能用」。
        //             ★ 改动清单：MainActivity（仅抽屉路由，不碰四条链路）/
        //               drawer_menu.xml / AndroidManifest.xml / strings.xml / 本文件。
        // ★ 第 44 期（2026-10-01，用户装上 0.20.52 跑了第一次干跑并把日志回传，
        //            手机同时接上了电脑）—— 修三处**真实数据暴露出来的问题** + 加只读自检：
        //             ①【修·真 bug】语料清洗：用户从微博 App「复制」的评论末尾带着
        //               `[/cp]`（微博自己加的复制标记），原样发出去就是机器痕迹。
        //               现在导入时自动清掉，**取用的时候再过一遍** ——
        //               已经存进库里的那一条不用重新导入也能生效。
        //               顺带清零宽字符（U+200B~200D/FEFF/2060，从网页复制常带、肉眼看不见，
        //               会让「看起来一样」的两条判成不同，也是异常特征）。
        //               ★ 只清「不是用户写的」那一部分，正文一个字不动。
        //             ②【修·我的 bug】默认分组名：第 43 期的 quickAddLine 把
        //               **按钮文案**「新建分组」当成了分组名，实测语料库里就出现了一个
        //               叫「新建分组」的分组。改用新字符串 `interact_lib_default_group`。
        //             ③【修·判断太松】目标分类：用户填的是 `weibo.com/u/6986999782`
        //               —— 那是**用户主页**，而「评论」要的是**某一条微博**；
        //               第 43 期的干跑只检查「填没填」，于是打印「检查全部通过」，等于骗人。
        //               新增 InteractTarget：把目标分成 单条微博 / 用户主页 / 看不懂 / 没填，
        //               干跑逐类说清楚要做什么。★ 刻意**不拦主页** ——
        //               「抢首评」要的恰恰就是「给我一个人，我去评论他最新那条」。
        //             ④【新增·只读】InteractProbe 接口自检：用**账号自己存在手机里的
        //               Cookie** 去发几个 GET，把真实回包记进互动黑匣子。
        //               要探的三件事：登录态在 m.weibo.cn 上还有效吗、
        //               评论列表接口的真实结构、发评论要的一次性票据从哪来。
        //               ★★ 全部 GET、只读、不消耗额度（不调 RateGuard.markRun）、
        //                  不碰 Prefs / AccountStore / WeiboClient。
        //                  跑一百遍也不会在微博那边留下任何痕迹。
        //               ★ 刻意关掉自动跳转：没登录时 302 跳 visitor.passport.weibo.cn，
        //                 **看见这个 302 本身就是结论**。
        //             ★ 与「试跑」分成两颗按钮：试跑保证零网络请求，自检会联网。
        //               混在一起用户就分不清「刚才那下到底发没发东西」。
        //             ★ 隔离保证不变：四个核心文件 + 八个链路执行器仍**逐字节未动**，
        //               由 `_audit_interact_isolation.py` 看守。
        // 第 45 期（96 / 0.20.55）—— 把「用户主页 → 最新一条微博」真机验证掉（**仍全是只读**）。
        //   ★ 起因：第 44 期的自检只拿到「主页容器」，里面 `tabsInfo` 给出了各 tab 的
        //     `containerid`，我据此**推断**「微博」tab 是 `107603<uid>` —— 但**没验证过**。
        //   ★ 只改了 InteractProbe.kt（+ strings.xml + 版本号）：
        //     ① `parseWeiboContainer()` 从 `tabsInfo` 解析「微博」tab 的 containerid
        //        （解析失败回退到固定前缀 `107603<uid>`）；
        //     ② `parseLatestPost()` 在 `cards[]` 里**逐张找带 `mblog` 的那一张** ——
        //        ★ 实测这一步是必需的：`cards[0]` 是 `card_type=156` 的话题推荐卡，
        //        **没有 `mblog`**，直接取 `cards[0]` 会拿到空；
        //     ③ 拿解析出的 mid 再拉一次 `/comments/hotflow`；
        //     ④ `cookieNames()` 只记 Cookie 的**字段名**（不记值）。
        //   ★★ 真机实测结论（23:43）：`containerid=1076036986999782`（从 tabsInfo 解析）、
        //     微博列表 HTTP 200 · 105169 字符、**最新微博 mid=5347885881235669 /
        //     bid=Rk5Ji5bs9**、`comments_count=25`。⇒ **主页→mid 这一步通了**，
        //     `InteractRunner.send()` 就是一道填空题。
        //   ★★ 但发现一个异常：`comments_count=25`，而 `/comments/hotflow` 回
        //     `{"ok":0,"msg":"快来发表你的评论吧"}`（说「没有评论」）。
        //     ⇒ 本版做**一次只改一个变量**的实验：把 Cookie 里的 `XSRF-TOKEN`
        //     同时放进请求头 `X-XSRF-TOKEN`（微博 Web 端的标准做法，发 POST 也需要它），
        //     再跑一次同一套探测，看 hotflow 会不会变。
        //   ★ 隔离保证：四个核心文件 + 八个链路执行器仍**逐字节未动**，
        //     由 `_audit_interact_isolation.py` 看守（断言 20 条）。
        //   ★ 第 48 期例外：`WeiboClient.kt` 被批准改了一处明细文案
        //     （补签轮「重试仍失败」补上原因），已在隔离断言里登记为**已批准例外**
        //     并写死 md5 ⇒ 它再被改动一个字节就照样报错。
        // 第 49 期（103 / 0.20.62）—— 修链路③「自动验证打开的是第一超话」这个真缺陷。
        //   ★ 起因：2026-10-02 16:30 真机报告（账号 5 / 然妈爱吃汉堡包）里，
        //     自动验证连试 3 轮全空转、最后放弃。逐行读日志后定性：
        //       `[打开] https://weibo.com/p/100808212349219ac32e9f5c1165965a769d0f`（第一超话 花小龙）
        //       `[手势] … 文本=已签到`  ← 这个超话**今天已经签过了**
        //       `[滑块] 30 秒内没等到验证码（点签到=true，曾出现过=false，已拖动 0 次）` ×3
        //       `[重挂] 已重挂 2/2 轮仍未过，停手，交给用户手动处理`
        //     ⇒ 已签过的超话，点「签到」不会发任何请求，验证码永远不出现
        //       ⇒ 自动验证**结构性地**必然空转。这不是滑块的问题，是「打开了哪个页面」的问题。
        //   ★ 改了什么（只改「挑哪一个超话」）：
        //     `WeiboClient.fetchFirstTopicContainerId` 先找 `!done`（今天还没签）的超话，
        //     一个都没有时才退回原来的「第一个」。滑块的识别 / 轨迹 / 成功判定**一个字未动**。
        //   ★ 一键回滚：`WeiboClient.verifyPreferUncheckedTopic = false` ⇒ 逐字节回到第 48 期。
        //   ★ 顺带订正报告口径（纯显示层）：`ma_jitter_note_40` 原写死「最近 80 条」，
        //     而 SliderTrace 的环形缓冲第 40 期起就是 400、报告摊开的一直是全量
        //     （2026-10-02 那份是 189 行）。改成按实际条数打印。
        //   ★ 隔离保证：四个核心文件 + 八个链路执行器**除下表列出的已批准改动外**逐字节未动，
        //     由 `_audit_interact_isolation.py` 看守。`WeiboClient.kt` 的例外条目
        //     已更新为「第 48 / 49 期两处改动」并重新写死 md5。
        // 第 49 期后续（104 / 0.20.63）—— 只订正一句**锁屏文案**（纯显示层，用户 2026-10-02 17:36 批准）。
        //   ★ 起因：用户问「给手机设个锁屏密码，自动验证会不会通过」。
        //     答案跟直觉相反 —— 设了**更可能失败**。
        //   ★ 旧文案 `ma_done_today_4` 写「如果手机当时是**锁着屏**的，多半过不了」，
        //     把「锁屏（状态）」和「锁屏（密码）」这两件**相反**的事混成了一件：
        //       · 没密码 + 锁屏 ⇒ **能过**（第 19 期就是为此设计的；
        //         真机实证 2026-10-02 16:29：全程 `锁屏=true 安全锁=false` → `[判定] 验证通过`）。
        //       · 有密码（`安全锁=true`）⇒ 系统不给非 Activity 悬浮窗发触摸
        //         （`OverlayVerifyHost.kt:761`）⇒ 点不动 ⇒ 必败。
        //     ⇒ 旧文案会误导用户「要解锁手机」甚至「去设密码」，方向完全反了。
        //   ★ 改了什么：只改 `values/strings.xml` 的 `ma_done_today_4` 这一条文案（+ 上面那段注释）。
        //     **没有任何 `.kt` 文件被改动** ⇒ 四个核心文件 / 八个链路执行器零改动，
        //     隔离断言的基线（第 42 期快照）**不需要推进**。
        // 第 46 期阶段 1（105 / 0.20.64）—— 在互动页里加一个**只读**的「抓真实请求」网页。
        //   ★ 背景：第 46 期卡在「为什么带登录态调 /api/comments/create 就被 100006 拦」。
        //     已排除：mid 真假（真 mid 也 403）、st 放 query 还是 body、路径对不对
        //     （PC 匿名打同一路径回「请先登录」⇒ 路径是对的）。
        //     ⇒ 剩下的只在「请求到底长什么样」上，靠猜没用，只能看一条**页面自己发的**真请求。
        //   ★ 做法：互动页底部加一个 WebView（默认隐藏，点按钮才出现），加载 m.weibo.cn，
        //     注入 JS hook XMLHttpRequest / fetch，把**方法 / 地址 / 请求头 / 请求体**记进
        //     InteractTrace。
        //   ★ 三条硬约束：
        //     ① 只记不改 —— open/send/setRequestHeader/fetch 全部透传，fetch 用 clone().text()
        //        读副本不消费原响应；整段删掉不影响任何功能，也不参与任何判定。
        //     ② 脱敏 —— Cookie / st / token / xsrf **只留字段名不留值**。
        //     ③ 不发评论、不 POST、不碰账号与 Prefs ⇒ **一次 POST 额度都没花**。
        //   ★ 为什么不去改 `OverlayVerifyHost.NET_HOOK_JS`（它已经有 XHR 钩子）：
        //     那份只记 URL/状态/回包、且只认滑块那几个关键词；而且它在**链路执行器清单**里，
        //     隔离闸门锁着 ⇒ 按第 19 期的规矩，在互动功能自己的范围内**另写一份**。
        //   ★ 改动文件：`activity_interact.xml`（WebView 容器 + 一张卡片）、
        //     `strings.xml`（8 个新键）、`InteractActivity.kt`（钩子 JS + 三个函数）。
        //     四个核心文件 / 八个链路执行器**零改动**，隔离断言基线不需要推进。
        //
        // 第 46 期阶段 2（106 / 0.20.65）—— 把「干跑」升级成**真预演**，并把发送层骨架写好。
        //   ★ 起因：干跑只检查「目标填没填」，第 44 期真机实测时用户填了一个用户主页链接，
        //     它也打印「以上检查全部通过」—— **那是骗人**，它根本没问过微博那条帖子在不在。
        //   ★ 两块改动：
        //     ① 真预演（`InteractRunner.rehearse`）—— 本地检查之外，再联网把目标
        //        **核对成一条具体的微博**：单条微博用 `/comments/hotflow` 判存在；
        //        用户主页走「主页容器 → tabsInfo 容器 → 最新一条微博」三步。
        //        ⇒ **全部 GET**，不消耗 POST 额度，也不调 RateGuard.markRun，可以反复点。
        //        解析逻辑复用 `InteractProbe` 里**已经验过的**那一份
        //        （新增 `resolveTarget`），不另写一份 —— 两份解析迟早会漂移。
        //     ② 发送骨架（`InteractRunner.send`）—— 校验 / 目标核对 / 错误判读 / 记账 /
        //        日志全部写好；真正的 HTTP 那一发留在 `doPost`，并用
        //        `@Volatile sendEnabled = false` 守着，**默认一次都不真发**。
        //        ★ `doPost` 里**故意不编造入参名**：参数名必须靠阶段 1 的抓包定死，
        //          照公开文档猜只会得到「看着像、跑起来全是 100006」的代码。
        //   ★ 两个必须记住的规矩（都写在代码注释里）：
        //     · 目标存在性是**三态**（EXISTS / NOT_EXISTS / UNKNOWN），
        //       UNKNOWN 与 NOT_EXISTS 一样**不许发** —— 第 46 期被 `ok:0` 骗开过闸门。
        //     · 只有真的发出去了才记账，失败不消耗额度。
        //   ★ 因为试跑现在会联网，`doDryRun` 改成后台线程 + `runOnUiThread`（同 `runProbe`），
        //     否则 UI 线程发请求就是 ANR。
        //   ★ 改动文件：`InteractProbe.kt`（新增 resolveTarget + 9 个函数/类，
        //       并把 SEND_URL / TargetState 改成公开以便复用）、`InteractRunner.kt`（重写）、
        //       `InteractActivity.kt`（试跑改后台线程）、`strings.xml`（16 个新键 + 3 处改文案）。
        //     四个核心文件 / 八个链路执行器**零改动**，隔离断言基线不需要推进。
        //
        // 第 46 期阶段 2 文案订正（107 / 0.20.66）—— 删掉界面里一句**已被真机反证**的话。
        //   ★ 起因：2026-10-02 我按一条**过时结论**改了首页「需要验证」提示，
        //     在里面写了「如果手机设了锁屏密码，这一下多半过不了：系统会不给悬浮窗发触摸」。
        //     那句话的来源是 `OverlayVerifyHost.kt:761` —— 它是第 24 期留下的**条件推测**
        //     （原文是「· 它不响 ⇒ 触摸被系统投给了别的窗口（安全锁屏下输入不给非 Activity 悬浮窗）」，
        //      属于「没响」这个分支的推论），我当成已成立的事实抄了下来。
        //   ★ 2026-10-03 13:50 真机反证（`安全锁=true`，手机确实设了锁屏密码）：
        //       [环境] 亮屏=false 锁屏=true 安全锁=true 悬浮窗=true 全屏通知=true
        //       [触摸] 窗口收到 action=0 @(917.0,782.5)   ← 触摸**到了**
        //       [验证页] 命中 security.weibo.com → captchaSeen=true
        //       [判定] 验证通过，账号进入静置期            ← **过了**
        //     第二路证据：同日诊断报告「上次结果：VERIFY_OK / 需要人工验证：否」。
        //   ★ 结论：设不设锁屏密码，**自动验证这条路都照跑**；怕锁屏的只有**手动**那条
        //     （`WeiboLoginActivity` 扫码登录）。旧文案会劝用户去关密码，方向是反的。
        //   ★ 改动范围：**只有 `strings.xml` 的注释与 `ma_done_today_4` 一个值**，
        //     外加把第 27 期那段同样过时的注释标注清楚。
        //     没有 `.kt` 改动 ⇒ 27 个 .kt 的 md5 应**逐个不变**（用这个证明改动范围）。
        //     四个核心文件 / 八个链路执行器零改动，隔离断言基线不需要推进。
        //     ★ 注意 `_literal_diff.py` 会**整个跳过 res/ 层**（快照目录里没有 res/），
        //       所以这一轮它在字面量上是 0/0 —— 那不是「没改」，是工具看不到，别误读。
        // 第 46 期阶段 2 文案订正（108 / 0.20.67）—— 收掉阶段 2 带进来的一条编译警告。
        //   ★ 阶段 2 的 `InteractRunner.doPost` 里 `account` 参数暂时用不到（真发送还没接），
        //     编译器报 `UNUSED_PARAMETER`，于是警告总数从 11 变成 12。
        //   ★ 为什么非修不可：项目把「`w:` 恰好 11 条」当**探针**用 —— 新警告必须立刻显形。
        //     留一条已知的、被解释过的警告在那儿，等于把探针调钝，下一轮就会漏掉真警告。
        //   ★ 修法：`@Suppress("UNUSED_PARAMETER")` + 注释说明「预留，非写漏」。
        //     不加日志、不加字面量、不改任何行为；参数保留，抓包到手时只填实现不动签名。
        //   ★ ★ 顺带记一条**我自己的失误**：阶段 2 我声称「已核对 11 条警告」，
        //     其实那次是 UP-TO-DATE 的编译，`w:` 一行都没重发，我数出来是 0，
        //     于是改成「逐条比对文件名」—— 那就**漏掉了新增的那一条**。
        //     ⇒ 教训：**数警告必须 clean build**；增量编译不重发警告，数出来是假数。
        //     本次 clean 之后实测 12 条 → 修掉 1 条 → 应为 11 条。
        //   ★ 改动范围：只有 `InteractRunner.kt` 一个 `.kt`（加 1 个注解 + 注释）。
        //     验证方式：与 107 的 `classes3.dex` 反汇编逐行比对，差异应**只有 doPost**。
        //     四个核心文件 / 八个链路执行器零改动，隔离断言基线不需要推进。
        // ============================================================================
        // 第 50 期（109 / 0.20.68）：把「开始日期」显示出来 —— 收掉一个**隐形地雷**。
        //   ★ 起因：2026-10-03 16:16 那次补签成功后排程跳到 **10-17 08:11**，
        //     用户问「10-17 是你自己设的吗，不太确定」。
        //   ★ 排查结论（详见 `星签-20261003-排程跳到10-17的排查.md`）：
        //     ① **不是排程 bug**。`LocalScheduler.baseRunAt():129` 写的是
        //        `if (startDate.after(now)) startDate.time else now.time`
        //        —— 未来日期被当成基准日，**设计如此**（`:121` 注释：基准日取 max(今天,开始日期)）。
        //     ② 写 `Prefs.startDate` 只有两处：弹窗确定按钮 / `turnOnSchedule` 里**仅当空白**写今天；
        //        `Prefs.kt:200` 默认 `""`；全 `LocalScheduler` 只有 `add(DAY_OF_YEAR,1)`；
        //        `pausedUntil` 一律 `now + 30 分钟`（`AgentService:1365`）
        //        ⇒ **未来日期只能由日期滚轮写入**。
        //     ③ 项目里唯一注入点击的脚本 `_adb/capture_overlay_tap*.sh`，`run.log` 停在
        //        2026-09-29 21:02/21:05，且只在悬浮窗（type=2038）活着时才点，
        //        `input tap` 对 `NumberPicker` 最多动 1 格 ⇒ 与本轮无关。
        //   ★ 真缺陷是**可见性**：首页行（`checkin_time_line` 只有 `%1$s`）、
        //     报告（`ma_report_14` 只有 `%02d:%02d`）、查看详情（`jitterNote()` 在差值为负时
        //     整行不输出）—— **三处都不显示日期** ⇒ 用户无从核对，「不太确定」是必然的。
        //   ★ 还有一层静默覆盖：日期与时间在**同一个弹窗、同一个确定按钮**里，无条件同时写
        //     ⇒ 只想改时间也会把日期覆盖一次；滚轮初值来自 `Prefs.startDate`，
        //     一旦被拨歪，之后每次改时间都会再确认一遍。
        //     ★ 这一条**不许改**（「数据写时机」属核心约束）⇒ 只能把日期**显示出来**。
        //   ★ 改动范围（**全部显示层，零判定变化**）：
        //     · `strings.xml`：新增 4 条（`checkin_time_line_from` / `checkin_time_dialog_hint_future`
        //       / `ma_report_start_date` / `ma_report_start_date_none`）+ 注释。
        //     · `dialog_schedule_time.xml`：给提示 TextView 加 `id=dialogDateHint`（只加 id）。
        //     · `MainActivity.kt`：新增 `startDateIsFuture()`（纯展示判断）；
        //       首页行加一个 if 分支（日期非未来时走原分支，**一个字不变**）；
        //       报告加一行；弹窗给日期滚轮挂 `setOnDateChangedListener` 只改提示文字。
        //     ★ `showScheduleTimeDialog` 里确定按钮的写入逻辑（`:540-548`）**一行未动**。
        //   ★ `startDateIsFuture()` 用**字符串比较**而不是解析日期：两个值都是固定宽度
        //     `yyyy-MM-dd`（`"%04d-%02d-%02d"` / `LocalScheduler.todayString()`），
        //     等价且**不引入新的日期格式字面量**。
        //   ★ 注意：`MainActivity.kt` 自 10-02 快照以来**首次改动** ⇒
        //     `_audit_core_untouched` 第 5 层与 `_p6_verify2` 会**首次**报出差异，
        //     必须逐条确认差异只落在本轮改的 3 个函数 + 1 个新函数上。
        //     `MainActivity.kt` 不在 `CORE_KT`、也不在 `_audit_interact_isolation` 的清单里
        //     ⇒ 隔离断言基线**不需要**推进。
        // ============================================================================
        // 第 46 期阶段 1 补强（110 / 0.20.69）：把「抓一条真实请求」的钩子修到真能用。
        //   ★ 阶段 1 的骨架（WebView + XHR/fetch 钩子 + 脱敏 + 黑匣子）**上一轮已实现**，
        //     本轮是逐行审它、补掉**三个会让阶段 3 白跑一趟**的缺口：
        //   ① **缓冲会被丢掉**（最致命）：钩子只把记录放 `window.__tjhNet`（内存）。
        //      而微博网页「发完评论」很可能刷新或跳转 ⇒ window 被整个换掉
        //      ⇒ **恰好把我们唯一要的那条评论请求丢了**。
        //      修：缓冲同步进 `sessionStorage`（`domStorageEnabled` 已开），
        //      安装钩子时合并回来 ⇒ 跨导航存活。
        //   ② **看不见浏览器自动加的头**：`Referer` / `Origin` 不是 `setRequestHeader`
        //      设的，钩子拿不到 —— 而它们很可能正是 100006 的成因。
        //      修：每条记录附上**当时的页面地址**与 `document.referrer`。
        //      顺带记 `withCredentials` / `credentials`：**到底带没带 Cookie** 是关键判据。
        //   ③ **文案把唯一要的东西挡掉了**：原文案写「不发评论、不改任何东西」，
        //      而阶段 3 要的恰恰就是那条评论请求。修：改成两步说明 ——
        //      先翻两下确认在抓，**再由用户自己**在网页里发一条评论。
        //   ★ 顺带补 `WEB_RESET_JS`：缓冲改持久化之后，**每次「打开」必须先清一次**，
        //     否则上一轮的残留会混进这一轮（= 「覆盖安装不清空黑匣子」那个坑的翻版）。
        //     只在**本次打开的第一页**清，之后导航绝不清（清了就等于把要的那条扔掉）。
        //   ★ 边界：全部在**互动功能自己范围内**，只读、只记、透传；
        //     不碰 `Prefs` / `AccountStore` / `WeiboClient`，不碰四个核心文件与链路执行器
        //     ⇒ `_audit_interact_isolation` 基线不需要推进。
        //   ★ 改动范围：`InteractActivity.kt`（1 个 .kt）+ `strings.xml` 1 条文案。
        //   ★ ★ 记一条**我自己的流程失误**：这一轮**先改了文件、后做备份**，
        //     违反硬规则二「备份在前」。源码不是 git 仓库 ⇒ 改前内容靠
        //     **逐字反向还原**重建（`_reconstruct_pre110.py`），并做了三重验证：
        //       ① 正向回放逐字节相同；
        //       ② 重建出的 `strings.xml` md5 = `dda05d85ef18b9ef0a99418399be1dd9`
        //          —— 与 109 轮记录的改后 md5 **完全一致**（这是独立证据）；
        //       ③ 与 18:39 的旧备份 diff，差异只有「第 46 期阶段 2」那一次，
        //          **本轮 6 处改动零残留**；另用 109 APK 的 dex 交叉验证过。
        // ==================== 111 / 0.20.70（2026-10-03 晚） ====================
        //   主题：修掉「能看不能发评论」—— 一个由**我们自己**造成的 WebView Cookie 遮蔽。
        //
        //   ★ 起因：用户报「好像发送不了评论」。抓包（110 的钩子，18:23 / 18:28 两批）
        //     抓到了**失败的那条请求本身**：
        //       POST m.weibo.cn/api/comments/create -> 403
        //       体: content=<urlenc>&mid=<mid>&st=<st>&_spr=screen:WxH
        //       回: ok:0 errno:100006 msg:请求非法（原文照录会带双引号，
        //           ★ 这里刻意不写双引号 —— `_literal_diff.py` 不剥注释，
        //           在注释里写带双引号的字面量会凭空多出一批「新增字面量」，第 50 期栽过。）
        //     重试 11 次全部相同；WebView 控制台同时打了 15 条
        //     `Request failed with status code 403`（来自 weibo-lite 的 axios）。
        //     ⇒ 是服务端在拒，不是用户没点对。
        //
        //   ★ 先排除掉的（都有证据，不是猜）：
        //     ① **不是抓包钩子改坏的**：逐行读 `WEB_HOOK_JS`，`open`/`send`/`setRequestHeader`
        //        三个包装全是 `apply(this, arguments)` 纯透传；脱敏 `hide()` 只作用在
        //        **记录副本**上，绝不改真参数。
        //     ② **不是 WebView 缺 Cookie**：把 WebView 的 Cookie 库（`app_webview/Default/Cookies`）
        //        导出来解析，`m.weibo.cn` 下 `SUB`/`SUBP`/`XSRF-TOKEN`/`_T_WM`/
        //        `SSOLoginState`/`MLOGIN=1`/`M_WEIBOCN_PARAMS` 全套都在。
        //     ③ **不太像「账号不能写」**：滑块日志显示这个号（用户8242606810）今天
        //        15:26 / 16:29 两次「验证通过」并「已自动点击签到按钮」，签到也是写操作。
        //
        //   ★★★ 真正的根因（Cookie 库里的时间戳对比出来的）：
        //     | 字段                     | 来源                 | 值 / 登录时刻          |
        //     |--------------------------|----------------------|------------------------|
        //     | `.weibo.cn` SSOLoginState| 签到 WebView / 服务器 | 登录于 10-01 16:25     |
        //     | `m.weibo.cn` SSOLoginState| **我们注入的账号 Cookie** | 登录于 09-30 22:43 |
        //     | `.m.weibo.cn` XSRF-TOKEN | **服务器 18:22:29 新下发** | 当前会话的正确令牌 |
        //     | `m.weibo.cn` XSRF-TOKEN  | **我们 18:22:28 注入**  | **上一次登录的旧令牌** |
        //     按 RFC 6265，同名同 path 的 Cookie「创建更早的排前面」，浏览器取第一个
        //     ⇒ 请求头里带的是我们注入的**旧**令牌，把服务器刚下发的**新**令牌遮住了
        //     ⇒ 写操作的 CSRF 校验必然失败 ⇒ 403 / errno 100006。
        //     这一条同时解释了全部现象：读操作不做该校验所以正常；写操作一律失败；
        //     **网页自己的 JS 也失败**（它继承的是同一个被污染的 cookie jar）；
        //     签到能成功（走 `weibo.com`，那套里没有我们注入的旧 XSRF-TOKEN）。
        //
        //   ★ 改法（单变量，只动一个名字）：`openWeb()` 里
        //     ① **先删** jar 里可能残留的旧 XSRF-TOKEN（它是**会话 Cookie**，会一直留着，
        //        光「不灌」不够）；
        //     ② 灌的时候**跳过**这个名字，让服务器在页面加载时自己下发。
        //     ★ 为什么只动这一个：库里其余字段要么服务器不另发一份，要么创建时间比我们早
        //       （按排序规则本来就用服务器那份）⇒ 唯一真正「遮蔽」的就是 XSRF-TOKEN。
        //     ★ 顺带补一个诊断：`setCookie` 的返回值以前被丢掉 ⇒ **灌失败是静默的**。
        //       现在把失败字段名记进黑匣子（**只记名，绝不记值**）。
        //
        //   ★ 边界：仍然只在**互动功能自己范围内**（`openWeb` 是抓包用的，不是发送链路）。
        //     不碰 `Prefs` / `AccountStore` / `WeiboClient`，不碰四个核心文件与链路执行器
        //     ⇒ `_audit_interact_isolation` 基线不推进；`InteractActivity.kt` 不在
        //     `CORE_KT` 也不在 `_p6_verify2` 清单 ⇒ 不需要 `APPROVED_CHANGES`。
        //   ★ 改动范围：`InteractActivity.kt`（1 个 .kt）。文案与布局**一行未动**。
        //   ★ 备份**在第一次写文件之前**完成：`_backup_before_webview_xsrf_20261003/`
        //     （`InteractActivity.kt` f10efafc18e1a104846056875a0b945c、
        //       `build.gradle.kts` 2906823e3484aa36196eab264a01bc4a、
        //       `strings.xml` 26ac172d1d87bd73b808f1da8c3a3bbd —— 三个都与 110 出包时一致）。
        // ==================== 112 / 0.20.71（2026-10-03 深夜） ====================
        //   主题：把「发评论」这条链**按第 51 期抓到的成功请求**接上 ——
        //         但**仍然不真发**（安全闸 `sendEnabled` 保持 false）。
        //
        //   ★ 用户选择：「先修 + 实现，不真发」。理由：出包后先由用户抓包确认
        //     请求对，再单独决定开不开闸；绝不让 App 拿账号去试错。
        //
        //   ★ 修的是什么（第 51 期定位的根因，同一类 bug 的**第二处**）：
        //     `InteractProbe.kt` 的原生请求路径里，请求头 X-XSRF-TOKEN 取的是
        //     **账号 Cookie 里那份**（`cookieValue(cookie, XSRF-TOKEN)`）——
        //     和第 51 期 WebView 那个 bug **同源**：那份属于**上一次登录**，
        //     按 RFC 6265 会遮住服务器新下发的值 ⇒ 10-02 那次原生 POST 也报 100006。
        //     ① `httpPost`：改用**请求体里现取的** st（头与体同一个值，微博 Web 端就是这样）；
        //        取不到 st 就**不发这个头**（宁可不带，也不带一个陈旧的）。
        //     ② `httpGet`：**撤掉**这个头（第 45 期加的）。GET 本来就不做 CSRF 校验
        //        ⇒ 它一直是空转，留着只会误导后来人以为「Cookie 里那份令牌可信」。
        //     ③ 自检日志里那句「已同时放进请求头」已经不成立，改如实：
        //        只报告账号里有没有这个字段，并点明真正用的是现取的 st。
        //
        //   ★ 实现的是什么（第 46 期留下的那道填空题）：
        //     `InteractRunner.doPost` 由「明确地空着」改为**按规格实现**：
        //       POST https://m.weibo.cn/api/comments/create
        //       体：content / mid / st / _spr
        //       成功判据：**回包 ok:1 且带新评论 id**（不看界面提示 —— 第 51 期的教训：
        //       网页弹的「发送成功」可以是假的，唯一可信的是回包）。
        //     ★★ 关键设计：请求体的**构造点只有一处**（`InteractProbe.commentForm`），
        //        真发送与零风险自检（`probeSend`）共用它
        //        ⇒ 「自检跑通了」就真的等价于「真发送的请求体没问题」，
        //          而不是两处各写一份、看着像但其实不一样。
        //        ★ 顺带把自检里多带的 id 参数去掉：抓到的成功请求里没有它。
        //
        //   ★★ 关于 `_spr`：抓包里是 screen:361x801，而真机 1080x2400 @3.0 换算成 dp
        //      正好 360x800 ⇒ 按「dp 宽 x dp 高」算。
        //      这是整个请求里**唯一一个还没被正面验证过**的值，若抓包发现不一样，
        //      改 `commentForm` 里那一行即可。
        //
        //   ★ 边界：只改互动功能自己的文件
        //     （`InteractProbe.kt` / `InteractRunner.kt`），两个都在 `Interact` 前缀内
        //     ⇒ 只受 `_audit_interact_isolation` 的 ③④ 两条约束（不得写共享状态），
        //     **不在** `CORE_KT` 也不在链路执行器清单
        //     ⇒ **不需要** `APPROVED_CHANGES`，隔离基线 `SNAPSHOT` 不动。
        //     四个核心文件与链路执行器**一行未动**。
        //   ★ 改动范围：`InteractProbe.kt`、`InteractRunner.kt`、`strings.xml`（+3 条文案）。
        //   ★ 安全：`sendEnabled` 仍为 false ⇒ 真发送的代码**一行都不会被执行**；
        //     且 `send()` 目前在界面上**没有入口**（界面只接了只读的 rehearse）。
        //   ★ 备份**在第一次写文件之前**完成：`_backup_before_send_impl_20261003/`
        //     （`InteractProbe.kt` a4348a0024ac4408201054237a288fa2、
        //       `InteractRunner.kt` 3b704941dd7913b4f6c9f8c8b876aa64、
        //       `build.gradle.kts` 9f6fef18ace73f41cf370a6b6ed3b611、
        //       `strings.xml` 26ac172d1d87bd73b808f1da8c3a3bbd）。
        // ==================== 113 / 0.20.72（2026-10-03 深夜） ====================
        //   主题：**互动页「一眼看懂」重排**（用户要求「简约、一眼看懂，但功能不能少」）。
        //
        //   ★ 改前的问题：一屏铺了 13 颗按钮 + 5 段说明，**日常操作**和**排查工具**混在一起，
        //     用户分不清哪颗是平时要点的。这不是功能太多，是**没分组**。
        //
        //   ★ 改法（只动界面，**一个控件都没删**）：把页面分成两层 ——
        //       第一层「日常」：账号保护 → 语料库 → 互动任务 → 发送 → 频率设置
        //       第二层「排查工具」：接口自检 / 路径探测 / 探发送 / 抓包 / 互动日志
        //         ★ **默认收起**（interactToolsWrap 默认 gone），点标题才展开。
        //     ⇒ 默认那一屏从 13 颗按钮降到 6 颗，但每个功能都还在，点开就能用。
        //
        //   ★ 新增「发送」卡：真发开关 + 试跑一次 + 立即发送，三件事放在一起。
        //     ★★ 真发开关（`InteractRunner.sendEnabled`）从「代码里的常量」变成
        //        **界面上的开关，默认关** —— 开闸这个决定交回用户手上（他自己的手指点）。
        //        ★ 它**不落盘**：每次打开 App 都回到关。这是有意的 ——
        //          真发是危险动作，不该「上次开了这次还开着」。
        //        ★ 真发前会再弹一次确认（把**目标**摆出来）；开关关着时不弹，
        //          因为那一次根本不会发出去，多问一遍反而让人以为发了。
        //        ★ 确认框**不预告具体是哪条评语** —— 语料是随机取一条的，
        //          显示一条「样例」会让人以为发出去的就是它，那是假话。
        //
        //   ★ 边界：全部在互动功能自己范围内（`InteractActivity.kt` /
        //     `activity_interact.xml` / `strings.xml`，全是界面层）；
        //     四个核心文件与链路执行器**一行未动**。
        //     `InteractActivity.kt` 在 `Interact` 前缀内 ⇒ 只受隔离③④约束
        //     ⇒ **不需要** `APPROVED_CHANGES`，`SNAPSHOT` 不推进。
        //   ★ 新增文案 12 条 + 改 3 条措辞；★ 新文案**刻意不带「」引号** ——
        //     那两个审计工具会把引号短语当成「界面控件名」去核对。
        //   ★ 备份**在第一次写文件之前**完成：`_backup_before_interact_ui_20261003/`
        //     （`InteractActivity.kt` 1720059937c2b2cc8998b4e3b6b7950a、
        //       `activity_interact.xml` 0a4e1ac03bb2667aa5858408cb05f878、
        //       `strings.xml` fbc00980a915c0c22696669721a235a7、
        //       `build.gradle.kts` e93a5e1a0eea24a36e7acc3c831e6c71）。
        // ==================================================== 第 54 期（114 / 0.20.73）
        // ★ 一句话：修掉「真实存在的微博被判成『没能确认』」—— 试跑卡死的那一条。
        //
        // ★ 现场（2026-10-03 19:34，用户点「试跑一次」）：
        //     目标 = 用户主页 6986999782 → 拉到最新微博 mid=5349913661279062
        //     → 目标核对：没能确认微博 5349913661279062 在不在（接口没给明确答复）
        //     → 按不能发送处理
        //   ★ 这条微博**真实存在** —— 是判据的错，不是目标的错。
        //
        // ★ 取证的原始回包（从手机 files/interact_probe.txt 导出）：
        //     GET /comments/hotflow?id=5349913661279062 → HTTP 200
        //     {"ok":0,"msg":"还没有人评论哦~快来抢沙发！"}
        //   而第 46 期写死的判据只认 msg 里含「快来发表」：
        //     10-02 实测那句是「快来发表你的评论吧」，10-03 换成了「快来抢沙发」。
        //   ⇒ 微博对**同一个状态**会换文案，按字面匹配的判据必然腐坏。
        //
        // ★ 第 54 期把合法 / 非法 mid 的回包逐条测了一遍（**不带 Cookie 也能复现**）：
        //     真 mid、有评论       ok:1 + data.data                        → EXISTS
        //     真 mid、没评论       ok:0 + msg（上面两种文案都算）           → EXISTS
        //     假 mid               errno:20000 + extra:param error         → NOT_EXISTS
        //     数字超范围           errno:20000 + extra:value invalid       → NOT_EXISTS
        //     合法格式但查不到     只有 ok:0（**无 msg、无 errno**）        → UNKNOWN
        //     空 mid               errno:100013 + msg:参数缺失             → UNKNOWN
        //   ⇒ 判据从「认一句文案」改成「认结构」：
        //     errno 有值 ⇒ 不在；errno 缺失 + msg 非空 + 不像报错 ⇒ 在。
        //   ★ 「只有 ok:0」那行是关键反例：**不许**用「没报错 ⇒ 存在」蒙过去 ⇒ 仍 UNKNOWN。
        //
        // ★ 边界：只改 `InteractProbe.kt` 的 `postState`（纯 JSON 解析），
        //   外加 `ERROR_WORDS` / `looksLikeError` 一处词表兜底（挡到 ⇒ 退回 UNKNOWN ⇒ 不许发，
        //   方向是安全的）。**不联网、不写任何状态、不碰任何核心链路**。
        //   仍是三态、仍只认正面证据 —— UNKNOWN 与 NOT_EXISTS 一样是「不许发」。
        //   `InteractProbe.kt` 在 `Interact` 前缀内 ⇒ 只受隔离③④约束
        //   ⇒ **不需要** `APPROVED_CHANGES`，`SNAPSHOT` 不推进。
        //   ★ 四个核心文件与链路执行器**一行未动**；签到 / 发帖 / 自动验证的判定**一处未动**。
        //   ★ 文案层**一条未增、一条未改**（strings.xml 不动）⇒ 闸门 2 / 7 不受影响。
        //   ★ 备份**在第一次写文件之前**完成：`_backup_before_post_exists_20261003/`
        //     （`InteractProbe.kt` f17baaaca4c38a706e4bb194bfb4d9ad、
        //       `build.gradle.kts` 4f7fd393158ccb48ba9ddb02b66cb051）。
        //
        // ★ 第 55 期：给「互评 / 楼赞」加一道闸（不让它们悄悄变成顶层评论）。
        //
        // ★ 现场（2026-10-03 20:40，用户问「互评和评论的具体区别」）：
        //     查遍全项目，`action` 这个字段只被引用 4 处 ——
        //       新建任务对话框的选项与提示语 / 任务行的标签 /
        //       试跑结果里「动作：」那一行 / 日志里记一句 动作=REPLY。
        //     **没有一处影响行为**：send 从头到尾没读过 task.action。
        //
        // ★ 证据（全项目搜索）：
        //     · 真发送只有一个接口：m.weibo.cn/api/comments/create
        //     · 请求体固定四字段：content / mid / st / _spr（mid 是**微博**的 id）
        //     · 搜不到任何「回复接口」或「点赞接口」
        //     · 任务数据模型里 target 的注释写着「楼评 / 楼赞时同一栏填楼层标识」，
        //       但表单里**没有第二个输入框**，解析器也只认 mid / uid ⇒ 楼层无处可填
        //   ⇒ 结论：选「互评」和选「评论」发出去的东西**完全一样**，
        //     都是一条全新的顶层评论。这是**公开可见**的误发，比不发更糟。
        //
        // ★ 边界：只改 `InteractRunner.kt` 的 `localCheck`（加一步纯本地判断，
        //   排在「任务是否启用」之后、「目标」之前）+ `strings.xml` 加一条文案。
        //   ★ 不联网、不写任何状态、不碰任何核心链路；
        //     `Interact*` 前缀 ⇒ 只受隔离③④约束 ⇒ **不需要** APPROVED_CHANGES，
        //     SNAPSHOT 不推进。四个核心文件与链路执行器**一行未动**。
        //   ★ 备份在第一次写文件之前完成：`_backup_before_interact_action_guard_20261003/`
        //     （`InteractRunner.kt` 55bd79f5c23e667c523658db599ff0f6、
        //       `strings.xml` f45c3eaabcf72fefe2b765f4cb83e6ed、
        //       `build.gradle.kts` 3beb7321520ac5f6f39427f0da2f4df7）。
        //
        // ================================================================
        // 第 56 期（116 / 0.20.75）：语料「低质风险」提示 + 任务行「上次执行」
        // ================================================================
        //
        // ★ 现场（用户 2026-10-03 21:01 真机，评论 id=5350040316936616）：
        //     评论**真的发出去了**（POST /api/comments/create → ok:1，额度记 1 次），
        //     但微博把它折叠成「疑似低质或无意义」—— 计数照算、默认不显示。
        //   ⇒ 发送链路 100% 通了，**这是内容问题**：那条评语是
        //     「话题标签 + 大量 emoji + @某人」的成套模板。
        //     用户批准做 A + C（B 经查证**不需要改**，见下）。
        //
        // ★ B 为什么**不改**（重要，别再翻案）：
        //     用户报告里那条「16:30~16:33 已签到却还去点，空等 90 秒」是
        //     **2026-10-02 16:30** 的事，不是 10-03。日志时间戳没有日期，
        //     我把前一天的记录当成了当天的新发现。
        //     它当天就被**第 49 期**修好了（`verifyPreferUncheckedTopic`，
        //     验证页优先挑「今天还没签过」的超话），而且**同一份日志里就有 A/B 对照**：
        //       16:30:57 花小龙（第一个）→ `文本=已签到` → 3 轮空转 → 「停手」
        //       17:48:01 换了一个超话 → `文本=签到` → 立刻弹验证码 → `[判定] 验证通过`
        //     整份缓冲里 `文本=已签到` 只出现在 10-02 16:31~16:33，之后再没有过。
        //   ⇒ 一行都不用改。详见 `星签-第55期续-真发送达成-115.md` §8 更正节。
        //
        // ★ 本轮改了什么：
        //     ① 新增 `CommentQuality.kt`（纯本地、只读、**只提示不拦**）：
        //        数话题标签个数 / 表情符号个数 / 有没有 @ / 正文长度 —— 四件**形状**，
        //        一个中文关键词都不认（第 54 期吃过「认文案」的亏）。
        //        接进「加一条评语 / 批量导入」对话框的**实时**提示，
        //        以及分组菜单最后一项「低质风险自检」（整组扫一遍）。
        //     ② `InteractTaskStore.markRun()` + `InteractRunner.send()` 回写 +
        //        任务行多显示一行「上次执行：MM-dd HH:mm · 结果」。
        //        在这之前 `lastRunAt` / `lastResult` **从来没被写过**。
        //
        // ★ 边界（硬规则一，逐条对照）：
        //     · ① 自动签到 / ② 自动发帖 / ③ 全自动验证 / ④ 数据层 —— **一个字未动**。
        //       `CommentQuality` 不读盘不写盘不联网；`markRun` 写的是
        //       **互动任务自己的** `interact_tasks.xml`，与 `WeiboAccount.lastRunAt`
        //       （第 41 期跨天复活判据）同名不同物，本文件对账号数据一个字都不写。
        //     · 不新增/删除任何界面控件（id 对账：新增的只有**动态生成**的 TextView，
        //       没有动 `activity_interact.xml`，所以没有 id 增减）。
        //     · `Interact*` / `Comment*` 前缀 ⇒ 只受隔离③④约束 ⇒ **不需要**
        //       APPROVED_CHANGES，`_audit_interact_isolation.SNAPSHOT` **不推进**。
        //       四个核心文件与链路执行器**一行未动**（①② 继续与第 42 期快照逐字节比对）。
        //     · `markRun` 用 `copy(lastRunAt = …)` 而**不是** `x.lastRunAt = …`：
        //       ① 语义上更好（换成新实例，界面手上的旧引用不会被偷偷改掉，必须重读）；
        //       ② 隔离闸门③的正则 `\w+\.lastRunAt\s*=` 依然**原样保留**、
        //          依然能抓到任何对 `.lastRunAt` 的赋值 —— 闸门没有放宽，只是这条路
        //          本来就不该用「就地改字段」写。
        //
        // ★ 备份在第一次写文件之前完成：
        //   `_backup_before_interact_quality_and_lastrun_20261003/`
        //     （`InteractActivity.kt`  e23d0e40159144792098db5d5ebb3f9a、
        //       `InteractRunner.kt`    d6fea02d9e8be0248268950da3ab204c、
        //       `InteractTaskStore.kt` d49ad17a5048524f59ad17a81963b14a、
        //       `strings.xml`          059e2ffad59f2c8974a978ed2512e979、
        //       `build.gradle.kts`     4ede0e3c114ea19d0e2f507366b286d2）。
        // ================= 第 57 期（用户报告两件事）=================
        // 用户原话：「这个语料库太复杂了，把精简一下，还有现在选不了哪个账号，
        //           也选不了哪个语料库」+ 两张截图。
        //
        // ★ 第二件事是**真 bug**，不是「没做」：
        //   `showAddTaskDialog` 里 `spinner(accountChoices())` / `spinner(groupChoices())`
        //   建出来了，却**少了两句 `root.addView(...)`** —— 所以界面上只剩
        //   「用哪个账号」「用哪组语料」两行灰字，下面一片空白。
        //   更糟的是 `.setPositiveButton` 里**真的在读** `selectedItemPosition`，
        //   ⇒ 一直在用一个从未显示过的控件的默认值（第 0 项 = 所有账号轮流 / 自动挑一组）。
        //   ★ 这种错**不报编译错**（变量被读了，编译器不会说「没用」），
        //     所以它一路活到了 116 版 —— 只有真机点开这个对话框才看得见。
        //   修：补上两句 `root.addView`，并让下拉框撑满一行（不设 layoutParams 会退到
        //   WRAP_CONTENT，只有几个字那么宽，夹在一堆满宽输入框里像「这里什么都没有」）。
        //
        // ★ 第一件事是**归位**，不是删功能：
        //   分组菜单原来 8 项，问题不是「多」而是「乱」—— 三种性质混在一起：
        //     ① 日常：加评语 / 随机取一条 / 低质风险自检
        //     ② 改结构：重命名 / 清空 / 删除
        //     ③ 跟这个分组无关：追加一个后缀（后缀是**全局**表，见 `CommentLib.addSuffix`）
        //   现在 ① 留外层（3 项）+ 「分组设置…」（1 项）= **4 项**；
        //   ② 收进「分组设置…」子菜单（3 项）；③ 挪到语料库菜单（那里本来就是全局动作）。
        //   「加一条评语」和「批量导入评语」合并成「加评语」——
        //   `CommentLib.addLines` 本来就按换行拆行，两个入口跑的是**同一段代码**，
        //   只差一句提示语，摆两个选项纯粹是让人犹豫点哪个。
        //   ⇒ 能力对照：原来能做的现在都还能做
        //     （加 / 批量 / 取一条 / 自检 / 改名 / 清空 / 删除 / 加后缀）。
        //
        // ★ 边界（硬规则一）：只动**显示层**（菜单项怎么排、文案、对话框标题、下拉框宽度）。
        //   ① 自动签到 / ② 自动发帖 / ③ 全自动验证 / ④ 数据层 —— **一个字未动**。
        //   控件只增不减：没有删掉任何 id（`activity_interact.xml` 未动），
        //   删掉的只是**两个菜单项**，而它们的功能都还在（一个被合并、一个被挪位）。
        //   删掉的字符串资源 `interact_lib_import_title` / `interact_lib_import_hint`
        //   正是被合并掉那两项的文案，源码里已无任何引用（`_stale_refs` 已核）。
        //   `Interact*` / `Comment*` 前缀 ⇒ 只受隔离③④约束 ⇒ **不需要** APPROVED_CHANGES，
        //   `_audit_interact_isolation.SNAPSHOT` **不推进**。
        //
        // ★ 备份在第一次写文件之前完成：
        //   `_backup_before_interact_lib_simplify_20261003/`
        //     （`InteractActivity.kt`  bec94e805b63ff80a61ccc64cb82c215、
        //       `CommentQuality.kt`   b3ab7e5b28c7729980d264828d065060、
        //       `strings.xml`         b58bb84eba63552ac90efbf05705df36、
        //       `build.gradle.kts`    ed375a1b9902705ebb95b4e3d8bd6467）。
        // ================= 第 58 期（用户报告两件事）=================
        // 用户原话：「新建分组看不到里面的评语内容，用哪个账号显示账号一账号2没有显示账号名称」。
        //
        // ★ 第一件事 —— **加完评语没有任何地方能看见它**（真的缺口，不是错觉）：
        //   语料库那一层只显示「分组名（N 条）」，点进分组只有**动作**、没有**内容**。
        //   ⇒ 唯一能看见一条评语的途径是「随机取一条」，一条一条抽，
        //     抽到重复的还会让人以为「没加进去」。新建的分组尤其明显：N 一直是个数字。
        //   修：分组菜单加一项「看看这组的评语」—— 只读清单（编号从 1 起），
        //       看完就关。**不改、不删、不排序**。
        //
        // ★★ 顺带修掉一个**很可能是真正病根**的地方（`quickAddLine`）：
        //   「快速加一条评语」那颗按钮原来**固定往第一个分组里加**，而且界面上一个字都没说。
        //   用户新建了「分组 2」、点这颗按钮加了几条，回头点开「分组 2」—— 空的；
        //   评语没丢，只是进了「分组 1」，而用户拿不到任何线索。
        //   修：① 只有一个分组时照旧直接加（不多一次点击），但**标题里写明是哪个分组**；
        //       ② 有多个分组时**先让用户挑** —— 猜意图再悄悄写进别的分组，
        //          正是这个工程反复吃过亏的那类「静默的不同决定」。
        //   ★ 第 44 期的教训保留：绝不拿「新建分组」这种**按钮文案**当默认分组名。
        //
        // ★ 第二件事 —— **下拉框显示的是内部序号，不是账号名**：
        //   原来 `accountChoices()` 用的是 `WeiboAccount.label`，而 label 由
        //   `syncOrderLabels` 统一写成「账号 N」⇒ 用户看到「账号 1 / 账号 2」，认不出谁是谁。
        //   修：显示 `WeiboAccount.displayName`（有昵称就是昵称），
        //       与账号页那一行 `accountName` 用的是**同一个字段**。
        //   ★★★ 但**只改显示，不改存进去的值**：任务里存的仍是 `label`。
        //     因为 `accountLabel` 是靠 `firstOrNull { it.label == … }` 匹配回账号的
        //     （`resolveAccount` 有 4 处调用点都这么比），
        //     存昵称会让匹配失败、静默退化成「第一个账号」—— 那是**行为变化**，不许。
        //     ⇒ 显示昵称、存序号，两边各司其职。
        //
        // ★ 边界（硬规则一）：只动**显示层 + 互动功能自己的入口**。
        //   ① 自动签到 / ② 自动发帖 / ③ 全自动验证 / ④ 数据层 —— **一个字未动**。
        //   控件只增不减：`activity_interact.xml` 未动（新增的是**动态**菜单项与对话框），
        //   没有删掉任何 id。删掉的字符串键 `interact_lib_add_line_title` /
        //   `interact_lib_line_hint` 是第 57 期合并后**只剩 quickAddLine 在用**的旧文案，
        //   已被 `interact_lib_add` / `interact_lib_add_hint` 取代（`_stale_refs` 已核）。
        //   `Interact*` / `Comment*` 前缀 ⇒ 只受隔离③④约束 ⇒ **不需要** APPROVED_CHANGES，
        //   `_audit_interact_isolation.SNAPSHOT` **不推进**。
        //
        // ★ 备份在第一次写文件之前完成：
        //   `_backup_before_interact_lib_view_and_account_name_20261003/`
        //     （`InteractActivity.kt`  892c76b94ff8a4fa7a65a22db58ef3ac、
        //       `CommentQuality.kt`    20af6265c32bca48c3dbe45421996214、
        //       `strings.xml`          15bbd5b0d7c2eeaa18c1f994e8eccafa、
        //       `build.gradle.kts`     bf11374181d7e1b7bc7b7b6309161032）。
        // ================= 第 59 期（用户截图：「发送结果」里还写着「账号 1」）=================
        // 用户发来一张「发送结果」截图：
        //     动作：楼赞 / 目标：https://weibo.com/u/9080022869 / 目标类型：用户主页
        //     账号：账号1        ← ★ 就是这一行
        // 第 58 期只改了「新建任务」下拉框里显示什么，**这个结果对话框没改到** ——
        // 于是用户在下拉框里选了昵称、结果框里却写着「账号 1」，两处对不上，更像坏了。
        //
        // ★ 根因：同一个账号有**两个名字**，之前没有分开用：
        //     · `WeiboAccount.label`       —— 内部序号（`syncOrderLabels` 统一写成「账号 N」）。
        //                                    它是**键**：`RateGuard.verdict` / `markRun` 按它记账，
        //                                    `interact_tasks.xml` 里存的 `accountLabel` 也是它。
        //     · `WeiboAccount.displayName` —— **给人看的名字**（有昵称就是昵称）。
        //   ⇒ 本轮把**所有印给用户看的地方**统一换成 displayName，**键一个字没动**。
        //
        // ★ 改到的 4 处（全在互动功能内，都是显示层）：
        //   ① `InteractRunner.localCheck` 的「账号：%1$s」   ← 截图里这一行
        //      （参数从「label 字符串」换成整个 `WeiboAccount?`，因为要同时拿到两个名字；
        //        同函数里的「判空」与 `RateGuard.verdict` 仍然用 label）
        //   ② `InteractRunner.localCheck` 的保护模式提示「账号 %1$s 正在保护模式…」
        //   ③ `InteractActivity.refreshGuard` 的「账号保护」卡（`interact_guard_ok` /
        //      `interact_guard_resting`）—— 原来也写着「账号 1：本小时已互动 0 / 20 条」
        //   ④ `InteractProbe` 自检摘要「账号 %1$s 的登录态探测完成」
        //
        // ★ **刻意没改**的地方：`InteractTrace.log(...)` 里的「账号=…」。
        //   那是诊断日志，它的职责是**跟存起来的数据对得上号**（`accountLabel` 就是 label），
        //   出问题时我靠它去查 `interact_tasks.xml`。给它换名字反而会让两边对不上。
        //   ⇒ 界面上给人看 = displayName；日志里对号 = label。
        //
        // ★ 边界（硬规则一）：**纯显示层**。没有任何一个 `RateGuard` 的键、
        //   没有任何一个 `it.label == …` 匹配、没有任何一处 `accountLabel` 的**存值**被改动。
        //   ① 自动签到 / ② 自动发帖 / ③ 全自动验证 / ④ 数据层 —— **一个字未动**。
        //   没有新增/删除任何界面控件、没有改任何字符串资源（`strings.xml` 本轮**未动**）。
        //   `Interact*` 前缀 ⇒ 只受隔离③④约束 ⇒ **不需要** APPROVED_CHANGES，
        //   `_audit_interact_isolation.SNAPSHOT` **不推进**。
        //
        // ★ 备份在第一次写文件之前完成：
        //   `_backup_before_interact_account_displayname_20261003/`
        //     （`InteractRunner.kt`    b6ebc33ecc3d95745fe18688f929d0f1、
        //       `InteractActivity.kt`  480a4780f4e7eb7cae83175dd40c5a6c、
        //       `InteractProbe.kt`     6998aec5108b3df4c91c79879ebc732e、
        //       `build.gradle.kts`     3ad88a6739dfc1d591784d42428149fb）。
        // ================= 第 60 期（微博网页「复制链接」给的地址被判成「用户主页」）=================
        // 用户贴来的运行日志：
        //     动作=COMMENT 账号=账号 1 目标=https://weibo.com/9080022869/5345638346654862
        //     中止：目标状态=UNKNOWN mid=
        //     目标类型：用户主页        ← ★ 判错了，这明明是**单条微博**
        //     目标核对：这条链接里没解析出用户 uid
        //
        // ★ 根因：`InteractTarget.kind()` 判断 `weibo.com` 链接时，只看**最后一段是不是纯数字**：
        //     `weibo.com/6986999782`             1 段、末段纯数字 ⇒ 主页   ✅ 对
        //     `weibo.com/9080022869/5345638…`    2 段、末段**也是**纯数字 ⇒ 主页  ❌ 错
        //   两种链接的末段长得一模一样，只看末段**根本区分不开**。
        //   ⇒ 判成主页后去取 uid，而这条链接里没有 `/u/`，`uid()` 返回空 ⇒ 报
        //     「没解析出用户 uid」⇒ 状态 UNKNOWN ⇒ 中止（★ 这个中止本身是对的：
        //     宁可什么都不发，也不发到不确定的地方）。
        //
        // ★ 为什么非修不可：`weibo.com/<uid>/<mid>` 是微博网页端点「复制链接」给出的
        //   **默认形态**，也是最常见的一种。不支持它 = 用户按正常方式复制来的链接用不了。
        //
        // ★ 修法：新增 `UID_POST_PATH = weibo\.(?:com|cn)/(\d{5,20})/([A-Za-z0-9]+)`
        //   —— 改看**路径有几段**（host 后面还有第二段 ⇒ 就是「uid + 微博 id」），
        //   并放在「末段是不是纯数字」那条老判断**之前**；顺序反了就会重现这个 bug。
        //   第二段既可能是**数字 mid**，也可能是 base62 短 id，两种都收。
        //   `postId()` 同步加了同一个分支（取第 2 组）。
        //
        // ★ 顺带修掉一个**潜在** bug：老 `postId()` 走「取最后一段」时，会把查询串
        //   **一起**当 mid 返回 —— 例如 `…/5345638346654862?from=page_100505`
        //   会返回 `5345638346654862?from=page_100505`，发出去必然失败。
        //   新正则只吃 `[A-Za-z0-9]+`，查询串自然被挡在外面。
        //
        // ★ 影响面（用 14 个真实链接形态逐条对照过，见 `_p60_target_regex_test.py`）：
        //   只有 `weibo.com/<uid>/<纯数字 id>` 这一种的判定从 PROFILE 变成 POST；
        //   其余 13 种（纯数字 / status / detail / u / profile / n / 单段数字 /
        //   非微博域名 / 空串）**判定与取值全部不变**。
        //
        // ★ 调用点只有 3 处，全在互动功能内：`InteractProbe` 的接口自检、`resolveTarget`
        //   （预演与发送共用）、`InteractRunner.localCheck`。
        //
        // ★ 边界（硬规则一）：`InteractTarget` 是**纯函数** —— 不联网、不读存储、
        //   不碰任何共享状态。没有新增/删除界面控件、没有改任何字符串资源
        //   （`strings.xml` 本轮**未动**）。① 自动签到 / ② 自动发帖 / ③ 全自动验证 /
        //   ④ 数据层 —— **一个字未动**。
        //   `Interact*` 前缀 ⇒ 只受隔离③④约束 ⇒ **不需要** APPROVED_CHANGES，
        //   `_audit_interact_isolation.SNAPSHOT` **不推进**。
        //
        // ★ 备份在第一次写文件之前完成：
        //   `_backup_before_interact_target_uid_post_20261003/`
        //     （`InteractTarget.kt`  15c2f198fda1b33a96f4808789be9cb3、
        //       `build.gradle.kts`   136674936e44729f66725a6d522d7a47）。
        // ============ 第 61 期（「已签到」被当成「签到」按钮点，验证流程空转到停手）============
        // 用户贴来的诊断报告（账号四为什么没签上）+ 手机 slider_trace.xml 实证：
        //     09:46:53  [手势] 按钮 … 文本=签到        ← 首轮点了，签到请求发出去了，但没弹验证码
        //     09:47:22  [滑块] 30 秒内没等到验证码（点签到=true，曾出现过=false，已拖动 0 次）
        //     09:47:39  [手势] 按钮 … 文本=已签到      ← 重挂 1：同一个超话，点不动
        //     09:48:27  [手势] 按钮 … 文本=已签到      ← 重挂 2：同一个超话，点不动
        //     09:49:12  [重挂] 已重挂 2/2 轮仍未过，停手，交给用户手动处理
        //   ⇒ needsVerify 留着不清 ⇒ 该账号被 `!needsVerify` 过滤出待签池 ⇒ 当天再也不会自动
        //     去签它 ⇒ 报告里「今日进度 4/5」。只有第二天 0 点后第 41 期的「跨天复活」才给一次机会。
        //
        // ★ 根因一（识别）：`YidunAutoSlider` 找签到按钮用的是**包含**判据
        //     `t.indexOf('签到') >= 0`
        //   —— `'已签到'.indexOf('签到') === 0` ⇒「已签到」也命中。而「已签到」点下去微博
        //   **什么都不做**（不签、不发请求、不弹验证码）⇒ 每轮干等 30 秒后停手。
        //   真机日志里「文本=已签到」共 5 次，每一次后面都跟着「30 秒内没等到验证码」+
        //   「已重挂 2/2 轮仍未过，停手」：
        //     10-02 16:31:00 / 16:31:46 / 16:32:33（然妈爱吃汉堡包）
        //     10-04 09:47:39 / 09:48:27（用户8242606810）
        //   ★ 这条判据**不是新发明**：无障碍那条路（`WeiboClient.kt:867`）从一开始就是对的 ——
        //     `buttonName.contains("签到") && !buttonName.contains("已签")`。本轮只是把 JS 这条路
        //     对齐过去，并收敛成**全工程唯一一份** `jsCheckinBtnHelper()`（原来三处各写一份）。
        //
        // ★ 根因二（动作）：第 49 期只把「优先挑今天还没签的超话」加在**首轮**上，重挂复用
        //   `currentCheckinUrl` ⇒ 2 轮重挂全砸在同一个超话上。而 10-04 09:50:49 同一账号重新起
        //   一次会话、重开**同一个**超话，验证码就出来了、验证通过 ⇒「三轮全废在同一个超话上」
        //   是卡死的关键一环。现在重挂前在**后台线程**重新挑一个超话（排除刚点不动的那个）。
        //
        // ★ 改了什么：
        //   · `YidunAutoSlider.jsCheckinBtnHelper()` 新增（判据唯一一份，3 处共用）；
        //   · `YidunAutoSlider` 的 scroll / measure / `clickCheckinButton` 三处改用该判据；
        //   · 找不到真按钮时**不点**，每页留一次痕（`deadBtnLogged`），不再空点；
        //   · `WeiboClient.fetchFirstTopicContainerId(account, excludeContainerId = "")`
        //     新增**默认参数**（向后兼容，老调用点不改）；
        //   · `OverlayVerifyHost.scheduleRearm` 重挂时换超话，取不到则回退原地址。
        //
        // ★ 边界（硬规则一）：滑块的识别 / 缺口计算 / 拖动轨迹 / **成功判定**全部未动；
        //   只决定「点哪个元素」「重挂时打开哪个地址」，不决定「这一轮算不算过」。
        //   数据层未动 —— `excludeContainerId` 是默认参数，没有任何东西写进
        //   `WeiboAccount` / `Prefs`；`WeiboAccount.kt` 本轮**未动**。①②④ 一个字未动。
        //   本轮属**链路③的识别/动作层**，已**逐项取得用户批准**。
        //   两条 `@Volatile` 一键回滚：`YidunAutoSlider.strictCheckinButtonText`、
        //   `OverlayVerifyHost.rearmSwitchTopic`（都置 `false` = 逐字节回到第 60 期）。
        //   没有新增/删除界面控件、`strings.xml` 本轮**未动**。
        //
        // ★ 编译前先用 Python 等价性夹具验过判据：`_p61_checkin_btn_judge_test.py`，
        //   15 个用例 0 失败；并验到「同一页上『已签到』排在『签到』前面时，改前选中
        //   『已签到』、改后正确选中『签到』」。
        //
        // ★ 备份在第一次写文件之前完成：`_backup_before_verify_btn_text_20261004/`
        //   （`YidunAutoSlider.kt`   ecd1718c447f047d6670ac64fa873c1e、
        //     `OverlayVerifyHost.kt` d93f01e03df58d26f30574227aa4ee98、
        //     `WeiboClient.kt`       7a542746f0105f24d30396a1f6b36d53、
        //     `AgentService.kt`      60ee9306d68a28e34be3158744233f77（本轮未改，只备）、
        //     `build.gradle.kts`     384d5449a365b7f1101c18ecf868e70b）。
        // ★★★★★ 第 62 期（122 / 0.20.81）：验证失败后**自动重试补签** + 账号页按钮改「去验证」
        //
        // ★ 用户 2026-10-04 的原话：
        //   「我的理想需求是，不出现重新授权登录类似的，他既然需要人工验证失败了，
        //     就再从试一次重新补签」。
        //   追问三个参数后用户选定：重试间隔 **2 小时**；按钮改「**去验证**」（保留登录态）；
        //   状态文案改「**验证没过，稍后自动重试**」。
        //
        // ★ 根因（第 41 期只打了一半的补丁）：`needsVerify = true` 的账号被
        //   `ready() / notRunToday() / partialPending() / postPending()` 里的 `!it.needsVerify`
        //   彻底排除出待跑池 ⇒ 当天再也不会被自动签到。真机 2026-10-04 实证：账号四
        //   09:48「停手」之后一整天没人管它，要等第二天「跨天复活」才重试
        //   （用户看到「今日进度 4/5」）。第 41 期只加了「跨天」这一条路。
        //
        // ★ 改了什么：
        //   · `AgentService.verifyFailRetryHours`（`@Volatile`，默认 **2**）新增；
        //   · `AgentService` 的「复活」判定由「跨天」放宽为「跨天 **或** 距上次失败 >= 该值」，
        //     两种情形分别留痕（「跨天自动给一次重试机会」/「已过 N 小时，自动再试一次补签」）；
        //   · `MainActivity.openLogin(account, verifyMode = false)` 加参数；账号页那个按钮
        //     在 `account.needsVerify` 时传 `true` ⇒ 走**验证模式**（保留登录态、直接打开
        //     微博让用户手动过验证码），不再走「清 Cookie → 重新扫码」；
        //   · `strings.xml`：`account_reauth` 重新授权 → **去验证**、
        //     `account_state_verifying` 需要重新授权 → **验证没过，稍后自动重试**；
        //     `notif_verify_needed` / `ma_run_status_label_5` / `ma_done_today_4` /
        //     `interact_rehearse_no_cookie` 同步改词。
        //
        // ★ 边界（硬规则一）：**没有改变任何一次签到请求的内容** ——
        //   滑块的识别 / 拖动 / 成功判定、超话选取、风控判定、`runCheckin` 的 CAPTCHA 分支
        //   一个字未动；改的只是「什么时候再把它捞起来跑一轮」这一个条件。
        //   `WeiboClient.kt` / `WeiboAccount.kt` / `Prefs.kt` / `OverlayVerifyHost.kt` /
        //   `YidunAutoSlider.kt` 本轮**全部未动**（没有新增/删除任何字段）。
        //   界面控件数量未变（只改按钮上印的字），无删除。
        //   本轮属**链路④判定 + 人工验证入口**，已**逐项取得用户批准**。
        //   一键回滚：`AgentService.verifyFailRetryHours = 0` ⇒ 逐字节回到第 41 期行为；
        //   `MainActivity.accountButtonUseVerifyMode = false` ⇒ 回到第 27 期的按钮行为。
        //   ★ 后者没有界面开关，改它要重新出包（已在报告里写明）。
        //
        // ★ 编译前先用 Python 等价性夹具验过「复活」判据：`_p62_verify_retry_test.py`
        //   （覆盖：跨天 / 刚好 2 小时 / 1 小时 59 分 / lastRunAt=0 / 开关=0 等边界）。
        //
        // ★ 备份在第一次写文件之前完成：`_backup_before_verify_retry_20261004/`
        //   （`AgentService.kt`  60ee9306d68a28e34be3158744233f77、
        //     `MainActivity.kt`   aaec2cb7ef21f8d7acc0b69c5442a309、
        //     `strings.xml`       d678a54f4c00249195ce3781794b6725、
        //     `build.gradle.kts`  714ee3900d4f69f5d1b018b6e8b75ef4）。
        //
        // ---------------------------------------------------------------------------
        // 第 62 期补丁（versionCode 123 / versionName 0.20.82）——
        //   用户 2026-10-04 在三个选项里选了「补钩子：到点自动醒（推荐）」。
        //
        //   为什么 122 不够：122 只把「≥2 小时就复活」这条**判据**加对了，但程序当天
        //   并不会自己醒到 2 小时后 —— 一次运行结束后，下一次要么排在 30~60 分钟后
        //   （风控暂停重跑，离失败还不够 2 小时），要么直接排到明天。
        //   真机日志实证（2026-10-04）：09:49:12 停手之后当天再没有任何一次签到运行，
        //   账号四一直卡到第二天才被跨天复活。也就是说账号页那句「稍后自动重试」
        //   当时是句空话。本次补上「到点自己醒」这一环。
        //
        //   改动（AgentService.kt，同一文件累计）：
        //     ① 在第 2 步排程的 when 里，pauseLeft 之后新增 retryWaitMs 计算：
        //          取所有 needsVerify 账号的 (lastRunAt + retryGapMs - now) 最小值，
        //          lastRunAt==0 的账号不参与，结果 coerceAtLeast(0)。
        //     ② 在 when 的最后、else 之前新增分支 retryWaitMs > 0L：
        //          按 retryWaitMs + 0~20 分钟抖动排下一次运行，并写一行风控日志。
        //     ③ strings.xml 新增一条通知文案 notif_verify_retry。
        //
        //   边界：只决定「什么时候再跑一次」，**不改变任何一次签到请求的内容**。
        //     到点那次运行仍走 runCheckin 原路，撞到验证页就立刻停手（只发 1~2 个请求）。
        //     同一天不做重试次数上限 —— 每次重试成功后 onVerifySuccess 会设 restUntil
        //     （默认 24 小时）自然停止；失败则每 2 小时再试一次。用户已知晓此取舍。
        //     数据层未动；无控件增删；MainActivity.kt 本轮补丁未再改动。
        //   一键回滚：verifyFailRetryHours = 0 ⇒ retryWaitMs 恒为 0 ⇒ 新分支不成立，
        //     逐字节回到第 41 期行为。
        //   补丁前的备份：`_backup_before_verify_retry_hook_20261004/AgentService.kt`
        //     （md5 2096abb2af986d97701ee02e9edbb7c4，即 122 版的状态）。
        // ---------------------------------------------------------------------------
        //
        // ---------------------------------------------------------------------------
        // 第 63 期（versionCode 124 / versionName 0.20.83）——
        //   互动限频「每小时最多互动几条」在「休息时长 < 1 小时」时形同虚设。
        //
        //   用户 2026-10-04 贴来互动日志（同一条链接 10-03 判成用户主页、10-04 判成单条微博），
        //   核对时顺带从设备读 `shared_prefs/interact_guard.xml`，发现用户配置是
        //   hourly_limit=1、rest_minutes=5 —— 而夹具 `_p62_rate_guard_test.py` 模拟显示
        //   实际是每 5 分钟 1 条 = 12 条/小时，**超过界面承诺的 11 倍**。
        //   用户在三个选项里选了「修（推荐）」。
        //
        //   病因（RateGuard.kt，第 52 期起未改）：
        //     markRun 达到上限时把 windowStart 与 count 一起清零，
        //     expireIfNeeded 里休息到期时又清一次 ⇒ 1 小时的计数窗口永远攒不满
        //     ⇒ 节流退化成「每 rest_minutes 一次」。rest_minutes 只要小于 60，
        //     实际频率就超过用户设的上限 —— 用户想设最保守，拿到最激进的一档。
        //
        //   改动（RateGuard.kt，只此一个文件）：
        //     ① 新增 @Volatile var capByHourWindow = true（一键回滚开关）；
        //     ② markRun 达到上限时**不再清窗口**，休息时间改为
        //          max(now + restMinutes * 60_000L, windowStart + 3600_000L)
        //        （休息结束时窗口必然也到期，计数自然归零，既不会出不来又真按小时封顶）；
        //     ③ expireIfNeeded 休息到期时**不再清 count / windowStart**，
        //        计数归零只交给真正的窗口过期判断。
        //     开关为 false 时，② ③ 都逐字回到第 52 期的行为（夹具 30 组组合验证一致）。
        //
        //   边界：只改「同一账号多长时间内最多发几条」这一个节流判据。
        //     发送请求的内容 / URL / 参数 / 判定一个字未动（都在 InteractRunner.doPost）；
        //     闸门本身仍在 InteractRunner.localCheck 第 ④ 步，位置未动；
        //     数据层未动（RateGuard 只写自己的 interact_guard 私有文件，
        //     绝不碰 WeiboAccount / Prefs —— 见 RateGuard.kt 顶部那段纪律）；
        //     无控件增删；strings.xml 本轮未动（界面那句「每小时最多互动几条」现在是真的了）。
        //     ★ 四条硬规则链路（签到 / 发帖 / 验证 / 数据层）一个字节未动。
        //
        //   编译前夹具：`_p63_rate_cap_test.py`（改后每小时都 ≤ 上限、回滚 30 组 0 不一致）。
        //   备份：`_backup_before_interact_rate_cap_20261004/`
        //     （RateGuard.kt e7872fba88d584cb5f528afb404c0f8c、
        //       build.gradle.kts c564164cd7e29fffd2fb4b3a914dc8e9）。
        //   ★ 已知工具盲区：RateGuard.kt 不在七道闸门的覆盖范围里（既不是 CORE_KT /
        //     CHAIN_FILES，也不以 Interact / Comment 开头）⇒ 本轮靠夹具 + 人工核对兜住。
        // ---------------------------------------------------------------------------
        // ---------------------------------------------------------------------------
        // 第 64 期（versionCode 125 / versionName 0.20.84）——
        //   互动功能：「互评 / 楼赞」接口侦察（为把这两个动作做真铺路）。
        //
        //   背景：第 55 期给「互评 / 楼赞」加了闸 —— 任务模型里有这两个动作、任务行也照实显示，
        //   但真发送那条路只打 `/api/comments/create` 一个接口，请求体固定是
        //   content / mid / st / _spr，**没有任何「回哪一层」的字段**
        //   ⇒ 选「互评」实际会发出一条全新的顶层评论。第 55 期起直接拦下，只让「评论」往下走。
        //   第 56 ~ 59 期报告一直写着下一步是「必须真机抓包」拿父评论 id 与两个接口的参数名。
        //
        //   ★ 本轮不改任何发送逻辑、不改任何判定、不动数据层 —— 只**加一个只读探针**
        //     和一颗**试发按钮**，把「猜参数」变成「问微博」。思路与第 44 期「接口自检」、
        //     第 46 期「路径探测」完全一致：App 自己存着这个账号的 Cookie，让它自己发请求问。
        //
        //   改动（InteractProbe.kt + InteractActivity.kt + activity_interact.xml + strings.xml）：
        //     ① InteractProbe 新增 `scoutReplyLike()` —— **全只读**（只用 GET）：
        //          目标解析（复用 resolveTarget，与「真预演」同一套规则）
        //          → GET 评论列表（`/comments/hotflow`）拿**真实评论** ⇒ 定死父评论 id 是哪一栏
        //          → 把 4 个候选路径（2 个回复 + 2 个点赞）各 GET 一次 ⇒ 先分清哪个路径真的存在。
        //     ② InteractProbe 新增 `probeReplyLike()` —— **会发 POST**，四道闸：
        //          目标必须是 EXISTS 三态里的 EXISTS；
        //          评论列表里必须有**本账号自己**的评论 ⇒ 只回自己的楼，绝不碰陌生人；
        //          候选路径按可能性排序、**命中即停**（第一个 ok:1 就收手，绝不连发）；
        //          **绝不重试**（httpPost 本身就不重试）。
        //     ③ 判据只认回包里的 `ok`（第 51 期教训：界面提示可以是假的）。
        //          回复成功时 `rootid` 应等于父评论 id；若 `rootid` 等于新评论自己的 `id`，
        //          说明它被当成了新的顶层评论 —— 一并报出来。
        //     ④ UI 加**两颗独立按钮** + 两条说明（沿用既有惯例：只读与写请求必须分开，
        //          用户不该靠记忆去分辨哪颗发过东西）。加控件，**未删任何控件**。
        //
        //   边界：**四条硬规则链路（签到 / 发帖 / 验证 / 数据层）一个字节未动。**
        //     本文件只出现在 InteractProbe / InteractActivity / 布局 / 字符串里；
        //     `InteractRunner.localCheck` 里第 55 期那道闸**原样保留**（互评/楼赞仍然拦下不发）；
        //     不写 WeiboAccount、不写 Prefs、不调 RateGuard.markRun ⇒ 不消耗任何账号额度。
        //     ★ 候选里**刻意不含** `/api/comments/create` —— 它已验证是「发新顶层评论」，
        //       若它也接受 id 参数，发过去会多出一条重复的顶层评论，那不是批准的范围。
        //
        //   备份：`_backup_before_interact_reply_scout_20261004/`
        //     （InteractProbe.kt 68cad8f57f2ccfd4ebec49771982faea、
        //       InteractActivity.kt 9783f690919e2c97843298e2e1b18105、
        //       build.gradle.kts 978fa81fe366d1fd448495bcd9b72737）。
        // ---------------------------------------------------------------------------
        // 第 65 期（versionCode 126 / versionName 0.20.85）——
        //   互动功能：「互评 / 楼赞」接口侦察**第二轮**（把第 64 期的探针修正到位）。
        //
        //   背景：第 64 期真机实测（`_dev_interact_probe_64.txt`）拿到四条硬结论 ——
        //     ① `GET /comments/hotflow` 首次拿到**非空**评论列表 ⇒ wrapper = `data.data[]`，
        //        本账号那条评论 id = 5350328096788952（rootid 同值、floor_number=1）；
        //     ② `POST /api/comments/reply` 回 `{"ok":0,"errno":"100013","msg":"参数缺失"}`
        //        ⇒ **路径存在**（不是 404），只是参数名不对；
        //     ③ `POST /comments/reply` 回 `errno:404 链接无效` ⇒ 路径不存在；
        //     ④ `POST /api/attitudes/create` 带 `id=<评论 id>` 回 `20101 该微博不存在`
        //        ⇒ 这条路径要的是**微博 mid**（给微博点赞），不是给评论点赞。
        //
        //   本轮据此做三件事（★ 仍然**不改任何发送逻辑、不改任何判定、不动数据层**）：
        //     ① **回复参数定死**。真名来自 m 站前端 SDK `jasdk.js` 的 `wb.m_comment_reply`
        //        逐字原文：`{content, mid, reply:cid, cid:cid, withReply:1, st, _spr}`
        //        ⇒ 第 64 期缺的正是 `reply` / `cid` / `withReply` 三个，
        //          与 `100013 参数缺失` 完全吻合。本轮按真名重发。
        //     ② **点赞候选从 1 条路径扩成「路径 × 参数」4 种组合**，仍然**命中即停**。
        //     ③ **只读那一步加「前端线索」**：抓一次 H5 详情页 → 取它引用的 JS 包地址 →
        //        进包里搜 `attitudes` / `comments` 相关的接口名 ⇒ 万一 4 种组合都不中，
        //        也能从 m 站自己的前端代码里读出「评论点赞」真正的路径。
        //        （`httpGet` 因此多了一个 `limit` 参数，默认仍是 FILE_LIMIT，其余调用行为不变；
        //          抓 JS 包时用 JS_LIMIT = 300 万字符，否则只读到包开头、冷门接口名读不到。）
        //
        //   ★ UI / Activity / 布局**一个字都没动** —— 复用第 64 期那两颗按钮：
        //     「探回复与点赞接口（全只读）」现在多了第 ③ 步；
        //     「试发一条测试回复 + 一个赞（会发出去）」用上了正确参数与更多候选。
        //   ★ 四道闸原样保留（目标必须 EXISTS / 只回自己的楼 / 命中即停 / 绝不重试）。
        //
        //   边界：**四条硬规则链路（签到 / 发帖 / 验证 / 数据层）一个字节未动。**
        //     本轮只动 InteractProbe.kt 与 strings.xml；`InteractRunner.localCheck` 里
        //     第 55 期那道闸**原样保留**（互评/楼赞仍然拦下不发）；
        //     不写 WeiboAccount、不写 Prefs、不调 RateGuard.markRun ⇒ 不消耗任何账号额度。
        //
        //   备份：`_backup_before_interact_endpoint_fix_20261004/`
        //     （InteractProbe.kt b2e965d4edec47fcabd5406687200396、
        //       strings.xml 6295b3cdb7650398b13e8d1d7c685292、
        //       build.gradle.kts 56a93d7cd6ea6d4ac8c4bb2fd49e213d）。
        // ---------------------------------------------------------------------------
        // ---------------------------------------------------------------------------
        // 第 66 期（versionCode 127 / versionName 0.20.86）——
        //   互动功能：「互评（回复楼层）/ 楼赞（给评论点赞）」**真做出来**。
        //
        //   背景：第 65 期实测把「回复」彻底定死了，但「楼赞」仍然没找到 ——
        //     候选④（`/api/attitudes/create` 带 `id=<微博mid>&cid=<评论id>`）虽然回了
        //     `ok:1`，但重拉评论列表 `liked` 仍是 `false`，同一页 H5 里微博的
        //     `attitudes_count` 变成了 1 ⇒ **那一下赞记到了微博头上，`cid` 被整个忽略**。
        //
        //   ★★★ 本轮从 m 站**自己的前端源码**里把真名挖出来了（不用抓包）：
        //     ① 从 H5 详情页的打包表（入口包里的 chunk 哈希表）跟到微博详情页那个包
        //        `statusLite.<hash>.js`，里面评论组件的点赞函数逐字原文是
        //          `var a = "api/likes/update", o = "api/likes/destroy",
        //               n = i.liked ? o : a;
        //           this.$http.post(n, {id: i.id, type: "comment"})`
        //        ⇒ **评论点赞 = `POST /api/likes/update` + `{id: <评论id>, type: "comment"}`**；
        //        同文件里**微博**点赞是另一条：
        //          `this.$http.post(liked ? "api/attitudes/destroy" : "api/attitudes/create",
        //                           {id: <微博id>, attitude: "heart"})`。
        //     ② 回复（`miniComposer` 里）原文：`api/comments/reply` + `{content, mid, cid}`
        //        ⇒ 与第 65 期实测成功的那条一致（`cid` 就是父评论 id）。
        //     ③ 楼中楼列表（只读）：`GET /comments/hotFlowChild` + `{cid, max_id, max_id_type}`。
        //
        //   本轮据此做四件事（★ 仍然**不改任何核心链路、不动数据层**）：
        //     ① **撤掉第 55 期那道闸**（`InteractRunner.localCheck`）——
        //        拦它的理由（选互评会发出一条全新的顶层评论）已在物理上消失：
        //        两条动作各走各的接口，且**判据只认结构**。
        //     ② **互评**：先只读 GET 评论列表挑一层楼，再
        //        `POST /api/comments/reply`；成败判据 = 回包 `ok:1` **且** `rootid == 父评论 id`
        //        （若 `rootid` 等于新评论自己的 id ⇒ 被当成顶层评论 ⇒ 按**失败**处理）。
        //     ③ **楼赞**：挑好楼层后 `POST /api/likes/update`；成败判据 = **重拉评论列表
        //        看到 `liked=true`** —— 回包 `ok:1` **不算数**（第 65 期就是被它坑的）。
        //     ④ **探针修两个 bug**：前端线索原来抓错了包（抓到极验库 + 性能埋点，
        //        真正的业务包排在后面），现在按优先级排序、并且**跟着打包表进详情页 chunk**；
        //        搜索词也从 `attitudes|comments` 扩到含 `likes`（第 65 期正是漏了这个词）。
        //
        //   ★ 挑楼层的默认规则（界面上已写明，随时可改）：**楼赞先剔掉已赞过的**
        //     （`api/likes/update` 是「点赞」不是开关 —— 对已赞的楼再打一次只会白耗额度，
        //      而且自检看到 liked=true 还会误报「成功」）；剩下的里**优先挑别人的评论**，
        //     整页都是自己的就退回第一条并注明 —— 不中止，否则「自己给自己盖楼」会被一刀切。
        //     一条都没得挑时**一个请求都不发**，直接如实报告（不产生假成功）。
        //   ★ 楼赞**不发文字** ⇒ 语料库为空也不再拦它（`localCheck` 里按动作分流）。
        //   ★ 写请求**每种动作只发一次**，绝不连发、绝不重试（`httpPost` 本身也不重试）。
        //
        //   边界：**四条硬规则链路（签到 / 发帖 / 验证 / 数据层）一个字节未动。**
        //     只动 InteractProbe.kt / InteractRunner.kt / strings.xml 三个文件；
        //     `Interact*` 属于互动功能自己的文件，不写 WeiboAccount、不写 Prefs、
        //     不写 AccountStore；`RateGuard.markRun` 只在**真的成功**后才记账（与第 52 期一致）。
        //     ★ UI / Activity / 布局**一个字都没动** —— 复用现有的动作选择与两颗按钮。
        //
        //   备份：`_backup_before_interact_reply_like_20261004/`
        //     （InteractProbe.kt 0a9a1619d36b2ae6a7568302e70ad309、
        //       InteractRunner.kt 7612f6a01924a6945d50f772f452fd3f、
        //       strings.xml de8dabd3874c4694d3e614d9004c1eef、
        //       build.gradle.kts 582eba2e3df16919a67c3cf526dc2ed2）。
        // ---------------------------------------------------------------------------
        // 第 67 期（versionCode 128 / versionName 0.20.87）——
        //   互动任务：**账号范围从「只发第一个」改成「所有账号轮流」**。
        //
        //   背景（用户 2026-10-04 提问：「现在只给第一个账号发，其他 4 个账号为什么不发」）：
        //     新建任务对话框里「用哪个账号」下拉的第 0 项写着**「所有账号轮流」**，
        //     但实现从来**没有轮流** —— 真发与试跑都是
        //       `usableAccounts().firstOrNull { it.label == resolveAccount(task) }
        //        ?: usableAccounts().firstOrNull()`，
        //     而 `resolveAccount` 在 `accountLabel` 为空时只返回**第一个**可用账号。
        //     ⇒ **界面承诺与实现不符**（同一个对话框里，「用哪组语料」的第 0 项写的是
        //       「第一个分组」，那一个是如实的 —— 账号那项是第 57 期留下的文案错误）。
        //     ★ 对比：签到 / 发帖链路本来就是**批量**的（`AgentService.executeOnce` /
        //       `executePostOnce`：`batch = if (allAccounts) ready else (pool ?: ready).take(3)`），
        //       互动任务不是 —— 用户会觉得「签到都跑 5 个账号，互动只跑 1 个」。
        //
        //   本轮做法（用户选择「真做轮流」）：
        //     ① 新增 `InteractActivity.accountsFor(task)`：
        //        `accountLabel` 非空 ⇒ 只发那一个；为空 ⇒ **全部可用账号**。
        //     ② 真发 `doSend` 与试跑 `doRehearse` 都改成**逐个账号执行**，
        //        每个账号**单独兜异常**（第一个账号网络抽风不会把剩下几个一起带掉），
        //        结果按账号分段拼接后一起显示。
        //        ★ 试跑与真发**共用同一套分派** —— 预演说会对哪几个账号执行，真发就必须对
        //          同样这几个执行，否则预演没有意义（沿用第 66 期「预演与真发同源」）。
        //     ③ 顺带修掉一个隐患：原来那个 `?: usableAccounts().firstOrNull()` 兜底，
        //        会让「指定了一个**已被禁用**的账号」**静默换成第一个账号**（用错账号）；
        //        现在指定了却不可用 ⇒ 空列表 ⇒ **明确报错**，绝不静默换人。
        //     ④ 排查工具那 5 颗按钮（接口自检 / 探路径 / 发送探测 / 回复侦察 / 回复探测）
        //        **保持用第一个账号** —— 它们是探接口，不需要轮流。
        //
        //   ★ 文案：下拉第 0 项「所有账号轮流」现在**名副其实**了，**不需要改**。
        //   ★ 新增 2 条字符串：`interact_multi_running`、`interact_no_usable_account`。
        //
        //   边界：**四条硬规则链路（签到 / 发帖 / 验证 / 数据层）一个字节未动。**
        //     只动 InteractActivity.kt / strings.xml / build.gradle.kts 三个文件。
        //     `RateGuard` 按 label 独立记账 ⇒ 每个账号各有自己的额度，无需改动。
        //
        //   备份：`_backup_before_interact_multi_account_20261004/`
        //     （InteractActivity.kt 6a6d91599ab18d5098b0d7ba2c856439、
        //       strings.xml ee8ee66a780e8ad39ed59866d2038d1c、
        //       build.gradle.kts 6cf2868a629cc54b7afe5e359beae2fa）。
        // ---------------------------------------------------------------------------
        // ---------------------------------------------------------------------------
        // 第 68 期（versionCode 129 / versionName 0.20.88）——
        //   互动任务：**目标新增「超话」这一种** —— 贴一个超话链接，从它里面随机挑一条帖子。
        //
        //   背景（用户 2026-10-04）：
        //     · 用户说明真实目的：「我的目的主要是涨经验，而经验必须得在超话里完成」；
        //     · 随后提出：「可以贴上超话链接随机找个帖子评论」，
        //       并给出真实链接 `https://m.weibo.cn/p/100808db807a7a7c131532c93920af92091f0e`。
        //
        //   ★ 官方规则（抄自 `huati.weibo.cn/about/super`，本期新查证的）：
        //     超话**经验值** = 原创 + 互动 + 圈粉；其中「互动」的计分项是
        //       · 在当前超话**评论帖子**：+1/次（0 互动帖首评 +2），**每日最多奖励 4 次**；
        //       · 转发：+1/次，每日上限 2 分。
        //     ★★ **点赞不涨经验**（点赞影响的是「热度值」，不是个人经验值）。
        //     ★★ 两条硬限制：① 评论/转发前**必须已关注该超话**、且未被该超话屏蔽，否则不加分；
        //                    ② **评论自己的帖子不加分**。
        //
        //   本轮做法（全部在互动功能自己的文件里，不碰任何核心链路）：
        //     ① `InteractTarget.kt`：新增枚举值 `TargetKind.SUPERTOPIC` + 超话 id 正则
        //        （`/(?:p|page)/(100808<hex>)` 与 `containerid=(100808<hex>)`）+ `topicId(raw)`。
        //        ★ `kind()` 里**超话判断放在最前** —— 否则 `m.weibo.cn/p/100808db807a…`
        //          会被判成 POST（末段不是全数字），然后拿 `100808db807a…` 当 mid 去请求。
        //     ② `InteractProbe.kt`：`resolveTarget` 新增 `SUPERTOPIC` 分支 ——
        //        拉超话容器 `getIndex?containerid=100808…`（与「用户主页」**同一条**接口链路，
        //        只是 container 前缀从 `107603` 换成 `100808`）→ 解析帖子 → **随机挑一条** →
        //        再用既有的 `checkPost` 核对。新增 `randomTopicPost` / `parseTopicPosts` /
        //        `collectMblog`；解析**同时看两层**（`cards[].mblog` 与
        //        `cards[].card_group[].mblog`），并**跳过本账号自己发的帖子**（官方规则②）。
        //     ③ `InteractRunner.kt`：干跑的分类 `when` 补一条 `SUPERTOPIC` 分支（只加一句说明）。
        //        ★ 必须补 —— 新增枚举值会让**穷举 when 编译失败**；真发/预演路径本身
        //          走的是 `resolveTarget(...).mid`，**一行未改**。
        //     ④ 新增 6 条字符串 + 4 条旧提示文案补上「超话」（纯显示层）。
        //
        //   ★ 无法在电脑上预验证：`m.weibo.cn` 对无 Cookie 请求一律 302 到访客墙
        //     （`visitor.passport.weibo.cn`，跟过去是 HTTP 432），网页版 `weibo.com/p/100808…`
        //     同样返回访客系统页 ⇒ 超话回包结构**只能靠真机实测**。因此本轮额外给
        //     「接口自检」加了 `SUPERTOPIC` 分支，跑一次就把原始回包落进
        //     `filesDir/interact_probe.txt`，并在 `interact_trace.xml` 里打印分层条数。
        //
        //   边界：**四条硬规则链路（签到 / 发帖 / 验证 / 数据层）一个字节未动。**
        //     只动 InteractTarget.kt / InteractProbe.kt / InteractRunner.kt /
        //     strings.xml / build.gradle.kts 五个文件。
        //     ★ 新分支走的是**既有**的 `resolveTarget` → `checkPost` → `send` 通路，
        //       没有任何新的写请求、没有新的存储键、没有改变任何读写的时机。
        //
        //   备份：`_backup_before_supertopic_20261004/`
        //     （InteractProbe.kt d6d8394e860e7b7d8643a0b0f1ddadab、
        //       InteractTarget.kt cec54603779ccb70dee4153ea1acf4f8、
        //       build.gradle.kts 07c7160627c50a7cfec22e330e01424f、
        //       strings.xml a619e0c798d19dd1bc72d3113ed86d5b）。
        // ---------------------------------------------------------------------------
        // 第 69 期（versionCode 130 / versionName 0.20.89）——
        //   兼容性收口 + 瘦身：**「点了没反应」的根因修复**与 **14MB 减重**。
        //
        //   背景（用户 2026-10-05 给的优化清单，逐条只读核实后收敛）：
        //     用户给 11 条，核实结果 10 条属实。★ 其中「加 <queries> 恢复设置页跳转」
        //     这条需要修正：Android 包可见性**豁免 `Settings` 系 Intent**，
        //     所以电池优化跳转本来就不需要 <queries>；真正被它卡住的是
        //     `openBrandAutoStart()` 里那些**第三方组件**（`com.vivo.permissionmanager` 等）。
        //
        //   本轮真正做的事（**全部在「设置跳转 / 诊断报告 / 构建配置」三层，
        //   四条硬规则链路（签到 / 发帖 / 验证 / 数据层）一个字节未动**）：
        //
        //     ① `DeviceCompatibility.kt` —— 三级兜底 + **每一步留痕**。
        //        旧实现两级且都在 `catch (_: Exception)` 里静默吞掉：
        //        `startActivity()` **不抛异常也会什么都没发生**（Intent 被解析到但页面空白、
        //        被 ROM 拦、缺 extra）⇒ 用户症状「点了没反应」，而报告里一个字都没有。
        //        新增 `fire()`：先 `resolveActivity()` 预检（说明「当前 ROM 根本没这个页面」），
        //        再 `startActivity()`；两条路都判成败。电池优化补第 3 级
        //        `ACTION_APPLICATION_DETAILS_SETTINGS`（所有 ROM 都保证存在的应用详情页）。
        //        新增 `compatTrace`（只读诊断字段，记录「实际走到哪一级」）。
        //     ② `strings.xml` —— 无障碍描述补一句，**预先打消系统红字强提示的顾虑**
        //        （Android 11+ 打开无障碍会弹「可查看和控制屏幕」，用户会因此放弃）。
        //        新增 5 条（WebView 版本行、自检两行、占位两条）。
        //     ③ `MainActivity.kt` —— 诊断报告新增 3 行（全部只读、不参与判定）：
        //        · WebView 版本：滑块链路跑在 WebView 里，「滑块不动」时最先要排除的变量。
        //          用 `WebView.getCurrentWebViewPackage()`（静态只读，API 26+，不建实例）。
        //        · 必选项完成度 N/3：与 `SetupWizardActivity.REQUIRED_ITEM_COUNT` 共用常量。
        //        · 最近一次兼容性跳转：读 `DeviceCompatibility.compatTrace` ⇒
        //          `battery:none(all 3 failed)` / `autostart:none(brand=vivo)` 一眼定性。
        //     ④ `AndroidManifest.xml` —— 新增 `<queries>`（9 个包 + 2 条 intent）。
        //        只声明需要拉起的系统组件所在包，**不申请 QUERY_ALL_PACKAGES**。
        //        同时把 `USE_EXACT_ALARM` 注释里「不受此限制」的半句改成中性表述
        //        （技术说明保留，去掉「明示豁免」的措辞）。
        //     ⑤ `build.gradle.kts` —— `abiFilters` **只留 arm64-v8a**，砍掉 32 位。
        //        APK 立减 **13.94 MB**（43.45 MB → 约 29.3 MB）。对 arm64 设备装到的
        //        `.so` 与砍之前**逐字节相同**，纯构建配置。
        //
        //   ★★ 本轮**明确不做**的四件事（用户已同意，理由已核实）：
        //     · 不删 OpenCV：属链路③「识别层」（`YidunSliderSolver.kt` 是 CORE_KT），
        //       且用户给的前置条件「先过 30~50 张滑块图准确率对比」**目前不满足** ——
        //       实测桌面上只有 2 组图（`weibo-captcha/images/`），
        //       其 `offline-analysis.json` 自己就写着 `success_baseline_status: insufficient`。
        //     · 不升 targetSdk（34 豁免 Android 16 全部行为变更；升上去白亏 UI 回归，
        //       且 AGP 8.5.2 也不支持 compileSdk 36）。
        //     · 不动 `USE_EXACT_ALARM` 权限本身（安装即授予，是「到点能执行」的关键）。
        //     · 不动 `AlarmManager` 三档降级（`LocalScheduler.scheduleAt`：
        //       逐档亲自试、失败才降级、只有真登记成功才写 nextRunAt —— 全工程最稳的一段）。
        //     · 不为老系统做 WebView 拦截（minSdk=26，自用，没有用户需要照顾）。
        //
        //   备份：`_backup_before_compat_slim_20261005/`（6 文件，md5 见报告）
        // ---------------------------------------------------------------------------
        // 第 73 期 A（versionCode 131 / versionName 0.20.90）——
        //   滑块缺口识别换实现：OpenCV → 纯 Kotlin（`SliderMatch`）。
        //   **本期只换实现、不删依赖**，两个开关（usePureKotlin / abProbe）可一键切回。
        //
        //   为什么换：OpenCV 带进来 `libopencv_java4.so`(16.39MB) + `libc++_shared.so`(5.95MB)
        //     = APK 的 76%，且两者 ELF PT_LOAD 对齐**均为 4096** ⇒ 16KB 页手机 `dlopen` 必失败。
        //     第 73 期 B 删依赖后 APK 预计 29.52 MB → ≈7.2 MB。
        //
        //   等价性依据（第 72 期 · 8 组真实滑块样本）：
        //     「纯 Kotlin solve()」与「OpenCV solve()」max_loc 与整数缺口 8/8 完全相同，
        //     max_val 最大绝对差 2.98e-06（float32 舍入噪声量级）。
        //     复现工具：`_cv_replica/v72/`。
        //
        //   本轮同时：`SliderSampler.enabled` → false、`Dbg.enabled` → false（交付态）。
        //   备份：`_backup_before_remove_opencv_20261006/`（4 文件，md5 见报告）
        // ---------------------------------------------------------------------------
        // 第 73 期 B（versionCode 132 / versionName 0.20.91）——
        //   删掉 OpenCV 依赖，以及 `YidunSliderSolver` 里的旧路径（`solveOpenCv()` /
        //   `init()` / `describe()` / 两个开关）。纯 Kotlin 实现成为**唯一**路径。
        //
        //   A 期已把 `usePureKotlin = true` 设为生效路径 ⇒ B 期**只删死代码、不改行为**。
        //   真机侧无法直接 A/B（当天风控没触发验证码），改用「真实样本 + 最坏情况扰动」
        //   把「Bitmap → RGBA 取整差」的影响算成上界，见下。
        //
        //   等价性证据（第 73 期 A 补充取证 · 8 组**真机真实样本** × 6 变体）：
        //     把 front 图所有 mask 内半透明像素统一 ±1（即反预乘取整差的**上界**）：
        //       `max_loc` **0/8 翻转**；最大 |ΔgapLeft| **0.0071 px**（判据阈 0.1，低 14 倍）。
        //       余量约 5 倍 —— 扰动放大到 ±5 才出现 1 组翻转。
        //       bg 是 JPEG（无 alpha）⇒ 反预乘是空操作 ⇒ 两条路逐字节相同。
        //     复现工具：`_p73_ab_bound/SliderRunner74.java`（依赖 `_cv_replica/v73/out`）。
        //   备份：`_backup_before_b_remove_dep_20261006/`（2 文件，md5 见报告）
        // ---------------------------------------------------------------------------
        // ★ 第 74 期（收尾）：零风险小修，不动任何判定。
        //   ① `strings.xml` 的 `ma_jitter_note_49`：原先把「张」和「组」两个单位混用，
        //      且写的 30~50 组与 `SliderSampler.MAX_SETS=60`（= 30 组）对不上。
        //      现改为按「张」计数，并点明 1 组 = 2 张、上限 30 组。
        //      （`SliderSampler.count()` 数的是 `.jpg` 文件数，也就是张数，单位没错。）
        //   ② `MainActivity.kt` 的一处过期注释：仍写着「删 OpenCV 的前置条件是攒够样本」，
        //      而 OpenCV 已于第 73 期 B 删除。改为历史留痕的说明。
        //   两处都**不参与任何判定**（一处纯显示层文案、一处注释），无控件增删。
        //   备份：`_backup_before_p74_tidy_20261006/`（3 文件）
        // ---------------------------------------------------------------------------
        // ★ 第 75 期：删「悬浮窗实验」按钮 + 其独占的 OverlayProbe.kt（零风险删控件）。
        //   第 18 期的一次性实验装置（测安全锁屏下悬浮窗 WebView 能否跑定时器），
        //   结论早已用于第 37 期悬浮窗设计。全工程只被 MainActivity.kt 的
        //   probeOverlayButton 监听调用，删按钮时一并删文件，无任何判定依赖。
        //   顺带：3 条 probe_overlay* 文案（strings.xml）、_literal_diff.py 的
        //   KOTLIN_FILES 清单移除 OverlayProbe.kt 项。
        //   功能零缺失：删的是默认收起「更多设置 ▾」里、本就看不见的实验按钮。
        //   备份：_backup_before_p75_remove_probe_20261006/（5 文件）
        // ---------------------------------------------------------------------------
        // ★ 第 76 期：发帖多段内容输入简化 —— 加「＋ 添加一条」按钮（纯 UI，不动发帖判定）。
        //   按钮在 MainActivity.kt 的 setupPostPanel 里接线，点一下在光标处插入分隔符
        //   `\n---\n`，等价于用户手敲；parsePostBodies 的解析逻辑一字未动。
        //   备份：_backup_before_p76_post_input_20261006/（4 文件）
        // ---------------------------------------------------------------------------
        // ★★ 第 77 期：界面改版（**纯资源层，零 Kotlin 改动**）。
        //   目标：把「功能一个不能少」的既有界面做出明显更好看的观感。
        //
        //   改了什么（全部落在 res/ 下）：
        //     ① 调色板 +4 色键（明暗各一份，键一一对应）：hero_grad_start /
        //        hero_chip_bg / card_border / nav_active_bg。
        //     ② 新增 8 个 drawable：bg_hero（品牌渐变 22dp 圆角）/ bg_btn_primary
        //        （同款渐变 18dp）/ bg_chip（半透明白药丸）/ bg_field（浅灰底+细描边）/
        //        bg_warning（告警横幅圆角）/ bg_nav_item（抽屉选中高亮）/
        //        bg_nav_header（导航头渐变）/ ic_chevron_right（时间行可点提示）。
        //     ③ bg_account_row 加细描边（色名 row_bg 不变，InteractActivity 仍在用）。
        //     ④ themes.xml 新增 materialButtonStyle ⇒ 全 App 26 颗按钮从
        //        「实心品牌蓝」统一成「浅灰底 + 细描边 + 强调色文字」，
        //        主操作（立即签到 / 立即发送）用渐变 drawable 覆盖，层级一眼分明。
        //     ⑤ activity_main.xml：顶栏加 App 图标；签到页状态卡从白卡改成品牌渐变
        //        hero 卡（白字 + 药丸「查看详情 ▾」）；四张卡 16→20dp 圆角 + 细描边；
        //        时间行/输入框换 bg_field 并加「›」；抽屉加选中高亮。
        //     ⑥ activity_interact.xml：9 张卡同款圆角/描边，频率输入框换 bg_field。
        //     ⑦ item_account.xml / nav_header.xml：**只改属性值**（闸门 1 的 B 节
        //        要求元素树逐字节不变，所以没加图标、没包一层）。
        //
        //   ★ 为什么这一期风险极低：**一个 .kt 都没碰**。
        //     4 个 .kt 类闸门（core_untouched / string_blob_diff / literal_diff /
        //     p6_verify2 / interact_isolation）的输出与改前**逐字节一致**。
        //   ★ 控件零增删：四个布局的 android:id 集合改前改后完全相同
        //     （activity_main 45→45、activity_interact 39→39、item_account 6→6、
        //      nav_header 0→0；comm -23 全部为空）。
        //   备份：_backup_before_ui_face_20261007/（10 文件，md5 见报告）
        // ---------------------------------------------------------------------------
        // ★ 第 78 期：修主按钮被主题染色（**纯属性改动，2 个文件各加 1 个属性**）。
        //
        //   症状（真机 0.20.95 实测）：
        //     · 浅色模式：「立即签到」「立即发送」是**白字压浅灰底**，几乎看不见。
        //     · 深色模式：看着正常（白字压深灰底），所以只在浅色下暴露。
        //     · 效果图里这两颗按钮是**品牌渐变蓝**，真机却是浅灰 —— 观感对不上。
        //
        //   根因（读 material-1.12.0-sources.jar 的 MaterialButtonHelper.java 得出）：
        //     · 主题 materialButtonStyle 把 backgroundTint 定成了 @color/surface_muted。
        //     · 布局里写了 android:background ⇒ loadFromAttributes 里
        //       `if (attributes.hasValue(MaterialButton_android_background))`
        //       成立 ⇒ 调 setBackgroundOverwritten()，**不调 updateBackground()**
        //       ⇒ 我们的渐变背景**确实保留了**（不是被顶掉）。
        //     · 但 setBackgroundOverwritten() 里紧跟着一句
        //       `materialButton.setSupportBackgroundTintList(backgroundTint)`，
        //       把主题那条 surface_muted 当成**染色指令**重新盖到渐变上
        //       ⇒ 不透明单色 SRC_IN 一染，渐变整块消失。
        //
        //   修法：给这两颗按钮显式写 `app:backgroundTint="@null"`。
        //     backgroundTint 读出来是 null ⇒ setSupportBackgroundTintList(null)
        //     ⇒ 染色被清掉 ⇒ 渐变原样露出来。
        //
        //   ★ 为什么不用别的写法：
        //     · 换 AppCompatButton：能绕开，但改了视图类，没必要冒这个险。
        //     · 外面包一层 FrameLayout 扛渐变：多一层视图、还丢掉点击反馈。
        //     · 改成 app:backgroundTint 单色：丢掉渐变，观感直接退一档。
        //
        //   ★ 为什么风险极低：只加了 1 个 XML 属性 × 2 个文件，
        //     **一个 .kt 都没碰**，控件零增删，id 集合不变。
        //   备份：_backup_before_btn_tint_20261007/（2 文件）
        // ---------------------------------------------------------------------------
        // ★ 第 79 期：滑块缺口匹配提速（**改 1 个 .kt，纯提速，判定逐位零改动**）。
        //
        //   症状：单次 solve 约 4.4 秒，滑块验证整轮被拖到 7 秒级。
        //
        //   先排除两条看起来很美、实际不成立的路：
        //     · 积分图：它只能加速分母的 ΣI²。实测把整个 ΣI² 删掉，
        //       耗时也只从 3070ms 降到 2101ms ⇒ 能量项仅占 34%，
        //       积分图理论上界 1.52×，永远到不了百毫秒级。
        //     · 算法改写（FFT 互相关 / 换累加结构 / 换 Double）：都会改变浮点
        //       求和顺序，分数出现 1e-7 以上偏差。易盾图上**存在分数极接近的次峰**
        //       ⇒ 这种偏差有翻盘风险，与「判定零改动」冲突，一律否决。
        //
        //   真正管用的：**内层热循环被「逐字节读取 + AND 0xFF + int→float 转换」
        //   和 Array<FloatArray> 的二次间接卡住了。**
        //     · bg 的四通道预先转成平面 FloatArray（纯搬运，无运算）；
        //     · 模板四通道拍平成一维数组；
        //     · 掩码内像素预先存好「相对模板左上角的像素偏移」⇒ 内层免掉整数除法。
        //
        //   实测（PC 侧单文件真编，8 组真实样本，预热 2 次取最快 5~8 次，去首组）：
        //     基线 3011~3070ms → 986~1019ms ⇒ **约 3.0×**；
        //     单次 solve 由约 440ms 降到约 140ms。
        //
        //   ★★★ 等价性是**逐位**的，不是近似：
        //     · 预存的 Float 与 (byte & 0xFF).toFloat() 是同一个值；
        //     · 内层 num / sumI2 的累加顺序与舍入点与基线一字不差；
        //     · 8 组样本的整张 result 矩阵做了逐位指纹
        //       （FNV-1a over floatToRawIntBits）——8/8 完全相同，
        //       max_loc / gap_left / score 自然全同。
        //     ⇒ 程序做出的决定**一模一样**，不是「差不多」。
        //
        //   ★ 闸门：6/7 道输出与改前**逐字节一致**；只有 _audit_core_untouched.py
        //     报 SliderMatch.kt 的 matchCcorrNormed 一个函数原语有变
        //     （多出显式乘加、for/in 消失、整数除法 2→1），全部可逐条解释。
        //   ★ 未动的部分：solve / extractAlpha / thresholdBinary / boundingBox /
        //     cropRgba / cropGray / minMaxLoc 一个字都没改。
        //   备份：_backup_before_slider_planar_20261007/（1 文件）
        // ---------------------------------------------------------------------------
        // ★ 第 80 期：修发帖批次 bug（**改 1 个 .kt，只改「发帖拿哪些账号」这一步**）。
        //
        //   症状：账号数 ≥ 4 且开着自动发帖时，**只有账号列表最前面 3 个发得满**，
        //     第 4 个往后永远停在第一条；之后每 20 分钟空转一轮（日志是「都发满了」），
        //     一直空转到跨天。用户视角 = 「后加的账号永远不发帖，还一直弹通知」。
        //
        //   根因（一处代码，两个入口）：
        //     runCheckin 里选批次的兜底分支是
        //         (if (pool.isNotEmpty()) pool else ready).take(BATCH_SIZE)
        //     签到池 pool 一旦跑空（当天所有账号都签过一遍），它就**恒等于**
        //     ready.take(BATCH_SIZE) —— 一个固定不变的前 3 个账号。
        //     而发帖阶段直接复用了这个 batch ⇒ 每轮都在给同样 3 个账号发，
        //     它们发满后 runPostPhase 里那个 continue 把整轮变成 no-op，
        //     真正还欠帖子的账号一次都轮不到。
        //     executePostOnce（手动 / 关闭签到只留发帖那条路）里的
        //     ready.take(BATCH_SIZE) 是同一个 bug 的第二处。
        //
        //   ★ 为什么不是「签到也错了」：签到池跑空后那次兜底签到本身廉价 ——
        //     WeiboClient 里 pending 为空会直接返回 SUCCESS，只拉一次超话列表。
        //     所以问题只在「把签到批次当发帖批次传下去」这一步。
        //
        //   修法：发帖用**发帖自己的池子**
        //     AccountStore.postPending(today, postPerAccount)
        //       = 已启用 + 已登录 + 不在静置 + 无需验证 + 今天没发够
        //     它是 ready() 的**子集** ⇒ 不会放进任何 ready 之外的账号，
        //     只是把入参收窄到真正还欠帖子的账号；下一轮自然轮到后面那批。
        //
        //   ★★★ 硬规则一的边界（这一版最要紧的一句）：
        //     · 签到批次那三行（pool / batch / remainingAfterBatch）**逐字未动**；
        //     · 只新增两行（postPool / postBatch），并把两处 runPostPhase 的入参
        //       由 batch 换成 postBatch；
        //     · 签到链路的分批、池子优先级、兜底、排程判据全部不变。
        //     ⇒ 签到那一侧的行为与第 79 期**逐字等价**。
        //     · 发帖的「每轮每账号一条」「间隔 postIntervalMinutes」「失败/风控处理」
        //       「进度落盘时机」一律未动 —— 变的只是「这一轮挑哪几个账号」。
        //
        //   ★ allAccounts = true 的两条路（手动「立即签到」/「立即发帖」）改前改后
        //     结果完全相同：ready 里那些今天已发够的账号在 runPostPhase 里本来就被跳过。
        //     唯一差别是少了几次空转迭代、唤醒锁按真实待发账号数申请。
        //
        //   ★ 验证：源码侧真编译 clean assembleDebug（告警数 = 基线 9）；
        //     7 道闸门逐条归因；AgentService.kt 属链路① 执行器 ⇒
        //     按第 48 期机制在 _audit_interact_isolation.py 的 APPROVED_CHANGES
        //     里扩写该文件的条目（含新 md5），并做篡改自测。
        //   备份：_backup_before_post_batch_20261007/（2 文件）
        // ---------------------------------------------------------------------------
        // ★ 第 81 期：发帖正文改成「逐条语料库」（**纯界面，1 个 .kt + 2 个 XML + 文案**）。
        //
        //   用户的诉求（原话）：「发帖内容，显示添加一条，但他添加的是符号，
        //     我的需求是弄一个类似于语料库，把想发的内容一条一条加进去」。
        //   症状：点「＋ 添加一条」只是在光标处插一个 `---` —— 用户在输入框里看到的
        //     就是三个短横线，既不知道那是「一条的分界」，也不好删（得手动删符号）。
        //
        //   改法：正文区域变成**一行一条的语料库**：
        //     · activity_main.xml 新增容器 postBodyList，第一行是静态的
        //       postContentEdit（id、位置都不变）+ 一个删除按钮；
        //     · 新增 item_post_body.xml 作为第 2..N 行的模板；
        //     · MainActivity 运行时按 Prefs.postContentText 拆段铺开，
        //       「＋ 添加一条」改为**追加一个输入框**，「删除」去掉某一行，
        //       行数 > 1 时才显示删除按钮（不许把语料库删成 0 条）；
        //     · 新增「共 N 条」提示，让用户一眼看到自己填了几条。
        //
        //   ★★★ 硬规则二的边界（这一版最要紧的一句）——**存储与判定一个字都没动**：
        //     · Prefs.postContentText 仍是「各行用一行 --- 连接」的**单字符串**，
        //       键名、类型、写入时机（失焦 / onPause / 点测试 / 开开关）全部照旧；
        //     · AgentService.parsePostBodies 的切段正则 `(?m)^\s*-{3,}\s*$`
        //       与发帖判定**一行未改**，AgentService.kt 本轮**没碰**；
        //     · MainActivity 里那份 splitPostBodies 与上述正则**逐字相同**，
        //       且只用于界面回显 —— 显示的分段必须与真正发出去的分段一致，
        //       否则就是「看到的和发出去的不一样」，属最难查的一类问题。
        //     ⇒ 「程序会做出不同的决定吗？」不会：改前改后落盘的字符串完全相同。
        //
        //   ★ 为什么不能「删掉 postContentEdit 再统一动态生成」：
        //     删控件 = 违规。既有控件必须原地保留 ⇒ 第 1 行静态、第 2..N 行动态，
        //     两者在代码里用同一个 id 走同一条分支（row.findViewById 从行内取）。
        //
        //   ★ 保留既有能力：超话框的「一行一个链接」与正文语料库无关，未动；
        //     「立即发一条试试」、自动保存提示、条数/间隔校验全部照旧。
        //
        //   ★ 验证：源码侧真编译 clean assembleDebug（告警数须 = 基线 9）；7 道闸门逐条归因。
        //   备份：_backup_before_post_corpus_20261007/（4 文件）
        // ---------------------------------------------------------------------------
        // ★ 第 82 期：修「发帖只发一轮就不发了」（**改 1 个 .kt，3 处**）。
        //
        //   症状（用户原话：发帖就发了一次，后面就不发了）：
        //     自动发帖开着、账号 4 个、每账号 3 条，但只发了第一轮 4 条（进度 4/12），
        //     之后 30 多分钟一条都没再发。
        //
        //   根因（`CheckinAlarmReceiver.kt` 第 18 行的守卫漏改）：
        //     闹钟广播收到的第一件事是 `if (!Prefs.scheduleEnabled) return` ——
        //     它在问「自动签到开了吗」。用户只开了发帖、没开签到 ⇒
        //     **主闹钟和备用看门狗响了之后都被直接扔掉**，服务根本没被拉起来。
        //     而进程一旦被 ROM 冻结（唤醒锁挡不住冻结），服务内循环也停了 ⇒
        //     两条唤醒通道同时失效 ⇒ 发帖永远停在第一轮。
        //
        //   ★ 这是「漏改」而不是「设计如此」：
        //     `Prefs.automationEnabled`（= scheduleEnabled || postEnabled）的注释白纸黑字写着
        //     「调度、闹钟、守护循环的判断都要用这个值」。查一遍现状 ——
        //       调度 ensureScheduled / hasPendingWork ................ 已用
        //       守护循环 AgentService:471 ........................... 已用
        //       服务自停 AgentService:194/215 ....................... 已用
        //       发帖排程 AgentService:268 ........................... 已用
        //       闹钟 CheckinAlarmReceiver:18 ........................ 漏了（本次补上）
        //
        //   三处改动：
        //     ① `if (!Prefs.scheduleEnabled) return` 改成 `if (!Prefs.automationEnabled) return`；
        //     ② `lastAlarmAt`（闹钟心跳）的写入**提到守卫之前** ——
        //        原来它写在守卫后面，闹钟响了但被挡掉时不会写，报告里「闹钟最近触发」
        //        显示无记录，与「闹钟压根没响」长得一样，没法区分。提前之后一眼可分；
        //     ③ 到点后的 action 由 `if (due) ACTION_RUN_CHECKIN else ACTION_START_SCHEDULED`
        //        改成按开关分流：只开发帖时走 `ACTION_RUN_POST` ——
        //        否则 `ACTION_RUN_CHECKIN` 会进 executeOnce()（那条路不看签到开关），
        //        把只开发帖的用户顺带带去签到。
        //
        //   ★★★ 硬规则边界：
        //     · 签到开着的用户走的分支与改前**逐字相同**（ACTION_RUN_CHECKIN + 同一套续期）；
        //     · 只改「闹钟响之后做什么」，不改任何存储格式、不改发帖/签到的判定规则、
        //       不改 `nextRunAt` 的写入时机；
        //     · `CheckinAlarmReceiver.kt` 在隔离闸 CHAIN_FILES（链路① 闹钟接收）里 ⇒
        //       按第 48 期机制在 `_audit_interact_isolation.py` 的 APPROVED_CHANGES
        //       里**新增**该文件的条目（含新 md5），并做篡改自测。
        //
        //   ★ 验证：真编译 clean assembleDebug（告警须 = 基线 9）；7 道闸门逐条归因。
        //   ★ 本版（140 / 0.20.99）**包含第 81 + 82 两期改动** —— 0.20.99 从未发布过，
        //     一次出包同时带上语料库与闹钟修复。
        //   备份：_backup_before_alarm_guard_20261007/（2 文件）
        // ---------------------------------------------------------------------------
        // ---------------------------------------------------------------------------
        // ★ 第 83 期：外观改成「默认浅色 + 设置页可切深色」（**新增 1 个 .kt，改 5 个文件**）。
        //
        //   症状（用户原话：我要的是所有手机看到的就是浅色模式，而不是需要去设置里调）：
        //     手机系统开着深色 ⇒ 整个 App 跟着变深色。用户不想为了这个去改手机的系统设置。
        //
        //   改动（全部落在显示层，不碰任何判定）：
        //     ① 新增 `App.kt`：Application 入口 + `UiTheme`（界面偏好）。
        //        在 Application.onCreate 里 `AppCompatDelegate.setDefaultNightMode(...)` ——
        //        放这里而不是 MainActivity，是因为本应用还有两条**绕过 MainActivity**
        //        把界面拉起来的路径：闹钟到点起前台服务；进程被回收后从最近任务直接重建互动页。
        //     ② `AndroidManifest.xml`：`<application>` 加 `android:name=".App"`。
        //        ★ 只加属性、不动元素树 —— 闸门 1 对「新增 / 变更属性」要求逐条说明即可。
        //     ③ `values/themes.xml`：补 `android:forceDarkAllowed=false`。
        //        ★★ 这一条不写，本轮功能**当场失效**：默认强制浅色之后会出现
        //        「系统深色 + 应用浅色」这个组合 —— 而它恰好是 Android 10 强制深色
        //        唯一会介入的组合，系统会把调好的浅色配色再自动反色一遍。
        //        （第 5 期那段注释说「不加是死代码」，前提是「跟系统走」；第 83 期起前提反了。）
        //     ④ `values-night/colors.xml`：**只改头部注释** —— 原来写着「跟随系统、没有 App 内开关」，
        //        已经变成假话。调色板本身一个色值都没动，深色仍由它承担。
        //     ⑤ `activity_main.xml`：设置页顶部新增一张「外观」卡（1 个 SwitchCompat）。
        //        ★ 只加控件，没有删掉任何一项（删控件 = 违规）。
        //     ⑥ `MainActivity.kt`：接线开关；并补 `onSaveInstanceState` +
        //        `setupDrawer(initialPageItemId)` —— 切主题会重建 Activity，
        //        不处理的话用户点完开关会被弹回签到页。
        //
        //   ★★★ 硬规则边界：
        //     · 开关状态存**独立的界面偏好文件**（`ui_theme`），与 `Prefs` 零交集 ——
        //       `Prefs.kt`（CORE_KT，md5 锁死）一个字节都没动；
        //     · 不碰四条链路、不删任何控件、不碰文案以外的判定；
        //     · 判据自检：这个开关会让程序做出不同的决定吗？不会 ——
        //       它只决定像素用哪套颜色，签到 / 发帖 / 验证 / 账号里的判断一个都不参与。
        //
        //   ★ 验证：真编译 clean assembleDebug（告警须 = 基线 9）；7 道闸门逐条归因。
        //   备份：_backup_before_theme_toggle_20261007/（6 文件）
        // ---------------------------------------------------------------------------
        // ★★★ 第 84 期：互动模块新增第 4 种动作「转发」（`InteractAction.REPOST`）。
        //
        //   本轮改了 7 个文件（全部落在**互动模块**内，四条核心链路一行未动）：
        //     ① `res/values/strings.xml`             +8 条文案
        //     ② `InteractTask.kt`                    枚举 3 值 → 4 值
        //     ③ `InteractProbe.kt`                   REPOST_URL / repostForm / postRepost /
        //                                            judgeRepost / probeRepost
        //     ④ `InteractRunner.kt`                  rehearse 判据修正 + send 分派 + doRepost
        //     ⑤ `res/layout/activity_interact.xml`   +2 控件（探测按钮 + 说明）
        //     ⑥ `InteractActivity.kt`                接线 + runRepostProbe
        //     ⑦ `app/build.gradle.kts`               ← 本文件，**只改版本号**
        //
        //   ★ 为什么要提版本：CI 的 `softprops/action-gh-release` 用
        //     `tag_name = v<versionName>`。若沿用 0.21.00，CI 会**覆盖已发布的
        //     那个 Release 及其 APK 资产**（下载页指向的就是它）。提版本才安全。
        //   ★ 下载页（gh-pages）**本轮不推** ⇒ 0.21.01 先当内部测试包，
        //     等「超Like 一键编排」做完再一起上架。
        //
        //   ★ 判据自检（硬规则二）：版本号会让程序做出不同的决定吗？不会 ——
        //     它是**包元数据**，只在「安装 / 覆盖安装」时被系统比较，
        //     运行期的签到 / 发帖 / 验证 / 账号判断一条都不参与。
        //
        //   ★ 验证：真编译 clean assembleDebug（告警须 = 基线 9）；8 道闸门逐条归因；
        //     隔离闸篡改自测（绿 → 红 → 绿）。
        //   备份：_backup_before_p84_repost_20261008/（7 文件）
        // ---------------------------------------------------------------------------
        // ★★★ 第 84 期续（C 段）：互动模块新增「超Like 一键编排」。
        //
        //   规格来自竞品「张奕然超话助手 v1.0.6」（用户 2026-10-08 明确要求参照它）：
        //     微博官方「超Like」= **超话签到 ×1 + 首评 ×4 + 转发 ×2**，
        //     配比是竞品**自己的完成文案**写死的，不是猜的。
        //
        //   ★ 用户拍板的两件事：
        //     ① 功能**放互动页**，不新建独立页 —— 超Like 的 2/3（首评 / 转发）
        //        本来就在互动模块里，放进去是「本就在那儿，只缺一个编排器」；
        //        新建独立页要碰 `drawer_menu.xml` + `AndroidManifest.xml`
        //        两个**被锁的核心 XML**，代价大得多。
        //     ② **编排不管签到** —— 签到是核心链路①（AgentService）的职责，
        //        本来就按用户设的时间自动跑，编排再签一次等于伸手进核心链路。
        //
        //   本轮改/加了 8 个文件（全部落在**互动模块**内，四条核心链路一行未动）：
        //     ① `res/values/strings.xml`             +30 条文案（含 interact_title 补「转发」）
        //     ② `InteractProbe.kt`                   LatestPost 公开 + commentsCount /
        //                                            CommentBrief + floorNumber /
        //                                            topicPosts / ownTimeline（可空返回值）
        //     ③ `SuperLikePlan.kt`                   ★新文件，配比模型
        //     ④ `SuperLikeRunner.kt`                 ★新文件，编排执行器
        //     ⑤ `InteractTaskStore.kt`               + KEY_PLAN / plan() / savePlan()
        //     ⑥ `res/layout/activity_interact.xml`   +超Like 折叠卡（10 个控件，默认收起）
        //     ⑦ `InteractActivity.kt`                接线 + 10 个新方法
        //     ⑧ `app/build.gradle.kts`               ← 本文件，**只改版本号**
        //
        //   ★ 三条判据（都是从竞品扒出来、逐条对齐的）：
        //     · 「首评」候选 = 回包**明确说** `comments_count == 0` 的帖子
        //       （`-1` = 回包没给 ⇒ **绝不当候选**，写成 `<= 0` 就会去评一条
        //        不知道有没有人评过的帖子，那条评论大概率不是首评，白占额度）；
        //     · 发完必须**读回来核对** `floor_number == 1`，被抢先的不计入、
        //       继续找下一条帖子（竞品文案：「刚刚被抢首评，未计数，继续找帖」）；
        //     · 转发前先读**自己的时间线**，最近转过的跳过；时间线**读不到**
        //       就整步跳过 —— 原则是竞品那句「宁可漏做，绝不重复转发」。
        //
        //   ★ 为什么要提版本：同前一段（CI 用 `tag_name = v<versionName>`，
        //     沿用 0.21.01 会覆盖已发布的那个 Release 及其 APK 资产）。
        //   ★ 下载页（gh-pages）**本轮仍不推** ⇒ 0.21.02 与 0.21.01 一样是
        //     内部测试包，等真机把三个未证假设验完再一起上架。
        //
        //   ★ 判据自检（硬规则二）：版本号会让程序做出不同的决定吗？不会 ——
        //     它是**包元数据**，运行期的签到 / 发帖 / 验证 / 账号判断一条都不参与。
        //
        //   ★ 验证：真编译 clean assembleDebug（告警须 = 基线 9）；8 道闸门逐条归因；
        //     隔离闸篡改自测（绿 → 红 → 绿）。
        //   备份：_backup_before_p84c_superlike_20261008/（7 文件 + _md5_before.txt）
        //
        // ---------------------------------------------------------------------------
        // ★★ 第 85 期：修「超话输入框不认裸 ID」（真机验出来的 bug）。
        //
        //   ★ 病因：`InteractTarget.topicId()` 只有两条正则，**都要求带链接前缀**
        //     （`/(?:p|page)/100808<hex>` 和 `containerid=100808<hex>`）。
        //     于是往超话输入框里粘一个**裸 ID** `100808db807a…`，两条都不匹配
        //     ⇒ 报「这个链接里读不出超话 ID，换一个再试」。
        //     可界面上的提示一直写着「粘超话的链接**或 ID**」—— **提示在骗人**。
        //     （真机实测：21:2x 粘裸 ID 直接弹这个 toast，用户截图确认。）
        //
        //   ★ 修法：`topicId()` 末尾加一条 `TOPIC_BARE`，用 **`matches()`**（整串匹配）
        //     认下裸 ID。**只加在 `topicId()`，`kind()` 一行没动** ——
        //     `kind()` 是「互动任务目标」的分流器，那边一个裸 ID 必须继续按
        //     `PURE_ID` 当**微博 mid**；把裸 ID 判成超话会让「只填 mid 的任务」全废。
        //
        //   ★ 为什么用 `matches()` 而不是 `find()`：`find()` 会把
        //     `随便什么100808<hex>随便什么` 也认成超话 —— 那等于把「解析失败」
        //     悄悄变成「解析成功、但 ID 是从一串东西里猜的」，猜错就去读别人的超话。
        //
        //   ★ 判据自检（硬规则二）：会让程序做出不同的决定吗？**会** ——
        //     但它只把「以前必然报错的输入」变成「按提示所说的那样正常工作」，
        //     属于**修 bug**（第 85 期，用户已确认）。
        //     且**只增不减**：加一条正则只会多认一种输入，老形态一条都没失效。
        //     证据：`_p85_topicid_truth/TopicIdTruth.java`（JDK 同一套正则引擎，
        //     17 条用例全绿：新形态命中 / 老形态照旧 / 垃圾输入继续拒绝 /
        //     `kind()` 对裸 ID 仍然不是超话）。
        //
        //   ★ 顺带：`interact_superlike_topic_hint` 写清楚两种写法（文案）。
        //   备份：_backup_before_p85_bare_topic_20261008/（9 文件 + _md5_before.txt）
        // ---------------------------------------------------------------------------
        // ★★★ 第 86 期（versionCode 145 / versionName 0.21.04）—— 发帖页加显式保存按钮
        //
        //   起因（用户原话）：发帖页改「每个账号发几条」和「间隔时间」时不会自动保存，
        //     必须去点正文那边才会保存 —— 希望旁边有一个保存按键。
        //
        //   ★ 查证结论：发帖页**本来就是自动保存**，触发时机是**输入框失焦**
        //     （`setupPostPanel` 里的 `autoSave`，挂在 `postTopicsEdit` /
        //     `postCountEdit` / `postIntervalEdit` 三个框上），另有 `onPause` 的
        //     静默兜底（`silentSavePostConfig`）。
        //     ⇒ 用户看到的「点正文才保存」，其实是**条数 / 间隔框一直没失焦**：
        //       键盘上点完成键在部分机型不触发 focus change，数字停在框里
        //       没有任何反馈，看上去就像没保存。
        //
        //   ★ 改法（**只加不减**）：
        //     ① 布局：把原提示 `postAutoSaveHint` 与新增的 `postSaveButton`
        //        并排放进一个横向 LinearLayout（原 TextView 保留，只是宽度改 0dp + weight）；
        //     ② 代码：`postSaveButton` 的点击处理**复用** `autoSave` 那套校验 +
        //        `persistPostConfig`，非法值同样报错回退 —— 写入规则一字未改；
        //     ③ 文案：`post_autosave_hint` 原文写「不用再点保存」，与新按钮矛盾，
        //        改成「改动会自动保存（点到别处即存），也可以点右边按钮立刻存一次。」，
        //        并新增 `post_manual_save` = 「保存」。
        //        ★ 键名特意**不带 `post_save` 前缀**：闸门 2（`_p2_ui_verify.py:220`）
        //          判定「已删字符串是否仍被引用」时用的是 `"@string/" + k in xml`（**子串**，
        //          无词边界），`REMOVED_KEYS` 里有历史删除的 `post_save` ⇒ 叫 `post_save_now`
        //          会被**误报**成「已删字符串 post_save 仍被 activity_main.xml 引用」。
        //          改叫 `post_manual_save` 后闸门 2 恢复全绿。
        //
        //   ★ 判据自检（硬规则二）：会让程序做出不同的决定吗？**不会** ——
        //     `Prefs.postTopicsText` / `postContentText` / `postPerAccount` /
        //     `postIntervalMinutes` 的**键名、类型、取值范围、非法值回退策略
        //     全部未动**；失焦保存与 onPause 兜底**全部保留**；
        //     本按钮只是**多一个触发入口**，且走的是同一个 `persistPostConfig`。
        //     ⇒ 属于「UI 新增」（硬规则二允许），发帖链路的行为不变。
        //   备份：_backup_before_p86_post_save_20261008/（4 文件 + _md5_before.txt）
        // ---------------------------------------------------------------------------
        // ★★★ 第 87 期（versionCode 146 / versionName 0.21.05）—— 超Like：失败也节流 + 账号级限流立即停手
        //
        //   起因（用户贴的 2026-10-09 11:43 真机日志，4 账号试跑）：
        //     账号「伟大族丝」转发第 2 条时，微博回 `20016 / 操作频繁，请您稍后再试`，
        //     结果**同一条失败被打了 14 次**、19 秒内共 14 个写请求。
        //
        //   ★ 根因（两个，都在 `SuperLikeRunner.run()` 的循环控制里）：
        //     ① **失败不暂停**：`pause()` 只挂在**成功**分支后面，失败走 `continue`
        //        直接进下一次 ⇒ 零间隔连打。日志铁证：11:43:53 一秒内 3 次 POST，
        //        相邻只差 412ms / 266ms（= 纯网络往返），而成功那次的后面老老实实停了 2352ms。
        //     ② **账号级错误没有「停手」语义**：`20016 操作频繁` 是**账号级**限流，
        //        换哪条帖子结果都一样；但代码把它当「这条帖子不行」，`continue` 换下一条
        //        ⇒ 对剩余 13 条帖子各打一次，**在已被限流的情况下继续加压**。
        //
        //   ★ 改法（三处，**不新增任何写请求、不改任何成功/失败判定**）：
        //     ① `InteractProbe.SendOutcome` 新增**结构化**字段 `errno: String = ""`
        //        （默认值 ⇒ 所有既有调用点源码级不变），由 `judgeCreate` / `judgeRepost`
        //        把回包里的 `errno` **原样**带出；`postComment` / `postRepost` 的
        //        「拿不到 st」分支带本地哨兵 `InteractProbe.ERRNO_NO_ST`（= "no_st"）。
        //        ★ 为什么必须是结构字段：`detail` 是**给人看的拼好的文案**，
        //          拿它做判断就是「认文案」（第 20 条纪律禁止）。
        //     ② `SuperLikeRunner` 两个循环的失败分支**补上 `pause()`** ⇒ 写请求一律节流。
        //     ③ `SuperLikeRunner` 新增 `STOP_ERRNOS = {"20016", "100006", NO_ST}`
        //        + `isAccountLevel(errno)`：命中即**结束本轮**（首评阶段命中还会
        //        `!stopped` 掉整个转发段），并打印新文案 `interact_superlike_stop`。
        //        ★ `20130 暂无查看权限`（目标级）**故意不在表里** —— 换下一条是对的。
        //        ★ `errno` 为空（网络失败 / 非 JSON）一律按目标级 ⇒ **不擅自停手**，
        //          避免一次网络抖动把整趟编排误判成「被限流」。
        //
        //   ★ 判据自检（硬规则二）：会让程序做出不同的决定吗？**会** ——
        //     所以本期改动**先经用户拍板**（用户在四个选项里明确勾了
        //     「失败也暂停」+「账号级限流立即停手」两项，并选了「合并进下一期」）。
        //     ★ 未采纳的两项（用户明确不选）：默认每小时上限 5 → 8、失败行编号统一。
        //     ★ 改的都是**互动模块自己的文件**（`InteractProbe.kt` / `SuperLikeRunner.kt`），
        //       不碰 CORE_KT / 链路执行器 / 任何共享状态（隔离闸门 7 全绿）。
        //   备份：_backup_before_p87_stop_policy_20261009/（4 文件 + _md5_before.txt）
        // ---------------------------------------------------------------------------

        // ★★★ 第 88 期（versionCode 147 / versionName 0.21.06）—— 超Like：诊断日志拆开「候选 0 条」的两种可能
        //
        //   起因（用户 2026-10-09 报）：4 账号跑超Like，**只有前两个账号完成了首评**，
        //     后两个账号首评 0 条；同一份日志里账号 3/4 的候选池是「0 评论 0 条」。
        //
        //   ★ 问题：原日志只印 `count { commentsCount == 0 }` ⇒ 「候选 0 条」两种可能分不开：
        //     ① 那批帖子**真的**都有人评论过（回包 `comments_count` 都是正数）；
        //     ② 回包**根本没给** `comments_count` 字段 ⇒ `optInt(..., -1)` 全判 -1 ⇒ 全落选
        //        （候选只认 `== 0`，见 `LatestPost.commentsCount` 的注释）。
        //     两者的处置方向完全相反（②要改筛选口径，①只是窗口太短），必须能分开。
        //
        //   ★ 改法（一处，**纯诊断**）：`InteractProbe.topicPosts()` 那行日志补
        //     三分类计数（0 评论 / 回包没给评论数 / 有评论）+ 评论数分布直方图 +
        //     `body.full.contains("\"comments_count\"")` 字段名检测。
        //
        //   ★ 判据自检（硬规则二）：会让程序做出不同的决定吗？**不会** ——
        //     只往互动日志多写一行文本，**不新增/不删除任何请求，不改任何判定**，
        //     连 `InteractTrace` 本身都没动（`log()` 本就无条件记录，release 包可见）。
        //     ★ 只改互动模块自己的文件（`InteractProbe.kt`），不碰 CORE_KT / 链路执行器 /
        //       任何共享状态（隔离闸门 7 全绿）。
        //   备份：_backup_before_p88_topic_diag_20261009/（2 文件 + _p88_md5_before.txt）
        // ---------------------------------------------------------------------------

        // ★★★ 第 89 期（versionCode 148 / versionName 0.21.07）—— 超Like：查清「怎么切到『最新』流」（只读诊断）
        //
        //   起因（用户 2026-10-09 报）：「**有关注，可不可以把首评从最新里面找帖子**」。
        //     上一轮（第 88 期）真机日志已经给出定论：
        //       `[超Like] 可用帖子 15 条 … 有评论 15 条；回包含 comments_count 字段名=true`
        //       评论数分布 `{ 5×1 10×1 18×1 24×1 27×2 28×1 29×1 33×1 34×1 75×1 400×1 434×1 435×1 879×1 }`
        //     ⇒ 15 条**全部**都有评论（最少 5、最多 879），字段名也在。
        //     ★ 若真是「按最新排」的 feed，最新几条的评论数应从 0 往上递增；这里是**按热度**
        //       排的 ⇒ **那个 feed 根本不是「最新」流**，热门帖当然条条都有评论
        //       ⇒ 候选天然为 0。**星签的判据（只认 `commentsCount == 0`）没错，错的是取数的那个流。**
        //
        //   ★ 目标：切到「最新」流 —— 只有刚发出、还没人评论的帖子才可能抢到首评。
        //   ★ 难点：超话排序 containerid 的后缀**从未被实测确认过**，且**PC 侧验证不了**
        //     （m 站无 Cookie 一律 302 到访客墙，带 Cookie 也被风控回 432）⇒ 只能真机取证。
        //
        //   ★ 改法（两段，**全只读**，★ 用户已选「先出诊断包」）：
        //     ① `diagnoseTopicCards()` —— **零额外请求**，只解析**已经拿到的那一份回包**：
        //        `cards[].card_type` 分布 / `data.tabsInfo.tabs[]`（每项自带 containerid）/
        //        `data.cardlistInfo` / 不带 `mblog` 的卡的 `card_group` 里 title·scheme 线索。
        //     ② `probeSortVariants()` —— **+2 个只读 GET**，对 `containerId + "_-_sort_time"`
        //        与 `"_-_sort_hot"` 各请求一次，打印 HTTP 头 + 可用条数 + 0 评论条数。
        //     另：把 `ownUid(account)` 的结果**存一次**复用（求值时机不变），免得试探重发 `/api/config`。
        //
        //   ★ 判据自检（硬规则二）：会让程序做出不同的决定吗？**不会** ——
        //     `topicPosts()` 的返回值**一个字节都没变**（试探结果只进日志，不参与任何判定）；
        //     两段诊断**都不改筛选口径、不动 `STOP_ERRNOS`、不碰 `SuperLikeRunner` 的编排**。
        //     ★ 唯一的「行为变化」是**多发 2 个只读 GET**，而这正是用户批准的诊断包内容。
        //     ★ 只改互动模块自己的文件（`InteractProbe.kt`），不碰 CORE_KT / 链路执行器 /
        //       任何共享状态（隔离闸门 7 全绿）。
        //   ★ 下一步（**未做，要先问用户**）：若诊断确认了「最新」流的 containerid，
        //     才轮到改取数来源 —— 那属于「会让程序做出不同决定」，必须先经用户逐条批准，
        //     且需同步评估 `InteractTarget.TOPIC_BARE` 的**全串匹配**（带后缀 ID 会被判成 mid）。
        //   备份：_backup_before_p89_sort_probe_20261009/（2 文件 + _p89_md5_before.txt）
        // ---------------------------------------------------------------------------

        // ★★★ 第 90 期（versionCode 149 / versionName 0.21.08）—— 超Like：首评改走「最新」流 + 自动回退
        //
        //   起因（用户 2026-10-09）：「**有关注，可不可以把首评从最新里面找帖子**」。
        //     第 89 期按用户拍板先出**只读诊断包**，2026-10-09 19:58 四账号真机跑完，
        //     结论**推翻了第 88 期「这个 feed 是按热度排的」那条推断**：
        //       · 基准 containerid 是个**不可预测的混合流** —— 同一账号同一 containerid，
        //         19:07 分布 `{5×1 … 879×1}`（最少 5 条评论）、19:58 分布 `{0×4 1×10 2×2 4×2}`；
        //         同一时刻四个账号拿到的也各不相同（1/2 像热门池、3 像按时间、4 像最新）。
        //         ⇒ **这才是「有时候能抢到首评、有时候一条都没有」的真正根因**。
        //       · 而 `containerId + "_-_sort_time"` 在**四个账号上无一例外**都给出 0 评论帖
        //         （5 / 10 / 5 / 9 条，占比都约 **50%**）；对照组 `_-_sort_hot` 一致更少
        //         （3 / 6 / 2 / 5）⇒ 两个后缀被服务端**区别对待**，`time` = 最新。
        //         ★ 这是**结构证据**（第 20 条纪律），不是猜的。四个账号全部 HTTP 200。
        //
        //   ★ 用户拍板（三选一）：**「换最新流 + 自动回退（推荐）」**。
        //
        //   ★ 改法（`InteractProbe.kt`，一处）：
        //     ① `topicPosts()` 先请求 `containerId + "_-_sort_time"`；
        //     ② 若拉回的候选里**有 0 评论帖** ⇒ 直接用它（**正常路径，0 个额外请求**）；
        //     ③ 若「最新」流里**一条 0 评论帖都没有** ⇒ 回退到**基准 containerid**，
        //        也就是第 89 期之前的老行为 ⇒ **最坏情况不比改之前差**；
        //     ④ 两个流都没有 0 评论帖时，才调用第 89 期的 `diagnoseTopicCards()` 打回包结构
        //        （**异常路径专属**，正常不占日志缓冲）。
        //     ⑤ 把「拼 URL → GET → 解析 → 打三分类日志」抽成 `fetchTopicPosts()`（两次请求共用）；
        //     ⑥ **删掉** `probeSortVariants()` 与 `SORT_PROBE_SUFFIXES` —— 试探的使命已完成，
        //        而且 `_-_sort_time` 现在就是正式取数路径，再试探纯属重复请求（每次省 2 个 GET）。
        //     ⑦ 第 88 期的**三分类日志原样保留**（换流之后同样要靠它看「新流给了几条 0 评论帖」）。
        //
        //   ★ 判据自检（硬规则二）：会让程序做出不同的决定吗？**会** ——
        //     所以**先问过用户、拿到明确批准**才动手（用户选了「换最新流 + 自动回退」）。
        //     ★ 影响面**只有超Like 编排**：`topicPosts()` 的唯一调用点是
        //       `SuperLikeRunner.kt:373`。签到 / 发帖 / 验证三条链路一行未动。
        //     ★ `InteractTarget.topicId()` **不需要改** —— 后缀是在 `topicPosts()` 内部拼的，
        //       `topicId()` 仍然只返回纯 `100808<hex>`（所以 `TOPIC_BARE` 的全串匹配不受影响）。
        //     ★ 首评与转发**共用同一个帖子列表** ⇒ 会一起切到最新流（转新帖其实更像真人）。
        //       这一点已在给用户的选项说明里写明，用户知情。
        //     ★ 请求数变化：正常 **1 个 GET**（与改之前相同，`_-_sort_time` 顶替了基准）；
        //       最坏 **2 个 GET**（回退时）；另外**省掉**了第 89 期试探的 2 个 GET ⇒ 净减少。
        //   备份：_backup_before_p90_sort_time_20261009/（2 文件 + _p90_md5_before.txt）
        // ---------------------------------------------------------------------------

        // ===========================================================================
        // ★★★ 第 91 期（versionCode 150 / versionName 0.21.09）—— 超Like：核对楼层时加「只读诊断」
        //
        //   起因（第 90 期真机暴露）：2026-10-09 20:26 真发 4 条首评，日志逐条报
        //     「首评第 N 条：已确认是第 1 楼（floor_number=1）」，
        //     但用户到微博里核对，**实际只抢到 2 条、还有 1 条不是首评**。
        //
        //   ⇒ 说明「读回 floor_number == 1」与「实际是不是第 1 楼」**可能不等价**。
        //     最可疑的一点：核对读的是 `/comments/hotflow`（**热门**评论流），
        //     0 赞的新评论很可能**根本不在返回列表里** —— 那样程序看到的永远是
        //     「列表里只有我 + floor=1」，判据必然通过，无论别人是否已经评论过。
        //     ★ 旁证：4 次核对回包都只有 **2690~2693 字符**（一条评论的 JSON 约 2000+）
        //       ⇒ 列表里基本只有 1 条；而 `parseComments()` 从来**没读 `total_number`**
        //       ⇒ 程序从头到尾不知道那条帖子**总共**有几条评论。
        //
        //   改法（**只加只读诊断，不碰任何判据**）：
        //     ① `InteractProbe.kt` 新增 `logCommentScout(mid, body, ownUid)` —— 纯日志，
        //        打一行摘要（`total_number` / 返回条数 / 自己那条在第几位·楼层 / 有无下一页）
        //        + 最多 `SCOUT_LOG_LINES`（5）行明细（逐条 floor / uid·是否自己 / 赞数）。
        //     ② `listComments()` 加参数 `ownUid: String = ""`（**有默认值**）——
        //        `ownUid` 只喂给诊断，**不参与本函数任何返回**。
        //     ③ `SuperLikeRunner.kt` 的 `verifyFirst()` 传一次 `ownUid`（**1 行**）。
        //     ④ `parseComments()` 一行未动；`listComments()` / `verifyFirst()` 的
        //        **返回值与第 90 期逐字节相同**。
        //
        //   ★ 判据自检（硬规则二）：会让程序做出不同的决定吗？**不会** ——
        //     新增的只有 `InteractTrace.log()` 调用；程序的所有分支、返回值、请求数
        //     （诊断**不发任何请求**，复用已经拿到的回包）全部不变。
        //     ★ 影响面：`listComments()` 的 4 个调用点里只有 `SuperLikeRunner.kt:418`
        //       传了新参数；其余三处（`InteractRunner.kt:196` / `:407`、
        //       `InteractProbe.kt` 的楼赞自检）**源码级不变**（靠默认值）。
        //     ★ 诊断日志只在**传了 uid** 的调用点打明细，别的调用点只多 1 行摘要。
        //
        //   ★ 下一步（等真机数据回来再定）：若 `total_number > 1` 而返回列表里
        //     只有自己那条 ⇒ 判据要升级（例如要求 `total_number == 1`）。
        //     ★ 那属于「会让程序做出不同决定」的改动 ⇒ **必须先问用户**。
        //   备份：_backup_before_p91_comment_scout_20261009/（3 文件 + _p91_md5_before.txt）
        // ---------------------------------------------------------------------------

        // ===========================================================================
        // ★★★ 第 92 期（versionCode 151 / versionName 0.21.10）—— 互动页：重排顺序 + 超Like 默认展开
        //
        //   起因（用户 2026-10-09 21:04 提）：
        //     「把互动页面也简化一下，弄得清晰，更容易看懂，还有一键超like，为什么需要展开才能看见」
        //
        //   问题：互动页 7 块混排 —— 主力功能「超Like 一键编排」排在第 4 位、还要点一下才展开；
        //         「发送」本来是给互动任务用的，却隔着超Like；配置项（账号保护 / 频率 / 语料库）
        //         和日常操作混在一起。
        //
        //   改法（**只改 UI：顺序 / 折叠初始状态 / 注释；Kotlin 代码一行未动**）：
        //     ① 顺序重排为「日常 → 配置 → 排查」：
        //          超Like(展开) → 互动任务 → 发送 → 语料库 → 账号保护 → 频率设置 → 排查工具(收起)
        //     ② `interactSuperlikeWrap` 的 `android:visibility` 由 `gone` → `visible`（**默认展开**）；
        //        折叠标题文案由 `_title_closed` → `_title_open`（「点这里收起」）。
        //        ★ 折叠能力**保留** —— `toggleSuperlike()` 读的是**当前** visibility，天然兼容，
        //          所以**代码一行未改**（展开后仍能点标题收起）。
        //     ③ 三段分段注释按新布局重写（原来那句「第一部分…一共 5 张卡」已不成立）。
        //     ④ **排查工具仍默认收起** —— 它确实是排查用的，不该占首屏。
        //
        //   ★ 判据自检（硬规则二）：会让程序做出不同的决定吗？**不会** ——
        //     改的全是 `res/layout/activity_interact.xml` 里元素的**顺序**与 `visibility`
        //     初始值，外加注释；Kotlin 代码、判定逻辑、请求数一律未动。
        //     ★ **控件一个都没删**：改前 / 改后 `android:id` 集合**完全一致（51 个）**（脚本对账）。
        //     ★ 影响面：只有互动页的**观感**。
        //   备份：_backup_before_p92_interact_ui_20261009/（4 文件 + _p92_md5_before.txt）
        // ---------------------------------------------------------------------------
        versionCode = 151
        versionName = "0.21.10"

        // ★★★ 第 69 期：只保留 arm64-v8a。
        //
        //   为什么砍 armeabi-v7a（32 位）：
        //     · 这一版 APK（0.20.88）实测：armeabi-v7a 目录占 **13.94 MB**，
        //       其中 libopencv_java4.so 9.95MB + libc++_shared.so 3.98MB。
        //     · 本应用只装在自己的 arm64 手机上（vivo V2339A），
        //       且本项目为**侧载自用**、不分发 ⇒ 32 位用户为零。
        //     · 从 Android 10（API 29）起 64 位是硬要求，arm64 是绝对主流。
        //
        //   ⇒ 收益：APK 立减 13.94 MB（43.45 MB → 约 29.3 MB）。
        //
        //   ★ 风险与前提（写在代码里，避免以后误删这段注释后忘记）：
        //     砍掉后本包**无法安装在没有 arm64 的设备上**（会报
        //     INSTALL_FAILED_NO_MATCHING_ABIS）。若将来要给 32 位老机用，
        //     把 "armeabi-v7a" 加回这个 list 即可 —— 一行的事。
        //
        //   ★ 注意：这是**构建配置**，不改任何代码、不改任何判定。
        //     对 arm64 设备来说，装到的 .so 与砍之前**逐字节相同**。
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    // ★★ AGP 8.0 起 `buildConfig` 默认是 **关闭** 的：不显式打开，就不会生成 BuildConfig 类。
    //   首页那行「版本：0.19.x（构建号 NN）」用的正是 BuildConfig.VERSION_NAME / VERSION_CODE，
    //   少了这个开关，CI 会直接编译失败：
    //       e: MainActivity.kt:311:50 Unresolved reference: BuildConfig
    //   （v0.19.6 就是这样挂了。）
    //
    // ★★★ 2026-09-27 更正一条**过期结论**：
    //   上面原本写着「本机没有 JDK/Android SDK，静态检查查不出「类不存在」这类错误」——
    //   这句话**已经不成立**，别再照它做判断。
    //
    //   实测：本机确实能编译。JDK 藏在 Minecraft 自带的运行时里（完整的 OpenJDK 17，
    //   带 javac），Android SDK 在 %LOCALAPPDATA%\Android\Sdk，Gradle 缓存也是热的。
    //   可用的构建命令（Git Bash）：
    //
    //     cd <项目>/android
    //     export JAVA_HOME="C:/Users/TJH/AppData/Roaming/.minecraft/runtime/java-runtime-gamma-snapshot"
    //     ./gradlew assembleDebug
    //
    //   实测耗时约 1~2 分钟，产物 app/build/outputs/apk/debug/app-debug.apk（约 45 MB）。
    //
    //   ★ 因此「改完只跑静态检查就交付」这个习惯可以退休了：
    //     现在每一轮改完都应该真编一次 —— 静态检查查不出「类不存在 / 资源引用错」，
    //     而 AAPT2 + kotlinc 一次就能把它们全抓出来。
    buildFeatures {
        buildConfig = true
    }

    signingConfigs {
        if (hasFixedKeystore) {
            create("fixed") {
                storeFile = file(keystorePath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (hasFixedKeystore) {
                signingConfig = signingConfigs.getByName("fixed")
            }
        }
        debug {
            // debug 包也用同一把钥匙，这样 debug 包之间可以互相覆盖安装
            if (hasFixedKeystore) {
                signingConfig = signingConfigs.getByName("fixed")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // ★★★ 第 73 期 B：**已删除** OpenCV 依赖。
    //
    //   原为 `implementation("com.quickbirdstudios:opencv:4.5.3.0")`。
    //   删它是因为它带进来 `libopencv_java4.so`(16.39MB) + `libc++_shared.so`(5.95MB)
    //   = 原 APK 的 76%，且两个 .so 的 ELF PT_LOAD 对齐**均为 4096**
    //   ⇒ 16KB 页手机 `dlopen` 必失败。
    //
    //   回退：把上面那行加回来，并从 `_backup_before_b_remove_dep_20261006/`
    //   还原 `YidunSliderSolver.kt`（那份同时含 OpenCV 路径与两个开关）。
}
